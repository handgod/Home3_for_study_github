package com.softspb.weather.core;

import android.app.Activity;
import android.view.View;
import android.view.ViewParent;

public class Util
{
  public static Activity lookForActivity(View paramView)
  {
    Object localObject;
    if ((paramView.getContext() instanceof Activity))
    {
      localObject = (Activity)paramView.getContext();
      return localObject;
    }
    Activity localActivity = null;
    for (ViewParent localViewParent = paramView.getParent(); ; localViewParent = localViewParent.getParent())
    {
      if (localViewParent != null)
      {
        if (!(localViewParent instanceof View))
          continue;
        View localView = (View)localViewParent;
        if (!(localView.getContext() instanceof Activity))
          continue;
        localActivity = (Activity)localView.getContext();
      }
      localObject = localActivity;
      break;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.core.Util
 * JD-Core Version:    0.6.0
 */