package com.softspb.weather.core;

import android.database.ContentObserver;
import java.util.Iterator;
import java.util.List;

class WeatherDataCache$1
  implements Runnable
{
  public void run()
  {
    Iterator localIterator = this.val$list.iterator();
    while (localIterator.hasNext())
      ((ContentObserver)localIterator.next()).onChange(0);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.core.WeatherDataCache.1
 * JD-Core Version:    0.6.0
 */