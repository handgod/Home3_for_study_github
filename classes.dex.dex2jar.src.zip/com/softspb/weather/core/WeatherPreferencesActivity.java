package com.softspb.weather.core;

import android.os.Bundle;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;
import android.preference.PreferenceScreen;
import android.view.Window;
import com.softspb.util.IntListPreference;
import com.softspb.weather.model.WeatherParameter;

public class WeatherPreferencesActivity extends PreferenceActivity
{
  private static final WeatherParameter<?>[] CONFIGURABLE_WEATHER_PARAMETERS;
  private WeatherPreferencesHelper helper;

  static
  {
    WeatherParameter[] arrayOfWeatherParameter = new WeatherParameter[4];
    WeatherParameter localWeatherParameter1 = WeatherParameter.TEMPERATURE;
    arrayOfWeatherParameter[0] = localWeatherParameter1;
    WeatherParameter localWeatherParameter2 = WeatherParameter.PRESSURE;
    arrayOfWeatherParameter[1] = localWeatherParameter2;
    WeatherParameter localWeatherParameter3 = WeatherParameter.WIND_DIRECTION;
    arrayOfWeatherParameter[2] = localWeatherParameter3;
    WeatherParameter localWeatherParameter4 = WeatherParameter.WIND_SPEED;
    arrayOfWeatherParameter[3] = localWeatherParameter4;
    CONFIGURABLE_WEATHER_PARAMETERS = arrayOfWeatherParameter;
  }

  private Preference createLaunchModeWidgetPreference()
  {
    ListPreference localListPreference = new ListPreference(this);
    this.helper.initLaunchModeWidgetPreference(localListPreference);
    return localListPreference;
  }

  private Preference createUpdatePeriodPreference()
  {
    IntListPreference localIntListPreference = new IntListPreference(this);
    this.helper.initUpdatePeriodPreference(localIntListPreference);
    return localIntListPreference;
  }

  private Preference createWeatherParameterUnitsPreference(WeatherParameter<?> paramWeatherParameter)
  {
    ListPreference localListPreference = new ListPreference(this);
    this.helper.initWeatherParameterUnitsPreference(localListPreference, paramWeatherParameter);
    return localListPreference;
  }

  protected void onCreate(Bundle paramBundle)
  {
    boolean bool1 = getWindow().requestFeature(1);
    super.onCreate(paramBundle);
    WeatherPreferencesHelper localWeatherPreferencesHelper = new WeatherPreferencesHelper(this);
    this.helper = localWeatherPreferencesHelper;
    PreferenceManager localPreferenceManager = getPreferenceManager();
    localPreferenceManager.setSharedPreferencesName("weather");
    PreferenceScreen localPreferenceScreen = localPreferenceManager.createPreferenceScreen(this);
    Preference localPreference1 = createUpdatePeriodPreference();
    boolean bool2 = localPreferenceScreen.addPreference(localPreference1);
    Preference localPreference2 = createLaunchModeWidgetPreference();
    boolean bool3 = localPreferenceScreen.addPreference(localPreference2);
    WeatherParameter[] arrayOfWeatherParameter = CONFIGURABLE_WEATHER_PARAMETERS;
    int i = arrayOfWeatherParameter.length;
    int j = 0;
    while (j < i)
    {
      WeatherParameter localWeatherParameter = arrayOfWeatherParameter[j];
      Preference localPreference3 = createWeatherParameterUnitsPreference(localWeatherParameter);
      boolean bool4 = localPreferenceScreen.addPreference(localPreference3);
      j += 1;
    }
    setPreferenceScreen(localPreferenceScreen);
  }

  protected void onDestroy()
  {
    this.helper.dispose();
    super.onDestroy();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.core.WeatherPreferencesActivity
 * JD-Core Version:    0.6.0
 */