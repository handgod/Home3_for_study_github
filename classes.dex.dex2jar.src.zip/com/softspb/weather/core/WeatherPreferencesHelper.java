package com.softspb.weather.core;

import android.content.Context;
import android.content.res.Resources;
import android.preference.CheckBoxPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceChangeListener;
import android.preference.PreferenceActivity;
import com.softspb.updateservice.UpdateService;
import com.softspb.util.IIntListPreference;
import com.softspb.weather.model.WeatherParameter;

public class WeatherPreferencesHelper
  implements Preference.OnPreferenceChangeListener
{
  private final WeatherApplicationPreferences appPrefs;
  private final PreferenceActivity prefActivity;

  public WeatherPreferencesHelper(PreferenceActivity paramPreferenceActivity)
  {
    this.prefActivity = paramPreferenceActivity;
    WeatherApplicationPreferences localWeatherApplicationPreferences = new WeatherApplicationPreferences(paramPreferenceActivity);
    this.appPrefs = localWeatherApplicationPreferences;
  }

  public void dispose()
  {
    this.appPrefs.dispose();
  }

  public void initLaunchModeWidgetPreference(ListPreference paramListPreference)
  {
    int i = R.string.weather_config_launch_mode_widget_title;
    paramListPreference.setTitle(i);
    Resources localResources = this.prefActivity.getResources();
    int j = R.array.weather_launch_mode_choices;
    String[] arrayOfString = localResources.getStringArray(j);
    int k = this.appPrefs.getLaunchMode();
    String str1 = arrayOfString[k];
    paramListPreference.setSummary(str1);
    String str2 = Integer.toString(2);
    paramListPreference.setDefaultValue(str2);
    paramListPreference.setKey("weather-launch-mode-widget");
    int m = R.array.weather_launch_mode_choices;
    paramListPreference.setEntries(m);
    int n = R.array.weather_launch_mode_values;
    paramListPreference.setEntryValues(n);
    paramListPreference.setOnPreferenceChangeListener(this);
    paramListPreference.setEnabled(1);
  }

  public <T extends ListPreference,  extends IIntListPreference> void initUpdatePeriodPreference(T paramT)
  {
    PreferenceActivity localPreferenceActivity = this.prefActivity;
    int i = R.string.weather_config_update_period_title;
    paramT.setTitle(i);
    String str1 = Long.toString(this.appPrefs.getUpdateIntervalMs());
    int j = R.array.weather_update_period_values;
    paramT.setEntryValues(j);
    int k = paramT.findIndexOfValue(str1);
    Resources localResources = localPreferenceActivity.getResources();
    int m = R.array.weather_update_period_choices;
    String str2 = localResources.getStringArray(m)[k];
    paramT.setSummary(str2);
    String str3 = Long.toString(this.appPrefs.getDefaultUpdateInterval(localPreferenceActivity));
    paramT.setDefaultValue(str3);
    paramT.setKey("update-interval");
    int n = R.array.weather_update_period_choices;
    paramT.setEntries(n);
    paramT.setOnPreferenceChangeListener(this);
    paramT.setEnabled(1);
  }

  public void initWeatherParameterUnitsPreference(ListPreference paramListPreference, WeatherParameter<?> paramWeatherParameter)
  {
    int i = 1;
    PreferenceActivity localPreferenceActivity = this.prefActivity;
    String[] arrayOfString1 = paramWeatherParameter.getUnits(localPreferenceActivity);
    String[] arrayOfString2 = paramWeatherParameter.getUnitValues(localPreferenceActivity);
    String str1 = paramWeatherParameter.getUnitsTitle(localPreferenceActivity);
    paramListPreference.setTitle(str1);
    int k = this.appPrefs.getUnits(paramWeatherParameter);
    String str2 = arrayOfString1[k];
    paramListPreference.setSummary(str2);
    String str3 = paramWeatherParameter.getInitialUnits(localPreferenceActivity);
    paramListPreference.setDefaultValue(str3);
    String str4 = paramWeatherParameter.getName();
    paramListPreference.setKey(str4);
    paramListPreference.setEntries(arrayOfString1);
    paramListPreference.setEntryValues(arrayOfString2);
    paramListPreference.setOnPreferenceChangeListener(this);
    if (arrayOfString2.length > i);
    while (true)
    {
      paramListPreference.setEnabled(i);
      return;
      int j = 0;
    }
  }

  public void initWifiPreference(CheckBoxPreference paramCheckBoxPreference)
  {
    boolean bool = this.appPrefs.isUseOnlyWifi();
    paramCheckBoxPreference.setChecked(bool);
    int i = R.string.weather_use_only_wifi_title;
    paramCheckBoxPreference.setTitle(i);
    paramCheckBoxPreference.setSummaryOn(17039379);
    paramCheckBoxPreference.setSummaryOff(17039369);
    paramCheckBoxPreference.setOnPreferenceChangeListener(this);
    paramCheckBoxPreference.setEnabled(1);
  }

  public boolean onPreferenceChange(Preference paramPreference, Object paramObject)
  {
    if ((paramPreference instanceof ListPreference))
    {
      ListPreference localListPreference1 = (ListPreference)paramPreference;
      String str1 = (String)paramObject;
      int i = localListPreference1.findIndexOfValue(str1);
      CharSequence localCharSequence = localListPreference1.getEntries()[i];
      localListPreference1.setSummary(localCharSequence);
    }
    String str2 = paramPreference.getKey();
    if ("update-interval".equals(str2))
    {
      ListPreference localListPreference2 = (ListPreference)paramPreference;
      String str3 = (String)paramObject;
      localListPreference2.setValue(str3);
      long l = Long.valueOf((String)paramObject).longValue();
      this.appPrefs.setUpdateIntervalMs(l);
    }
    while (true)
    {
      return true;
      if ("use-only-wifi".equals(str2))
      {
        boolean bool = this.appPrefs.isUseOnlyWifi();
        UpdateService.setUseOnlyWifiPreference(this.prefActivity, bool);
        this.appPrefs.setUseOnlyWifi(bool);
        continue;
      }
      if (!(paramPreference instanceof ListPreference))
        continue;
      this.appPrefs.setValue(str2, paramObject);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.core.WeatherPreferencesHelper
 * JD-Core Version:    0.6.0
 */