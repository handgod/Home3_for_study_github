package com.softspb.weather.core;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.SystemClock;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.util.Arrays;
import java.util.List;

public class WeatherApplication
{
  public static final String ACTION_CHANGE_PREFERENCES = "com.softspb.toshiba.weather.action.ChangePrefs";
  public static final IntentFilter FILTER_CHANGE_PREFERENCES = ;
  public static final String PREFERENCE_CITY_ID = "city_id";
  private static final long REGULAR_UPDATES_DELAY_MS = 300000L;
  public static final int SKIN_DEFAULT = 2;
  public static final int SKIN_LARGE = 3;
  public static final int SKIN_MEDIUM = 2;
  public static final int SKIN_SIMPLE = 0;
  public static final int SKIN_SMALL_1 = 1;
  public static final int SKIN_SMALL_2 = 4;
  public static final int SKIN_XLARGE = 5;
  public static final String WEATHER_PREFERENCES = "weather_prefs";
  private static Logger logger;
  public static final IntentFilter weatherUpdateStatusIntentFilter = new IntentFilter("com.softspb.weather.updateservice.action.WeatherUpdateStatus");

  static
  {
    logger = Loggers.getLogger(WeatherApplication.class.getName());
  }

  public static void cancelWeatherUpdates(Context paramContext)
  {
    AlarmManager localAlarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    Intent localIntent1 = new Intent("com.softspb.weather.updateservice.action.UpdateForecast");
    PendingIntent localPendingIntent1 = PendingIntent.getService(paramContext, 0, localIntent1, 268435456);
    localAlarmManager.cancel(localPendingIntent1);
    Intent localIntent2 = new Intent("com.softspb.weather.updateservice.action.UpdateCurrent");
    PendingIntent localPendingIntent2 = PendingIntent.getService(paramContext, 0, localIntent2, 268435456);
    localAlarmManager.cancel(localPendingIntent2);
  }

  private static Intent createUpdateCurrentIntent(int[] paramArrayOfInt, Context paramContext)
  {
    Intent localIntent1 = new Intent("com.softspb.weather.updateservice.action.UpdateCurrent");
    String str = paramContext.getPackageName();
    Intent localIntent2 = localIntent1.setPackage(str);
    Intent localIntent3 = localIntent1.putExtra("update_ids", paramArrayOfInt);
    return localIntent1;
  }

  private static Intent createUpdateForecastIntent(int[] paramArrayOfInt, Context paramContext)
  {
    Intent localIntent1 = new Intent("com.softspb.weather.updateservice.action.UpdateForecast");
    String str = paramContext.getPackageName();
    Intent localIntent2 = localIntent1.setPackage(str);
    Intent localIntent3 = localIntent1.putExtra("update_ids", paramArrayOfInt);
    return localIntent1;
  }

  private static int[] intArrayOnlyPositive(List<Integer> paramList)
  {
    if (paramList == null);
    for (int i = 0; i == 0; i = paramList.size())
    {
      arrayOfInt = new int[0];
      return arrayOfInt;
    }
    int j = 0;
    int k = 0;
    while (k < i)
    {
      if (((Integer)paramList.get(k)).intValue() > 0)
        j += 1;
      k += 1;
    }
    int[] arrayOfInt = new int[j];
    k = 0;
    int m = 0;
    label77: int i1;
    if (k < i)
    {
      int n = ((Integer)paramList.get(k)).intValue();
      if (n <= 0)
        break label129;
      i1 = m + 1;
      arrayOfInt[m] = n;
    }
    while (true)
    {
      k += 1;
      m = i1;
      break label77;
      break;
      label129: i1 = m;
    }
  }

  private static void logTrace()
  {
    Exception localException = new Exception();
    Throwable localThrowable = localException.fillInStackTrace();
    StackTraceElement[] arrayOfStackTraceElement = localException.getStackTrace();
    int i = 1;
    while (true)
    {
      int j = arrayOfStackTraceElement.length;
      if (i >= j)
        break;
      StringBuilder localStringBuilder = new StringBuilder().append("|  ");
      StackTraceElement localStackTraceElement = arrayOfStackTraceElement[i];
      logd(localStackTraceElement);
      i += 1;
    }
  }

  private static void logd(String paramString)
  {
    logger.d(paramString);
  }

  public static void scheduleWeatherUpdates(long paramLong, List<Integer> paramList, Context paramContext)
  {
    StringBuilder localStringBuilder = new StringBuilder().append("scheduleWeatherUpdates: intervalAlarmMgr=").append(paramLong).append(" cityIds=");
    String str = Arrays.toString(paramList.toArray());
    logd(str);
    logTrace();
    int[] arrayOfInt = intArrayOnlyPositive(paramList);
    scheduleWeatherUpdates(paramLong, arrayOfInt, paramContext);
  }

  private static void scheduleWeatherUpdates(long paramLong, int[] paramArrayOfInt, Context paramContext)
  {
    AlarmManager localAlarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    Intent localIntent1 = createUpdateForecastIntent(paramArrayOfInt, paramContext);
    PendingIntent localPendingIntent1 = PendingIntent.getService(paramContext, 0, localIntent1, 268435456);
    long l1 = SystemClock.elapsedRealtime() + 300000L;
    long l2 = paramLong;
    localAlarmManager.setInexactRepeating(2, l1, l2, localPendingIntent1);
    Intent localIntent2 = createUpdateCurrentIntent(paramArrayOfInt, paramContext);
    PendingIntent localPendingIntent2 = PendingIntent.getService(paramContext, 0, localIntent2, 268435456);
    long l3 = SystemClock.elapsedRealtime() + 300000L;
    long l4 = paramLong;
    localAlarmManager.setInexactRepeating(2, l3, l4, localPendingIntent2);
  }

  public static void updateWeather(List<Integer> paramList, Context paramContext)
  {
    updateWeather(intArrayOnlyPositive(paramList), paramContext, 0);
  }

  public static void updateWeather(List<Integer> paramList, Context paramContext, boolean paramBoolean)
  {
    updateWeather(intArrayOnlyPositive(paramList), paramContext, paramBoolean);
  }

  private static void updateWeather(int[] paramArrayOfInt, Context paramContext, boolean paramBoolean)
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("updateWeather: cityIds=");
    String str1 = Arrays.toString(paramArrayOfInt);
    logd(str1);
    logTrace();
    Intent localIntent1 = createUpdateCurrentIntent(paramArrayOfInt, paramContext);
    Intent localIntent2 = localIntent1.putExtra("force_update", paramBoolean);
    StringBuilder localStringBuilder2 = new StringBuilder().append("Starting service: action=");
    String str2 = localIntent1.getAction();
    StringBuilder localStringBuilder3 = localStringBuilder2.append(str2).append(", update_ids=");
    String str3 = Arrays.toString(paramArrayOfInt);
    logd(str3);
    ComponentName localComponentName1 = paramContext.startService(localIntent1);
    Intent localIntent3 = createUpdateForecastIntent(paramArrayOfInt, paramContext);
    Intent localIntent4 = localIntent3.putExtra("force_update", paramBoolean);
    StringBuilder localStringBuilder4 = new StringBuilder().append("Starting service: action=");
    String str4 = localIntent3.getAction();
    StringBuilder localStringBuilder5 = localStringBuilder4.append(str4).append(", update_ids=");
    String str5 = Arrays.toString(paramArrayOfInt);
    logd(str5);
    ComponentName localComponentName2 = paramContext.startService(localIntent3);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.core.WeatherApplication
 * JD-Core Version:    0.6.0
 */