package com.softspb.weather.core;

import android.content.Context;
import android.content.SharedPreferences.Editor;
import com.softspb.util.CrossProcessusPreferences;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class WeatherWidgetPreferences extends CrossProcessusPreferences
  implements WeatherPreferences
{
  public static final String PREFERENCE_SKIN = "weather-skin";
  public static final int SKIN_NOT_SET = -2147483648;
  private static final String WIDGET_PREFS_NAME_PREFIX = "weather-widget-";
  private static final Logger logger = Loggers.getLogger(WeatherWidgetPreferences.class.getName());
  private String mSharedPrefsName;
  private WeatherApplicationPreferences sharedWeatherPrefs;
  private int widgetId;

  public WeatherWidgetPreferences(Context paramContext, int paramInt)
  {
    super(paramContext, str1, str2);
    String str3 = "weather-widget-" + paramInt;
    this.mSharedPrefsName = str3;
    this.widgetId = paramInt;
    WeatherApplicationPreferences localWeatherApplicationPreferences = new WeatherApplicationPreferences(paramContext);
    this.sharedWeatherPrefs = localWeatherApplicationPreferences;
    logd("WeatherWidgetPreferences constructor:");
    String str4 = "   widgetId=" + paramInt;
    logd(str4);
    StringBuilder localStringBuilder1 = new StringBuilder().append("   context=");
    String str5 = paramContext.getPackageName();
    String str6 = str5;
    logd(str6);
    StringBuilder localStringBuilder2 = new StringBuilder().append("   ClassLoader=");
    ClassLoader localClassLoader = getClass().getClassLoader();
    String str7 = localClassLoader;
    logd(str7);
    String str8 = "   this=" + this;
    logd(str8);
    logPreferences();
  }

  public void dispose()
  {
    super.dispose();
    this.sharedWeatherPrefs.dispose();
  }

  public int getCurrentCityId()
  {
    return getInt("weather-current-city-id", -2147483648);
  }

  public int getCurrentLocationCityId()
  {
    return this.sharedWeatherPrefs.getCurrentLocationCityId();
  }

  public int getLastUsedScreen()
  {
    return getInt("weather-last-used-screen", -1);
  }

  public int getLaunchMode()
  {
    return this.sharedWeatherPrefs.getLaunchMode();
  }

  public String getSharedPreferencesName()
  {
    return this.mSharedPrefsName;
  }

  public int getSkin()
  {
    int i = getInt("weather-skin", -2147483648);
    String str = "getSkin: skin=" + i;
    logd(str);
    return i;
  }

  public int getWidgetId()
  {
    return this.widgetId;
  }

  protected void logPreferences()
  {
    logd("--- Available preferences: ---");
    Iterator localIterator = getAll().entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      StringBuilder localStringBuilder1 = new StringBuilder().append("    ");
      String str1 = (String)localEntry.getKey();
      StringBuilder localStringBuilder2 = localStringBuilder1.append(str1).append("=");
      Object localObject = localEntry.getValue();
      String str2 = localObject;
      logd(str2);
    }
    logd("---------- end ---------------");
  }

  protected void logd(String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder().append("(widgetId=");
    int i = this.widgetId;
    String str = i + ") " + paramString;
    logger.d(paramString);
  }

  public void setCurrentCityId(int paramInt)
  {
    String str1 = "setCurrentCityId: cityId=" + paramInt;
    logd(str1);
    boolean bool = edit().putInt("weather-current-city-id", paramInt).commit();
    StringBuilder localStringBuilder = new StringBuilder().append("Result: currentId=");
    int i = getCurrentCityId();
    String str2 = i;
    logd(str2);
  }

  public void setLastUsedScreen(int paramInt)
  {
    boolean bool = edit().putInt("weather-last-used-screen", paramInt).commit();
  }

  public void setSkin(int paramInt)
  {
    String str = "setSkin: skin=" + paramInt;
    logd(str);
    boolean bool = edit().putInt("weather-skin", paramInt).commit();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.core.WeatherWidgetPreferences
 * JD-Core Version:    0.6.0
 */