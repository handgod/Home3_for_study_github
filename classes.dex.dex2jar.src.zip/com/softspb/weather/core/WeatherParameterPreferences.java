package com.softspb.weather.core;

import com.softspb.weather.model.WeatherParameter;

public abstract interface WeatherParameterPreferences
{
  public abstract int getUnits(WeatherParameter<?> paramWeatherParameter);
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.core.WeatherParameterPreferences
 * JD-Core Version:    0.6.0
 */