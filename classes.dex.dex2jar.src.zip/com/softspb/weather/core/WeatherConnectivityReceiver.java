package com.softspb.weather.core;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.NetworkInfo;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.util.Iterator;
import java.util.List;

public class WeatherConnectivityReceiver extends BroadcastReceiver
{
  private static final Logger logger = Loggers.getLogger(WeatherConnectivityReceiver.class);

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    logger.d("ConnectivityChangeReceiver.onReceive");
    WeatherApplicationPreferences localWeatherApplicationPreferences = new WeatherApplicationPreferences(paramContext);
    List localList1 = localWeatherApplicationPreferences.getAllCityIds();
    WeatherDataCache localWeatherDataCache = WeatherDataCache.getInstance(paramContext);
    List localList2 = localWeatherDataCache.resolveCurrentLocationCityIds(localList1);
    try
    {
      NetworkInfo localNetworkInfo = (NetworkInfo)paramIntent.getParcelableExtra("networkInfo");
      if (localNetworkInfo.isAvailable())
      {
        if ((localNetworkInfo.getType() != 1) || (!localWeatherApplicationPreferences.isUseOnlyWifi()))
          break label94;
        logger.d("connected to Wi-Fi network, doing update");
        WeatherApplication.updateWeather(localWeatherApplicationPreferences.getAllCityIds(), paramContext);
      }
      while (true)
      {
        return;
        label94: Logger localLogger = logger;
        String str = "Consider updating cities: " + localList2;
        localLogger.d(str);
        Iterator localIterator = localList2.iterator();
        while (localIterator.hasNext())
        {
          int i = ((Integer)localIterator.next()).intValue();
          localWeatherDataCache.considerWeatherUpdate(i);
        }
      }
    }
    finally
    {
      localWeatherApplicationPreferences.dispose();
    }
    throw localObject;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.core.WeatherConnectivityReceiver
 * JD-Core Version:    0.6.0
 */