package com.softspb.weather.core;

import java.util.Iterator;
import java.util.List;

class WeatherDataCache$2
  implements Runnable
{
  public void run()
  {
    WeatherDataCache.access$000("considerUpdateRunnable.run >>>");
    WeatherDataCache localWeatherDataCache = this.this$0;
    List localList = WeatherDataCache.access$100(this.this$0).getAllCityIds();
    Iterator localIterator = localWeatherDataCache.resolveCurrentLocationCityIds(localList).iterator();
    while (localIterator.hasNext())
    {
      int i = ((Integer)localIterator.next()).intValue();
      this.this$0.considerWeatherUpdate(i);
    }
    WeatherDataCache.access$000("considerUpdateRunnable.run <<<");
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.core.WeatherDataCache.2
 * JD-Core Version:    0.6.0
 */