package com.softspb.weather.core;

import java.util.List;

public class ScheduleInfo
{
  List<Integer> scheduledIds;
  long scheduledInterval;
  long scheduledTimestampToken;

  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("ScheduleInfo[timestamp=");
    long l1 = this.scheduledTimestampToken;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(l1).append(" ids=");
    List localList = this.scheduledIds;
    StringBuilder localStringBuilder3 = localStringBuilder2.append(localList);
    StringBuilder localStringBuilder4 = new StringBuilder().append(" interval=");
    long l2 = this.scheduledInterval;
    String str = l2;
    return str;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.core.ScheduleInfo
 * JD-Core Version:    0.6.0
 */