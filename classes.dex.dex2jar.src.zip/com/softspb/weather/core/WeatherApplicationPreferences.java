package com.softspb.weather.core;

import android.content.Context;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import com.softspb.updateservice.UpdatePreferences;
import com.softspb.util.CrossProcessusPreferences;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import com.softspb.weather.model.WeatherParameter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class WeatherApplicationPreferences extends CrossProcessusPreferences
  implements WeatherPreferences, WeatherParameterPreferences, UpdatePreferences
{
  private static final long DEFAULT_UPDATE_PERIOD = 7200000L;
  public static final String PREFERENCE_ALL_CITY_IDS = "weather-all-city-ids";
  public static final String PREFERENCE_LAUNCH_MODE_WIDGET = "weather-launch-mode-widget";
  public static final String PREFERENCE_LOCAL_CITY_ID = "weather-local-city-id";
  public static final String PREFERENCE_PREFERRED_WIDGET_ID = "weather-preferred-widget-id";
  public static final String PREFERENCE_SCHEDULED_CITY_IDS = "weather-scheduled-ids";
  public static final String PREFERENCE_SCHEDULED_INTERVAL = "weather-scheduled-interval";
  public static final String PREFERENCE_SCHEDULED_TIMESTAMP_TOKEN = "weather-scheduled-timestamp-token";
  public static final String WEATHER_PREFERENCES_NAME = "weather";
  public static final int WIDGET_ID_NOT_SET = -2147483648;
  private static final Logger logger = Loggers.getLogger(WeatherApplicationPreferences.class.getName());

  public WeatherApplicationPreferences(Context paramContext)
  {
    super(paramContext, str, "weather");
  }

  private ArrayList<Integer> loadCityIds()
  {
    String str = getString("weather-all-city-ids", "");
    return parseCommaSeparatedInts(str);
  }

  private static void logd(String paramString)
  {
    logger.d(paramString);
  }

  private ArrayList<Integer> parseCommaSeparatedInts(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    String[] arrayOfString = paramString.split(",");
    int i = arrayOfString.length;
    int j = 0;
    while (true)
    {
      String str;
      if (j < i)
        str = arrayOfString[j];
      try
      {
        Integer localInteger = Integer.valueOf(Integer.parseInt(str));
        boolean bool = localArrayList.add(localInteger);
        label53: j += 1;
        continue;
        return localArrayList;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        break label53;
      }
    }
  }

  private void saveCityIds(ArrayList<Integer> paramArrayList)
  {
    SharedPreferences.Editor localEditor = edit();
    String str = toCommaSeparatedLine(paramArrayList);
    boolean bool = localEditor.putString("weather-all-city-ids", str).commit();
  }

  private String toCommaSeparatedLine(List<Integer> paramList)
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      Integer localInteger = (Integer)localIterator.next();
      if (localStringBuilder1.length() > 0)
        StringBuilder localStringBuilder2 = localStringBuilder1.append(",");
      StringBuilder localStringBuilder3 = localStringBuilder1.append(localInteger);
    }
    return localStringBuilder1.toString();
  }

  public void addCityId(int paramInt)
  {
    logd("addCityId: cityId=" + paramInt);
    ArrayList localArrayList = loadCityIds();
    Integer localInteger1 = Integer.valueOf(paramInt);
    if (!localArrayList.contains(localInteger1))
    {
      Integer localInteger2 = Integer.valueOf(paramInt);
      boolean bool = localArrayList.add(localInteger2);
      saveCityIds(localArrayList);
    }
    StringBuilder localStringBuilder = new StringBuilder().append("Result: allIds=");
    String str = Arrays.toString(getAllCityIds().toArray());
    logd(str + ", currentId=" + paramInt);
  }

  public void addCityId(int paramInt1, int paramInt2)
  {
    logd("addCityId: cityId=" + paramInt1 + ", afterCityId=" + paramInt2);
    ArrayList localArrayList = loadCityIds();
    Integer localInteger1 = Integer.valueOf(paramInt1);
    if (!localArrayList.contains(localInteger1))
    {
      Integer localInteger2 = Integer.valueOf(paramInt2);
      int i = localArrayList.indexOf(localInteger2) + 1;
      Integer localInteger3 = Integer.valueOf(paramInt1);
      localArrayList.add(i, localInteger3);
      saveCityIds(localArrayList);
    }
  }

  public List<Integer> getAllCityIds()
  {
    return loadCityIds();
  }

  public int getCurrentCityId()
  {
    return getInt("weather-current-city-id", -2147483648);
  }

  public int getCurrentLocationCityId()
  {
    return getInt("weather-local-city-id", -2147483648);
  }

  public long getDefaultUpdateInterval(Context paramContext)
  {
    try
    {
      Resources localResources = paramContext.getResources();
      int i = R.integer.weather_default_update_period;
      int j = localResources.getInteger(i);
      l = j;
      return l;
    }
    catch (Exception localException)
    {
      while (true)
        long l = 7200000L;
    }
  }

  public int getLastUsedScreen()
  {
    return 1;
  }

  public int getLaunchMode()
  {
    String str = getString("weather-launch-mode-widget", null);
    if (str == null);
    for (int i = 2; ; i = Integer.parseInt(str))
      return i;
  }

  public int getPreferredWidgetId()
  {
    int i = getInt("weather-preferred-widget-id", -2147483648);
    logd("getPreferredWidgetId: returning " + i);
    return i;
  }

  public ScheduleInfo getScheduleInfo()
  {
    logd("getSchedultInfo");
    ScheduleInfo localScheduleInfo = null;
    String str = getString("weather-scheduled-ids", null);
    if (str != null)
    {
      localScheduleInfo = new ScheduleInfo();
      ArrayList localArrayList = parseCommaSeparatedInts(str);
      localScheduleInfo.scheduledIds = localArrayList;
      long l1 = getLong("weather-scheduled-interval", 0L);
      localScheduleInfo.scheduledInterval = l1;
      long l2 = getLong("weather-scheduled-timestamp-token", 0L);
      localScheduleInfo.scheduledTimestampToken = l2;
    }
    logd("getScheduleInfo: info=" + localScheduleInfo);
    return localScheduleInfo;
  }

  public int getUnits(WeatherParameter<?> paramWeatherParameter)
  {
    String str1 = paramWeatherParameter.getName();
    String str2 = getString(str1, null);
    if (str2 == null)
    {
      Context localContext = this.targetContext;
      str2 = paramWeatherParameter.getInitialUnits(localContext);
    }
    try
    {
      int i = Integer.parseInt(str2);
      j = i;
      return j;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      while (true)
        int j = paramWeatherParameter.getDefaultUnits();
    }
  }

  public long getUpdateIntervalMs()
  {
    logd("getUpdateIntervalMs >>>");
    long l = getLong("update-interval", 65535L);
    if (l == 65535L)
    {
      Context localContext = this.targetContext;
      l = getDefaultUpdateInterval(localContext);
    }
    logd("getUpdateIntervalMs <<< " + l);
    return l;
  }

  public boolean isUseOnlyWifi()
  {
    logd("isUseOnlyWifi >>>");
    boolean bool = getBoolean("use-only-wifi", 0);
    logd("isUseOnlyWifi <<< " + bool);
    return bool;
  }

  public void removeCityId(int paramInt)
  {
    logd("removeCityId: cityId=" + paramInt);
    ArrayList localArrayList = loadCityIds();
    Integer localInteger = Integer.valueOf(paramInt);
    int i = localArrayList.indexOf(localInteger);
    if (i != -1)
    {
      Object localObject = localArrayList.remove(i);
      saveCityIds(localArrayList);
    }
  }

  public void removeScheduleInfo()
  {
    SharedPreferences.Editor localEditor1 = edit();
    SharedPreferences.Editor localEditor2 = localEditor1.remove("weather-scheduled-ids");
    SharedPreferences.Editor localEditor3 = localEditor1.remove("weather-scheduled-interval");
    SharedPreferences.Editor localEditor4 = localEditor1.remove("weather-scheduled-timestamp-token");
    boolean bool = localEditor1.commit();
  }

  public void setCurrentCityId(int paramInt)
  {
    logd("setCurrentCityId: cityId=" + paramInt);
    boolean bool = edit().putInt("weather-current-city-id", paramInt).commit();
    StringBuilder localStringBuilder = new StringBuilder().append("Result: currentId=");
    int i = getCurrentCityId();
    logd(i);
  }

  public void setLastUsedScreen(int paramInt)
  {
  }

  public void setPreferredWidgetId(int paramInt)
  {
    logd("setPreferredWidgetId: widgetId=" + paramInt);
    boolean bool = edit().putInt("weather-preferred-widget-id", paramInt).commit();
  }

  public void setScheduleInfo(ScheduleInfo paramScheduleInfo)
  {
    logd("setScheduleInfo: " + paramScheduleInfo);
    SharedPreferences.Editor localEditor1 = edit();
    List localList = paramScheduleInfo.scheduledIds;
    String str = toCommaSeparatedLine(localList);
    SharedPreferences.Editor localEditor2 = localEditor1.putString("weather-scheduled-ids", str);
    long l1 = paramScheduleInfo.scheduledInterval;
    SharedPreferences.Editor localEditor3 = localEditor1.putLong("weather-scheduled-interval", l1);
    long l2 = paramScheduleInfo.scheduledTimestampToken;
    SharedPreferences.Editor localEditor4 = localEditor1.putLong("weather-scheduled-timestamp-token", l2);
    boolean bool = localEditor1.commit();
  }

  public void setUnits(WeatherParameter<?> paramWeatherParameter, int paramInt)
  {
    SharedPreferences.Editor localEditor1 = edit();
    String str = paramWeatherParameter.getName();
    SharedPreferences.Editor localEditor2 = localEditor1.putInt(str, paramInt);
    boolean bool = localEditor1.commit();
  }

  public void setUpdateIntervalMs(long paramLong)
  {
    logd("setUpdateIntervalMs: " + paramLong);
    boolean bool = edit().putLong("update-interval", paramLong).commit();
  }

  public void setUseOnlyWifi(boolean paramBoolean)
  {
    logd("setUseOnlyWifi: " + paramBoolean);
    boolean bool = edit().putBoolean("use-only-wifi", paramBoolean).commit();
  }

  public void setValue(String paramString, Object paramObject)
  {
    String str1 = getString(paramString, null);
    String str2 = paramObject.toString();
    if ((str2 != null) && (!str2.equals(str1)))
    {
      SharedPreferences.Editor localEditor = edit();
      String str3 = paramObject.toString();
      boolean bool = localEditor.putString(paramString, str3).commit();
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.core.WeatherApplicationPreferences
 * JD-Core Version:    0.6.0
 */