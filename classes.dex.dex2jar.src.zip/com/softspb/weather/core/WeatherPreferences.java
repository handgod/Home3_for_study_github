package com.softspb.weather.core;

public abstract interface WeatherPreferences
{
  public static final int LAUNCH_MODE_CURRENT = 1;
  public static final int LAUNCH_MODE_DEFAULT = 2;
  public static final int LAUNCH_MODE_FORECAST = 0;
  public static final int LAUNCH_MODE_LAST_USED = 2;
  public static final String PREFERENCE_CURRENT_CITY_ID = "weather-current-city-id";
  public static final String PREFERENCE_LAST_USED_SCREEN = "weather-last-used-screen";
  public static final int SCREEN_CURRENT = 2;
  public static final int SCREEN_FORECAST = 1;

  public abstract int getCurrentCityId();

  public abstract int getCurrentLocationCityId();

  public abstract int getLastUsedScreen();

  public abstract int getLaunchMode();

  public abstract void setCurrentCityId(int paramInt);

  public abstract void setLastUsedScreen(int paramInt);
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.core.WeatherPreferences
 * JD-Core Version:    0.6.0
 */