package com.softspb.weather.core;

class WeatherDataCache$3
  implements Runnable
{
  public void run()
  {
    WeatherDataCache.access$000("rescheduleUpdatesRunnable.run >>>");
    this.this$0.rescheduleWeatherUpdates();
    WeatherDataCache.access$000("rescheduleUpdatesRunnable.run <<<");
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.core.WeatherDataCache.3
 * JD-Core Version:    0.6.0
 */