package com.softspb.weather.core;

import android.app.Application;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.SparseArray;
import android.util.SparseIntArray;
import com.softspb.util.DecimalDateTimeEncoding;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import com.softspb.weather.model.CurrentConditions;
import com.softspb.weather.model.Forecast;
import com.softspb.weather.model.UpdateStatus;
import com.softspb.weather.provider.WeatherMetaData.CurrentMetaData;
import com.softspb.weather.provider.WeatherMetaData.DailyForecastMetaData;
import com.softspb.weather.provider.WeatherMetaData.ForecastMetaData;
import com.softspb.weather.provider.WeatherMetaData.TimeOfDayForecastMetaData;
import com.softspb.weather.provider.WeatherMetaData.UpdateStatusMetaData;
import com.spb.cities.provider.CitiesContract.Cities;
import com.spb.cities.service.CurrentLocationClient;
import com.spb.cities.service.CurrentLocationClient.CurrentLocationListener;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class WeatherDataCache
  implements CurrentLocationClient.CurrentLocationListener, SharedPreferences.OnSharedPreferenceChangeListener
{
  static final String ORDER_CURRENT_LATEST_FIRST = "date DESC,time DESC";
  private static final String ORDER_DATE_TIME = "date,time";
  private static int instanceCount = 0;
  private static Logger logger = Loggers.getLogger(WeatherDataCache.class.getName());
  private Application application;
  private final SparseIntArray cityIdsCount;
  private final SparseArray<CityInfo> cityNameCache;
  protected final Runnable considerUpdateRunnable;
  private ContentResolver contentResolver;
  private final SparseArray<CurrentConditions> currentCache;
  private CurrentLocationClient currentLocationClient;
  private final ArrayList<CurrentLocationClient.CurrentLocationListener> currentLocationListeners;
  private final SparseArray<Forecast[]> detailedForecastCache;
  private final SparseArray<Forecast[]> forecastCache;
  private boolean isUsingCurrentLocation;
  private int mCurrentLocationCityId;
  protected Handler mHandler;
  private HandlerThread mHandlerThread;
  protected final SparseArray<List<ContentObserver>> mObservers;
  private PositioningStatusObserver positioningStatusObserver;
  private final SparseArray<Forecast[]> rawForecastCache;
  protected final Runnable rescheduleUpdatesRunnable;
  private ScheduleInfo scheduleInfo;
  private String token;
  private final SparseArray<UpdateStatus> updateStatusCache;
  private final SparseArray<List<WeatherListener>> weatherListeners;
  private WeatherApplicationPreferences weatherPrefs;

  public WeatherDataCache(Application paramApplication, CurrentLocationClient paramCurrentLocationClient)
  {
    WeatherDataCache.2 local2 = new WeatherDataCache.2(this);
    this.considerUpdateRunnable = local2;
    WeatherDataCache.3 local3 = new WeatherDataCache.3(this);
    this.rescheduleUpdatesRunnable = local3;
    StringBuilder localStringBuilder1 = new StringBuilder();
    int i = getClass().getClassLoader().hashCode();
    StringBuilder localStringBuilder2 = localStringBuilder1.append(i).append(":");
    int j = instanceCount + 1;
    instanceCount = j;
    String str1 = j;
    this.token = str1;
    SparseIntArray localSparseIntArray = new SparseIntArray();
    this.cityIdsCount = localSparseIntArray;
    SparseArray localSparseArray1 = new SparseArray();
    this.mObservers = localSparseArray1;
    this.isUsingCurrentLocation = 0;
    SparseArray localSparseArray2 = new SparseArray();
    this.forecastCache = localSparseArray2;
    SparseArray localSparseArray3 = new SparseArray();
    this.rawForecastCache = localSparseArray3;
    SparseArray localSparseArray4 = new SparseArray();
    this.detailedForecastCache = localSparseArray4;
    SparseArray localSparseArray5 = new SparseArray();
    this.currentCache = localSparseArray5;
    SparseArray localSparseArray6 = new SparseArray();
    this.cityNameCache = localSparseArray6;
    SparseArray localSparseArray7 = new SparseArray();
    this.updateStatusCache = localSparseArray7;
    SparseArray localSparseArray8 = new SparseArray();
    this.weatherListeners = localSparseArray8;
    ArrayList localArrayList = new ArrayList();
    this.currentLocationListeners = localArrayList;
    this.mCurrentLocationCityId = -2147483648;
    logger.enableThreadLog();
    log("Ctor:");
    StringBuilder localStringBuilder3 = new StringBuilder().append("    context=");
    String str2 = paramApplication.getPackageName();
    String str3 = str2;
    log(str3);
    StringBuilder localStringBuilder4 = new StringBuilder().append("    classLoader=");
    ClassLoader localClassLoader = getClass().getClassLoader();
    String str4 = localClassLoader;
    log(str4);
    StringBuilder localStringBuilder5 = new StringBuilder().append("    thread=");
    String str5 = Thread.currentThread().getName();
    StringBuilder localStringBuilder6 = localStringBuilder5.append(str5).append(":");
    long l = Thread.currentThread().getId();
    String str6 = l;
    log(str6);
    this.application = paramApplication;
    ContentResolver localContentResolver = paramApplication.getContentResolver();
    this.contentResolver = localContentResolver;
    this.currentLocationClient = paramCurrentLocationClient;
    start();
  }

  private void addCityId(int paramInt)
  {
    logd("addCityId: " + paramInt);
    synchronized (this.cityIdsCount)
    {
      int i = this.cityIdsCount.get(paramInt, -2147483648);
      if (i == -2147483648)
        i = 0;
      int j = i + 1;
      this.cityIdsCount.put(paramInt, j);
      logd("GROUPER addCityId " + paramInt + ", count=" + j);
      if (j == 1)
      {
        if (paramInt != 64512)
        {
          startObserving(paramInt);
          considerWeatherUpdate(paramInt);
          rescheduleWeatherUpdates();
        }
      }
      else
        return;
      startObservingCurrentLocation();
    }
  }

  private CityInfo getCityInfo(int paramInt)
  {
    CityInfo localCityInfo;
    if (paramInt == 64512)
      if (this.mCurrentLocationCityId > 0)
      {
        int i = this.mCurrentLocationCityId;
        localCityInfo = getCityInfo(i);
      }
    while (true)
    {
      return localCityInfo;
      localCityInfo = null;
      continue;
      localCityInfo = (CityInfo)this.cityNameCache.get(paramInt);
      if (localCityInfo != null)
      {
        log("    returning data from cache...");
        continue;
      }
      log("    no cached data available, querying...");
      Uri localUri1 = CitiesContract.Cities.getContentUri(this.application);
      long l = paramInt;
      Uri localUri2 = ContentUris.withAppendedId(localUri1, l);
      String str = "    uri=" + localUri2;
      log(str);
      localCityInfo = queryCity(localUri2);
      if (localCityInfo != null)
      {
        log("    data obtained, updating cache...");
        this.cityNameCache.put(paramInt, localCityInfo);
        continue;
      }
      log("    data not avaible, returning null");
    }
  }

  private UpdateStatus getDirectUpdateStatus(int paramInt)
  {
    UpdateStatus localUpdateStatus = (UpdateStatus)this.updateStatusCache.get(paramInt);
    if (localUpdateStatus == null)
    {
      Uri localUri1 = WeatherMetaData.UpdateStatusMetaData.getContentUri(this.application);
      long l = paramInt;
      Uri localUri2 = ContentUris.withAppendedId(localUri1, l);
      localUpdateStatus = queryUpdateStatus(paramInt, localUri2);
      if (localUpdateStatus != null)
        this.updateStatusCache.put(paramInt, localUpdateStatus);
    }
    return localUpdateStatus;
  }

  public static WeatherDataCache getInstance(Context paramContext)
  {
    Context localContext = paramContext.getApplicationContext();
    if (!(localContext instanceof Application))
    {
      String str = "Application context is not an Application instance: " + localContext;
      throw new IllegalArgumentException(str);
    }
    Application localApplication = (Application)localContext;
    Class localClass = localApplication.getClass();
    try
    {
      Class[] arrayOfClass = new Class[0];
      Method localMethod = localClass.getMethod("getWeatherDataCache", arrayOfClass);
      Object[] arrayOfObject = new Object[0];
      WeatherDataCache localWeatherDataCache = (WeatherDataCache)localMethod.invoke(localApplication, arrayOfObject);
      return localWeatherDataCache;
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      throw new IllegalArgumentException("Application class must define getWeatherDataCache() method", localNoSuchMethodException);
    }
    catch (Exception localException)
    {
    }
    throw new IllegalArgumentException("Failed to invoke getWeatherDataCache() method", localException);
  }

  private void log(String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder().append(91);
    String str = this.token;
    logd(str + "] " + paramString);
  }

  private static void logd(String paramString)
  {
    logger.d(paramString);
  }

  private void onUpdateRateChanged()
  {
    logd("onUpdateRateChanged");
    if (this.mHandler != null)
    {
      Handler localHandler1 = this.mHandler;
      Runnable localRunnable1 = this.considerUpdateRunnable;
      localHandler1.removeCallbacks(localRunnable1);
      Handler localHandler2 = this.mHandler;
      Runnable localRunnable2 = this.considerUpdateRunnable;
      boolean bool1 = localHandler2.post(localRunnable2);
      Handler localHandler3 = this.mHandler;
      Runnable localRunnable3 = this.rescheduleUpdatesRunnable;
      localHandler3.removeCallbacks(localRunnable3);
      Handler localHandler4 = this.mHandler;
      Runnable localRunnable4 = this.rescheduleUpdatesRunnable;
      boolean bool2 = localHandler4.post(localRunnable4);
    }
  }

  private void reload(int paramInt)
  {
    logd("reload: cityId=" + paramInt);
    List localList = (List)this.mObservers.get(paramInt);
    if (localList != null)
    {
      Handler localHandler = this.mHandler;
      WeatherDataCache.1 local1 = new WeatherDataCache.1(this, localList);
      boolean bool = localHandler.post(local1);
    }
  }

  private void removeCityId(int paramInt)
  {
    String str = "removeCityId: cityId=" + paramInt;
    log(str);
    while (true)
    {
      int i;
      synchronized (this.cityIdsCount)
      {
        i = this.cityIdsCount.get(paramInt, -2147483648);
        if (i == -2147483648)
          continue;
        i += -1;
        logd("GROUPER removeCityId " + paramInt + ", count=" + i);
        if (i <= 0)
        {
          if (paramInt == 64512)
            continue;
          stopObserving(paramInt);
          rescheduleWeatherUpdates();
          this.cityIdsCount.delete(paramInt);
          return;
          stopObservingCurrentLocation();
        }
      }
      this.cityIdsCount.put(paramInt, i);
    }
  }

  private Forecast[] selectForecast(Forecast[] paramArrayOfForecast, int paramInt)
  {
    int i = 0;
    if (paramArrayOfForecast == null);
    for (int j = 0; ; j = paramArrayOfForecast.length)
    {
      k = 0;
      while (k < j)
      {
        if (paramArrayOfForecast[k].getDateLocal() == paramInt)
          i += 1;
        k += 1;
      }
    }
    if (i == 0)
    {
      arrayOfForecast = null;
      return arrayOfForecast;
    }
    Forecast[] arrayOfForecast = new Forecast[i];
    int k = 0;
    int m = 0;
    label72: int n;
    if (k < j)
    {
      if (paramArrayOfForecast[k].getDateLocal() != paramInt)
        break label122;
      n = m + 1;
      Forecast localForecast = paramArrayOfForecast[k];
      arrayOfForecast[m] = localForecast;
    }
    while (true)
    {
      k += 1;
      m = n;
      break label72;
      break;
      label122: n = m;
    }
  }

  protected void considerWeatherUpdate(int paramInt)
  {
    logd("considerWeatherUpdate: cityId=" + paramInt);
    if ((paramInt == -2147483648) || (paramInt == 64512))
    {
      Logger localLogger = logger;
      String str = "considerWeatherUpdated: invalid cityId=" + paramInt;
      localLogger.w(str);
      return;
    }
    int i = 0;
    UpdateStatus localUpdateStatus = getUpdateStatus(paramInt);
    if (localUpdateStatus == null)
    {
      logd("considerWeatherUpdate: no update status for cityId=" + paramInt);
      i = 1;
    }
    while (true)
    {
      logd("considerWeatherUpdate: need update: " + i);
      if (i == 0)
        break;
      List localList = Collections.singletonList(Integer.valueOf(paramInt));
      Application localApplication = this.application;
      WeatherApplication.updateWeather(localList, localApplication);
      break;
      long l1 = System.currentTimeMillis();
      long l2 = this.weatherPrefs.getUpdateIntervalMs();
      StringBuilder localStringBuilder1 = new StringBuilder().append("considerWeatherUpdate: latestSuccessfulCurrentConditionsTimestamp=");
      long l3 = localUpdateStatus.latestSuccessfulCurrentConditionsTimestamp;
      logd(l3);
      StringBuilder localStringBuilder2 = new StringBuilder().append("considerWeatherUpdate: latestSuccessfulForecastTimestamp=");
      long l4 = localUpdateStatus.latestSuccessfulForecastTimestamp;
      logd(l4);
      long l5 = localUpdateStatus.latestSuccessfulCurrentConditionsTimestamp;
      long l6 = localUpdateStatus.latestSuccessfulForecastTimestamp;
      long l7 = Math.min(l5, l6);
      long l8 = l1 - l7;
      logd("considerWeatherUpdate: currentMillis=" + l1);
      logd("considerWeatherUpdate: lastUpdated=" + l7);
      logd("considerWeatherUpdate: updateInterval=" + l2);
      logd("considerWeatherUpdate: updateDelay=" + l1);
      StringBuilder localStringBuilder3 = new StringBuilder().append("considerWeatherUpdate: update ");
      long l9 = l8 / 60000L;
      StringBuilder localStringBuilder4 = localStringBuilder3.append(l9).append(" min ago, update interval ");
      long l10 = l2 / 60000L;
      logd(l10 + " min");
      if (l8 < l2)
        continue;
      int j = 1;
    }
  }

  protected String createCurrentLocationCityName(String paramString)
  {
    try
    {
      Application localApplication = this.application;
      int i = R.string.weather_format_current_location;
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = paramString;
      str1 = localApplication.getString(i, arrayOfObject);
      StringBuilder localStringBuilder1 = new StringBuilder().append("Loaded resource id=0x");
      String str2 = Integer.toHexString(R.string.weather_format_current_location);
      logd(str2);
      StringBuilder localStringBuilder2;
      String str3;
      StringBuilder localStringBuilder3;
      ClassLoader localClassLoader1;
      return str1;
    }
    catch (Exception localException)
    {
      while (true)
      {
        Logger localLogger = logger;
        StringBuilder localStringBuilder4 = new StringBuilder().append("Error loading resource id=0x");
        String str4 = Integer.toHexString(R.string.weather_format_current_location);
        String str5 = str4;
        localLogger.e(str5);
        StringBuilder localStringBuilder5 = new StringBuilder().append("    mContext=");
        String str6 = this.application.getPackageName();
        logd(str6);
        StringBuilder localStringBuilder6 = new StringBuilder().append("    classLoader=");
        ClassLoader localClassLoader2 = getClass().getClassLoader();
        logd(localClassLoader2);
        String str1 = paramString;
      }
    }
    finally
    {
      StringBuilder localStringBuilder7 = new StringBuilder().append("    mContext=");
      String str7 = this.application.getPackageName();
      logd(str7);
      StringBuilder localStringBuilder8 = new StringBuilder().append("    classLoader=");
      ClassLoader localClassLoader3 = getClass().getClassLoader();
      logd(localClassLoader3);
    }
    throw localObject;
  }

  public String getCityName(int paramInt)
  {
    String str1 = "getCityName: cityId=" + paramInt;
    log(str1);
    CityInfo localCityInfo = getCityInfo(paramInt);
    String str2;
    if (localCityInfo == null)
      str2 = null;
    while (true)
    {
      return str2;
      if (paramInt == 64512)
      {
        String str3 = localCityInfo.cityName;
        str2 = createCurrentLocationCityName(str3);
        continue;
      }
      str2 = localCityInfo.cityName;
    }
  }

  public CurrentConditions getCurrent(int paramInt)
  {
    String str1 = "getCurrent: cityId=" + paramInt;
    log(str1);
    CurrentConditions localCurrentConditions;
    if (paramInt == 64512)
      if (this.mCurrentLocationCityId > 0)
      {
        int i = this.mCurrentLocationCityId;
        localCurrentConditions = getCurrent(i);
      }
    while (true)
    {
      return localCurrentConditions;
      localCurrentConditions = null;
      continue;
      localCurrentConditions = (CurrentConditions)this.currentCache.get(paramInt);
      if (localCurrentConditions != null)
      {
        log("    returning data from cache");
        continue;
      }
      log("    no cached data available, querrying...");
      Uri localUri1 = WeatherMetaData.CurrentMetaData.getContentUri(this.application);
      long l = paramInt;
      Uri localUri2 = ContentUris.withAppendedId(localUri1, l);
      String str2 = "    uri=" + localUri2;
      log(str2);
      localCurrentConditions = queryCurrent(localUri2);
      if (localCurrentConditions != null)
      {
        log("    obtained data, updating cache...");
        this.currentCache.put(paramInt, localCurrentConditions);
        continue;
      }
      log("    no data available, returning null");
    }
  }

  public int getCurrentLocationCityId()
  {
    return this.mCurrentLocationCityId;
  }

  public Forecast[] getDetailedForecast(int paramInt1, int paramInt2)
  {
    Forecast[] arrayOfForecast1 = null;
    String str1 = "getDetailedForecast: cityId=" + paramInt1;
    log(str1);
    if (paramInt1 == 64512)
      if (this.mCurrentLocationCityId > 0)
      {
        int i = this.mCurrentLocationCityId;
        arrayOfForecast1 = getDetailedForecast(i, paramInt2);
      }
    while (true)
    {
      return arrayOfForecast1;
      Forecast[] arrayOfForecast2 = (Forecast[])this.detailedForecastCache.get(paramInt1);
      if (arrayOfForecast2 == null)
      {
        log("    no cached data available, querrying...");
        Uri localUri1 = WeatherMetaData.TimeOfDayForecastMetaData.getContentUri(this.application);
        long l = paramInt1;
        Uri localUri2 = ContentUris.withAppendedId(localUri1, l);
        String str2 = "    uri=" + localUri2;
        log(str2);
        arrayOfForecast2 = queryDetailedForecast(localUri2);
        if (arrayOfForecast2 != null)
        {
          log("    data obtained, updating cache...");
          this.detailedForecastCache.put(paramInt1, arrayOfForecast2);
        }
      }
      while (true)
      {
        if (arrayOfForecast2 == null)
          break label192;
        arrayOfForecast1 = selectForecast(arrayOfForecast2, paramInt2);
        break;
        log("    using data from cache");
      }
      label192: log("    no data available, returning null");
    }
  }

  public Forecast[] getForecast(int paramInt)
  {
    String str1 = "getForecast: cityId=" + paramInt;
    log(str1);
    Forecast[] arrayOfForecast;
    if (paramInt == 64512)
      if (this.mCurrentLocationCityId > 0)
      {
        int i = this.mCurrentLocationCityId;
        arrayOfForecast = getForecast(i);
      }
    while (true)
    {
      return arrayOfForecast;
      arrayOfForecast = null;
      continue;
      arrayOfForecast = (Forecast[])this.forecastCache.get(paramInt);
      if (arrayOfForecast != null)
      {
        log("getForecast:    returning data from cache...");
        continue;
      }
      log("getForecast:    no cached data available, querrying...");
      Uri localUri1 = WeatherMetaData.DailyForecastMetaData.getContentUri(this.application);
      long l = paramInt;
      Uri localUri2 = ContentUris.withAppendedId(localUri1, l);
      String str2 = "getForecast:    uri=" + localUri2;
      log(str2);
      arrayOfForecast = queryForecast(localUri2);
      if (arrayOfForecast != null)
      {
        log("getForecast:    data obtained, updating cache... ");
        this.forecastCache.put(paramInt, arrayOfForecast);
        continue;
      }
      log("getForecast:    data not avaible, returning null");
    }
  }

  public Forecast[] getRawForecast(int paramInt)
  {
    String str1 = "getRawForecast: cityId=" + paramInt;
    log(str1);
    Forecast[] arrayOfForecast;
    if (paramInt == 64512)
      if (this.mCurrentLocationCityId > 0)
      {
        int i = this.mCurrentLocationCityId;
        arrayOfForecast = getRawForecast(i);
      }
    while (true)
    {
      return arrayOfForecast;
      arrayOfForecast = null;
      continue;
      arrayOfForecast = (Forecast[])this.rawForecastCache.get(paramInt);
      if (arrayOfForecast != null)
      {
        log("    returning data from cache...");
        continue;
      }
      log("    no cached data available, querying...");
      int j = DecimalDateTimeEncoding.getTodayDateEncoded();
      Uri localUri = WeatherMetaData.ForecastMetaData.getCityDateUri(this.application, paramInt, j);
      String str2 = "    uri=" + localUri;
      log(str2);
      arrayOfForecast = queryRawForecast(localUri);
      if (arrayOfForecast != null)
      {
        log("    data obtained, updating cache... ");
        this.rawForecastCache.put(paramInt, arrayOfForecast);
        continue;
      }
      log("    data not avaible, returning null");
    }
  }

  public UpdateStatus getUpdateStatus(int paramInt)
  {
    String str1 = "getUpdateStatus >>> cityId=" + paramInt;
    log(str1);
    UpdateStatus localUpdateStatus2;
    if (paramInt == 64512)
      if (this.mCurrentLocationCityId > 0)
      {
        int i = this.mCurrentLocationCityId;
        UpdateStatus localUpdateStatus1 = getUpdateStatus(i);
        if (localUpdateStatus1 != null)
          localUpdateStatus2 = new UpdateStatus(localUpdateStatus1, paramInt);
      }
    while (true)
    {
      return localUpdateStatus2;
      localUpdateStatus2 = null;
      continue;
      localUpdateStatus2 = getDirectUpdateStatus(paramInt);
      String str2 = "getUpdateStatus <<< cityId=" + paramInt + " updateStatus=" + localUpdateStatus2;
      log(str2);
    }
  }

  public int getUtcOffsetMin(int paramInt)
  {
    String str = "getUtcOffsetMin: cityId=" + paramInt;
    log(str);
    CityInfo localCityInfo = getCityInfo(paramInt);
    if (localCityInfo == null);
    for (int i = 0; ; i = localCityInfo.utcOffset)
      return i;
  }

  public boolean isRunning()
  {
    if ((this.mHandlerThread != null) && (this.mHandlerThread.isAlive()));
    for (int i = 1; ; i = 0)
      return i;
  }

  void notifyCityNameUpdated(int paramInt, String paramString)
  {
    String str1 = "notifyCityNameUpdated >>> cityId=" + paramInt + " cityName=" + paramString;
    log(str1);
    logd("notifyCityNameUpdated: obtaining weather_lock...");
    synchronized (this.weatherListeners)
    {
      logd("notifyCityNameUpdated: obtained weather_lock...");
      List localList = (List)this.weatherListeners.get(paramInt);
      if (localList != null)
      {
        Iterator localIterator = localList.iterator();
        if (localIterator.hasNext())
        {
          WeatherListener localWeatherListener = (WeatherListener)localIterator.next();
          String str2 = "notifyCityNameUpdated: notifying Weather listener: " + localWeatherListener;
          log(str2);
          localWeatherListener.onCityNameUpdated(paramInt, paramString);
        }
      }
    }
    monitorexit;
    logd("notifyCityNameUpdated: released weather_lock...");
    int i = this.mCurrentLocationCityId;
    if (paramInt == i)
    {
      log("notifyCityNameUpdated: also notifying current location listeners");
      String str3 = createCurrentLocationCityName(paramString);
      notifyCityNameUpdated(64512, str3);
    }
    String str4 = "notifyCityNameUpdated <<< cityId=" + paramInt + " cityName=" + paramString;
    log(str4);
  }

  void notifyCurrentLocationCityIdUpdated(int paramInt)
  {
    String str1 = "notifyCurrentLocationCityIdUpdated >>> cityId=" + paramInt;
    log(str1);
    synchronized (this.currentLocationListeners)
    {
      Iterator localIterator = this.currentLocationListeners.iterator();
      if (localIterator.hasNext())
        ((SharedPreferences.OnSharedPreferenceChangeListener)localIterator.next()).onCurrenLocationCityIdUpdated(paramInt);
    }
    monitorexit;
    String str2 = "notifyCurrentLocationCityIdUpdated >>> cityId=" + paramInt;
    log(str2);
  }

  void notifyCurrentUpdated(int paramInt, CurrentConditions paramCurrentConditions)
  {
    String str1 = "notifyCurrentUpdated >>> cityId=" + paramInt;
    log(str1);
    logd("notifyCurrentUpdated: obtaining weather_lock...");
    synchronized (this.weatherListeners)
    {
      logd("notifyCurrentUpdated: obtained weather_lock");
      List localList = (List)this.weatherListeners.get(paramInt);
      if (localList != null)
      {
        Iterator localIterator = localList.iterator();
        if (localIterator.hasNext())
        {
          WeatherListener localWeatherListener = (WeatherListener)localIterator.next();
          String str2 = "notifyCurrentUpdated: notifying Weather listener: " + localWeatherListener;
          log(str2);
          localWeatherListener.onCurrentUpdated(paramInt, paramCurrentConditions);
        }
      }
    }
    monitorexit;
    logd("notifyCurrentUpdated: released weather_lock");
    int i = this.mCurrentLocationCityId;
    if (paramInt == i)
    {
      log("notifyCurrentUpdated: also notifying current location listeners");
      notifyCurrentUpdated(64512, paramCurrentConditions);
    }
    String str3 = "notifyCurrentUpdated <<< cityId=" + paramInt;
    log(str3);
  }

  void notifyDetailedForecastUpdated(int paramInt, Forecast[] paramArrayOfForecast)
  {
    String str1 = "notifyDetailedForecastUpdated >>> cityId=" + paramInt;
    log(str1);
    logd("notifyDetailedForecastUpdated: obtaining weather_lock...");
    synchronized (this.weatherListeners)
    {
      logd("notifyDetailedForecastUpdated: obtained weather_lock");
      List localList = (List)this.weatherListeners.get(paramInt);
      if (localList != null)
      {
        Iterator localIterator = localList.iterator();
        if (localIterator.hasNext())
        {
          WeatherListener localWeatherListener = (WeatherListener)localIterator.next();
          int i = localWeatherListener.getDetailedForecastDate();
          Forecast[] arrayOfForecast = selectForecast(paramArrayOfForecast, i);
          String str2 = "notifyDetailedForecastUpdated: notifying Weather listener: " + localWeatherListener;
          log(str2);
          localWeatherListener.onDetailedForecastUpdated(paramInt, arrayOfForecast);
        }
      }
    }
    monitorexit;
    logd("notifyDetailedForecastUpdated: released weather_lock");
    int j = this.mCurrentLocationCityId;
    if (paramInt == j)
    {
      log("notifyDetailedForecastUpdated: also notifying current location listeners");
      notifyDetailedForecastUpdated(64512, paramArrayOfForecast);
    }
    String str3 = "notifyDetailedForecastUpdated <<< cityId=" + paramInt;
    log(str3);
  }

  void notifyForecastUpdated(int paramInt, Forecast[] paramArrayOfForecast)
  {
    String str1 = "notifyForecastUpdated >>> cityId=" + paramInt;
    log(str1);
    logd("notifyForecastUpdated: obtaining weather_lock...");
    synchronized (this.weatherListeners)
    {
      logd("notifyForecastUpdated: obtained weather_lock...");
      List localList = (List)this.weatherListeners.get(paramInt);
      if (localList != null)
      {
        Iterator localIterator = localList.iterator();
        if (localIterator.hasNext())
        {
          WeatherListener localWeatherListener = (WeatherListener)localIterator.next();
          String str2 = "notifyForecastUpdated: notifying Weather listener: " + localWeatherListener;
          log(str2);
          localWeatherListener.onForecastUpdated(paramInt, paramArrayOfForecast);
        }
      }
    }
    monitorexit;
    logd("notifyForecastUpdated: released weather_lock...");
    int i = this.mCurrentLocationCityId;
    if (paramInt == i)
    {
      log("notifyForecastUpdated: also notifying current location listeners");
      notifyForecastUpdated(64512, paramArrayOfForecast);
    }
    String str3 = "notifyForecastUpdated <<< cityId=" + paramInt;
    log(str3);
  }

  void notifyNA(int paramInt)
  {
    notifyCurrentUpdated(paramInt, null);
    notifyForecastUpdated(paramInt, null);
    notifyDetailedForecastUpdated(paramInt, null);
    notifyUpdateStatus(paramInt, null);
    notifyRawForecastUpdated(paramInt, null);
    notifyCityNameUpdated(paramInt, null);
  }

  void notifyRawForecastUpdated(int paramInt, Forecast[] paramArrayOfForecast)
  {
    String str1 = "notifyRawForecastUpdated >>> cityId=" + paramInt;
    log(str1);
    logd("notifyRawForecastUpdated: obtaining weather_lock...");
    synchronized (this.weatherListeners)
    {
      logd("notifyRawForecastUpdated: obtained weather_lock");
      List localList = (List)this.weatherListeners.get(paramInt);
      if (localList != null)
      {
        Iterator localIterator = localList.iterator();
        if (localIterator.hasNext())
        {
          WeatherListener localWeatherListener = (WeatherListener)localIterator.next();
          String str2 = "notifyRawForecastUpdated: notifying Weather listener: " + localWeatherListener;
          log(str2);
          localWeatherListener.onRawForecastUpdated(paramInt, paramArrayOfForecast);
        }
      }
    }
    monitorexit;
    logd("notifyRawForecastUpdated: released weather_lock");
    int i = this.mCurrentLocationCityId;
    if (paramInt == i)
    {
      log("notifyRawForecastUpdated: also notifying current location listeners");
      notifyRawForecastUpdated(64512, paramArrayOfForecast);
    }
    String str3 = "notifyRawForecastUpdated <<< cityId=" + paramInt;
    log(str3);
  }

  void notifyUpdateStatus(int paramInt, UpdateStatus paramUpdateStatus)
  {
    String str1 = "notifyUpdateStatus >>> cityId=" + paramInt + " updateStatus=" + paramUpdateStatus;
    log(str1);
    logd("notifyUpdateStatus: obtaining weather_lock...");
    synchronized (this.weatherListeners)
    {
      logd("notifyUpdateStatus: obtained weather_lock.");
      List localList = (List)this.weatherListeners.get(paramInt);
      if (localList != null)
      {
        Iterator localIterator = localList.iterator();
        if (localIterator.hasNext())
        {
          WeatherListener localWeatherListener = (WeatherListener)localIterator.next();
          String str2 = "notifyUpdateStatus: notifying Weather listener: " + localWeatherListener;
          log(str2);
          localWeatherListener.onUpdateStatusChanged(paramInt, paramUpdateStatus);
        }
      }
    }
    monitorexit;
    logd("notifyUpdateStatus: released weather_lock.");
    int i = this.mCurrentLocationCityId;
    if (paramInt == i)
    {
      log("notifyUpdateStatus: also notifying current location listeners");
      if (paramUpdateStatus != null)
        paramUpdateStatus = new UpdateStatus(paramUpdateStatus, 64512);
      notifyUpdateStatus(64512, paramUpdateStatus);
    }
    String str3 = "notifyUpdateStatus <<< cityId=" + paramInt + " updateStatus=" + paramUpdateStatus;
    log(str3);
  }

  public void onCurrenLocationCityIdUpdated(int paramInt)
  {
    if (paramInt == -2147483648)
    {
      StringBuilder localStringBuilder = new StringBuilder().append("CurrentLocationObserver.onChange: new current location uknown, keep using last known value: cityId=");
      int i = this.mCurrentLocationCityId;
      logd(i);
    }
    while (true)
    {
      return;
      if (paramInt > 0)
      {
        int j = this.mCurrentLocationCityId;
        if (paramInt == j)
          continue;
        int k = this.mCurrentLocationCityId;
        removeCityId(k);
        this.mCurrentLocationCityId = paramInt;
        int m = this.mCurrentLocationCityId;
        addCityId(m);
        int n = this.mCurrentLocationCityId;
        reload(n);
        notifyCurrentLocationCityIdUpdated(paramInt);
        continue;
      }
    }
  }

  public void onSharedPreferenceChanged(SharedPreferences paramSharedPreferences, String paramString)
  {
    if (paramString.equals("update-interval"))
      onUpdateRateChanged();
  }

  CityInfo queryCity(Uri paramUri)
  {
    CityInfo localCityInfo = null;
    String str1 = "queryCityName: uri=" + paramUri;
    log(str1);
    int i = 0;
    try
    {
      ContentResolver localContentResolver = this.contentResolver;
      String[] arrayOfString = new String[2];
      arrayOfString[0] = "city_name";
      arrayOfString[1] = "utc_offset_min";
      Uri localUri = paramUri;
      localCursor = localContentResolver.query(localUri, arrayOfString, null, null, null);
      if ((localCursor != null) && (localCursor.moveToFirst()))
      {
        i = 0 + 1;
        localCityInfo = new CityInfo();
        String str2 = localCursor.getString(0);
        localCityInfo.cityName = str2;
        int j = localCursor.getInt(1);
        localCityInfo.utcOffset = j;
        String str3;
        return localCityInfo;
      }
      if (localCursor != null)
        localCursor.close();
      String str4 = "queryCityName: read " + 0 + " rows";
      log(str4);
    }
    finally
    {
      Cursor localCursor;
      if (localCursor != null)
        localCursor.close();
      String str5 = "queryCityName: read " + i + " rows";
      log(str5);
    }
  }

  CurrentConditions queryCurrent(Uri paramUri)
  {
    Object localObject1 = null;
    String str1 = "queryCurrent: uri=" + paramUri;
    log(str1);
    int i = 0;
    try
    {
      ContentResolver localContentResolver = this.contentResolver;
      String[] arrayOfString = WeatherMetaData.CurrentMetaData.DEFAULT_PROJECTION;
      Uri localUri = paramUri;
      localCursor = localContentResolver.query(localUri, arrayOfString, null, null, "date DESC,time DESC");
      if ((localCursor != null) && (localCursor.moveToFirst()))
      {
        CurrentConditions localCurrentConditions = WeatherMetaData.CurrentMetaData.fromDefaultCursor(localCursor);
        localObject1 = localCurrentConditions;
        i = 0 + 1;
        String str2;
        return localObject1;
      }
      if (localCursor != null)
        localCursor.close();
      String str3 = "queryCurrent: read " + 0 + " rows";
      log(str3);
    }
    finally
    {
      Cursor localCursor;
      if (localCursor != null)
        localCursor.close();
      String str4 = "queryCurrent: read " + 0 + " rows";
      log(str4);
    }
  }

  Forecast[] queryDetailedForecast(Uri paramUri)
  {
    String str1 = "queryDetailedForecast: uri=" + paramUri;
    log(str1);
    int i = DecimalDateTimeEncoding.getTodayDateEncoded();
    int j = 0;
    Cursor localCursor;
    Forecast[] arrayOfForecast;
    label225: String str4;
    try
    {
      ContentResolver localContentResolver = this.contentResolver;
      String[] arrayOfString1 = WeatherMetaData.TimeOfDayForecastMetaData.DEFAULT_PROJECTION;
      String[] arrayOfString2 = new String[1];
      String str2 = Integer.toString(i);
      arrayOfString2[0] = str2;
      Uri localUri = paramUri;
      localCursor = localContentResolver.query(localUri, arrayOfString1, "date >= ?", arrayOfString2, "time_of_day");
      if (localCursor != null)
      {
        int k = localCursor.getCount();
        arrayOfForecast = new Forecast[k];
        if (localCursor.moveToFirst())
        {
          int m = 0;
          if (m >= k)
            break label225;
          if (!localCursor.isAfterLast())
          {
            Forecast localForecast = WeatherMetaData.TimeOfDayForecastMetaData.fromDefaultCursor(localCursor);
            arrayOfForecast[m] = localForecast;
            j += 1;
            m += 1;
            boolean bool = localCursor.moveToNext();
          }
        }
      }
    }
    finally
    {
      if (localCursor != null)
        localCursor.close();
      String str3 = "queryDetailedForecast: read " + j + " rows";
      log(str3);
    }
    while (true)
    {
      return arrayOfForecast;
      if (localCursor != null)
        localCursor.close();
      String str5 = "queryDetailedForecast: read " + 0 + " rows";
      log(str5);
      arrayOfForecast = null;
    }
  }

  Forecast[] queryForecast(Uri paramUri)
  {
    String str1 = "queryForecast: uri=" + paramUri;
    log(str1);
    int i = DecimalDateTimeEncoding.getTodayDateEncoded();
    int j = 0;
    Cursor localCursor;
    Forecast[] arrayOfForecast;
    label225: String str4;
    try
    {
      ContentResolver localContentResolver = this.contentResolver;
      String[] arrayOfString1 = WeatherMetaData.DailyForecastMetaData.DEFAULT_PROJECTION;
      String[] arrayOfString2 = new String[1];
      String str2 = Integer.toString(i);
      arrayOfString2[0] = str2;
      Uri localUri = paramUri;
      localCursor = localContentResolver.query(localUri, arrayOfString1, "date >= ?", arrayOfString2, "date");
      if (localCursor != null)
      {
        int k = localCursor.getCount();
        arrayOfForecast = new Forecast[k];
        if (localCursor.moveToFirst())
        {
          int m = 0;
          if (m >= k)
            break label225;
          if (!localCursor.isAfterLast())
          {
            Forecast localForecast = WeatherMetaData.DailyForecastMetaData.fromDefaultCursor(localCursor);
            arrayOfForecast[m] = localForecast;
            j += 1;
            m += 1;
            boolean bool = localCursor.moveToNext();
          }
        }
      }
    }
    finally
    {
      if (localCursor != null)
        localCursor.close();
      String str3 = "queryForecast: read " + j + " rows.";
      log(str3);
    }
    while (true)
    {
      return arrayOfForecast;
      if (localCursor != null)
        localCursor.close();
      String str5 = "queryForecast: read " + 0 + " rows.";
      log(str5);
      arrayOfForecast = null;
    }
  }

  Forecast[] queryRawForecast(Uri paramUri)
  {
    Forecast[] arrayOfForecast = null;
    String str1 = "queryRawForecast: uri=" + paramUri;
    log(str1);
    int i = 0;
    Cursor localCursor;
    label199: String str3;
    try
    {
      ContentResolver localContentResolver = this.contentResolver;
      String[] arrayOfString = WeatherMetaData.ForecastMetaData.DEFAULT_PROJECTION;
      Uri localUri = paramUri;
      localCursor = localContentResolver.query(localUri, arrayOfString, null, null, "date,time");
      if (localCursor != null)
      {
        int j = localCursor.getCount();
        arrayOfForecast = new Forecast[j];
        if (localCursor.moveToFirst())
        {
          int k = 0;
          if (k >= j)
            break label199;
          if (!localCursor.isAfterLast())
          {
            Forecast localForecast = WeatherMetaData.ForecastMetaData.fromDefaultCursor(localCursor);
            arrayOfForecast[k] = localForecast;
            i += 1;
            k += 1;
            boolean bool = localCursor.moveToNext();
          }
        }
      }
    }
    finally
    {
      if (localCursor != null)
        localCursor.close();
      String str2 = "queryRawForecast: read " + i + " rows.";
      log(str2);
    }
    while (true)
    {
      return arrayOfForecast;
      if (localCursor != null)
        localCursor.close();
      String str4 = "queryRawForecast: read " + 0 + " rows.";
      log(str4);
    }
  }

  UpdateStatus queryUpdateStatus(int paramInt, Uri paramUri)
  {
    String str1 = "queryUpdateStatus: uri=" + paramUri;
    log(str1);
    Object localObject1 = null;
    try
    {
      ContentResolver localContentResolver = this.contentResolver;
      String[] arrayOfString = WeatherMetaData.UpdateStatusMetaData.DEFAULT_PROJECTION;
      Uri localUri = paramUri;
      localCursor = localContentResolver.query(localUri, arrayOfString, null, null, null);
      if ((localCursor != null) && (localCursor.moveToFirst()))
      {
        UpdateStatus localUpdateStatus = WeatherMetaData.UpdateStatusMetaData.fromDefaultCursor(paramInt, localCursor);
        localObject1 = localUpdateStatus;
      }
      if (localCursor != null)
        localCursor.close();
      log("queryUpdateStatus: query completed");
      String str2 = "queryUpdateStatus: updateStatus=" + localObject1;
      log(str2);
      return localObject1;
    }
    finally
    {
      Cursor localCursor;
      if (localCursor != null)
        localCursor.close();
      log("queryUpdateStatus: query completed");
    }
    throw localObject2;
  }

  public void registerWeatherListener(WeatherListener paramWeatherListener, int paramInt, boolean paramBoolean)
  {
    String str1 = "GROUPER registerWeatherListener >>> cityId=" + paramInt + " l=" + paramWeatherListener;
    log(str1);
    log("registerWeatherListener: obtaining weather_lock...");
    while (true)
    {
      synchronized (this.weatherListeners)
      {
        log("registerWeatherListener: obtained weather_lock");
        Object localObject1 = (List)this.weatherListeners.get(paramInt);
        if (localObject1 != null)
          continue;
        localObject1 = new LinkedList();
        this.weatherListeners.put(paramInt, localObject1);
        if (((List)localObject1).contains(paramWeatherListener))
          continue;
        boolean bool = ((List)localObject1).add(paramWeatherListener);
        addCityId(paramInt);
        log("registerWeatherListener: released weather_lock");
        if (!paramBoolean)
          continue;
        if (paramInt != 64512)
          break label242;
        if (this.mCurrentLocationCityId != -2147483648)
        {
          int i = this.mCurrentLocationCityId;
          addCityId(i);
          int j = this.mCurrentLocationCityId;
          reload(j);
          String str2 = "GROUPER registerWeatherListener <<< cityId=" + paramInt + " l=" + paramWeatherListener;
          log(str2);
          return;
        }
      }
      notifyNA(64512);
      this.currentLocationClient.postUpdateCurrentLocation();
      continue;
      label242: reload(paramInt);
    }
  }

  public void rescheduleWeatherUpdates()
  {
    logd("rescheduleWeatherUpdates");
    int i = 0;
    List localList1 = this.weatherPrefs.getAllCityIds();
    List localList2 = resolveCurrentLocationCityIds(localList1);
    long l1 = this.weatherPrefs.getUpdateIntervalMs();
    if (this.scheduleInfo == null)
    {
      logd("rescheduleWeatherUpdates: no schedule info available");
      i = 1;
      break label357;
      label46: if (i == 0)
        break label443;
      logd("rescheduleWeatherUpdates: will re-schedule weather updates");
      Application localApplication = this.application;
      WeatherApplication.scheduleWeatherUpdates(l1, localList2, localApplication);
      ScheduleInfo localScheduleInfo1 = new ScheduleInfo();
      this.scheduleInfo = localScheduleInfo1;
      this.scheduleInfo.scheduledIds = localList2;
      this.scheduleInfo.scheduledInterval = l1;
      ScheduleInfo localScheduleInfo2 = this.scheduleInfo;
      long l2 = System.currentTimeMillis();
      localScheduleInfo2.scheduledTimestampToken = l2;
      WeatherApplicationPreferences localWeatherApplicationPreferences = this.weatherPrefs;
      ScheduleInfo localScheduleInfo3 = this.scheduleInfo;
      localWeatherApplicationPreferences.setScheduleInfo(localScheduleInfo3);
    }
    while (true)
    {
      return;
      ScheduleInfo localScheduleInfo4 = this.weatherPrefs.getScheduleInfo();
      if (localScheduleInfo4 == null)
      {
        logd("rescheduleWeatherUpdates: stored schedule info not found");
        i = 1;
        break label46;
      }
      long l3 = localScheduleInfo4.scheduledTimestampToken;
      long l4 = this.scheduleInfo.scheduledTimestampToken;
      if (l3 != l4)
      {
        logd("rescheduleWeatherUpdates: schedule info outdated");
        i = 1;
        break label46;
      }
      logd("rescheduleWeatherUpdates: found information about current schedule: " + localScheduleInfo4);
      long l5 = localScheduleInfo4.scheduledInterval;
      if (l1 != l5)
      {
        StringBuilder localStringBuilder = new StringBuilder().append("rescheduleWeatherUpdates: new update interval: ");
        long l6 = l1 / 60000L;
        logd(l6 + " min");
        i = 1;
        break label46;
      }
      logd("rescheduleWeatherUpdates: cityIds=" + localList2);
      int j = localList2.size();
      int k = this.scheduleInfo.scheduledIds.size();
      if (j != k)
      {
        logd("rescheduleWeatherUpdates: city IDs changed");
        i = 1;
        break label46;
      }
      Iterator localIterator = localList2.iterator();
      label357: if (!localIterator.hasNext())
        break label46;
      int m = ((Integer)localIterator.next()).intValue();
      List localList3 = localScheduleInfo4.scheduledIds;
      Integer localInteger = Integer.valueOf(m);
      if (localList3.contains(localInteger))
        break;
      logd("rescheduleWeatherUpdates: update for cityId=" + m + " + is not scheduled");
      i = 1;
      break label46;
      label443: logd("rescheduleWeatherUpdates: will NOT re-schedule weather updates");
    }
  }

  public List<Integer> resolveCurrentLocationCityIds(List<Integer> paramList)
  {
    int i;
    if (paramList == null)
    {
      i = 0;
      if (i != 0)
        break label22;
    }
    while (true)
    {
      return paramList;
      i = paramList.size();
      break;
      label22: ArrayList localArrayList = null;
      int j = 0;
      while (j < i)
      {
        int k = ((Integer)paramList.get(j)).intValue();
        if (k == 64512)
        {
          if (localArrayList == null)
          {
            localArrayList = new ArrayList();
            List localList = paramList.subList(0, j);
            boolean bool1 = localArrayList.addAll(localList);
          }
          k = getCurrentLocationCityId();
        }
        if ((k != -2147483648) && (localArrayList != null))
        {
          Integer localInteger = Integer.valueOf(k);
          boolean bool2 = localArrayList.add(localInteger);
        }
        j += 1;
      }
      if (localArrayList == null)
        continue;
      paramList = localArrayList;
    }
  }

  /** @deprecated */
  public void start()
  {
    monitorenter;
    try
    {
      log("start");
      HandlerThread localHandlerThread = new HandlerThread("WeatherDataCache");
      this.mHandlerThread = localHandlerThread;
      this.mHandlerThread.start();
      Looper localLooper = this.mHandlerThread.getLooper();
      Handler localHandler = new Handler(localLooper);
      this.mHandler = localHandler;
      Application localApplication = this.application;
      WeatherApplicationPreferences localWeatherApplicationPreferences = new WeatherApplicationPreferences(localApplication);
      this.weatherPrefs = localWeatherApplicationPreferences;
      this.weatherPrefs.registerOnSharedPreferenceChangeListener(this);
      synchronized (this.cityIdsCount)
      {
        int i = this.cityIdsCount.size();
        int j = 0;
        while (j < i)
        {
          int k = this.cityIdsCount.keyAt(j);
          startObserving(k);
          j += 1;
        }
        monitorexit;
        return;
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject2;
  }

  void startObserving(int paramInt)
  {
    LinkedList localLinkedList = new LinkedList();
    Handler localHandler1 = this.mHandler;
    ForecastObserver localForecastObserver = new ForecastObserver(localHandler1, paramInt);
    boolean bool1 = localLinkedList.add(localForecastObserver);
    Handler localHandler2 = this.mHandler;
    RawForecastObserver localRawForecastObserver = new RawForecastObserver(localHandler2, paramInt);
    boolean bool2 = localLinkedList.add(localRawForecastObserver);
    Handler localHandler3 = this.mHandler;
    DetailedForecastObserver localDetailedForecastObserver = new DetailedForecastObserver(localHandler3, paramInt);
    boolean bool3 = localLinkedList.add(localDetailedForecastObserver);
    Handler localHandler4 = this.mHandler;
    CurrentObserver localCurrentObserver = new CurrentObserver(localHandler4, paramInt);
    boolean bool4 = localLinkedList.add(localCurrentObserver);
    Handler localHandler5 = this.mHandler;
    CityNameObserver localCityNameObserver = new CityNameObserver(localHandler5, paramInt);
    boolean bool5 = localLinkedList.add(localCityNameObserver);
    Handler localHandler6 = this.mHandler;
    UpdatedStatusObserver localUpdatedStatusObserver = new UpdatedStatusObserver(localHandler6, paramInt);
    boolean bool6 = localLinkedList.add(localUpdatedStatusObserver);
    this.mObservers.put(paramInt, localLinkedList);
  }

  void startObservingCurrentLocation()
  {
    logd("GROUPER startObservingCurrentLocation");
    if (!this.isUsingCurrentLocation)
    {
      Handler localHandler = this.mHandler;
      PositioningStatusObserver localPositioningStatusObserver = new PositioningStatusObserver(localHandler);
      this.positioningStatusObserver = localPositioningStatusObserver;
      this.currentLocationClient.registerCurrentLocationListener(this);
      this.isUsingCurrentLocation = 1;
    }
  }

  /** @deprecated */
  // ERROR //
  public void stop()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc_w 1067
    //   6: invokespecial 199	com/softspb/weather/core/WeatherDataCache:log	(Ljava/lang/String;)V
    //   9: aload_0
    //   10: getfield 387	com/softspb/weather/core/WeatherDataCache:mHandler	Landroid/os/Handler;
    //   13: aconst_null
    //   14: invokevirtual 1071	android/os/Handler:removeCallbacksAndMessages	(Ljava/lang/Object;)V
    //   17: aload_0
    //   18: getfield 647	com/softspb/weather/core/WeatherDataCache:mHandlerThread	Landroid/os/HandlerThread;
    //   21: invokevirtual 1030	android/os/HandlerThread:getLooper	()Landroid/os/Looper;
    //   24: invokevirtual 1076	android/os/Looper:quit	()V
    //   27: aload_0
    //   28: getfield 647	com/softspb/weather/core/WeatherDataCache:mHandlerThread	Landroid/os/HandlerThread;
    //   31: ldc2_w 1077
    //   34: invokevirtual 1082	android/os/HandlerThread:join	(J)V
    //   37: aconst_null
    //   38: astore_1
    //   39: aload_0
    //   40: aload_1
    //   41: putfield 647	com/softspb/weather/core/WeatherDataCache:mHandlerThread	Landroid/os/HandlerThread;
    //   44: aload_0
    //   45: getfield 248	com/softspb/weather/core/WeatherDataCache:weatherPrefs	Lcom/softspb/weather/core/WeatherApplicationPreferences;
    //   48: invokevirtual 1085	com/softspb/weather/core/WeatherApplicationPreferences:dispose	()V
    //   51: aload_0
    //   52: aconst_null
    //   53: putfield 248	com/softspb/weather/core/WeatherDataCache:weatherPrefs	Lcom/softspb/weather/core/WeatherApplicationPreferences;
    //   56: aload_0
    //   57: getfield 158	com/softspb/weather/core/WeatherDataCache:cityIdsCount	Landroid/util/SparseIntArray;
    //   60: astore_2
    //   61: aload_2
    //   62: monitorenter
    //   63: aload_0
    //   64: getfield 158	com/softspb/weather/core/WeatherDataCache:cityIdsCount	Landroid/util/SparseIntArray;
    //   67: invokevirtual 1041	android/util/SparseIntArray:size	()I
    //   70: istore_3
    //   71: iconst_0
    //   72: istore 4
    //   74: iload 4
    //   76: iload_3
    //   77: if_icmpge +29 -> 106
    //   80: aload_0
    //   81: getfield 158	com/softspb/weather/core/WeatherDataCache:cityIdsCount	Landroid/util/SparseIntArray;
    //   84: iload 4
    //   86: invokevirtual 1044	android/util/SparseIntArray:keyAt	(I)I
    //   89: istore 5
    //   91: aload_0
    //   92: iload 5
    //   94: invokevirtual 415	com/softspb/weather/core/WeatherDataCache:stopObserving	(I)V
    //   97: iload 4
    //   99: iconst_1
    //   100: iadd
    //   101: istore 4
    //   103: goto -29 -> 74
    //   106: aload_2
    //   107: monitorexit
    //   108: aload_0
    //   109: monitorexit
    //   110: return
    //   111: astore_1
    //   112: aload_2
    //   113: monitorexit
    //   114: aload_1
    //   115: athrow
    //   116: astore 6
    //   118: aload_0
    //   119: monitorexit
    //   120: aload 6
    //   122: athrow
    //   123: astore 7
    //   125: goto -88 -> 37
    //
    // Exception table:
    //   from	to	target	type
    //   63	108	111	finally
    //   112	114	111	finally
    //   2	27	116	finally
    //   27	37	116	finally
    //   39	63	116	finally
    //   114	116	116	finally
    //   27	37	123	java/lang/InterruptedException
  }

  void stopObserving(int paramInt)
  {
    List localList = (List)this.mObservers.get(paramInt);
    if (localList != null)
    {
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        ContentObserver localContentObserver = (ContentObserver)localIterator.next();
        log("Unregistering Forecast observer...");
        this.contentResolver.unregisterContentObserver(localContentObserver);
      }
      this.mObservers.remove(paramInt);
    }
  }

  void stopObservingCurrentLocation()
  {
    logd("GROUPER stopObservingCurrentLocation");
    if (this.isUsingCurrentLocation)
    {
      if (this.mCurrentLocationCityId != -2147483648)
      {
        int i = this.mCurrentLocationCityId;
        removeCityId(i);
      }
      ContentResolver localContentResolver = this.contentResolver;
      PositioningStatusObserver localPositioningStatusObserver = this.positioningStatusObserver;
      localContentResolver.unregisterContentObserver(localPositioningStatusObserver);
      this.currentLocationClient.unregisterCurrentLocationListener(this);
      this.positioningStatusObserver = null;
      this.isUsingCurrentLocation = 0;
    }
  }

  public void unregisterWeatherListener(WeatherListener paramWeatherListener, int paramInt)
  {
    String str1 = "GROUPER unregisterWeatherListener >>> cityId=" + paramInt + " l=" + paramWeatherListener;
    log(str1);
    logd("unregisterWeatherListener: obtaining weather_lock...");
    synchronized (this.weatherListeners)
    {
      logd("unregisterWeatherListener: obtained weather_lock.");
      List localList = (List)this.weatherListeners.get(paramInt);
      if ((localList != null) && (localList.remove(paramWeatherListener)))
      {
        removeCityId(paramInt);
        if (localList.size() == 0)
          this.weatherListeners.remove(paramInt);
      }
      logd("unregisterWeatherListener: released weather_lock...");
      String str2 = "GROUPER unregisterWeatherListener <<< cityId=" + paramInt + " l=" + paramWeatherListener;
      log(str2);
      return;
    }
  }

  class PositioningStatusObserver extends ContentObserver
  {
    private Uri uri;

    PositioningStatusObserver(Handler arg2)
    {
      super();
      Uri localUri1 = ContentUris.withAppendedId(WeatherMetaData.UpdateStatusMetaData.getContentUri(WeatherDataCache.this.application), 64512L);
      this.uri = localUri1;
      StringBuilder localStringBuilder = new StringBuilder().append("Registering content observer for URI: ");
      Uri localUri2 = this.uri;
      String str = localUri2;
      WeatherDataCache.this.log(str);
      ContentResolver localContentResolver = WeatherDataCache.this.contentResolver;
      Uri localUri3 = this.uri;
      localContentResolver.registerContentObserver(localUri3, 1, this);
    }

    public void onChange(boolean paramBoolean)
    {
      WeatherDataCache localWeatherDataCache1 = WeatherDataCache.this;
      StringBuilder localStringBuilder = new StringBuilder().append("onChange: uri=");
      Uri localUri1 = this.uri;
      String str = localUri1;
      localWeatherDataCache1.log(str);
      WeatherDataCache localWeatherDataCache2 = WeatherDataCache.this;
      Uri localUri2 = this.uri;
      UpdateStatus localUpdateStatus = localWeatherDataCache2.queryUpdateStatus(64512, localUri2);
      if (localUpdateStatus != null)
        WeatherDataCache.this.updateStatusCache.put(64512, localUpdateStatus);
      if (localUpdateStatus == null)
        localUpdateStatus = (UpdateStatus)WeatherDataCache.this.updateStatusCache.get(64512);
      WeatherDataCache.this.notifyUpdateStatus(64512, localUpdateStatus);
    }
  }

  class UpdatedStatusObserver extends ContentObserver
  {
    int cityId;
    Uri uri;

    UpdatedStatusObserver(Handler paramInt, int arg3)
    {
      super();
      int i;
      this.cityId = i;
      Uri localUri1 = WeatherMetaData.UpdateStatusMetaData.getContentUri(WeatherDataCache.this.application);
      long l = i;
      Uri localUri2 = ContentUris.withAppendedId(localUri1, l);
      this.uri = localUri2;
      StringBuilder localStringBuilder = new StringBuilder().append("Registering content observer for URI: ");
      Uri localUri3 = this.uri;
      String str = localUri3;
      WeatherDataCache.this.log(str);
      ContentResolver localContentResolver = WeatherDataCache.this.contentResolver;
      Uri localUri4 = this.uri;
      localContentResolver.registerContentObserver(localUri4, 1, this);
    }

    public void onChange(boolean paramBoolean)
    {
      WeatherDataCache localWeatherDataCache1 = WeatherDataCache.this;
      StringBuilder localStringBuilder = new StringBuilder().append("onChange: uri=");
      Uri localUri1 = this.uri;
      String str = localUri1;
      localWeatherDataCache1.log(str);
      WeatherDataCache localWeatherDataCache2 = WeatherDataCache.this;
      int i = this.cityId;
      Uri localUri2 = this.uri;
      UpdateStatus localUpdateStatus = localWeatherDataCache2.queryUpdateStatus(i, localUri2);
      if (localUpdateStatus != null)
      {
        SparseArray localSparseArray1 = WeatherDataCache.this.updateStatusCache;
        int j = this.cityId;
        localSparseArray1.put(j, localUpdateStatus);
      }
      if (localUpdateStatus == null)
      {
        SparseArray localSparseArray2 = WeatherDataCache.this.updateStatusCache;
        int k = this.cityId;
        localUpdateStatus = (UpdateStatus)localSparseArray2.get(k);
      }
      WeatherDataCache localWeatherDataCache3 = WeatherDataCache.this;
      int m = this.cityId;
      localWeatherDataCache3.notifyUpdateStatus(m, localUpdateStatus);
    }
  }

  class CityNameObserver extends ContentObserver
  {
    int mCityId;
    Uri mUri;

    CityNameObserver(Handler paramInt, int arg3)
    {
      super();
      int i;
      this.mCityId = i;
      Uri localUri1 = CitiesContract.Cities.getContentUri(WeatherDataCache.this.application);
      long l = i;
      Uri localUri2 = ContentUris.withAppendedId(localUri1, l);
      this.mUri = localUri2;
      StringBuilder localStringBuilder = new StringBuilder().append("Registering content observer for URI: ");
      Uri localUri3 = this.mUri;
      String str = localUri3;
      WeatherDataCache.this.log(str);
      ContentResolver localContentResolver = WeatherDataCache.this.contentResolver;
      Uri localUri4 = this.mUri;
      localContentResolver.registerContentObserver(localUri4, 1, this);
    }

    public void onChange(boolean paramBoolean)
    {
      WeatherDataCache localWeatherDataCache1 = WeatherDataCache.this;
      StringBuilder localStringBuilder = new StringBuilder().append("onChange: uri=");
      Uri localUri1 = this.mUri;
      String str1 = localUri1;
      localWeatherDataCache1.log(str1);
      WeatherDataCache localWeatherDataCache2 = WeatherDataCache.this;
      Uri localUri2 = this.mUri;
      WeatherDataCache.CityInfo localCityInfo = localWeatherDataCache2.queryCity(localUri2);
      if (localCityInfo != null)
      {
        SparseArray localSparseArray1 = WeatherDataCache.this.cityNameCache;
        int i = this.mCityId;
        localSparseArray1.put(i, localCityInfo);
      }
      if (localCityInfo == null)
      {
        SparseArray localSparseArray2 = WeatherDataCache.this.cityNameCache;
        int j = this.mCityId;
        localCityInfo = (WeatherDataCache.CityInfo)localSparseArray2.get(j);
      }
      if (localCityInfo != null)
      {
        WeatherDataCache localWeatherDataCache3 = WeatherDataCache.this;
        int k = this.mCityId;
        String str2 = localCityInfo.cityName;
        localWeatherDataCache3.notifyCityNameUpdated(k, str2);
      }
    }
  }

  class CurrentObserver extends ContentObserver
  {
    int mCityId;
    Uri mUri;

    CurrentObserver(Handler paramInt, int arg3)
    {
      super();
      int i;
      this.mCityId = i;
      Uri localUri1 = WeatherMetaData.CurrentMetaData.getContentUri(WeatherDataCache.this.application);
      long l = i;
      Uri localUri2 = ContentUris.withAppendedId(localUri1, l);
      this.mUri = localUri2;
      StringBuilder localStringBuilder = new StringBuilder().append("Registering content observer for URI: ");
      Uri localUri3 = this.mUri;
      String str = localUri3;
      WeatherDataCache.this.log(str);
      ContentResolver localContentResolver = WeatherDataCache.this.contentResolver;
      Uri localUri4 = this.mUri;
      localContentResolver.registerContentObserver(localUri4, 1, this);
    }

    public void onChange(boolean paramBoolean)
    {
      WeatherDataCache localWeatherDataCache1 = WeatherDataCache.this;
      StringBuilder localStringBuilder = new StringBuilder().append("onChange: uri=");
      Uri localUri1 = this.mUri;
      String str = localUri1;
      localWeatherDataCache1.log(str);
      WeatherDataCache localWeatherDataCache2 = WeatherDataCache.this;
      Uri localUri2 = this.mUri;
      CurrentConditions localCurrentConditions = localWeatherDataCache2.queryCurrent(localUri2);
      if (localCurrentConditions != null)
      {
        SparseArray localSparseArray1 = WeatherDataCache.this.currentCache;
        int i = this.mCityId;
        localSparseArray1.put(i, localCurrentConditions);
      }
      if (localCurrentConditions == null)
      {
        SparseArray localSparseArray2 = WeatherDataCache.this.currentCache;
        int j = this.mCityId;
        localCurrentConditions = (CurrentConditions)localSparseArray2.get(j);
      }
      WeatherDataCache localWeatherDataCache3 = WeatherDataCache.this;
      int k = this.mCityId;
      localWeatherDataCache3.notifyCurrentUpdated(k, localCurrentConditions);
    }
  }

  class DetailedForecastObserver extends ContentObserver
  {
    int mCityId;
    Uri mUri;

    DetailedForecastObserver(Handler paramInt, int arg3)
    {
      super();
      int i;
      this.mCityId = i;
      Uri localUri1 = WeatherMetaData.TimeOfDayForecastMetaData.getUri(WeatherDataCache.this.application, i);
      this.mUri = localUri1;
      StringBuilder localStringBuilder = new StringBuilder().append("Registering content observer for URI: ");
      Uri localUri2 = this.mUri;
      String str = localUri2;
      WeatherDataCache.this.log(str);
      ContentResolver localContentResolver = WeatherDataCache.this.contentResolver;
      Uri localUri3 = this.mUri;
      localContentResolver.registerContentObserver(localUri3, 1, this);
    }

    public void onChange(boolean paramBoolean)
    {
      WeatherDataCache localWeatherDataCache1 = WeatherDataCache.this;
      StringBuilder localStringBuilder = new StringBuilder().append("onChange: uri=");
      Uri localUri1 = this.mUri;
      String str = localUri1;
      localWeatherDataCache1.log(str);
      WeatherDataCache localWeatherDataCache2 = WeatherDataCache.this;
      Uri localUri2 = this.mUri;
      Forecast[] arrayOfForecast = localWeatherDataCache2.queryDetailedForecast(localUri2);
      if (arrayOfForecast != null)
      {
        SparseArray localSparseArray1 = WeatherDataCache.this.detailedForecastCache;
        int i = this.mCityId;
        localSparseArray1.put(i, arrayOfForecast);
      }
      if (arrayOfForecast == null)
      {
        SparseArray localSparseArray2 = WeatherDataCache.this.detailedForecastCache;
        int j = this.mCityId;
        arrayOfForecast = (Forecast[])localSparseArray2.get(j);
      }
      WeatherDataCache localWeatherDataCache3 = WeatherDataCache.this;
      int k = this.mCityId;
      localWeatherDataCache3.notifyDetailedForecastUpdated(k, arrayOfForecast);
    }
  }

  class RawForecastObserver extends ContentObserver
  {
    int cityId;
    int date;
    Uri observeUri;
    Uri queryUri;

    RawForecastObserver(Handler paramInt, int arg3)
    {
      super();
      int i;
      this.cityId = i;
      Uri localUri1 = WeatherMetaData.ForecastMetaData.getCityUri(WeatherDataCache.this.application, i);
      this.observeUri = localUri1;
      StringBuilder localStringBuilder = new StringBuilder().append("Registering content observer for URI: ");
      Uri localUri2 = this.observeUri;
      String str = localUri2;
      WeatherDataCache.this.log(str);
      ContentResolver localContentResolver = WeatherDataCache.this.contentResolver;
      Uri localUri3 = this.observeUri;
      localContentResolver.registerContentObserver(localUri3, 1, this);
    }

    public void onChange(boolean paramBoolean)
    {
      WeatherDataCache localWeatherDataCache1 = WeatherDataCache.this;
      StringBuilder localStringBuilder = new StringBuilder().append("onChange: uri=");
      Uri localUri1 = this.observeUri;
      String str = localUri1;
      localWeatherDataCache1.log(str);
      int i = DecimalDateTimeEncoding.getTodayDateEncoded();
      if (this.date != i)
      {
        this.date = i;
        Application localApplication = WeatherDataCache.this.application;
        int j = this.cityId;
        Uri localUri2 = WeatherMetaData.ForecastMetaData.getCityDateUri(localApplication, j, i);
        this.queryUri = localUri2;
      }
      WeatherDataCache localWeatherDataCache2 = WeatherDataCache.this;
      Uri localUri3 = this.queryUri;
      Forecast[] arrayOfForecast = localWeatherDataCache2.queryRawForecast(localUri3);
      if (arrayOfForecast != null)
      {
        SparseArray localSparseArray1 = WeatherDataCache.this.rawForecastCache;
        int k = this.cityId;
        localSparseArray1.put(k, arrayOfForecast);
      }
      if (arrayOfForecast == null)
      {
        SparseArray localSparseArray2 = WeatherDataCache.this.rawForecastCache;
        int m = this.cityId;
        arrayOfForecast = (Forecast[])localSparseArray2.get(m);
      }
      WeatherDataCache localWeatherDataCache3 = WeatherDataCache.this;
      int n = this.cityId;
      localWeatherDataCache3.notifyRawForecastUpdated(n, arrayOfForecast);
    }
  }

  class ForecastObserver extends ContentObserver
  {
    int mCityId;
    Uri mUri;

    ForecastObserver(Handler paramInt, int arg3)
    {
      super();
      int i;
      this.mCityId = i;
      Uri localUri1 = WeatherMetaData.DailyForecastMetaData.getContentUri(WeatherDataCache.this.application);
      long l = i;
      Uri localUri2 = ContentUris.withAppendedId(localUri1, l);
      this.mUri = localUri2;
      StringBuilder localStringBuilder = new StringBuilder().append("Registering content observer for URI: ");
      Uri localUri3 = this.mUri;
      String str = localUri3;
      WeatherDataCache.this.log(str);
      ContentResolver localContentResolver = WeatherDataCache.this.contentResolver;
      Uri localUri4 = this.mUri;
      localContentResolver.registerContentObserver(localUri4, 1, this);
    }

    public void onChange(boolean paramBoolean)
    {
      WeatherDataCache localWeatherDataCache1 = WeatherDataCache.this;
      StringBuilder localStringBuilder = new StringBuilder().append("onChange: uri=");
      Uri localUri1 = this.mUri;
      String str = localUri1;
      localWeatherDataCache1.log(str);
      WeatherDataCache localWeatherDataCache2 = WeatherDataCache.this;
      Uri localUri2 = this.mUri;
      Forecast[] arrayOfForecast = localWeatherDataCache2.queryForecast(localUri2);
      if (arrayOfForecast != null)
      {
        SparseArray localSparseArray1 = WeatherDataCache.this.forecastCache;
        int i = this.mCityId;
        localSparseArray1.put(i, arrayOfForecast);
      }
      if (arrayOfForecast == null)
      {
        SparseArray localSparseArray2 = WeatherDataCache.this.forecastCache;
        int j = this.mCityId;
        arrayOfForecast = (Forecast[])localSparseArray2.get(j);
      }
      WeatherDataCache localWeatherDataCache3 = WeatherDataCache.this;
      int k = this.mCityId;
      localWeatherDataCache3.notifyForecastUpdated(k, arrayOfForecast);
    }
  }

  class CityInfo
  {
    String cityName;
    int utcOffset;
  }

  public abstract interface WeatherListener
  {
    public abstract int getDetailedForecastDate();

    public abstract void onCityNameUpdated(int paramInt, String paramString);

    public abstract void onCurrentUpdated(int paramInt, CurrentConditions paramCurrentConditions);

    public abstract void onDetailedForecastUpdated(int paramInt, Forecast[] paramArrayOfForecast);

    public abstract void onForecastUpdated(int paramInt, Forecast[] paramArrayOfForecast);

    public abstract void onRawForecastUpdated(int paramInt, Forecast[] paramArrayOfForecast);

    public abstract void onUpdateStatusChanged(int paramInt, UpdateStatus paramUpdateStatus);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.core.WeatherDataCache
 * JD-Core Version:    0.6.0
 */