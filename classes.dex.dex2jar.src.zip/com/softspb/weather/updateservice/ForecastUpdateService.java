package com.softspb.weather.updateservice;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import com.softspb.updateservice.DownloadClient;
import com.softspb.util.log.Logger;
import com.softspb.weather.model.Forecast;
import com.softspb.weather.model.ForecastArray;
import com.softspb.weather.model.WeatherParameterValue;
import com.softspb.weather.provider.WeatherMetaData.ForecastMetaData;

public abstract class ForecastUpdateService extends WeatherUpdateService<ForecastArray>
{
  public static final String ACTION_UPDATE = "com.softspb.weather.updateservice.action.UpdateForecast";

  protected abstract DownloadClient<Integer, ForecastArray> createDownloadClient(Context paramContext);

  protected int getUpdateType()
  {
    return 2;
  }

  protected boolean onDataReceived(ForecastArray paramForecastArray)
  {
    Forecast[] arrayOfForecast = paramForecastArray.getItems();
    int i = arrayOfForecast.length;
    int j = paramForecastArray.getCityID();
    this.logger.d("onForecastDataReceived...");
    ContentValues[] arrayOfContentValues = new ContentValues[i];
    int k = 0;
    while (k < i)
    {
      Forecast localForecast = arrayOfForecast[k];
      ContentValues localContentValues = new ContentValues();
      int m = localForecast.getDateLocal();
      int n = localForecast.getTimeLocal();
      Logger localLogger1 = this.logger;
      String str1 = "Updating forecast: cityId=" + j + " date=" + m + " time=" + n;
      localLogger1.d(str1);
      Integer localInteger1 = Integer.valueOf(j);
      localContentValues.put("city_id", localInteger1);
      Integer localInteger2 = Integer.valueOf(m);
      localContentValues.put("date", localInteger2);
      Integer localInteger3 = Integer.valueOf(n);
      localContentValues.put("time", localInteger3);
      Integer localInteger4 = Integer.valueOf(localForecast.getCloud());
      localContentValues.put("cloud", localInteger4);
      Integer localInteger5 = Integer.valueOf(localForecast.getPrecip());
      localContentValues.put("precip", localInteger5);
      WeatherParameterValue localWeatherParameterValue = localForecast.getMinHeatIndex();
      if (localWeatherParameterValue != null)
      {
        Integer localInteger6 = Integer.valueOf(((Number)localWeatherParameterValue.getValueInDefaultUnits()).intValue());
        localContentValues.put("heat_min", localInteger6);
      }
      localWeatherParameterValue = localForecast.getMaxHeatIndex();
      if (localWeatherParameterValue != null)
      {
        Integer localInteger7 = Integer.valueOf(((Number)localWeatherParameterValue.getValueInDefaultUnits()).intValue());
        localContentValues.put("heat_max", localInteger7);
      }
      localWeatherParameterValue = localForecast.getMinTemp();
      if (localWeatherParameterValue != null)
      {
        Integer localInteger8 = Integer.valueOf(((Number)localWeatherParameterValue.getValueInDefaultUnits()).intValue());
        localContentValues.put("temp_min", localInteger8);
      }
      localWeatherParameterValue = localForecast.getMaxTemp();
      if (localWeatherParameterValue != null)
      {
        Integer localInteger9 = Integer.valueOf(((Number)localWeatherParameterValue.getValueInDefaultUnits()).intValue());
        localContentValues.put("temp_max", localInteger9);
      }
      localWeatherParameterValue = localForecast.getMaxHumidity();
      if (localWeatherParameterValue != null)
      {
        Float localFloat1 = Float.valueOf(((Number)localWeatherParameterValue.getValueInDefaultUnits()).floatValue());
        localContentValues.put("humidity_max", localFloat1);
      }
      localWeatherParameterValue = localForecast.getMinHumidity();
      if (localWeatherParameterValue != null)
      {
        Float localFloat2 = Float.valueOf(((Number)localWeatherParameterValue.getValueInDefaultUnits()).floatValue());
        localContentValues.put("humidity_min", localFloat2);
      }
      localWeatherParameterValue = localForecast.getMinPress();
      if (localWeatherParameterValue != null)
      {
        Float localFloat3 = Float.valueOf(((Number)localWeatherParameterValue.getValueInDefaultUnits()).floatValue());
        localContentValues.put("press_min", localFloat3);
      }
      localWeatherParameterValue = localForecast.getMaxPress();
      if (localWeatherParameterValue != null)
      {
        Float localFloat4 = Float.valueOf(((Number)localWeatherParameterValue.getValueInDefaultUnits()).floatValue());
        localContentValues.put("press_max", localFloat4);
      }
      localWeatherParameterValue = localForecast.getMinWindSpeed();
      if (localWeatherParameterValue != null)
      {
        Float localFloat5 = Float.valueOf(((Number)localWeatherParameterValue.getValueInDefaultUnits()).floatValue());
        localContentValues.put("wind_min", localFloat5);
      }
      localWeatherParameterValue = localForecast.getMaxWindSpeed();
      if (localWeatherParameterValue != null)
      {
        Float localFloat6 = Float.valueOf(((Number)localWeatherParameterValue.getValueInDefaultUnits()).floatValue());
        localContentValues.put("wind_max", localFloat6);
      }
      localWeatherParameterValue = localForecast.getWindDirection();
      if (localWeatherParameterValue != null)
      {
        String str2 = ((Number)localWeatherParameterValue.getValueInDefaultUnits()).toString();
        localContentValues.put("wind_dir", str2);
      }
      Logger localLogger2 = this.logger;
      StringBuilder localStringBuilder = new StringBuilder().append("Updating values: ");
      String str3 = localContentValues.toString();
      String str4 = str3;
      localLogger2.d(str4);
      arrayOfContentValues[k] = localContentValues;
      k += 1;
    }
    ContentResolver localContentResolver = getContentResolver();
    Uri localUri = WeatherMetaData.ForecastMetaData.getContentUri(getBaseContext());
    int i1 = localContentResolver.bulkInsert(localUri, arrayOfContentValues);
    return true;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.updateservice.ForecastUpdateService
 * JD-Core Version:    0.6.0
 */