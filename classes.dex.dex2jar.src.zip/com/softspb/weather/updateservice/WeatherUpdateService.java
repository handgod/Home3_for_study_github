package com.softspb.weather.updateservice;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import com.softspb.updateservice.UpdateService;
import com.softspb.util.log.Logger;
import com.softspb.weather.provider.WeatherMetaData.UpdateStatusMetaData;

public abstract class WeatherUpdateService<DataType> extends UpdateService<DataType>
{
  public static final String ACTION_WEATHER_UPDATE_STATUS = "com.softspb.weather.updateservice.action.WeatherUpdateStatus";
  private static final String SHARED_PREFERENCES_NAME = "weather_update_service";
  public static final String WEATHER_UPDATE_ID = "weather-update-id";
  public static final String WEATHER_UPDATE_STATUS = "weather-update-status";
  public static final int WEATHER_UPDATE_STATUS_DOWNLOADING = 1;
  public static final int WEATHER_UPDATE_STATUS_IDLE = 2;
  public static final String WEATHER_UPDATE_TAG = "weather-update-tag";
  private static long nextUpdateId = 1L;
  long updateSessionId;
  private final int updateType;

  public WeatherUpdateService()
  {
    int i = getUpdateType();
    this.updateType = i;
    this.updateSessionId = 65535L;
  }

  public static long sendWeatherUpdateStatusDownloading(int paramInt, Context paramContext, String paramString)
  {
    monitorenter;
    try
    {
      long l = nextUpdateId;
      nextUpdateId = 1L + l;
      monitorexit;
      Intent localIntent1 = new Intent("com.softspb.weather.updateservice.action.WeatherUpdateStatus");
      Intent localIntent2 = localIntent1.putExtra("city_id", paramInt);
      Intent localIntent3 = localIntent1.putExtra("weather-update-status", 1);
      Intent localIntent4 = localIntent1.putExtra("weather-update-tag", paramString);
      Intent localIntent5 = localIntent1.putExtra("weather-update-id", l);
      paramContext.sendBroadcast(localIntent1);
      return l;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public static void sendWeatherUpdateStatusIdle(int paramInt, Context paramContext, String paramString, long paramLong)
  {
    Intent localIntent1 = new Intent("com.softspb.weather.updateservice.action.WeatherUpdateStatus");
    Intent localIntent2 = localIntent1.putExtra("city_id", paramInt);
    Intent localIntent3 = localIntent1.putExtra("weather-update-status", 2);
    Intent localIntent4 = localIntent1.putExtra("weather-update-tag", paramString);
    Intent localIntent5 = localIntent1.putExtra("weather-update-id", paramLong);
    paramContext.sendBroadcast(localIntent1);
  }

  protected SharedPreferences getSharedPreferences()
  {
    return getSharedPreferences("weather_update_service", 0);
  }

  protected abstract int getUpdateType();

  protected void onFinishedUpdate()
  {
    if (this.updateSessionId != 65535L)
    {
      Context localContext = getBaseContext();
      String str = this.TAG;
      long l = this.updateSessionId;
      sendWeatherUpdateStatusIdle(0, localContext, str, l);
    }
  }

  protected void onFinishedUpdateId(int paramInt, boolean paramBoolean)
  {
    if (paramBoolean);
    for (int i = 1; ; i = 999)
    {
      updateStatus(paramInt, i);
      return;
    }
  }

  protected void onStartedUpdate()
  {
    this.logger.d("Update event, broadcasting update in progress...");
    Context localContext = getBaseContext();
    String str = this.TAG;
    long l = sendWeatherUpdateStatusDownloading(0, localContext, str);
    this.updateSessionId = l;
  }

  protected void onStartedUpdateId(int paramInt)
  {
    updateStatus(paramInt, 2);
  }

  protected void updateStatus(int paramInt1, int paramInt2)
  {
    ContentValues localContentValues = new ContentValues();
    Integer localInteger1 = Integer.valueOf(paramInt1);
    localContentValues.put("city_id", localInteger1);
    Integer localInteger2 = Integer.valueOf(paramInt2);
    localContentValues.put("status", localInteger2);
    Integer localInteger3 = Integer.valueOf(this.updateType);
    localContentValues.put("type", localInteger3);
    ContentResolver localContentResolver = getContentResolver();
    Uri localUri1 = WeatherMetaData.UpdateStatusMetaData.getContentUri(getBaseContext());
    Uri localUri2 = localContentResolver.insert(localUri1, localContentValues);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.updateservice.WeatherUpdateService
 * JD-Core Version:    0.6.0
 */