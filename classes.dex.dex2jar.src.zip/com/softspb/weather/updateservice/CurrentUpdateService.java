package com.softspb.weather.updateservice;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import com.softspb.updateservice.DownloadClient;
import com.softspb.util.log.Logger;
import com.softspb.weather.model.CurrentConditions;
import com.softspb.weather.model.WeatherParameterValue;
import com.softspb.weather.provider.WeatherMetaData.CurrentMetaData;

public abstract class CurrentUpdateService extends WeatherUpdateService<CurrentConditions>
{
  public static final String ACTION_UPDATE = "com.softspb.weather.updateservice.action.UpdateCurrent";

  protected abstract DownloadClient<Integer, CurrentConditions> createDownloadClient(Context paramContext);

  protected int getUpdateType()
  {
    return 1;
  }

  protected boolean onDataReceived(CurrentConditions paramCurrentConditions)
  {
    this.logger.d("Current data received.");
    ContentValues localContentValues = new ContentValues();
    Integer localInteger1 = Integer.valueOf(paramCurrentConditions.getCityId());
    localContentValues.put("city_id", localInteger1);
    Integer localInteger2 = Integer.valueOf(paramCurrentConditions.getDateUTC());
    localContentValues.put("date", localInteger2);
    Integer localInteger3 = Integer.valueOf(paramCurrentConditions.getTimeUTC());
    localContentValues.put("time", localInteger3);
    WeatherParameterValue localWeatherParameterValue = paramCurrentConditions.getTemp();
    if (localWeatherParameterValue != null)
    {
      Integer localInteger4 = Integer.valueOf(((Number)localWeatherParameterValue.getValueInDefaultUnits()).intValue());
      localContentValues.put("temp", localInteger4);
    }
    localWeatherParameterValue = paramCurrentConditions.getPressure();
    if (localWeatherParameterValue != null)
    {
      Float localFloat1 = Float.valueOf(((Number)localWeatherParameterValue.getValueInDefaultUnits()).floatValue());
      localContentValues.put("pressure", localFloat1);
    }
    Integer localInteger5 = Integer.valueOf(paramCurrentConditions.getSkyIcon());
    localContentValues.put("sky_icon", localInteger5);
    String str1 = paramCurrentConditions.getLocation();
    localContentValues.put("station", str1);
    localWeatherParameterValue = paramCurrentConditions.getWindDirection();
    if (localWeatherParameterValue != null)
    {
      String str2 = ((Number)localWeatherParameterValue.getValueInDefaultUnits()).toString();
      localContentValues.put("wind_dir", str2);
    }
    localWeatherParameterValue = paramCurrentConditions.getWindSpeed();
    if (localWeatherParameterValue != null)
    {
      Float localFloat2 = Float.valueOf(((Number)localWeatherParameterValue.getValueInDefaultUnits()).floatValue());
      localContentValues.put("wind_speed", localFloat2);
    }
    localWeatherParameterValue = paramCurrentConditions.getRelHumidity();
    if (localWeatherParameterValue != null)
    {
      Float localFloat3 = Float.valueOf(((Number)localWeatherParameterValue.getValueInDefaultUnits()).floatValue());
      localContentValues.put("humidity", localFloat3);
    }
    localWeatherParameterValue = paramCurrentConditions.getDewPoint();
    if (localWeatherParameterValue != null)
    {
      Float localFloat4 = Float.valueOf(((Number)localWeatherParameterValue.getValueInDefaultUnits()).floatValue());
      localContentValues.put("dew_point", localFloat4);
    }
    ContentResolver localContentResolver = getContentResolver();
    Uri localUri1 = WeatherMetaData.CurrentMetaData.getContentUri(getBaseContext());
    Uri localUri2 = localContentResolver.insert(localUri1, localContentValues);
    return true;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.updateservice.CurrentUpdateService
 * JD-Core Version:    0.6.0
 */