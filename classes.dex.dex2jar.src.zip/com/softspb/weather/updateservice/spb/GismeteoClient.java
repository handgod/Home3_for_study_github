package com.softspb.weather.updateservice.spb;

import android.content.Context;
import com.softspb.updateservice.DownloadClient;
import com.softspb.util.DecimalDateTimeEncoding;
import com.softspb.weather.model.Forecast;
import com.softspb.weather.model.ForecastArray;
import com.softspb.weather.model.ForecastBuilder;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.GregorianCalendar;

public class GismeteoClient extends DownloadClient<Integer, ForecastArray>
{
  public static final int GISMETEO_DATA_VERSION = 1;
  private static final String[] SERVER_URLS;
  private String clientToken;

  static
  {
    String[] arrayOfString = new String[4];
    arrayOfString[0] = "http://www.spbtraveler.com/weather/spb_index.php";
    arrayOfString[1] = "http://www.spbtraveler1.com/weather/spb_index.php";
    arrayOfString[2] = "http://www.spbtraveler2.com/weather/spb_index.php";
    arrayOfString[3] = "http://www.spbtraveler3.com/weather/spb_index.php";
    SERVER_URLS = arrayOfString;
  }

  public GismeteoClient(Context paramContext)
  {
    super(arrayOfString);
    String str = ClientToken.getInstance(paramContext).getToken();
    this.clientToken = str;
  }

  static Forecast decodeForecastDataItem(int paramInt, InputStream paramInputStream, byte paramByte)
    throws IOException
  {
    ForecastBuilder localForecastBuilder1 = new ForecastBuilder();
    ForecastBuilder localForecastBuilder2 = localForecastBuilder1.withCityId(paramInt);
    GregorianCalendar localGregorianCalendar = new GregorianCalendar();
    localGregorianCalendar.setTimeInMillis(0L);
    int i = 0;
    if (i < 20)
    {
      int j = paramInputStream.read();
      if (j == -1)
      {
        String str = "Invalid format of Gismeteo data item: enexpected EOF at offset " + i;
        throw new IOException(str);
      }
      int k = paramByte & 0xFF;
      j ^= k;
      switch (i)
      {
      case 15:
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
      case 14:
      case 16:
      case 17:
      case 18:
      case 19:
      }
      while (true)
      {
        i += 1;
        break;
        localGregorianCalendar.set(5, j);
        continue;
        int m = j + -1;
        localGregorianCalendar.set(2, m);
        continue;
        int n = j;
        continue;
        int i1 = j << 8;
        int i2 = 0x0 | i1;
        localGregorianCalendar.set(1, i2);
        continue;
        localGregorianCalendar.set(11, j);
        Date localDate = localGregorianCalendar.getTime();
        int i3 = DecimalDateTimeEncoding.encodeDate(localDate);
        ForecastBuilder localForecastBuilder3 = localForecastBuilder1.withDateLocal(i3);
        int i4 = DecimalDateTimeEncoding.encodeTime(localDate);
        ForecastBuilder localForecastBuilder4 = localForecastBuilder1.withTimeLocal(i4);
        continue;
        ForecastBuilder localForecastBuilder5 = localForecastBuilder1.withCloudiness(j);
        continue;
        ForecastBuilder localForecastBuilder6 = localForecastBuilder1.withPrecipitation(j);
        continue;
        int i5 = j;
        continue;
        int i6 = j << 8;
        float f1 = 0x0 | i6;
        ForecastBuilder localForecastBuilder7 = localForecastBuilder1.withMaxPressMm(f1);
        continue;
        int i7 = j;
        continue;
        int i8 = j << 8;
        float f2 = 0x0 | i8;
        ForecastBuilder localForecastBuilder8 = localForecastBuilder1.withMinPressMm(f2);
        continue;
        int i9 = (byte)j;
        ForecastBuilder localForecastBuilder9 = localForecastBuilder1.withMaxTempC(i9);
        continue;
        int i10 = (byte)j;
        ForecastBuilder localForecastBuilder10 = localForecastBuilder1.withMinTempC(i10);
        continue;
        float f3 = j;
        ForecastBuilder localForecastBuilder11 = localForecastBuilder1.withMaxWindSpeedMps(f3);
        continue;
        float f4 = j;
        ForecastBuilder localForecastBuilder12 = localForecastBuilder1.withMinWindSpeedMps(f4);
        continue;
        float f5 = j;
        ForecastBuilder localForecastBuilder13 = localForecastBuilder1.withMaxHumidityPercents(f5);
        continue;
        float f6 = j;
        ForecastBuilder localForecastBuilder14 = localForecastBuilder1.withMinHumidityPercents(f6);
        continue;
        float f7 = (byte)j;
        ForecastBuilder localForecastBuilder15 = localForecastBuilder1.withMaxHeatIndexC(f7);
        continue;
        float f8 = (byte)j;
        ForecastBuilder localForecastBuilder16 = localForecastBuilder1.withMinHeatIndexC(f8);
      }
    }
    return localForecastBuilder1.build();
  }

  private static ForecastArray decodeGismeteoPacket(int paramInt, InputStream paramInputStream)
    throws IOException
  {
    int i = 0;
    int j = 0;
    int k = paramInputStream.read();
    if (k == -1)
      throw new IOException("Invalid format of Gismeteo data packet: unexpected EOF.");
    if (k != 1)
    {
      String str1 = "Unsupported version of Gismeteo format: " + k;
      throw new IOException(str1);
    }
    int m = 1;
    if (m < 6)
    {
      int n = paramInputStream.read();
      if (n == -1)
      {
        String str2 = "Invalid format of Gismeteo data packet: unexpected EOF at offset " + m;
        throw new IOException(str2);
      }
      switch (m)
      {
      default:
      case 1:
      case 2:
      }
      while (true)
      {
        m += 1;
        break;
        j = (byte)n;
        continue;
        i = n;
      }
    }
    ForecastArray localForecastArray = new ForecastArray(paramInt, i);
    int i1 = 0;
    while (i1 < i)
    {
      Forecast localForecast = decodeForecastDataItem(paramInt, paramInputStream, j);
      localForecastArray.setItem(localForecast, i1);
      i1 += 1;
    }
    return localForecastArray;
  }

  protected String createUrl(String paramString, Integer paramInteger)
  {
    StringBuilder localStringBuilder = new StringBuilder().append(paramString).append("?id=").append(paramInteger).append(38).append("client_token").append(61);
    String str = this.clientToken;
    return str;
  }

  protected ForecastArray parseResponse(InputStream paramInputStream, Integer paramInteger)
    throws IOException
  {
    return decodeGismeteoPacket(paramInteger.intValue(), paramInputStream);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.updateservice.spb.GismeteoClient
 * JD-Core Version:    0.6.0
 */