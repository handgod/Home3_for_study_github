package com.softspb.weather.updateservice.spb;

import android.content.Context;
import com.softspb.updateservice.DownloadClient;
import com.softspb.weather.model.CurrentConditions;
import com.softspb.weather.updateservice.CurrentUpdateService;

public class SPBCurrentUpdateService extends CurrentUpdateService
{
  protected DownloadClient<Integer, CurrentConditions> createDownloadClient(Context paramContext)
  {
    return new CurrentClient(paramContext);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.updateservice.spb.SPBCurrentUpdateService
 * JD-Core Version:    0.6.0
 */