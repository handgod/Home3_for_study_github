package com.softspb.weather.updateservice.spb;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import com.softspb.util.DeviceUtil;

public class ClientToken
{
  public static final String QUERY_PARAM_CLIENT_TOKEN = "client_token";
  private static ClientToken instance;
  private final String token;

  private ClientToken(Context paramContext)
  {
    String str1 = paramContext.getPackageName();
    String str2 = DeviceUtil.getDeviceId(paramContext);
    Object localObject = null;
    try
    {
      PackageInfo localPackageInfo = paramContext.getPackageManager().getPackageInfo(str1, 0);
      String str3 = localPackageInfo.versionName;
      String str4 = Integer.toString(localPackageInfo.versionCode);
      localObject = str4;
      label49: String str5 = createToken(str1, str3, localObject, str2);
      this.token = str5;
      return;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      break label49;
    }
  }

  private String createToken(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    long l1 = getCode(paramString1);
    StringBuilder localStringBuilder2 = localStringBuilder1.append(l1).append(45);
    long l2 = getCode(paramString2);
    StringBuilder localStringBuilder3 = localStringBuilder2.append(l2).append(45);
    long l3 = getCode(paramString3);
    StringBuilder localStringBuilder4 = localStringBuilder3.append(l3).append(45);
    long l4 = getCode(paramString4);
    return l4;
  }

  public static ClientToken getInstance(Context paramContext)
  {
    if (instance == null);
    synchronized (ClientToken.class)
    {
      if (instance == null)
        instance = new ClientToken(paramContext);
      return instance;
    }
  }

  long getCode(String paramString)
  {
    long l1;
    if (paramString == null)
    {
      l1 = 0L;
      return l1;
    }
    int i = paramString.hashCode();
    if (i >= 0)
      l1 = i;
    while (true)
    {
      break;
      long l2 = i;
      l1 = 4294967296L + l2;
    }
  }

  public String getToken()
  {
    return this.token;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.updateservice.spb.ClientToken
 * JD-Core Version:    0.6.0
 */