package com.softspb.weather.updateservice.spb;

import android.content.Context;
import com.softspb.updateservice.DownloadClient;
import com.softspb.weather.updateservice.ForecastUpdateService;

public class SPBForecastUpdateService extends ForecastUpdateService
{
  protected DownloadClient createDownloadClient(Context paramContext)
  {
    return new GismeteoClient(paramContext);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.updateservice.spb.SPBForecastUpdateService
 * JD-Core Version:    0.6.0
 */