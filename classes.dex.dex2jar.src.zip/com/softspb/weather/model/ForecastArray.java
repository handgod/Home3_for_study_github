package com.softspb.weather.model;

import com.softspb.util.DecimalDateTimeEncoding;
import java.util.Date;
import java.util.Random;

public class ForecastArray
{
  private static Random random;
  final int cityId;
  final Forecast[] items;

  public ForecastArray(int paramInt1, int paramInt2)
  {
    this.cityId = paramInt1;
    Forecast[] arrayOfForecast = new Forecast[paramInt2];
    this.items = arrayOfForecast;
  }

  public static ForecastArray generateRandom(int paramInt1, int paramInt2, int paramInt3)
  {
    return generateRandom(paramInt1, paramInt2, paramInt3, 0);
  }

  public static ForecastArray generateRandom(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    if (random == null)
    {
      long l = System.currentTimeMillis();
      random = new Random(l);
    }
    ForecastArray localForecastArray = new ForecastArray(paramInt2, paramInt1);
    int i = 1;
    int j = 0;
    while (true)
    {
      int k = localForecastArray.size();
      if (j >= k)
        break;
      Date localDate = DecimalDateTimeEncoding.decodeDate(paramInt3);
      int m = j % 4 * 6 + 3;
      localDate.setHours(m);
      Forecast localForecast = Forecast.generateRandom(paramInt2, localDate);
      if (paramBoolean)
      {
        localForecast.timeLocal = i;
        if (i + 1 <= 4);
      }
      localForecastArray.setItem(localForecast, j);
      if (j % 4 == 3)
        paramInt3 = DecimalDateTimeEncoding.add(paramInt3, 1);
      j += 1;
    }
    return localForecastArray;
  }

  public int getCityID()
  {
    return this.cityId;
  }

  public Forecast getItem(int paramInt)
  {
    if (this.items == null)
      throw new IndexOutOfBoundsException("Data not available.");
    return this.items[paramInt];
  }

  public Forecast[] getItems()
  {
    return this.items;
  }

  public void setItem(Forecast paramForecast, int paramInt)
  {
    int i = paramForecast.getCityId();
    if (this.cityId != i)
    {
      StringBuilder localStringBuilder = new StringBuilder().append("Unexpected cityId: ").append(i).append(", expected ");
      int j = this.cityId;
      String str = j;
      throw new IllegalArgumentException(str);
    }
    this.items[paramInt] = paramForecast;
  }

  public int size()
  {
    if (this.items == null);
    for (int i = 0; ; i = this.items.length)
      return i;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.model.ForecastArray
 * JD-Core Version:    0.6.0
 */