package com.softspb.weather.model;

import android.content.Context;

public class WeatherParameterValue<T>
{
  static final String WIND_DIRECTION_VARIABLE_CODE = "VRB";
  private int mUnits;
  private T mValue;
  private WeatherParameter<T> paramDescr;

  private WeatherParameterValue(T paramT, WeatherParameter<T> paramWeatherParameter, int paramInt)
  {
    this.mValue = paramT;
    this.paramDescr = paramWeatherParameter;
    this.mUnits = paramInt;
  }

  public static WeatherParameterValue<Number> createDewPointCelsius(int paramInt)
  {
    Integer localInteger = Integer.valueOf(paramInt);
    WeatherParameter localWeatherParameter = WeatherParameter.DEW_POINT;
    return new WeatherParameterValue(localInteger, localWeatherParameter, 0);
  }

  public static WeatherParameterValue<Number> createDewPointDefaultUnits(int paramInt)
  {
    Integer localInteger = Integer.valueOf(paramInt);
    WeatherParameter localWeatherParameter = WeatherParameter.DEW_POINT;
    int i = WeatherParameter.TEMPERATURE.getDefaultUnits();
    return new WeatherParameterValue(localInteger, localWeatherParameter, i);
  }

  public static WeatherParameterValue<Number> createDewPointFahrenheit(int paramInt)
  {
    Integer localInteger = Integer.valueOf(paramInt);
    WeatherParameter localWeatherParameter = WeatherParameter.DEW_POINT;
    return new WeatherParameterValue(localInteger, localWeatherParameter, 1);
  }

  public static WeatherParameterValue<Number> createPressureAtm(float paramFloat)
  {
    Float localFloat = Float.valueOf(paramFloat);
    WeatherParameter localWeatherParameter = WeatherParameter.PRESSURE;
    return new WeatherParameterValue(localFloat, localWeatherParameter, 2);
  }

  public static WeatherParameterValue<Number> createPressureDefaultUnits(float paramFloat)
  {
    Float localFloat = Float.valueOf(paramFloat);
    WeatherParameter localWeatherParameter = WeatherParameter.PRESSURE;
    int i = WeatherParameter.PRESSURE.getDefaultUnits();
    return new WeatherParameterValue(localFloat, localWeatherParameter, i);
  }

  public static WeatherParameterValue<Number> createPressureHpa(float paramFloat)
  {
    Float localFloat = Float.valueOf(paramFloat);
    WeatherParameter localWeatherParameter = WeatherParameter.PRESSURE;
    return new WeatherParameterValue(localFloat, localWeatherParameter, 3);
  }

  public static WeatherParameterValue<Number> createPressureIn(float paramFloat)
  {
    Float localFloat = Float.valueOf(paramFloat);
    WeatherParameter localWeatherParameter = WeatherParameter.PRESSURE;
    return new WeatherParameterValue(localFloat, localWeatherParameter, 1);
  }

  public static WeatherParameterValue<Number> createPressureMm(float paramFloat)
  {
    Float localFloat = Float.valueOf(paramFloat);
    WeatherParameter localWeatherParameter = WeatherParameter.PRESSURE;
    return new WeatherParameterValue(localFloat, localWeatherParameter, 0);
  }

  public static WeatherParameterValue<Number> createRelHumidityDefaultUnits(float paramFloat)
  {
    Float localFloat = Float.valueOf(paramFloat);
    WeatherParameter localWeatherParameter = WeatherParameter.RELATIVE_HUMIDITY;
    int i = WeatherParameter.RELATIVE_HUMIDITY.getDefaultUnits();
    return new WeatherParameterValue(localFloat, localWeatherParameter, i);
  }

  public static WeatherParameterValue<Number> createRelHumidityPercents(float paramFloat)
  {
    Float localFloat = Float.valueOf(paramFloat);
    WeatherParameter localWeatherParameter = WeatherParameter.RELATIVE_HUMIDITY;
    return new WeatherParameterValue(localFloat, localWeatherParameter, 0);
  }

  public static WeatherParameterValue<Number> createTemperatureCelsius(int paramInt)
  {
    Integer localInteger = Integer.valueOf(paramInt);
    WeatherParameter localWeatherParameter = WeatherParameter.TEMPERATURE;
    return new WeatherParameterValue(localInteger, localWeatherParameter, 0);
  }

  public static WeatherParameterValue<Number> createTemperatureDefaultUnits(int paramInt)
  {
    Integer localInteger = Integer.valueOf(paramInt);
    WeatherParameter localWeatherParameter = WeatherParameter.TEMPERATURE;
    int i = WeatherParameter.TEMPERATURE.getDefaultUnits();
    return new WeatherParameterValue(localInteger, localWeatherParameter, i);
  }

  public static WeatherParameterValue<Number> createTemperatureFahrenheit(int paramInt)
  {
    Integer localInteger = Integer.valueOf(paramInt);
    WeatherParameter localWeatherParameter = WeatherParameter.TEMPERATURE;
    return new WeatherParameterValue(localInteger, localWeatherParameter, 1);
  }

  static WeatherParameterValue<Number> createWindDirection(String paramString, int paramInt)
  {
    Object localObject = Double.valueOf((0.0D / 0.0D));
    if ((paramString != null) && (!"VRB".equals(paramString)));
    try
    {
      Double localDouble = Double.valueOf(Double.parseDouble(paramString));
      localObject = localDouble;
      label30: WeatherParameter localWeatherParameter = WeatherParameter.WIND_DIRECTION;
      return new WeatherParameterValue(localObject, localWeatherParameter, paramInt);
    }
    catch (NumberFormatException localNumberFormatException)
    {
      break label30;
    }
  }

  public static WeatherParameterValue<Number> createWindDirectionDefaultValues(String paramString)
  {
    return createWindDirection(paramString, 1);
  }

  public static WeatherParameterValue<Number> createWindDirectionDegrees(double paramDouble)
  {
    Double localDouble = Double.valueOf(paramDouble);
    WeatherParameter localWeatherParameter = WeatherParameter.WIND_DIRECTION;
    return new WeatherParameterValue(localDouble, localWeatherParameter, 2);
  }

  public static WeatherParameterValue<Number> createWindDirectionDegrees(String paramString)
  {
    return createWindDirection(paramString, 2);
  }

  public static WeatherParameterValue<Number> createWindSpeedDefaultUnits(float paramFloat)
  {
    Float localFloat = Float.valueOf(paramFloat);
    WeatherParameter localWeatherParameter = WeatherParameter.WIND_SPEED;
    int i = WeatherParameter.WIND_SPEED.getDefaultUnits();
    return new WeatherParameterValue(localFloat, localWeatherParameter, i);
  }

  public static WeatherParameterValue<Number> createWindSpeedKmph(float paramFloat)
  {
    Float localFloat = Float.valueOf(paramFloat);
    WeatherParameter localWeatherParameter = WeatherParameter.WIND_SPEED;
    return new WeatherParameterValue(localFloat, localWeatherParameter, 3);
  }

  public static WeatherParameterValue<Number> createWindSpeedKnots(float paramFloat)
  {
    Float localFloat = Float.valueOf(paramFloat);
    WeatherParameter localWeatherParameter = WeatherParameter.WIND_SPEED;
    return new WeatherParameterValue(localFloat, localWeatherParameter, 1);
  }

  public static WeatherParameterValue<Number> createWindSpeedMph(float paramFloat)
  {
    Float localFloat = Float.valueOf(paramFloat);
    WeatherParameter localWeatherParameter = WeatherParameter.WIND_SPEED;
    return new WeatherParameterValue(localFloat, localWeatherParameter, 0);
  }

  public static WeatherParameterValue<Number> createWindSpeedMps(float paramFloat)
  {
    Float localFloat = Float.valueOf(paramFloat);
    WeatherParameter localWeatherParameter = WeatherParameter.WIND_SPEED;
    return new WeatherParameterValue(localFloat, localWeatherParameter, 2);
  }

  public String format(int paramInt, Context paramContext)
  {
    int i = this.mUnits;
    if (paramInt == i);
    WeatherParameter localWeatherParameter;
    Object localObject2;
    int j;
    for (Object localObject1 = this.mValue; ; localObject1 = localWeatherParameter.convert(localObject2, j, paramInt))
    {
      return this.paramDescr.format(localObject1, paramInt, paramContext);
      localWeatherParameter = this.paramDescr;
      localObject2 = this.mValue;
      j = this.mUnits;
    }
  }

  public int getInt1000(int paramInt)
  {
    Object localObject = getValue(paramInt);
    if ((localObject instanceof Integer));
    for (int i = ((Integer)localObject).intValue() * 1000; ; i = (int)Math.round(((Number)localObject).doubleValue() * 1000.0D))
    {
      return i;
      if (!(localObject instanceof Number))
        break;
    }
    String str = "Weather parameter value is not integer: " + this;
    throw new NumberFormatException(str);
  }

  public T getValue(int paramInt)
  {
    int i = this.mUnits;
    if (paramInt == i);
    WeatherParameter localWeatherParameter;
    Object localObject2;
    int j;
    for (Object localObject1 = this.mValue; ; localObject1 = localWeatherParameter.convert(localObject2, j, paramInt))
    {
      return localObject1;
      localWeatherParameter = this.paramDescr;
      localObject2 = this.mValue;
      j = this.mUnits;
    }
  }

  public T getValueInDefaultUnits()
  {
    int i = this.paramDescr.getDefaultUnits();
    if (this.mUnits == i);
    WeatherParameter localWeatherParameter;
    Object localObject2;
    int j;
    for (Object localObject1 = this.mValue; ; localObject1 = localWeatherParameter.convert(localObject2, j, i))
    {
      return localObject1;
      localWeatherParameter = this.paramDescr;
      localObject2 = this.mValue;
      j = this.mUnits;
    }
  }

  public WeatherParameter<T> getWeatherParameter()
  {
    return this.paramDescr;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.model.WeatherParameterValue
 * JD-Core Version:    0.6.0
 */