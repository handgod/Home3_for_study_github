package com.softspb.weather.model;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class UpdateStatus
  implements Parcelable
{
  public static final Parcelable.Creator<UpdateStatus> CREATOR = ;
  public static final int UPDATE_STATUS_FAILED = 999;
  public static final int UPDATE_STATUS_OK = 1;
  public static final int UPDATE_STATUS_UNKNOWN = 0;
  public static final int UPDATE_STATUS_UPDATING = 2;
  public int cityId;
  public int currentConditionsStatus;
  public int forecastStatus;
  public long latestCurrentConditionsTimestamp;
  public long latestForecastTimestamp;
  public long latestSuccessfulCurrentConditionsTimestamp;
  public long latestSuccessfulForecastTimestamp;
  public int positioningStatus;

  public UpdateStatus(int paramInt)
  {
    this.cityId = paramInt;
  }

  private UpdateStatus(Parcel paramParcel)
  {
    int i = paramParcel.readInt();
    this.cityId = i;
    long l1 = paramParcel.readLong();
    this.latestCurrentConditionsTimestamp = l1;
    long l2 = paramParcel.readLong();
    this.latestForecastTimestamp = l2;
    long l3 = paramParcel.readLong();
    this.latestSuccessfulCurrentConditionsTimestamp = l3;
    long l4 = paramParcel.readLong();
    this.latestSuccessfulForecastTimestamp = l4;
    int j = paramParcel.readInt();
    this.currentConditionsStatus = j;
    int k = paramParcel.readInt();
    this.forecastStatus = k;
    int m = paramParcel.readInt();
    this.positioningStatus = m;
  }

  public UpdateStatus(UpdateStatus paramUpdateStatus, int paramInt)
  {
    this.cityId = paramInt;
    long l1 = paramUpdateStatus.latestCurrentConditionsTimestamp;
    this.latestCurrentConditionsTimestamp = l1;
    long l2 = paramUpdateStatus.latestForecastTimestamp;
    this.latestForecastTimestamp = l2;
    long l3 = paramUpdateStatus.latestSuccessfulForecastTimestamp;
    this.latestSuccessfulForecastTimestamp = l3;
    long l4 = paramUpdateStatus.latestSuccessfulCurrentConditionsTimestamp;
    this.latestSuccessfulCurrentConditionsTimestamp = l4;
    int i = paramUpdateStatus.currentConditionsStatus;
    this.currentConditionsStatus = i;
    int j = paramUpdateStatus.forecastStatus;
    this.forecastStatus = j;
    int k = paramUpdateStatus.positioningStatus;
    this.positioningStatus = k;
  }

  public int describeContents()
  {
    return 0;
  }

  public long getLatestSuccessfulUpdateTimestamp()
  {
    long l1 = this.latestSuccessfulCurrentConditionsTimestamp;
    long l2 = this.latestSuccessfulForecastTimestamp;
    long l3;
    if (l1 > l2)
      l3 = this.latestSuccessfulCurrentConditionsTimestamp;
    while (true)
    {
      return l3;
      l3 = this.latestSuccessfulForecastTimestamp;
    }
  }

  public int getOverallStatus()
  {
    int i = 1;
    if ((this.forecastStatus == 999) || (this.currentConditionsStatus == 999) || (this.positioningStatus == 999))
      i = 999;
    while (true)
    {
      return i;
      if ((this.forecastStatus == 2) || (this.currentConditionsStatus == 2) || (this.positioningStatus == 2))
      {
        i = 2;
        continue;
      }
      if ((this.forecastStatus == 1) || (this.currentConditionsStatus == 1) || (this.positioningStatus == 1))
        continue;
      i = 0;
    }
  }

  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("UpdateStatus[cityId=");
    int i = this.cityId;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(i).append(" lct=");
    long l1 = this.latestCurrentConditionsTimestamp;
    StringBuilder localStringBuilder3 = localStringBuilder2.append(l1).append(" lft=");
    long l2 = this.latestForecastTimestamp;
    StringBuilder localStringBuilder4 = localStringBuilder3.append(l2).append(" lsct=");
    long l3 = this.latestSuccessfulCurrentConditionsTimestamp;
    StringBuilder localStringBuilder5 = localStringBuilder4.append(l3).append(" lsft=");
    long l4 = this.latestSuccessfulForecastTimestamp;
    StringBuilder localStringBuilder6 = localStringBuilder5.append(l4).append(" cs=");
    int j = this.currentConditionsStatus;
    StringBuilder localStringBuilder7 = localStringBuilder6.append(j).append(" fs=");
    int k = this.forecastStatus;
    StringBuilder localStringBuilder8 = localStringBuilder7.append(k).append(" ps=");
    int m = this.positioningStatus;
    return m + "]";
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    int i = this.cityId;
    paramParcel.writeInt(i);
    long l1 = this.latestCurrentConditionsTimestamp;
    paramParcel.writeLong(l1);
    long l2 = this.latestForecastTimestamp;
    paramParcel.writeLong(l2);
    long l3 = this.latestSuccessfulCurrentConditionsTimestamp;
    paramParcel.writeLong(l3);
    long l4 = this.latestSuccessfulForecastTimestamp;
    paramParcel.writeLong(l4);
    int j = this.currentConditionsStatus;
    paramParcel.writeInt(j);
    int k = this.forecastStatus;
    paramParcel.writeInt(k);
    int m = this.positioningStatus;
    paramParcel.writeInt(m);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.model.UpdateStatus
 * JD-Core Version:    0.6.0
 */