package com.softspb.weather.model;

public class ForecastBuilder
{
  private int cityId;
  private int cloud;
  private int dateLocal;
  private WeatherParameterValue<Number> maxHeatIndex;
  private WeatherParameterValue<Number> maxHumidity;
  private WeatherParameterValue<Number> maxPress;
  private WeatherParameterValue<Number> maxTemp;
  private WeatherParameterValue<Number> maxWindSpeed;
  private WeatherParameterValue<Number> minHeatIndex;
  private WeatherParameterValue<Number> minHumidity;
  private WeatherParameterValue<Number> minPress;
  private WeatherParameterValue<Number> minTemp;
  private WeatherParameterValue<Number> minWindSpeed;
  private int precip;
  private int timeLocal;
  private long timestamp;
  private WeatherParameterValue<Number> windDirection;

  public Forecast build()
  {
    Forecast localForecast = new Forecast();
    int i = this.cityId;
    localForecast.cityId = i;
    int j = this.dateLocal;
    localForecast.dateLocal = j;
    int k = this.timeLocal;
    localForecast.timeLocal = k;
    int m = this.cloud;
    localForecast.cloud = m;
    int n = this.precip;
    localForecast.precip = n;
    WeatherParameterValue localWeatherParameterValue1 = this.minPress;
    localForecast.minPress = localWeatherParameterValue1;
    WeatherParameterValue localWeatherParameterValue2 = this.maxPress;
    localForecast.maxPress = localWeatherParameterValue2;
    WeatherParameterValue localWeatherParameterValue3 = this.minTemp;
    localForecast.minTemp = localWeatherParameterValue3;
    WeatherParameterValue localWeatherParameterValue4 = this.maxTemp;
    localForecast.maxTemp = localWeatherParameterValue4;
    WeatherParameterValue localWeatherParameterValue5 = this.minWindSpeed;
    localForecast.minWindSpeed = localWeatherParameterValue5;
    WeatherParameterValue localWeatherParameterValue6 = this.maxWindSpeed;
    localForecast.maxWindSpeed = localWeatherParameterValue6;
    WeatherParameterValue localWeatherParameterValue7 = this.windDirection;
    localForecast.windDirection = localWeatherParameterValue7;
    WeatherParameterValue localWeatherParameterValue8 = this.minHumidity;
    localForecast.minHumidity = localWeatherParameterValue8;
    WeatherParameterValue localWeatherParameterValue9 = this.maxHumidity;
    localForecast.maxHumidity = localWeatherParameterValue9;
    WeatherParameterValue localWeatherParameterValue10 = this.minHeatIndex;
    localForecast.minHeatIndex = localWeatherParameterValue10;
    WeatherParameterValue localWeatherParameterValue11 = this.maxHeatIndex;
    localForecast.maxHeatIndex = localWeatherParameterValue11;
    long l = this.timestamp;
    localForecast.timestamp = l;
    return localForecast;
  }

  public ForecastBuilder withCityId(int paramInt)
  {
    this.cityId = paramInt;
    return this;
  }

  public ForecastBuilder withCloudiness(int paramInt)
  {
    this.cloud = paramInt;
    return this;
  }

  public ForecastBuilder withDateLocal(int paramInt)
  {
    this.dateLocal = paramInt;
    return this;
  }

  public ForecastBuilder withMaxHeatIndexC(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureCelsius((int)paramFloat);
    this.maxHeatIndex = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withMaxHeatIndexDefaultUnits(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureDefaultUnits((int)paramFloat);
    this.maxHeatIndex = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withMaxHumidityDefaultUnits(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createRelHumidityDefaultUnits(paramFloat);
    this.maxHumidity = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withMaxHumidityPercents(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createRelHumidityPercents(paramFloat);
    this.maxHumidity = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withMaxPressDefaultUnits(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createPressureDefaultUnits(paramFloat);
    this.maxPress = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withMaxPressMm(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createPressureDefaultUnits(paramFloat);
    this.maxPress = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withMaxTempC(int paramInt)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureCelsius(paramInt);
    this.maxTemp = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withMaxTempDefaultUnits(int paramInt)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureDefaultUnits(paramInt);
    this.maxTemp = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withMaxWindSpeedDefaultUnits(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createWindSpeedDefaultUnits(paramFloat);
    this.maxWindSpeed = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withMaxWindSpeedMps(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createWindSpeedMps(paramFloat);
    this.maxWindSpeed = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withMinHeatIndexC(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureCelsius((int)paramFloat);
    this.minHeatIndex = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withMinHeatIndexDefaultUnits(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureDefaultUnits((int)paramFloat);
    this.minHeatIndex = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withMinHumidityDefaultUnits(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createRelHumidityDefaultUnits(paramFloat);
    this.minHumidity = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withMinHumidityPercents(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createRelHumidityPercents(paramFloat);
    this.minHumidity = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withMinPressDefaultUnits(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createPressureDefaultUnits(paramFloat);
    this.minPress = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withMinPressMm(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createPressureMm(paramFloat);
    this.minPress = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withMinTempC(int paramInt)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureCelsius(paramInt);
    this.minTemp = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withMinTempDefaultUnits(int paramInt)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureDefaultUnits(paramInt);
    this.minTemp = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withMinWindSpeedDefaultUnits(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createWindSpeedDefaultUnits(paramFloat);
    this.minWindSpeed = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withMinWindSpeedMps(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createWindSpeedMps(paramFloat);
    this.minWindSpeed = localWeatherParameterValue;
    return this;
  }

  public ForecastBuilder withPrecipitation(int paramInt)
  {
    this.precip = paramInt;
    return this;
  }

  public ForecastBuilder withTimeLocal(int paramInt)
  {
    this.timeLocal = paramInt;
    return this;
  }

  public ForecastBuilder withTimestamp(long paramLong)
  {
    this.timestamp = paramLong;
    return this;
  }

  public ForecastBuilder withWindDirectionDefaultUnits(String paramString)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createWindDirectionDefaultValues(paramString);
    this.windDirection = localWeatherParameterValue;
    return this;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.model.ForecastBuilder
 * JD-Core Version:    0.6.0
 */