package com.softspb.weather.model;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.softspb.util.DecimalDateTimeEncoding;
import java.util.Random;

public class CurrentConditions
  implements Parcelable
{
  public static final Parcelable.Creator<CurrentConditions> CREATOR = new CurrentConditions.1();
  private static Random random;
  String airportICAOCode;
  int cityId;
  String dataSource;
  int dateUTC;
  WeatherParameterValue<Number> dewPoint;
  WeatherParameterValue<Number> heatIndex;
  WeatherParameterValue<Number> humidex;
  String latitude;
  String location;
  String longitude;
  String metar;
  WeatherParameterValue<Number> press;
  WeatherParameterValue<Number> relHumidity;
  int skyIcon;
  WeatherParameterValue<Number> temp;
  int timeUTC;
  long timestamp;
  WeatherParameterValue<Number> visibility;
  String weather;
  WeatherParameterValue<Number> windChill;
  WeatherParameterValue<Number> windDir;
  WeatherParameterValue<Number> windSpeed;

  CurrentConditions()
  {
  }

  private CurrentConditions(Parcel paramParcel)
  {
    readFromParcel(paramParcel);
  }

  public static CurrentConditions createSimple(WeatherParameterValue<Number> paramWeatherParameterValue1, int paramInt, WeatherParameterValue<Number> paramWeatherParameterValue2, WeatherParameterValue<Number> paramWeatherParameterValue3, WeatherParameterValue<Number> paramWeatherParameterValue4, WeatherParameterValue<Number> paramWeatherParameterValue5)
  {
    CurrentConditions localCurrentConditions = new CurrentConditions();
    localCurrentConditions.temp = paramWeatherParameterValue1;
    localCurrentConditions.skyIcon = paramInt;
    localCurrentConditions.windSpeed = paramWeatherParameterValue2;
    localCurrentConditions.press = paramWeatherParameterValue3;
    localCurrentConditions.relHumidity = paramWeatherParameterValue4;
    localCurrentConditions.dewPoint = paramWeatherParameterValue5;
    return localCurrentConditions;
  }

  public static CurrentConditions generateRandom(int paramInt)
  {
    if (random == null)
    {
      long l = System.currentTimeMillis();
      random = new Random(l);
    }
    CurrentConditions localCurrentConditions = new CurrentConditions();
    localCurrentConditions.cityId = paramInt;
    int i = random.nextInt(30) + 1;
    localCurrentConditions.skyIcon = i;
    WeatherParameterValue localWeatherParameterValue1 = WeatherParameterValue.createTemperatureDefaultUnits(random.nextInt(100) + -50);
    localCurrentConditions.temp = localWeatherParameterValue1;
    WeatherParameterValue localWeatherParameterValue2 = WeatherParameterValue.createDewPointDefaultUnits(random.nextInt(20) + -10);
    localCurrentConditions.dewPoint = localWeatherParameterValue2;
    WeatherParameterValue localWeatherParameterValue3 = WeatherParameterValue.createRelHumidityDefaultUnits(random.nextFloat() * 100.0F);
    localCurrentConditions.relHumidity = localWeatherParameterValue3;
    WeatherParameterValue localWeatherParameterValue4 = WeatherParameterValue.createWindDirectionDefaultValues("VRB");
    localCurrentConditions.windDir = localWeatherParameterValue4;
    WeatherParameterValue localWeatherParameterValue5 = WeatherParameterValue.createWindSpeedDefaultUnits(random.nextFloat() * 50.0F);
    localCurrentConditions.windSpeed = localWeatherParameterValue5;
    WeatherParameterValue localWeatherParameterValue6 = WeatherParameterValue.createPressureDefaultUnits(random.nextFloat() * 200.0F + 650.0F);
    localCurrentConditions.press = localWeatherParameterValue6;
    StringBuilder localStringBuilder1 = new StringBuilder().append("Location-");
    String str1 = Integer.toHexString(random.nextInt(1000)).toUpperCase();
    String str2 = str1;
    localCurrentConditions.location = str2;
    StringBuilder localStringBuilder2 = new StringBuilder().append("Station-");
    String str3 = Integer.toHexString(random.nextInt(1000)).toUpperCase();
    String str4 = str3;
    localCurrentConditions.airportICAOCode = str4;
    String str5 = Float.toString(random.nextFloat() * 180.0F - 90.0F);
    localCurrentConditions.latitude = str5;
    float f = random.nextFloat();
    String str6 = Float.toString(360.0F * f - 180.0F);
    localCurrentConditions.longitude = str6;
    int j = DecimalDateTimeEncoding.getTodayDateEncoded();
    localCurrentConditions.dateUTC = j;
    int k = DecimalDateTimeEncoding.getTimeNowEncoded();
    localCurrentConditions.timeUTC = k;
    return localCurrentConditions;
  }

  public int describeContents()
  {
    return 0;
  }

  public String getAirportICAOCode()
  {
    return this.airportICAOCode;
  }

  public int getCityId()
  {
    return this.cityId;
  }

  public String getDataSource()
  {
    return this.dataSource;
  }

  public int getDateUTC()
  {
    return this.dateUTC;
  }

  public WeatherParameterValue<Number> getDewPoint()
  {
    return this.dewPoint;
  }

  public WeatherParameterValue<Number> getHeatIndex()
  {
    return this.heatIndex;
  }

  public WeatherParameterValue<Number> getHumidex()
  {
    return this.humidex;
  }

  public String getLatitude()
  {
    return this.latitude;
  }

  public String getLocation()
  {
    return this.location;
  }

  public String getLongitude()
  {
    return this.longitude;
  }

  public String getMetar()
  {
    return this.metar;
  }

  public WeatherParameterValue<Number> getPressure()
  {
    return this.press;
  }

  public WeatherParameterValue<Number> getRelHumidity()
  {
    return this.relHumidity;
  }

  public int getSkyIcon()
  {
    return this.skyIcon;
  }

  public WeatherParameterValue<Number> getTemp()
  {
    return this.temp;
  }

  public int getTimeUTC()
  {
    return this.timeUTC;
  }

  public long getTimestamp()
  {
    return this.timestamp;
  }

  public WeatherParameterValue<Number> getVisibility()
  {
    return this.visibility;
  }

  public String getWeather()
  {
    return this.weather;
  }

  public WeatherParameterValue<Number> getWindChill()
  {
    return this.windChill;
  }

  public WeatherParameterValue<Number> getWindDirection()
  {
    return this.windDir;
  }

  public WeatherParameterValue<Number> getWindSpeed()
  {
    return this.windSpeed;
  }

  public void readFromParcel(Parcel paramParcel)
  {
    int i = paramParcel.readInt();
    this.cityId = i;
    int j = paramParcel.readInt();
    this.dateUTC = j;
    int k = paramParcel.readInt();
    this.timeUTC = k;
    WeatherParameterValue localWeatherParameterValue1 = WeatherParameterValue.createTemperatureDefaultUnits(paramParcel.readInt());
    this.temp = localWeatherParameterValue1;
    WeatherParameterValue localWeatherParameterValue2 = WeatherParameterValue.createPressureDefaultUnits(paramParcel.readFloat());
    this.press = localWeatherParameterValue2;
    WeatherParameterValue localWeatherParameterValue3 = WeatherParameterValue.createRelHumidityDefaultUnits(paramParcel.readFloat());
    this.relHumidity = localWeatherParameterValue3;
    WeatherParameterValue localWeatherParameterValue4 = WeatherParameterValue.createWindDirectionDegrees(paramParcel.readDouble());
    this.windDir = localWeatherParameterValue4;
    WeatherParameterValue localWeatherParameterValue5 = WeatherParameterValue.createWindSpeedDefaultUnits(paramParcel.readFloat());
    this.windSpeed = localWeatherParameterValue5;
    WeatherParameterValue localWeatherParameterValue6 = WeatherParameterValue.createDewPointDefaultUnits(paramParcel.readInt());
    this.dewPoint = localWeatherParameterValue6;
    int m = paramParcel.readInt();
    this.skyIcon = m;
    String str = paramParcel.readString();
    this.location = str;
    long l = paramParcel.readLong();
    this.timestamp = l;
  }

  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("CurrentConditions: date=");
    int i = getDateUTC();
    StringBuilder localStringBuilder2 = localStringBuilder1.append(i).append(" time=");
    int j = getTimeUTC();
    StringBuilder localStringBuilder3 = localStringBuilder2.append(j).append(" timestamp=");
    long l = getTimestamp();
    StringBuilder localStringBuilder4 = localStringBuilder3.append(l);
    if (this.temp != null)
    {
      StringBuilder localStringBuilder5 = localStringBuilder4.append(" temp=");
      Object localObject1 = this.temp.getValueInDefaultUnits();
      StringBuilder localStringBuilder6 = localStringBuilder5.append(localObject1);
    }
    if (this.press != null)
    {
      StringBuilder localStringBuilder7 = localStringBuilder4.append(" press=");
      Object localObject2 = this.press.getValueInDefaultUnits();
      StringBuilder localStringBuilder8 = localStringBuilder7.append(localObject2);
    }
    if (this.windSpeed != null)
    {
      StringBuilder localStringBuilder9 = localStringBuilder4.append(" windSpeed=");
      Object localObject3 = this.windSpeed.getValueInDefaultUnits();
      StringBuilder localStringBuilder10 = localStringBuilder9.append(localObject3);
    }
    if (this.relHumidity != null)
    {
      StringBuilder localStringBuilder11 = localStringBuilder4.append(" relHum=");
      Object localObject4 = this.relHumidity.getValueInDefaultUnits();
      StringBuilder localStringBuilder12 = localStringBuilder11.append(localObject4);
    }
    if (this.dewPoint != null)
    {
      StringBuilder localStringBuilder13 = localStringBuilder4.append(" dewPoint=");
      Object localObject5 = this.dewPoint.getValueInDefaultUnits();
      StringBuilder localStringBuilder14 = localStringBuilder13.append(localObject5);
    }
    if (this.windDir != null)
    {
      StringBuilder localStringBuilder15 = localStringBuilder4.append(" windDir=");
      Object localObject6 = this.windDir.getValue(2);
      StringBuilder localStringBuilder16 = localStringBuilder15.append(localObject6);
    }
    return localStringBuilder4.toString();
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    int i = this.cityId;
    paramParcel.writeInt(i);
    int j = this.dateUTC;
    paramParcel.writeInt(j);
    int k = this.timeUTC;
    paramParcel.writeInt(k);
    int m = ((Number)this.temp.getValueInDefaultUnits()).intValue();
    paramParcel.writeInt(m);
    float f1 = ((Number)this.press.getValueInDefaultUnits()).floatValue();
    paramParcel.writeFloat(f1);
    float f2 = ((Number)this.relHumidity.getValueInDefaultUnits()).floatValue();
    paramParcel.writeFloat(f2);
    double d = ((Number)this.windDir.getValue(2)).doubleValue();
    paramParcel.writeDouble(d);
    float f3 = ((Number)this.windSpeed.getValueInDefaultUnits()).floatValue();
    paramParcel.writeFloat(f3);
    int n = ((Number)this.dewPoint.getValueInDefaultUnits()).intValue();
    paramParcel.writeInt(n);
    int i1 = this.skyIcon;
    paramParcel.writeInt(i1);
    String str = this.location;
    paramParcel.writeString(str);
    long l = this.timestamp;
    paramParcel.writeLong(l);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.model.CurrentConditions
 * JD-Core Version:    0.6.0
 */