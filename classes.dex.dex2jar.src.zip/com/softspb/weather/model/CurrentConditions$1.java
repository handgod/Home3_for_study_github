package com.softspb.weather.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class CurrentConditions$1
  implements Parcelable.Creator<CurrentConditions>
{
  public CurrentConditions createFromParcel(Parcel paramParcel)
  {
    return new CurrentConditions(paramParcel, null);
  }

  public CurrentConditions[] newArray(int paramInt)
  {
    return new CurrentConditions[paramInt];
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.model.CurrentConditions.1
 * JD-Core Version:    0.6.0
 */