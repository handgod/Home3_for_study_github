package com.softspb.weather.model;

final class WeatherParameter$3 extends WeatherParameter<Number>
{
  Number convert(Number paramNumber, int paramInt1, int paramInt2)
  {
    if (paramInt1 != 0)
    {
      String str1 = "Unsupported relative humidity units: " + paramInt1;
      throw new IllegalArgumentException(str1);
    }
    if (paramInt2 != 0)
    {
      String str2 = "Unsupported relative humidity units: " + paramInt2;
      throw new IllegalArgumentException(str2);
    }
    return paramNumber;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.model.WeatherParameter.3
 * JD-Core Version:    0.6.0
 */