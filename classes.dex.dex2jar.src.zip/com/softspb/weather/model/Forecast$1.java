package com.softspb.weather.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class Forecast$1
  implements Parcelable.Creator<Forecast>
{
  public Forecast createFromParcel(Parcel paramParcel)
  {
    return new Forecast(paramParcel, null);
  }

  public Forecast[] newArray(int paramInt)
  {
    return new Forecast[paramInt];
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.model.Forecast.1
 * JD-Core Version:    0.6.0
 */