package com.softspb.weather.model;

public class CurrentConditionsBuilder
{
  private String airportICAOCode;
  private int cityId;
  private String dataSource;
  private int dateUTC;
  private WeatherParameterValue<Number> dewPoint;
  private WeatherParameterValue<Number> heatIndex;
  private WeatherParameterValue<Number> humidex;
  private String latitude;
  private String location;
  private String longitude;
  private String metar;
  private WeatherParameterValue<Number> press;
  private WeatherParameterValue<Number> relHumidity;
  private int skyIcon;
  private WeatherParameterValue<Number> temp;
  private int timeUTC;
  private long timestamp;
  private WeatherParameterValue<Number> visibility;
  private String weather;
  private WeatherParameterValue<Number> windChill;
  private WeatherParameterValue<Number> windDir;
  private WeatherParameterValue<Number> windSpeed;

  public CurrentConditions build()
  {
    CurrentConditions localCurrentConditions = new CurrentConditions();
    int i = this.cityId;
    localCurrentConditions.cityId = i;
    String str1 = this.location;
    localCurrentConditions.location = str1;
    int j = this.dateUTC;
    localCurrentConditions.dateUTC = j;
    int k = this.timeUTC;
    localCurrentConditions.timeUTC = k;
    int m = this.skyIcon;
    localCurrentConditions.skyIcon = m;
    WeatherParameterValue localWeatherParameterValue1 = this.temp;
    localCurrentConditions.temp = localWeatherParameterValue1;
    WeatherParameterValue localWeatherParameterValue2 = this.press;
    localCurrentConditions.press = localWeatherParameterValue2;
    WeatherParameterValue localWeatherParameterValue3 = this.windSpeed;
    localCurrentConditions.windSpeed = localWeatherParameterValue3;
    WeatherParameterValue localWeatherParameterValue4 = this.relHumidity;
    localCurrentConditions.relHumidity = localWeatherParameterValue4;
    WeatherParameterValue localWeatherParameterValue5 = this.windDir;
    localCurrentConditions.windDir = localWeatherParameterValue5;
    WeatherParameterValue localWeatherParameterValue6 = this.dewPoint;
    localCurrentConditions.dewPoint = localWeatherParameterValue6;
    WeatherParameterValue localWeatherParameterValue7 = this.heatIndex;
    localCurrentConditions.heatIndex = localWeatherParameterValue7;
    WeatherParameterValue localWeatherParameterValue8 = this.windChill;
    localCurrentConditions.windChill = localWeatherParameterValue8;
    WeatherParameterValue localWeatherParameterValue9 = this.visibility;
    localCurrentConditions.visibility = localWeatherParameterValue9;
    WeatherParameterValue localWeatherParameterValue10 = this.humidex;
    localCurrentConditions.humidex = localWeatherParameterValue10;
    long l = this.timestamp;
    localCurrentConditions.timestamp = l;
    String str2 = this.dataSource;
    localCurrentConditions.dataSource = str2;
    String str3 = this.airportICAOCode;
    localCurrentConditions.airportICAOCode = str3;
    String str4 = this.latitude;
    localCurrentConditions.latitude = str4;
    String str5 = this.longitude;
    localCurrentConditions.longitude = str5;
    String str6 = this.metar;
    localCurrentConditions.metar = str6;
    String str7 = this.weather;
    localCurrentConditions.weather = str7;
    return localCurrentConditions;
  }

  public CurrentConditionsBuilder withAirportICAOCode(String paramString)
  {
    this.airportICAOCode = paramString;
    return this;
  }

  public CurrentConditionsBuilder withCityId(int paramInt)
  {
    this.cityId = paramInt;
    return this;
  }

  public CurrentConditionsBuilder withDataSource(String paramString)
  {
    this.dataSource = paramString;
    return this;
  }

  public CurrentConditionsBuilder withDateUTC(int paramInt)
  {
    this.dateUTC = paramInt;
    return this;
  }

  public CurrentConditionsBuilder withDewPointC(int paramInt)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createDewPointCelsius(paramInt);
    this.dewPoint = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withDewPointDefaultUnits(int paramInt)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createDewPointDefaultUnits(paramInt);
    this.dewPoint = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withDewPointF(int paramInt)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createDewPointFahrenheit(paramInt);
    this.dewPoint = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withHeatIndexC(int paramInt)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureCelsius(paramInt);
    this.heatIndex = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withHeatIndexDefaultUnits(int paramInt)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureDefaultUnits(paramInt);
    this.heatIndex = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withHeatIndexF(int paramInt)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureFahrenheit(paramInt);
    this.heatIndex = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withHumidexC(int paramInt)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureCelsius(paramInt);
    this.humidex = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withHumidexDefaultUnits(int paramInt)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureFahrenheit(paramInt);
    this.humidex = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withHumidexF(int paramInt)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureFahrenheit(paramInt);
    this.humidex = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withLatitude(String paramString)
  {
    this.latitude = paramString;
    return this;
  }

  public CurrentConditionsBuilder withLocation(String paramString)
  {
    this.location = paramString;
    return this;
  }

  public CurrentConditionsBuilder withLongitude(String paramString)
  {
    this.longitude = paramString;
    return this;
  }

  public CurrentConditionsBuilder withMetar(String paramString)
  {
    this.metar = paramString;
    return this;
  }

  public CurrentConditionsBuilder withPressureAtm(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createPressureAtm(paramFloat);
    this.press = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withPressureDefaultUnits(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createPressureDefaultUnits(paramFloat);
    this.press = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withPressureHpa(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createPressureHpa(paramFloat);
    this.press = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withPressureIn(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createPressureIn(paramFloat);
    this.press = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withPressureMm(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createPressureMm(paramFloat);
    this.press = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withRelativeHumidityDefaultUnits(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createRelHumidityDefaultUnits(paramFloat);
    this.relHumidity = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withRelativeHumidityPercents(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createRelHumidityPercents(paramFloat);
    this.relHumidity = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withSkyIcon(int paramInt)
  {
    this.skyIcon = paramInt;
    return this;
  }

  public CurrentConditionsBuilder withTempC(int paramInt)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureCelsius(paramInt);
    this.temp = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withTempDefaultUnits(int paramInt)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureDefaultUnits(paramInt);
    this.temp = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withTempF(int paramInt)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureFahrenheit(paramInt);
    this.temp = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withTimeUTC(int paramInt)
  {
    this.timeUTC = paramInt;
    return this;
  }

  public CurrentConditionsBuilder withTimestamp(long paramLong)
  {
    this.timestamp = paramLong;
    return this;
  }

  public CurrentConditionsBuilder withVisibility(int paramInt)
  {
    throw new UnsupportedOperationException("TODO");
  }

  public CurrentConditionsBuilder withWeather(String paramString)
  {
    this.weather = paramString;
    return this;
  }

  public CurrentConditionsBuilder withWindChillC(int paramInt)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureCelsius(paramInt);
    this.windChill = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withWindChillDefaultUnits(int paramInt)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureDefaultUnits(paramInt);
    this.windChill = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withWindChillF(int paramInt)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createTemperatureFahrenheit(paramInt);
    this.windChill = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withWindDirDefaultUnits(String paramString)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createWindDirectionDefaultValues(paramString);
    this.windDir = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withWindDirDegrees(String paramString)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createWindDirectionDegrees(paramString);
    this.windDir = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withWindSpeedDefaultUnits(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createWindSpeedDefaultUnits(paramFloat);
    this.windSpeed = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withWindSpeedKmph(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createWindSpeedKmph(paramFloat);
    this.windSpeed = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withWindSpeedKnots(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createWindSpeedKnots(paramFloat);
    this.windSpeed = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withWindSpeedMph(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createWindSpeedMph(paramFloat);
    this.windSpeed = localWeatherParameterValue;
    return this;
  }

  public CurrentConditionsBuilder withWindSpeedMps(float paramFloat)
  {
    WeatherParameterValue localWeatherParameterValue = WeatherParameterValue.createWindSpeedMps(paramFloat);
    this.windSpeed = localWeatherParameterValue;
    return this;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.model.CurrentConditionsBuilder
 * JD-Core Version:    0.6.0
 */