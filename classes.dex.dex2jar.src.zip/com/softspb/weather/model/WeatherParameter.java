package com.softspb.weather.model;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import com.softspb.weather.core.R.style;
import com.softspb.weather.core.R.styleable;
import java.util.Formatter;

public abstract class WeatherParameter<T>
{
  public static final int DEFAULT_HUMIDITY_UNITS = 0;
  public static final int DEFAULT_PRESSURE_UNITS = 0;
  public static final int DEFAULT_TEMPERATURE_UNITS = 0;
  public static final int DEFAULT_WIND_DIRECTION_UNITS = 1;
  public static final int DEFAULT_WIND_SPEED_UNITS = 3;
  public static final WeatherParameter<Number> DEW_POINT = ;
  private static final double HPA_PER_ATM = 1013.25D;
  public static final int HUMIDITY_PERCENTS_UNITS = 0;
  private static final double IN_PER_ATM = 29.921299999999999D;
  private static final double KNOT_TO_KMPH = 1.852D;
  private static final int MASK_INFLATED_STYLE = -2147483648;
  private static final double MM_PER_ATM = 760.00099999999998D;
  private static final double MPH_TO_KMPH = 1.609344D;
  private static final double MPH_TO_MPS = 0.44704D;
  private static final double MPS_TO_KMPH = 3.6D;
  public static final WeatherParameter<Number> PRESSURE = ;
  public static final int PRESSURE_ATM_UNITS = 2;
  public static final int PRESSURE_HPA_UNITS = 3;
  public static final int PRESSURE_IN_UNITS = 1;
  public static final int PRESSURE_MM_UNITS = 0;
  public static final WeatherParameter<Number> RELATIVE_HUMIDITY = ;
  public static final WeatherParameter<Number> TEMPERATURE = ;
  public static final int TEMPERATURE_CELSIUS_UNITS = 0;
  public static final int TEMPERATURE_FAHRENHEIT_UNITS = 1;
  public static final int TEMPERATURE_KELVIN_UNITS = 2;
  public static final WeatherParameter<Number> WIND_DIRECTION = ;
  public static final int WIND_DIRECTION_1_RHUMB_UNITS = 3;
  public static final int WIND_DIRECTION_2_RHUMBS_UNITS = 1;
  public static final int WIND_DIRECTION_4_RHUMBS_UNITS = 0;
  public static final int WIND_DIRECTION_DEGREES_UNITS = 2;
  public static final WeatherParameter<Number> WIND_SPEED = ;
  private static final double[][] WIND_SPEED_CONVERSION_TABLE = ;
  public static final int WIND_SPEED_KMPH_UNITS = 3;
  public static final int WIND_SPEED_KNOTS_UNITS = 1;
  private static final int WIND_SPEED_MAX_UNIT = 3;
  private static final int WIND_SPEED_MIN_UNIT = 0;
  public static final int WIND_SPEED_MPH_UNITS = 0;
  public static final int WIND_SPEED_MPS_UNITS = 2;
  protected int defaultUnits;
  protected int formatsId;
  ThreadLocal<Formatter> formatter;
  private int inflatedFlag = 0;
  protected int initialUnitsId;
  protected int largeIconId;
  private String name;
  protected int rangeFormatsId;
  protected int smallIconId;
  protected int styleId;
  protected int titleId;
  protected int unitValuesId;
  protected int unitsId;
  protected int unitsTitleId;

  static
  {
    int i = R.style.WeatherParameter_Temperature;
    TEMPERATURE = new TemperatureParameter(0);
    int j = R.style.WeatherParameter_DewPoint;
    DEW_POINT = new TemperatureParameter(0);
    int k = R.style.WeatherParameter_Pressure;
    PRESSURE = new WeatherParameter.1("pressure-weather-param", k, 0);
    int m = R.style.WeatherParameter_WindSpeed;
    WIND_SPEED = new WeatherParameter.2("weather-param-wind-speed", m, 3);
    int n = R.style.WeatherParameter_RelativeHumidity;
    RELATIVE_HUMIDITY = new WeatherParameter.3("weather-parameter-humidity", n, 0);
    int i1 = R.style.WeatherParameter_WindDirection;
    WIND_DIRECTION = new WeatherParameter.4("weather-parameter-wind-direction", i1, 1);
    double[] arrayOfDouble1 = new double[4];
    double[] arrayOfDouble2 = { 4607182418800017408L, 4606002261703711560L, -1459601686L, 4609926660211357856L };
    arrayOfDouble1[0] = arrayOfDouble2;
    double[] arrayOfDouble3 = { -1243432829L, 4607182418800017408L, 4602808923161882060L, -1065151889L };
    arrayOfDouble1[1] = arrayOfDouble3;
    double[] arrayOfDouble4 = { -624107631L, -1363628926L, 4607182418800017408L, -858993459L };
    arrayOfDouble1[2] = arrayOfDouble4;
    double[] arrayOfDouble5 = { -693452924L, 4603038718062955137L, 4598675619503873138L, 4607182418800017408L };
    arrayOfDouble1[3] = arrayOfDouble5;
    WIND_SPEED_CONVERSION_TABLE = arrayOfDouble1;
  }

  WeatherParameter(String paramString, int paramInt1, int paramInt2)
  {
    ThreadLocal localThreadLocal = new ThreadLocal();
    this.formatter = localThreadLocal;
    this.name = paramString;
    this.styleId = paramInt1;
    this.defaultUnits = paramInt2;
  }

  WeatherParameter(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
  {
    ThreadLocal localThreadLocal = new ThreadLocal();
    this.formatter = localThreadLocal;
    this.name = paramString;
    this.titleId = paramInt1;
    this.unitsTitleId = paramInt2;
    this.unitsId = paramInt3;
    this.unitValuesId = paramInt4;
    this.initialUnitsId = paramInt5;
    this.formatsId = paramInt6;
    this.rangeFormatsId = paramInt7;
    this.defaultUnits = paramInt8;
  }

  abstract T convert(T paramT, int paramInt1, int paramInt2);

  protected void ensureInflatedStyle(Context paramContext)
  {
    int i = this.inflatedFlag ^ 0xFFFFFFFF;
    if ((0x80000000 & i) == 0);
    while (true)
    {
      return;
      if (this.styleId != 0)
      {
        int j = this.styleId;
        int[] arrayOfInt = R.styleable.WeatherParameter;
        TypedArray localTypedArray = paramContext.obtainStyledAttributes(j, arrayOfInt);
        int k = localTypedArray.getResourceId(0, 0);
        this.titleId = k;
        int m = localTypedArray.getResourceId(1, 0);
        this.unitsTitleId = m;
        int n = localTypedArray.getResourceId(2, 0);
        this.unitsId = n;
        int i1 = localTypedArray.getResourceId(3, 0);
        this.unitValuesId = i1;
        int i2 = localTypedArray.getResourceId(4, 0);
        this.formatsId = i2;
        int i3 = localTypedArray.getResourceId(5, 0);
        this.rangeFormatsId = i3;
        int i4 = localTypedArray.getResourceId(6, 0);
        this.smallIconId = i4;
        int i5 = localTypedArray.getResourceId(7, 0);
        this.largeIconId = i5;
        int i6 = localTypedArray.getResourceId(8, 0);
        this.initialUnitsId = i6;
        localTypedArray.recycle();
        int i7 = this.inflatedFlag | 0x80000000;
        this.inflatedFlag = i7;
        continue;
      }
    }
  }

  public String format(T paramT, int paramInt, Context paramContext)
  {
    ensureInflatedStyle(paramContext);
    Resources localResources = paramContext.getResources();
    int i = this.formatsId;
    String str1 = localResources.getStringArray(i)[paramInt];
    Formatter localFormatter = (Formatter)this.formatter.get();
    if (localFormatter == null)
    {
      localFormatter = new Formatter();
      this.formatter.set(localFormatter);
    }
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = paramT;
    Appendable localAppendable = localFormatter.format(str1, arrayOfObject).out();
    String str2 = localAppendable.toString();
    ((StringBuilder)localAppendable).setLength(0);
    return str2;
  }

  public String formatRange(WeatherParameterValue<T> paramWeatherParameterValue1, WeatherParameterValue<T> paramWeatherParameterValue2, int paramInt, Context paramContext)
  {
    Object localObject1 = paramWeatherParameterValue1.getValue(paramInt);
    Object localObject2 = paramWeatherParameterValue2.getValue(paramInt);
    return formatRange(localObject1, localObject2, paramInt, paramContext);
  }

  public String formatRange(T paramT1, T paramT2, int paramInt, Context paramContext)
  {
    ensureInflatedStyle(paramContext);
    Resources localResources = paramContext.getResources();
    int i = this.rangeFormatsId;
    String str1 = localResources.getStringArray(i)[paramInt];
    Formatter localFormatter = (Formatter)this.formatter.get();
    if (localFormatter == null)
    {
      localFormatter = new Formatter();
      this.formatter.set(localFormatter);
    }
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = paramT1;
    arrayOfObject[1] = paramT2;
    Appendable localAppendable = localFormatter.format(str1, arrayOfObject).out();
    String str2 = localAppendable.toString();
    ((StringBuilder)localAppendable).setLength(0);
    return str2;
  }

  public int getDefaultUnits()
  {
    return this.defaultUnits;
  }

  public String getInitialUnits(Context paramContext)
  {
    ensureInflatedStyle(paramContext);
    Resources localResources = paramContext.getResources();
    int i = this.initialUnitsId;
    return localResources.getString(i);
  }

  public int getLargeIconResId(Context paramContext)
  {
    ensureInflatedStyle(paramContext);
    return this.largeIconId;
  }

  public String getName()
  {
    return this.name;
  }

  public int getSmallIconResId(Context paramContext)
  {
    ensureInflatedStyle(paramContext);
    return this.smallIconId;
  }

  public String getTitle(Context paramContext)
  {
    ensureInflatedStyle(paramContext);
    int i = this.titleId;
    return paramContext.getString(i);
  }

  public String[] getUnitValues(Context paramContext)
  {
    ensureInflatedStyle(paramContext);
    Resources localResources = paramContext.getResources();
    int i = this.unitValuesId;
    return localResources.getStringArray(i);
  }

  public String[] getUnits(Context paramContext)
  {
    ensureInflatedStyle(paramContext);
    Resources localResources = paramContext.getResources();
    int i = this.unitsId;
    return localResources.getStringArray(i);
  }

  public String getUnitsTitle(Context paramContext)
  {
    ensureInflatedStyle(paramContext);
    int i = this.unitsTitleId;
    return paramContext.getString(i);
  }

  class TemperatureParameter extends WeatherParameter<Number>
  {
    TemperatureParameter(int arg2)
    {
      super(this$1, i);
    }

    TemperatureParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int arg8)
    {
    }

    Number convert(Number paramNumber, int paramInt1, int paramInt2)
    {
      float f = paramNumber.floatValue();
      switch (paramInt1)
      {
      default:
        String str1 = "Unsupported temperature units: " + paramInt1;
        throw new IllegalArgumentException(str1);
      case 0:
        switch (paramInt2)
        {
        default:
          String str2 = "Unsupported temperature units: " + paramInt2;
          throw new IllegalArgumentException(str2);
        case 1:
          paramNumber = Integer.valueOf((int)(f * 9.0F / 5.0F + 32.0F));
        case 0:
        case 2:
        }
      case 1:
      case 2:
      }
      while (true)
      {
        return paramNumber;
        paramNumber = Integer.valueOf((int)(f + 273.14999F));
        continue;
        switch (paramInt2)
        {
        case 1:
        default:
          String str3 = "Unsupported temperature units: " + paramInt2;
          throw new IllegalArgumentException(str3);
        case 0:
          paramNumber = Integer.valueOf((int)((f - 32.0F) * 5.0F / 9.0F));
          break;
        case 2:
          paramNumber = Integer.valueOf((int)((f - 32.0F) * 5.0F / 9.0F + 273.14999F));
          continue;
          switch (paramInt2)
          {
          case 2:
          default:
            String str4 = "Unsupported temperature units: " + paramInt2;
            throw new IllegalArgumentException(str4);
          case 0:
            paramNumber = Integer.valueOf((int)(f - 273.14999F));
            break;
          case 1:
            paramNumber = Integer.valueOf((int)((f - 273.14999F) * 9.0F / 5.0F + 32.0F));
          }
        }
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.model.WeatherParameter
 * JD-Core Version:    0.6.0
 */