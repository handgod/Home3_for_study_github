package com.softspb.weather.model;

import android.content.Context;
import android.content.res.Resources;
import com.softspb.weather.core.R.array;
import com.softspb.weather.core.R.string;
import java.util.Formatter;

final class WeatherParameter$4 extends WeatherParameter<Number>
{
  private boolean isAllowedUnits(int paramInt)
  {
    int i = 1;
    if ((paramInt == 2) || (paramInt == 3) || (paramInt == 1) || (paramInt == 0));
    while (true)
    {
      return i;
      i = 0;
    }
  }

  Number convert(Number paramNumber, int paramInt1, int paramInt2)
  {
    if (!isAllowedUnits(paramInt1))
    {
      String str1 = "Unsupported relative humidity units: " + paramInt1;
      throw new IllegalArgumentException(str1);
    }
    if (!isAllowedUnits(paramInt2))
    {
      String str2 = "Unsupported relative humidity units: " + paramInt2;
      throw new IllegalArgumentException(str2);
    }
    return paramNumber;
  }

  public String format(Number paramNumber, int paramInt, Context paramContext)
  {
    double d1 = paramNumber.doubleValue();
    String str1;
    if (d1 == (0.0D / 0.0D))
    {
      int i = R.string.weather_wind_direction_variable;
      Context localContext1 = paramContext;
      int j = i;
      str1 = localContext1.getString(j);
    }
    while (true)
    {
      4 local4 = this;
      Context localContext2 = paramContext;
      local4.ensureInflatedStyle(localContext2);
      Resources localResources = paramContext.getResources();
      int k = this.formatsId;
      String str2 = localResources.getStringArray(k)[paramInt];
      Formatter localFormatter = (Formatter)this.formatter.get();
      if (localFormatter == null)
      {
        localFormatter = new Formatter();
        this.formatter.set(localFormatter);
      }
      Object[] arrayOfObject1 = new Object[1];
      arrayOfObject1[0] = str1;
      Object[] arrayOfObject2 = arrayOfObject1;
      Appendable localAppendable = localFormatter.format(str2, arrayOfObject2).out();
      String str3 = localAppendable.toString();
      StringBuilder localStringBuilder = (StringBuilder)localAppendable;
      int m = 0;
      localStringBuilder.setLength(m);
      return str3;
      while (d1 < 0.0D)
        d1 += 360.0D;
      while (d1 >= 360.0D)
        d1 -= 360.0D;
      int n = paramInt;
      int i1 = 2;
      if (n == i1)
      {
        str1 = Double.toString(d1);
        continue;
      }
      int i2 = 0;
      switch (paramInt)
      {
      case 2:
      default:
      case 3:
      case 1:
      case 0:
      }
      String[] arrayOfString;
      int i4;
      while (true)
      {
        arrayOfString = paramContext.getResources().getStringArray(i2);
        int i3 = arrayOfString.length;
        double d2 = i3;
        double d3 = 360.0D / d2;
        i4 = (int)Math.round(d1 / d3);
        while (i4 >= i3)
          i4 -= i3;
        i2 = R.array.weather_wind_directions_marine;
        continue;
        i2 = R.array.weather_wind_directions_finer;
        continue;
        i2 = R.array.weather_wind_directions;
      }
      str1 = arrayOfString[i4];
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.model.WeatherParameter.4
 * JD-Core Version:    0.6.0
 */