package com.softspb.weather.model;

final class WeatherParameter$2 extends WeatherParameter<Number>
{
  Number convert(Number paramNumber, int paramInt1, int paramInt2)
  {
    if ((paramInt1 < 0) || (paramInt1 > 3))
    {
      String str1 = "Unsupported wind speed units: " + paramInt1;
      throw new IllegalArgumentException(str1);
    }
    if ((paramInt2 < 0) || (paramInt2 > 3))
    {
      String str2 = "Unsupported wind speed units: " + paramInt1;
      throw new IllegalArgumentException(str2);
    }
    double d = paramNumber.doubleValue();
    long l = WeatherParameter.access$000()[paramInt1][paramInt2];
    return Double.valueOf(d * l);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.model.WeatherParameter.2
 * JD-Core Version:    0.6.0
 */