package com.softspb.weather.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class UpdateStatus$1
  implements Parcelable.Creator<UpdateStatus>
{
  public UpdateStatus createFromParcel(Parcel paramParcel)
  {
    return new UpdateStatus(paramParcel, null);
  }

  public UpdateStatus[] newArray(int paramInt)
  {
    return new UpdateStatus[paramInt];
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.model.UpdateStatus.1
 * JD-Core Version:    0.6.0
 */