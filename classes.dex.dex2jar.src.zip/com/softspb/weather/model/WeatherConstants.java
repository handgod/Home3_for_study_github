package com.softspb.weather.model;

public abstract class WeatherConstants
{
  public static final int CLOUDINESS_CLEAR = 1;
  public static final int CLOUDINESS_CLOUDY = 3;
  public static final int CLOUDINESS_HEAVY = 4;
  public static final int CLOUDINESS_PARTLY = 2;
  public static final int ICON_CLEAR = 2;
  public static final int ICON_CLOUDY = 4;
  public static final int ICON_HAIL = 12;
  public static final int ICON_HEAVY_CLOUDY = 5;
  public static final int ICON_HEAVY_RAIN = 8;
  public static final int ICON_HEAVY_SNOW = 11;
  public static final int ICON_HOT = 1;
  public static final int ICON_LIGHT_RAIN = 7;
  public static final int ICON_LIGHT_SNOW = 10;
  public static final int ICON_NA = 0;
  public static final int ICON_NIGHT_CLEAR = 17;
  public static final int ICON_NIGHT_CLOUDY = 19;
  public static final int ICON_NIGHT_HAIL = 26;
  public static final int ICON_NIGHT_HARDLY_CLOUDY = 20;
  public static final int ICON_NIGHT_HEAVY_RAIN = 22;
  public static final int ICON_NIGHT_HEAVY_SNOW = 25;
  public static final int ICON_NIGHT_LIGHT_RAIN = 21;
  public static final int ICON_NIGHT_LIGHT_SNOW = 24;
  public static final int ICON_NIGHT_PARTLY_CLOUDY = 18;
  public static final int ICON_NIGHT_RAIN_WITH_SNOW = 23;
  public static final int ICON_NIGHT_SUNNY_WITH_RAIN = 28;
  public static final int ICON_NIGHT_SUNNY_WITH_SNOW = 30;
  public static final int ICON_NIGHT_SUNNY_WITH_THUNDERSTORM = 29;
  public static final int ICON_NIGHT_THUNDERSTORM = 27;
  public static final int ICON_PARTLY_CLOUDY = 3;
  public static final int ICON_RAIN_WITH_SNOW = 9;
  public static final int ICON_SIZE_LARGE = 3;
  public static final int ICON_SIZE_MEDIUM = 2;
  public static final int ICON_SIZE_SMALL = 1;
  public static final int ICON_SIZE_XLARGE = 4;
  public static final int ICON_SMOKE = 6;
  public static final int ICON_SUNNY_WITH_RAIN = 14;
  public static final int ICON_SUNNY_WITH_SNOW = 16;
  public static final int ICON_SUNNY_WITH_THUNDERSTORM = 15;
  public static final int ICON_THUNDERSTORM = 13;
  public static final int PRECIPITATION_HEAVY_RAIN = 4;
  public static final int PRECIPITATION_HEAVY_SNOW = 6;
  public static final int PRECIPITATION_LIGHT_RAIN = 5;
  public static final int PRECIPITATION_LIGHT_SNOW = 7;
  public static final int PRECIPITATION_NONE_1 = 9;
  public static final int PRECIPITATION_NONE_2 = 10;
  public static final int PRECIPITATION_THUNDERSTORM = 8;
  public static final int TIME_OF_DAY_DAY = 3;
  public static final int TIME_OF_DAY_DAY_END = 1759;
  public static final int TIME_OF_DAY_DAY_START = 1200;
  public static final int TIME_OF_DAY_EVENING = 4;
  public static final int TIME_OF_DAY_EVENING_END = 2359;
  public static final int TIME_OF_DAY_EVENING_START = 1800;
  public static final int TIME_OF_DAY_MORNING = 2;
  public static final int TIME_OF_DAY_MORNING_END = 1159;
  public static final int TIME_OF_DAY_MORNING_START = 600;
  public static final int TIME_OF_DAY_NIGHT = 1;
  public static final int TIME_OF_DAY_NIGHT_END = 559;
  public static final int TIME_OF_DAY_NIGHT_START = 0;
  public static final int WEATHER_CLEAR = 2;
  public static final int WEATHER_CLOUDY = 4;
  public static final int WEATHER_HAIL = 12;
  public static final int WEATHER_HEAVY_CLOUDY = 5;
  public static final int WEATHER_HEAVY_RAIN = 8;
  public static final int WEATHER_HEAVY_SNOW = 11;
  public static final int WEATHER_HOT = 1;
  public static final int WEATHER_LIGHT_RAIN = 7;
  public static final int WEATHER_LIGHT_SNOW = 10;
  private static final int WEATHER_MAX_VALUE = 16;
  private static final int WEATHER_MIN_VALUE = 0;
  public static final int WEATHER_NA = 0;
  public static final int WEATHER_PARTLY_CLOUDY = 3;
  public static final int WEATHER_RAIN_WITH_SNOW = 9;
  public static final int WEATHER_SMOKE = 6;
  public static final int WEATHER_SUNNY_WITH_RAIN = 14;
  public static final int WEATHER_SUNNY_WITH_SNOW = 16;
  public static final int WEATHER_SUNNY_WITH_THUNDERSTORM = 15;
  public static final int WEATHER_THUNDERSTORM = 13;

  public static int dayIconToNightIcon(int paramInt)
  {
    if (paramInt == 1)
      paramInt = 17;
    while (true)
    {
      return paramInt;
      if ((paramInt >= 2) && (paramInt <= 5))
      {
        paramInt += 15;
        continue;
      }
      if ((paramInt < 7) || (paramInt > 16))
        continue;
      paramInt += 14;
    }
  }

  public static int getIconIndex(int paramInt1, int paramInt2)
  {
    if ((paramInt1 < 0) || (paramInt1 > 16))
    {
      String str1 = "Illegal weather value: " + paramInt1;
      throw new IllegalArgumentException(str1);
    }
    if ((paramInt2 == 3) || (paramInt2 == 2));
    while (true)
    {
      return paramInt1;
      if ((paramInt2 != 4) && (paramInt2 != 1))
        break;
      paramInt1 = dayIconToNightIcon(paramInt1);
    }
    String str2 = "Illegal timeOfDay value: " + paramInt2;
    throw new IllegalArgumentException(str2);
  }

  public static int getTimeOfDay(int paramInt)
  {
    int i;
    if ((paramInt >= 1200) && (paramInt <= 1759))
      i = 3;
    while (true)
    {
      return i;
      if ((paramInt >= 1800) && (paramInt <= 2359))
      {
        i = 4;
        continue;
      }
      if ((paramInt >= 600) && (paramInt <= 1159))
      {
        i = 2;
        continue;
      }
      if ((paramInt < 0) || (paramInt > 559))
        break;
      i = 1;
    }
    String str = "Illegal time value: " + paramInt;
    throw new IllegalArgumentException(str);
  }

  public static int gismeteoCodesToDayIcon(int paramInt1, int paramInt2)
  {
    int i = 0;
    switch (paramInt2)
    {
    default:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
    case 10:
    }
    while (true)
    {
      return i;
      switch (paramInt1)
      {
      default:
        break;
      case 0:
        i = 14;
        break;
      case 1:
      case 2:
      case 3:
        if (paramInt2 == 4);
        for (i = 8; ; i = 7)
          break;
        switch (paramInt1)
        {
        default:
          break;
        case 0:
          i = 16;
          break;
        case 1:
        case 2:
          i = 10;
          break;
        case 3:
          i = 11;
          continue;
          switch (paramInt1)
          {
          default:
            break;
          case 0:
            i = 15;
            break;
          case 1:
          case 2:
          case 3:
            i = 13;
            continue;
            switch (paramInt1)
            {
            default:
              break;
            case 0:
              i = 2;
              break;
            case 1:
              i = 3;
              break;
            case 2:
              i = 4;
              break;
            case 3:
              i = 5;
            }
          }
        }
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.model.WeatherConstants
 * JD-Core Version:    0.6.0
 */