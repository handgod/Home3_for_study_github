package com.softspb.weather.model;

final class WeatherParameter$1 extends WeatherParameter<Number>
{
  Number convert(Number paramNumber, int paramInt1, int paramInt2)
  {
    double d;
    switch (paramInt1)
    {
    default:
      String str1 = "Unsupported pressure units: " + paramInt1;
      throw new IllegalArgumentException(str1);
    case 0:
      d = 0.00131578774238455D;
    case 1:
    case 3:
    case 2:
    }
    while (true)
      switch (paramInt2)
      {
      default:
        String str2 = "Unsupported pressure units: " + paramInt2;
        throw new IllegalArgumentException(str2);
        d = 0.03342100777706851D;
        continue;
        d = 0.0009869232667160128D;
        continue;
        d = 1.0D;
      case 0:
      case 2:
      case 1:
      case 3:
      }
    d *= 760.00099999999998D;
    while (true)
    {
      return Double.valueOf(paramNumber.doubleValue() * d);
      d *= 29.921299999999999D;
      continue;
      d *= 1013.25D;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.model.WeatherParameter.1
 * JD-Core Version:    0.6.0
 */