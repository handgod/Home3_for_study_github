package com.softspb.weather.provider;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.BaseColumns;
import com.softspb.weather.model.CurrentConditions;
import com.softspb.weather.model.CurrentConditionsBuilder;
import com.softspb.weather.model.Forecast;
import com.softspb.weather.model.ForecastBuilder;
import com.softspb.weather.model.UpdateStatus;

public final class WeatherMetaData
{
  static final String CREATE_TABLE_CURRENT = "CREATE TABLE IF NOT EXISTS current (_id INTEGER PRIMARY KEY AUTOINCREMENT, city_id INTEGER, station TEXT, date INTEGER, time INTEGER, temp INTEGER, wind_dir TEXT, wind_speed REAL, pressure REAL, humidity REAL, dew_point INTEGER, sky_icon INTEGER,  UNIQUE (city_id, station));";
  static final String CREATE_TABLE_FORECAST = "CREATE TABLE IF NOT EXISTS forecast (_id INTEGER PRIMARY KEY AUTOINCREMENT, city_id INTEGER NOT NULL, date INTEGER, time INTEGER NOT NULL, temp_min INTEGER, temp_max INTEGER, cloud INTEGER, precip INTEGER, press_min INTEGER, press_max INTEGER, humidity_min INTEGER, humidity_max INTEGER, heat_min INTEGER, heat_max INTEGER, wind_min INTEGER, wind_max INTEGER, wind_dir INTEGER, UNIQUE (city_id, date, time));";
  static final String CREATE_TABLE_UPDATE_STATUS = "CREATE TABLE IF NOT EXISTS update_status (_id INTEGER PRIMARY KEY AUTOINCREMENT, city_id INTEGER NOT NULL, status INTEGER NOT NULL, timestamp LONG NOT NULL, type INTEGER NOT NULL,  UNIQUE (city_id,status,type));";
  private static final String WEATHER_AUTHORITY_SUFFIX = ".weather";
  private static String weatherProviderAuthority;

  static String getAuthority(Context paramContext)
  {
    if (weatherProviderAuthority == null);
    synchronized (WeatherMetaData.class)
    {
      if (weatherProviderAuthority == null)
      {
        StringBuilder localStringBuilder = new StringBuilder();
        String str = paramContext.getPackageName();
        weatherProviderAuthority = str + ".weather";
      }
      return weatherProviderAuthority;
    }
  }

  public final class UpdateStatusMetaData
    implements WeatherMetaData.UpdateStatusColumns
  {
    public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.softspb.eventslog";
    public static final String CONTENT_PATH = "update_status";
    public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.softspb.eventslog";
    public static final int DEFAULT_CITY_ID_INDEX = 0;
    public static final String[] DEFAULT_PROJECTION = ;
    public static final int DEFAULT_STATUS_INDEX = 1;
    public static final int DEFAULT_TIMESTAMP_INDEX = 2;
    public static final int DEFAULT_TYPE_INDEX = 3;
    public static final String TABLE_NAME = "update_status";
    public static final int UPDATE_TYPE_CURRENT_CONDITIONS = 1;
    public static final int UPDATE_TYPE_FORECAST = 2;
    private static Uri contentUri;

    static
    {
      String[] arrayOfString = new String[4];
      arrayOfString[0] = "city_id";
      arrayOfString[1] = "status";
      arrayOfString[2] = "timestamp";
      arrayOfString[3] = "type";
      DEFAULT_PROJECTION = arrayOfString;
    }

    static void checkInitUris(Context paramContext)
    {
      if (contentUri == null);
      synchronized (WeatherMetaData.class)
      {
        if (contentUri == null)
          initUris(WeatherMetaData.getAuthority(paramContext));
        return;
      }
    }

    public static UpdateStatus fromDefaultCursor(int paramInt, Cursor paramCursor)
    {
      UpdateStatus localUpdateStatus = new UpdateStatus(paramInt);
      if (paramCursor.moveToFirst())
        if (!paramCursor.isAfterLast())
        {
          int i;
          long l1;
          if (paramCursor.getInt(0) == paramInt)
          {
            i = paramCursor.getInt(1);
            l1 = paramCursor.getLong(2);
            switch (paramCursor.getInt(3))
            {
            default:
            case 2:
            case 1:
            }
          }
          while (true)
          {
            boolean bool = paramCursor.moveToNext();
            break;
            long l2 = localUpdateStatus.latestForecastTimestamp;
            if (l1 > l2)
            {
              localUpdateStatus.forecastStatus = i;
              localUpdateStatus.latestForecastTimestamp = l1;
            }
            if (i != 1)
              continue;
            long l3 = localUpdateStatus.latestSuccessfulForecastTimestamp;
            if (l1 <= l3)
              continue;
            localUpdateStatus.latestSuccessfulForecastTimestamp = l1;
            continue;
            long l4 = localUpdateStatus.latestCurrentConditionsTimestamp;
            if (l1 > l4)
            {
              localUpdateStatus.currentConditionsStatus = i;
              localUpdateStatus.latestCurrentConditionsTimestamp = l1;
            }
            if (i != 1)
              continue;
            long l5 = localUpdateStatus.latestSuccessfulCurrentConditionsTimestamp;
            if (l1 <= l5)
              continue;
            localUpdateStatus.latestSuccessfulCurrentConditionsTimestamp = l1;
          }
        }
      return localUpdateStatus;
    }

    public static Uri getContentUri(Context paramContext)
    {
      checkInitUris(paramContext);
      return contentUri;
    }

    private static void initUris(String paramString)
    {
      if (contentUri == null);
      synchronized (UpdateStatusMetaData.class)
      {
        if (contentUri == null)
          contentUri = Uri.parse("content://" + paramString + "/" + "update_status");
        return;
      }
    }
  }

  public abstract interface UpdateStatusColumns extends BaseColumns
  {
    public static final String CITY_ID = "city_id";
    public static final String STATUS = "status";
    public static final String TIMESTAMP = "timestamp";
    public static final String TYPE = "type";
  }

  public final class CurrentMetaData
    implements WeatherMetaData.CurrentColumns
  {
    public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.softspb.current";
    public static final String CONTENT_PATH = "current";
    public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.softspb.current";
    public static final int DEFAULT_CITY_ID_INDEX = 1;
    public static final int DEFAULT_DATE_INDEX = 3;
    public static final int DEFAULT_DEW_POINT_INDEX = 11;
    public static final int DEFAULT_HUMIDITY_INDEX = 8;
    public static final int DEFAULT_ID_INDEX = 0;
    public static final int DEFAULT_PRESSURE_INDEX = 7;
    public static final String[] DEFAULT_PROJECTION = ;
    public static final int DEFAULT_SKY_ICON_INDEX = 6;
    public static final int DEFAULT_STATION_INDEX = 2;
    public static final int DEFAULT_TEMP_INDEX = 5;
    public static final int DEFAULT_TIME_INDEX = 4;
    public static final int DEFAULT_WIND_DIRECTION_INDEX = 9;
    public static final int DEFAULT_WIND_SPEED_INDEX = 10;
    public static final String TABLE_NAME = "current";
    private static Uri contentUri;

    static
    {
      String[] arrayOfString = new String[12];
      arrayOfString[0] = "_id";
      arrayOfString[1] = "city_id";
      arrayOfString[2] = "station";
      arrayOfString[3] = "date";
      arrayOfString[4] = "time";
      arrayOfString[5] = "temp";
      arrayOfString[6] = "sky_icon";
      arrayOfString[7] = "pressure";
      arrayOfString[8] = "humidity";
      arrayOfString[9] = "wind_dir";
      arrayOfString[10] = "wind_speed";
      arrayOfString[11] = "dew_point";
      DEFAULT_PROJECTION = arrayOfString;
    }

    static void checkInitUris(Context paramContext)
    {
      if (contentUri == null);
      synchronized (WeatherMetaData.class)
      {
        if (contentUri == null)
          initUris(WeatherMetaData.getAuthority(paramContext));
        return;
      }
    }

    public static CurrentConditions fromDefaultCursor(Cursor paramCursor)
    {
      CurrentConditionsBuilder localCurrentConditionsBuilder1 = new CurrentConditionsBuilder();
      int i = paramCursor.getInt(1);
      CurrentConditionsBuilder localCurrentConditionsBuilder2 = localCurrentConditionsBuilder1.withCityId(i);
      if (!paramCursor.isNull(2))
      {
        String str1 = paramCursor.getString(2);
        CurrentConditionsBuilder localCurrentConditionsBuilder3 = localCurrentConditionsBuilder1.withLocation(str1);
      }
      if (!paramCursor.isNull(3))
      {
        int j = paramCursor.getInt(3);
        CurrentConditionsBuilder localCurrentConditionsBuilder4 = localCurrentConditionsBuilder1.withDateUTC(j);
      }
      if (!paramCursor.isNull(4))
      {
        int k = paramCursor.getInt(4);
        CurrentConditionsBuilder localCurrentConditionsBuilder5 = localCurrentConditionsBuilder1.withTimeUTC(k);
      }
      if (!paramCursor.isNull(6))
      {
        int m = paramCursor.getInt(6);
        CurrentConditionsBuilder localCurrentConditionsBuilder6 = localCurrentConditionsBuilder1.withSkyIcon(m);
      }
      if (!paramCursor.isNull(5))
      {
        int n = paramCursor.getInt(5);
        CurrentConditionsBuilder localCurrentConditionsBuilder7 = localCurrentConditionsBuilder1.withTempDefaultUnits(n);
      }
      if (!paramCursor.isNull(7))
      {
        float f1 = paramCursor.getFloat(7);
        CurrentConditionsBuilder localCurrentConditionsBuilder8 = localCurrentConditionsBuilder1.withPressureDefaultUnits(f1);
      }
      if (!paramCursor.isNull(10))
      {
        float f2 = paramCursor.getFloat(10);
        CurrentConditionsBuilder localCurrentConditionsBuilder9 = localCurrentConditionsBuilder1.withWindSpeedDefaultUnits(f2);
      }
      if (!paramCursor.isNull(8))
      {
        float f3 = paramCursor.getFloat(8);
        CurrentConditionsBuilder localCurrentConditionsBuilder10 = localCurrentConditionsBuilder1.withRelativeHumidityDefaultUnits(f3);
      }
      if (!paramCursor.isNull(9))
      {
        String str2 = paramCursor.getString(9);
        CurrentConditionsBuilder localCurrentConditionsBuilder11 = localCurrentConditionsBuilder1.withWindDirDefaultUnits(str2);
      }
      if (!paramCursor.isNull(11))
      {
        int i1 = paramCursor.getInt(11);
        CurrentConditionsBuilder localCurrentConditionsBuilder12 = localCurrentConditionsBuilder1.withDewPointDefaultUnits(i1);
      }
      long l = System.currentTimeMillis();
      CurrentConditionsBuilder localCurrentConditionsBuilder13 = localCurrentConditionsBuilder1.withTimestamp(l);
      return localCurrentConditionsBuilder1.build();
    }

    public static Uri getContentUri(Context paramContext)
    {
      checkInitUris(paramContext);
      return contentUri;
    }

    private static void initUris(String paramString)
    {
      if (contentUri == null);
      synchronized (CurrentMetaData.class)
      {
        if (contentUri == null)
          contentUri = Uri.parse("content://" + paramString + "/" + "current");
        return;
      }
    }
  }

  public abstract interface CurrentColumns extends BaseColumns
  {
    public static final String CITY_ID = "city_id";
    public static final String DATE = "date";
    public static final String DEW_POINT = "dew_point";
    public static final String HUMIDITY = "humidity";
    public static final String PRESSURE = "pressure";
    public static final String SKY_ICON = "sky_icon";
    public static final String STATION = "station";
    public static final String TEMP = "temp";
    public static final String TIME = "time";
    public static final String WIND_DIRECTION = "wind_dir";
    public static final String WIND_SPEED = "wind_speed";
  }

  public final class TimeOfDayForecastMetaData
    implements WeatherMetaData.TimeOfDayForecastColumns
  {
    public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.softspb.forecast.timeofday";
    public static final String CONTENT_PATH = "forecast/timeofday";
    public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.softspb.forecast.timeofday";
    public static final int DEFAULT_CITY_ID_INDEX = 1;
    public static final int DEFAULT_CLOUDINESS_INDEX = 6;
    public static final int DEFAULT_DATE_INDEX = 2;
    public static final int DEFAULT_ID_INDEX = 0;
    public static final int DEFAULT_PRECIPITATION_INDEX = 7;
    public static final String[] DEFAULT_PROJECTION = ;
    public static final int DEFAULT_TEMP_MAX_INDEX = 5;
    public static final int DEFAULT_TEMP_MIN_INDEX = 4;
    public static final int DEFAULT_TIME_OF_DAY_INDEX = 3;
    public static final String[] TIME_OF_DAY_FORECAST_PROJECTION;
    private static Uri contentUri;

    static
    {
      String[] arrayOfString1 = new String[8];
      arrayOfString1[0] = "_id";
      arrayOfString1[1] = "city_id AS city_id";
      arrayOfString1[2] = "date AS date";
      arrayOfString1[3] = "CASE WHEN time BETWEEN 0 AND 559 THEN 1 WHEN time BETWEEN 600 AND 1159 THEN 2 WHEN time BETWEEN 1200 AND 1759 THEN 3 WHEN time BETWEEN 1800 AND 2359 THEN 4 END AS time_of_day";
      arrayOfString1[4] = "MIN(temp_min) AS temp_min";
      arrayOfString1[5] = "MAX(temp_max) AS temp_max";
      arrayOfString1[6] = "cloud AS cloud";
      arrayOfString1[7] = "precip AS precip";
      TIME_OF_DAY_FORECAST_PROJECTION = arrayOfString1;
      String[] arrayOfString2 = new String[8];
      arrayOfString2[0] = "_id";
      arrayOfString2[1] = "city_id";
      arrayOfString2[2] = "date";
      arrayOfString2[3] = "time_of_day";
      arrayOfString2[4] = "temp_min";
      arrayOfString2[5] = "temp_max";
      arrayOfString2[6] = "cloud";
      arrayOfString2[7] = "precip";
      DEFAULT_PROJECTION = arrayOfString2;
    }

    static void checkInitUris(Context paramContext)
    {
      if (contentUri == null);
      synchronized (WeatherMetaData.class)
      {
        if (contentUri == null)
          initUris(WeatherMetaData.getAuthority(paramContext));
        return;
      }
    }

    public static Forecast fromDefaultCursor(Cursor paramCursor)
    {
      ForecastBuilder localForecastBuilder1 = new ForecastBuilder();
      String str = paramCursor.getString(1);
      if (str != null)
      {
        int i = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder2 = localForecastBuilder1.withCityId(i);
      }
      str = paramCursor.getString(6);
      if (str != null)
      {
        int j = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder3 = localForecastBuilder1.withCloudiness(j);
      }
      str = paramCursor.getString(2);
      if (str != null)
      {
        int k = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder4 = localForecastBuilder1.withDateLocal(k);
      }
      str = paramCursor.getString(3);
      if (str != null)
      {
        int m = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder5 = localForecastBuilder1.withTimeLocal(m);
      }
      str = paramCursor.getString(7);
      if (str != null)
      {
        int n = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder6 = localForecastBuilder1.withPrecipitation(n);
      }
      str = paramCursor.getString(5);
      if (str != null)
      {
        int i1 = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder7 = localForecastBuilder1.withMaxTempDefaultUnits(i1);
      }
      str = paramCursor.getString(4);
      if (str != null)
      {
        int i2 = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder8 = localForecastBuilder1.withMinTempDefaultUnits(i2);
      }
      long l = System.currentTimeMillis();
      ForecastBuilder localForecastBuilder9 = localForecastBuilder1.withTimestamp(l);
      return localForecastBuilder1.build();
    }

    public static Uri getContentUri(Context paramContext)
    {
      checkInitUris(paramContext);
      return contentUri;
    }

    public static Uri getUri(Context paramContext, int paramInt)
    {
      Uri localUri = getContentUri(paramContext);
      String str = Integer.toString(paramInt);
      return Uri.withAppendedPath(localUri, str);
    }

    public static Uri getUri(Context paramContext, int paramInt1, int paramInt2)
    {
      Uri localUri1 = getContentUri(paramContext);
      String str1 = Integer.toString(paramInt1);
      Uri localUri2 = Uri.withAppendedPath(localUri1, str1);
      String str2 = Integer.toString(paramInt2);
      return Uri.withAppendedPath(localUri2, str2);
    }

    private static void initUris(String paramString)
    {
      if (contentUri == null);
      synchronized (TimeOfDayForecastMetaData.class)
      {
        if (contentUri == null)
          contentUri = Uri.parse("content://" + paramString + "/" + "forecast/timeofday");
        return;
      }
    }
  }

  public abstract interface TimeOfDayForecastColumns extends BaseColumns
  {
    public static final String CITY_ID = "city_id";
    public static final String CLOUDINESS = "cloud";
    public static final String DATE = "date";
    public static final String PRECIPITATION = "precip";
    public static final String TEMP_MAX = "temp_max";
    public static final String TEMP_MIN = "temp_min";
    public static final String TIME_OF_DAY = "time_of_day";
  }

  public class DailyForecastMetaData
    implements WeatherMetaData.DailyForecastColumns
  {
    public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.softspb.forecast.day";
    public static final String CONTENT_PATH = "dailyforecast";
    public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.softspb.forecast.day";
    public static final int DEFAULT_CITY_ID_INDEX = 1;
    public static final int DEFAULT_CLOUDINESS_INDEX = 5;
    public static final int DEFAULT_DATE_INDEX = 2;
    public static final int DEFAULT_ID_INDEX = 0;
    public static final int DEFAULT_PRECIPITATION_INDEX = 6;
    public static final String[] DEFAULT_PROJECTION = ;
    public static final int DEFAULT_TEMP_MAX_INDEX = 4;
    public static final int DEFAULT_TEMP_MIN_INDEX = 3;
    private static Uri contentUri;

    static
    {
      String[] arrayOfString = new String[7];
      arrayOfString[0] = "_id";
      arrayOfString[1] = "city_id";
      arrayOfString[2] = "date";
      arrayOfString[3] = "temp_min";
      arrayOfString[4] = "temp_max";
      arrayOfString[5] = "cloud";
      arrayOfString[6] = "precip";
      DEFAULT_PROJECTION = arrayOfString;
    }

    static void checkInitUris(Context paramContext)
    {
      if (contentUri == null);
      synchronized (WeatherMetaData.class)
      {
        if (contentUri == null)
          initUris(WeatherMetaData.getAuthority(paramContext));
        return;
      }
    }

    public static Forecast fromDefaultCursor(Cursor paramCursor)
    {
      ForecastBuilder localForecastBuilder1 = new ForecastBuilder();
      String str = paramCursor.getString(1);
      if (str != null)
      {
        int i = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder2 = localForecastBuilder1.withCityId(i);
      }
      str = paramCursor.getString(5);
      if (str != null)
      {
        int j = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder3 = localForecastBuilder1.withCloudiness(j);
      }
      str = paramCursor.getString(2);
      if (str != null)
      {
        int k = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder4 = localForecastBuilder1.withDateLocal(k);
      }
      str = paramCursor.getString(6);
      if (str != null)
      {
        int m = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder5 = localForecastBuilder1.withPrecipitation(m);
      }
      str = paramCursor.getString(4);
      if (str != null)
      {
        int n = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder6 = localForecastBuilder1.withMaxTempDefaultUnits(n);
      }
      str = paramCursor.getString(3);
      if (str != null)
      {
        int i1 = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder7 = localForecastBuilder1.withMinTempDefaultUnits(i1);
      }
      long l = System.currentTimeMillis();
      ForecastBuilder localForecastBuilder8 = localForecastBuilder1.withTimestamp(l);
      return localForecastBuilder1.build();
    }

    public static Uri getContentUri(Context paramContext)
    {
      checkInitUris(paramContext);
      return contentUri;
    }

    private static void initUris(String paramString)
    {
      if (contentUri == null);
      synchronized (DailyForecastMetaData.class)
      {
        if (contentUri == null)
          contentUri = Uri.parse("content://" + paramString + "/" + "dailyforecast");
        return;
      }
    }
  }

  public abstract interface DailyForecastColumns extends BaseColumns
  {
    public static final String CITY_ID = "city_id";
    public static final String CLOUDINESS = "cloud";
    public static final String DATE = "date";
    public static final String PRECIPITATION = "precip";
    public static final String TEMP_MAX = "temp_max";
    public static final String TEMP_MIN = "temp_min";
  }

  public final class ForecastMetaData
    implements WeatherMetaData.ForecastColumns
  {
    public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.softspb.forecast";
    public static final String CONTENT_PATH = "forecast";
    public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.softspb.forecast";
    public static final int DAT_FORECAST_TEMP_MIN_INDEX = 3;
    public static final int DAY_FORECAST_CITY_ID_INDEX = 0;
    public static final int DAY_FORECAST_DATE_INDEX = 1;
    public static final String[] DAY_FORECAST_PROJECTION = ;
    public static final int DAY_FORECAST_TEMP_MAX_INDEX = 2;
    public static final int DEFAULT_CITY_ID_INDEX = 1;
    public static final int DEFAULT_CLOUDINESS_INDEX = 6;
    public static final int DEFAULT_DATE_INDEX = 2;
    public static final int DEFAULT_ID_INDEX = 0;
    public static final int DEFAULT_PRECIPITATION_INDEX = 7;
    public static final String[] DEFAULT_PROJECTION = ;
    public static final int DEFAULT_TEMP_MAX_INDEX = 5;
    public static final int DEFAULT_TEMP_MIN_INDEX = 4;
    public static final int DEFAULT_TIME_INDEX = 3;
    public static final String TABLE_NAME = "forecast";
    public static final String TIME_OF_DAY_ALIAS = "time_of_day";
    public static final int TIME_OF_DAY_DAY = 2;
    public static final int TIME_OF_DAY_EVENING = 3;
    public static final int TIME_OF_DAY_MORNING = 1;
    public static final int TIME_OF_DAY_NIGHT;
    private static Uri contentUri;

    static
    {
      String[] arrayOfString1 = new String[8];
      arrayOfString1[0] = "_id";
      arrayOfString1[1] = "city_id";
      arrayOfString1[2] = "date";
      arrayOfString1[3] = "time";
      arrayOfString1[4] = "temp_min";
      arrayOfString1[5] = "temp_max";
      arrayOfString1[6] = "cloud";
      arrayOfString1[7] = "precip";
      DEFAULT_PROJECTION = arrayOfString1;
      String[] arrayOfString2 = new String[4];
      arrayOfString2[0] = "city_id AS city_id";
      arrayOfString2[1] = "date AS date";
      arrayOfString2[2] = "MAX(temp_max) AS temp_max";
      arrayOfString2[3] = "MIN(temp_min) AS temp_min";
      DAY_FORECAST_PROJECTION = arrayOfString2;
    }

    static void checkInitUris(Context paramContext)
    {
      if (contentUri == null);
      synchronized (WeatherMetaData.class)
      {
        if (contentUri == null)
          initUris(WeatherMetaData.getAuthority(paramContext));
        return;
      }
    }

    public static Forecast fromDefaultCursor(Cursor paramCursor)
    {
      ForecastBuilder localForecastBuilder1 = new ForecastBuilder();
      String str = paramCursor.getString(1);
      if (str != null)
      {
        int i = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder2 = localForecastBuilder1.withCityId(i);
      }
      str = paramCursor.getString(6);
      if (str != null)
      {
        int j = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder3 = localForecastBuilder1.withCloudiness(j);
      }
      str = paramCursor.getString(2);
      if (str != null)
      {
        int k = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder4 = localForecastBuilder1.withDateLocal(k);
      }
      str = paramCursor.getString(3);
      if (str != null)
      {
        int m = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder5 = localForecastBuilder1.withTimeLocal(m);
      }
      str = paramCursor.getString(7);
      if (str != null)
      {
        int n = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder6 = localForecastBuilder1.withPrecipitation(n);
      }
      str = paramCursor.getString(5);
      if (str != null)
      {
        int i1 = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder7 = localForecastBuilder1.withMaxTempDefaultUnits(i1);
      }
      str = paramCursor.getString(4);
      if (str != null)
      {
        int i2 = Integer.parseInt(str);
        ForecastBuilder localForecastBuilder8 = localForecastBuilder1.withMinTempDefaultUnits(i2);
      }
      long l = System.currentTimeMillis();
      ForecastBuilder localForecastBuilder9 = localForecastBuilder1.withTimestamp(l);
      return localForecastBuilder1.build();
    }

    public static Uri getCityDateUri(Context paramContext, int paramInt1, int paramInt2)
    {
      Uri localUri1 = getContentUri(paramContext);
      String str1 = Integer.toString(paramInt1);
      Uri localUri2 = Uri.withAppendedPath(localUri1, str1);
      String str2 = Integer.toString(paramInt2);
      return Uri.withAppendedPath(localUri2, str2);
    }

    public static Uri getCityUri(Context paramContext, int paramInt)
    {
      Uri localUri = getContentUri(paramContext);
      String str = Integer.toString(paramInt);
      return Uri.withAppendedPath(localUri, str);
    }

    public static Uri getContentUri(Context paramContext)
    {
      checkInitUris(paramContext);
      return contentUri;
    }

    private static void initUris(String paramString)
    {
      if (contentUri == null);
      synchronized (ForecastMetaData.class)
      {
        if (contentUri == null)
          contentUri = Uri.parse("content://" + paramString + "/" + "forecast");
        return;
      }
    }
  }

  public abstract interface ForecastColumns extends BaseColumns
  {
    public static final String CITY_ID = "city_id";
    public static final String CLOUDINESS = "cloud";
    public static final String DATE = "date";
    public static final String HEAT_INDEX_MAX = "heat_max";
    public static final String HEAT_INDEX_MIN = "heat_min";
    public static final String HUMIDITY_MAX = "humidity_max";
    public static final String HUMIDITY_MIN = "humidity_min";
    public static final String PRECIPITATION = "precip";
    public static final String PRESSURE_MAX = "press_max";
    public static final String PRESSURE_MIN = "press_min";
    public static final String TEMP_MAX = "temp_max";
    public static final String TEMP_MIN = "temp_min";
    public static final String TIME = "time";
    public static final String WIND_DIRECTION = "wind_dir";
    public static final String WIND_SPEED_MAX = "wind_max";
    public static final String WIND_SPEED_MIN = "wind_min";
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.provider.WeatherMetaData
 * JD-Core Version:    0.6.0
 */