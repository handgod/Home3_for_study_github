package com.softspb.weather.provider;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.content.pm.ProviderInfo;
import android.database.AbstractCursor;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.CursorIndexOutOfBoundsException;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.database.sqlite.SQLiteStatement;
import android.net.Uri;
import android.os.Handler;
import android.text.TextUtils;
import android.text.format.Time;
import com.softspb.util.DecimalDateTimeEncoding;
import com.softspb.util.ProjectionCursor;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import com.spb.cities.CurrentLocationInfo;
import com.spb.cities.provider.CitiesContract.CurrentLocation;
import java.util.Arrays;
import java.util.List;

public abstract class WeatherProvider extends ContentProvider
{
  private static final int ALL_CURRENTS = 5;
  private static final int ALL_DAILY_FORECASTS = 7;
  private static final int ALL_DAILY_FORECASTS_FOR_CITY = 8;
  private static final int ALL_DETAILED_FORECASTS = 10;
  private static final int ALL_FORECASTS = 3;
  private static final int ALL_UPDATE_STATUS = 12;
  private static String CITY_DATE_GROUPING = ;
  private static String CITY_DATE_SELECTION = ;
  private static final int CITY_ID_NOT_SET = -2147483648;
  private static final int CLOUD_INDEX = 0;
  private static final String[] CLOUD_PRECIP_PROJECTION = ;
  private static final int DETAILED_FORECAST_CITY = 13;
  private static final int DETAILED_FORECAST_CITY_DATE = 14;
  private static final int FORECAST_FOR_CITY = 18;
  private static final int FORECAST_FOR_CITY_DAY = 19;
  private static final int PRECIP_INDEX = 1;
  private static final int SINGLE_CURRENT = 6;
  private static final int SINGLE_DAILY_FORECAST = 9;
  private static final int SINGLE_UPDATE_STATUS = 11;
  private static final int TIME_INDEX = 2;
  private static int dayForecastCursorCount;
  private static Logger logger;
  private static int requestCount = 0;
  String DELETE_UPDATE_STATUS_CURRENT_LOCATION_SQL = "DELETE FROM update_status WHERE city_id=?";
  String UPDATE_UPDATE_STATUS_CURRENT_LOCATION_SQL = "INSERT OR REPLACE INTO update_status (city_id,status,timestamp,type) SELECT -1024,status,timestamp,type FROM update_status WHERE city_id=?";
  private int currentLocationCityId;
  private ContentObserver currentLocationObserver;
  private Uri currentLocationUpdateStatusUri;
  private SQLiteStatement deleteUpdateStatusCurrentStatement;
  private ContentResolver mContentResolver;
  private SQLiteStatement updateUpdateStatusCurrentStatement;
  private UriMatcher uriMatcher;
  private SQLiteDatabase weatherDB;
  private WeatherDatabaseHelper weatherDBHelper;

  static
  {
    dayForecastCursorCount = 0;
    String[] arrayOfString = new String[3];
    arrayOfString[0] = "cloud";
    arrayOfString[1] = "precip";
    arrayOfString[2] = "time";
    CLOUD_PRECIP_PROJECTION = arrayOfString;
    CITY_DATE_SELECTION = "(city_id = ?) AND (date = ?)";
    CITY_DATE_GROUPING = "city_id,date";
    logger = Loggers.getLogger(WeatherProvider.class.getName());
  }

  public WeatherProvider()
  {
    Handler localHandler = new Handler();
    WeatherProvider.1 local1 = new WeatherProvider.1(this, localHandler);
    this.currentLocationObserver = local1;
  }

  private static StringBuilder compoundSelection(String paramString, int paramInt1, int paramInt2, StringBuilder[] paramArrayOfStringBuilder)
  {
    if ((paramArrayOfStringBuilder == null) || (paramArrayOfStringBuilder.length == 0));
    for (StringBuilder localStringBuilder1 = new StringBuilder(); ; localStringBuilder1 = paramArrayOfStringBuilder[0])
    {
      StringBuilder[] arrayOfStringBuilder = new StringBuilder[1];
      arrayOfStringBuilder[0] = localStringBuilder1;
      StringBuilder localStringBuilder2 = compoundSelection(paramString, paramInt1, arrayOfStringBuilder);
      StringBuilder localStringBuilder3 = localStringBuilder2.append(" AND (").append("date").append(" = ?)");
      return localStringBuilder2;
    }
  }

  private static StringBuilder compoundSelection(String paramString, int paramInt, StringBuilder[] paramArrayOfStringBuilder)
  {
    if ((paramArrayOfStringBuilder == null) || (paramArrayOfStringBuilder.length == 0));
    for (StringBuilder localStringBuilder1 = new StringBuilder(); ; localStringBuilder1 = paramArrayOfStringBuilder[0])
    {
      if (paramString != null)
        StringBuilder localStringBuilder2 = localStringBuilder1.append("(").append(paramString).append(") AND (");
      StringBuilder localStringBuilder3 = localStringBuilder1.append("city_id").append(" = ?");
      if (paramString != null)
        StringBuilder localStringBuilder4 = localStringBuilder1.append(41);
      return localStringBuilder1;
    }
  }

  private void initAuthority(String paramString, Context paramContext)
  {
    String str = "initAuthority: authority=" + paramString;
    logd(str);
    UriMatcher localUriMatcher = new UriMatcher(-1);
    this.uriMatcher = localUriMatcher;
    this.uriMatcher.addURI(paramString, "forecast", 3);
    this.uriMatcher.addURI(paramString, "forecast/#", 18);
    this.uriMatcher.addURI(paramString, "forecast/#/#", 19);
    this.uriMatcher.addURI(paramString, "current", 5);
    this.uriMatcher.addURI(paramString, "current/#", 6);
    this.uriMatcher.addURI(paramString, "dailyforecast", 7);
    this.uriMatcher.addURI(paramString, "dailyforecast/#", 8);
    this.uriMatcher.addURI(paramString, "dailyforecast/#/#", 9);
    this.uriMatcher.addURI(paramString, "forecast/timeofday", 10);
    this.uriMatcher.addURI(paramString, "forecast/timeofday/#", 13);
    this.uriMatcher.addURI(paramString, "forecast/timeofday/#/#", 14);
    this.uriMatcher.addURI(paramString, "update_status/*", 11);
    this.uriMatcher.addURI(paramString, "update_status", 12);
  }

  private void logd(int paramInt, String paramString)
  {
    Logger localLogger = logger;
    String str = 40 + paramInt + ") " + paramString;
    localLogger.d(str);
  }

  private void logd(String paramString)
  {
    logger.d(paramString);
  }

  private void logw(int paramInt, String paramString)
  {
    Logger localLogger = logger;
    String str = 40 + paramInt + ") " + paramString;
    localLogger.w(str);
  }

  private String[] mergeSelectionArgs(String[] paramArrayOfString, Object[] paramArrayOfObject)
  {
    String str = null;
    int i;
    int j;
    label16: String[] arrayOfString;
    int k;
    label47: int m;
    if (paramArrayOfString == null)
    {
      i = 0;
      if (paramArrayOfObject != null)
        break label94;
      j = 0;
      arrayOfString = new String[i + j];
      if (paramArrayOfString != null)
        System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, i);
      if (paramArrayOfObject == null)
        break label112;
      k = 0;
      if (k >= j)
        break label112;
      m = i + k;
      if (paramArrayOfObject[k] != 0)
        break label101;
    }
    label94: label101: for (str = "NULL"; ; str = paramArrayOfObject[k].toString())
    {
      arrayOfString[m] = str;
      k += 1;
      break label47;
      i = paramArrayOfString.length;
      break;
      j = paramArrayOfObject.length;
      break label16;
    }
    label112: return arrayOfString;
  }

  private void notifyDailyForecastChanged(int paramInt)
  {
    Uri localUri1 = WeatherMetaData.DailyForecastMetaData.getContentUri(null);
    String str1 = Integer.toString(paramInt);
    Uri localUri2 = Uri.withAppendedPath(localUri1, str1);
    StringBuilder localStringBuilder = new StringBuilder().append("Notifying change URI=");
    String str2 = localUri2.toString();
    String str3 = str2;
    logd(str3);
    this.mContentResolver.notifyChange(localUri2, null);
  }

  private void notifyDailyForecastChanged(int paramInt1, int paramInt2)
  {
    Uri localUri1 = WeatherMetaData.DailyForecastMetaData.getContentUri(null);
    String str1 = Integer.toString(paramInt1);
    Uri localUri2 = Uri.withAppendedPath(localUri1, str1);
    String str2 = Integer.toString(paramInt2);
    Uri localUri3 = Uri.withAppendedPath(localUri2, str2);
    StringBuilder localStringBuilder = new StringBuilder().append("Notifying change URI=");
    String str3 = localUri3.toString();
    String str4 = str3;
    logd(str4);
    this.mContentResolver.notifyChange(localUri3, null);
  }

  private void notifyDetailedForecastChanged(int paramInt)
  {
    Uri localUri = WeatherMetaData.TimeOfDayForecastMetaData.getUri(null, paramInt);
    StringBuilder localStringBuilder = new StringBuilder().append("Notifying change URI=");
    String str1 = localUri.toString();
    String str2 = str1;
    logd(str2);
    this.mContentResolver.notifyChange(localUri, null);
  }

  private void notifyDetailedForecastChanged(int paramInt1, int paramInt2)
  {
    Uri localUri = WeatherMetaData.TimeOfDayForecastMetaData.getUri(null, paramInt1, paramInt2);
    StringBuilder localStringBuilder = new StringBuilder().append("Notifying change URI=");
    String str1 = localUri.toString();
    String str2 = str1;
    logd(str2);
    this.mContentResolver.notifyChange(localUri, null);
  }

  private void notifyForecastChanged(int paramInt)
  {
    Uri localUri = WeatherMetaData.ForecastMetaData.getCityUri(null, paramInt);
    StringBuilder localStringBuilder = new StringBuilder().append("Notifying change URI=");
    String str1 = localUri.toString();
    String str2 = str1;
    logd(str2);
    this.mContentResolver.notifyChange(localUri, null);
  }

  private void notifyForecastChanged(int paramInt1, int paramInt2)
  {
    Uri localUri = WeatherMetaData.ForecastMetaData.getCityDateUri(null, paramInt1, paramInt2);
    StringBuilder localStringBuilder = new StringBuilder().append("Notifying change URI=");
    String str1 = localUri.toString();
    String str2 = str1;
    logd(str2);
    this.mContentResolver.notifyChange(localUri, null);
  }

  private Cursor queryAllDailyForecasts(int paramInt, Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    logd(paramInt, "Processing All Daily Forecasts query...");
    long l1 = System.currentTimeMillis();
    WeatherProvider localWeatherProvider = this;
    int i = paramInt;
    Uri localUri = paramUri;
    String[] arrayOfString1 = paramArrayOfString1;
    String str1 = paramString1;
    String[] arrayOfString2 = paramArrayOfString2;
    String str2 = paramString2;
    DailyForecastCursor localDailyForecastCursor = new DailyForecastCursor(i, localUri, arrayOfString1, str1, arrayOfString2, str2);
    long l2 = System.currentTimeMillis();
    StringBuilder localStringBuilder = new StringBuilder().append("DailyForeacastCursor object created in ");
    long l3 = l2 - l1;
    String str3 = l3 + "ms";
    logd(paramInt, str3);
    ContentResolver localContentResolver = this.mContentResolver;
    localDailyForecastCursor.setNotificationUri(localContentResolver, paramUri);
    logd(paramInt, "Request Completed.");
    return localDailyForecastCursor;
  }

  private Cursor queryAllDailyForecastsForCity(int paramInt1, Uri paramUri, int paramInt2, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("Processing All Daily Forecasts query for one city: cityId=");
    int i = paramInt2;
    String str1 = i;
    logd(paramInt1, str1);
    long l1 = System.currentTimeMillis();
    WeatherProvider localWeatherProvider = this;
    int j = paramInt1;
    Uri localUri1 = paramUri;
    int k = paramInt2;
    String[] arrayOfString1 = paramArrayOfString1;
    String str2 = paramString1;
    String[] arrayOfString2 = paramArrayOfString2;
    String str3 = paramString2;
    DailyForecastCursor localDailyForecastCursor = new DailyForecastCursor(j, localUri1, k, arrayOfString1, str2, arrayOfString2, str3);
    long l2 = System.currentTimeMillis();
    StringBuilder localStringBuilder2 = new StringBuilder().append("DailyForeacastCursor object created in ");
    long l3 = l2 - l1;
    String str4 = l3 + "ms";
    logd(paramInt1, str4);
    ContentResolver localContentResolver = this.mContentResolver;
    Uri localUri2 = paramUri;
    localDailyForecastCursor.setNotificationUri(localContentResolver, localUri2);
    logd(paramInt1, "Request Completed.");
    return localDailyForecastCursor;
  }

  private Cursor queryDetailedForecasts(int paramInt1, Uri paramUri, String[] paramArrayOfString1, int paramInt2, int paramInt3, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    WeatherProvider localWeatherProvider1 = this;
    int i = paramInt1;
    localWeatherProvider1.logd(i, "Processing All Time-Of-Day Forecasts query...");
    SQLiteQueryBuilder localSQLiteQueryBuilder = new SQLiteQueryBuilder();
    localSQLiteQueryBuilder.setTables("forecast");
    int j = 0;
    if (paramInt2 >= 0)
    {
      StringBuilder localStringBuilder1 = new StringBuilder().append("city_id").append(61);
      int k = paramInt2;
      StringBuilder localStringBuilder2 = localStringBuilder1.append(k);
      localSQLiteQueryBuilder.appendWhere(localStringBuilder2);
      j = 1;
    }
    if (paramInt3 >= 0)
    {
      if (j != 0)
        localSQLiteQueryBuilder.appendWhere(") AND (");
      StringBuilder localStringBuilder3 = new StringBuilder().append("date").append(61);
      int m = paramInt3;
      StringBuilder localStringBuilder4 = localStringBuilder3.append(m);
      localSQLiteQueryBuilder.appendWhere(localStringBuilder4);
    }
    StringBuilder localStringBuilder5 = new StringBuilder().append("city_id").append(44).append("date").append(44).append("time_of_day");
    String[] arrayOfString1 = WeatherMetaData.TimeOfDayForecastMetaData.TIME_OF_DAY_FORECAST_PROJECTION;
    String str1 = localStringBuilder5.toString();
    String str2 = paramString1;
    String[] arrayOfString2 = paramArrayOfString2;
    String str3 = paramString2;
    String str4 = localSQLiteQueryBuilder.buildQuery(arrayOfString1, str2, arrayOfString2, str1, null, str3, null);
    long l1 = System.currentTimeMillis();
    StringBuilder localStringBuilder6 = new StringBuilder().append("Doing raw query: ");
    String str5 = str4;
    String str6 = str5;
    WeatherProvider localWeatherProvider2 = this;
    int n = paramInt1;
    localWeatherProvider2.logd(n, str6);
    SQLiteDatabase localSQLiteDatabase = this.weatherDB;
    String str7 = str4;
    String[] arrayOfString3 = paramArrayOfString2;
    Cursor localCursor = localSQLiteDatabase.rawQuery(str7, arrayOfString3);
    long l2 = System.currentTimeMillis();
    StringBuilder localStringBuilder7 = new StringBuilder().append("Query completed in ");
    long l3 = l2 - l1;
    String str8 = l3 + "ms";
    WeatherProvider localWeatherProvider3 = this;
    int i1 = paramInt1;
    localWeatherProvider3.logd(i1, str8);
    String[] arrayOfString4 = paramArrayOfString1;
    ProjectionCursor localProjectionCursor = new ProjectionCursor(localCursor, arrayOfString4);
    ContentResolver localContentResolver = getContext().getContentResolver();
    Uri localUri = paramUri;
    localProjectionCursor.setNotificationUri(localContentResolver, localUri);
    WeatherProvider localWeatherProvider4 = this;
    int i2 = paramInt1;
    localWeatherProvider4.logd(i2, "Request Completed.");
    return localProjectionCursor;
  }

  private Cursor queryForecast(int paramInt, Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2, String paramString3, String paramString4)
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("queryForecast >>> uri=").append(paramUri).append(" selection=");
    String str1 = paramString1;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1).append(" selectionArgs=");
    String str2;
    Cursor localCursor;
    Uri localUri2;
    String str15;
    if (paramArrayOfString2 == null)
    {
      str2 = "null";
      StringBuilder localStringBuilder3 = localStringBuilder2.append(str2).append(" sort=");
      String str3 = paramString2;
      StringBuilder localStringBuilder4 = localStringBuilder3.append(str3).append(" cityId=");
      String str4 = paramString3;
      StringBuilder localStringBuilder5 = localStringBuilder4.append(str4).append(" date=");
      String str5 = paramString4;
      String str6 = str5;
      logd(paramInt, str6);
      SQLiteQueryBuilder localSQLiteQueryBuilder = new SQLiteQueryBuilder();
      int i = 0;
      localSQLiteQueryBuilder.setTables("forecast");
      if (paramString3 != null)
      {
        if (i != 0)
          localSQLiteQueryBuilder.appendWhere(") AND (");
        localSQLiteQueryBuilder.appendWhere("city_id");
        localSQLiteQueryBuilder.appendWhere("=");
        String str7 = paramString3;
        localSQLiteQueryBuilder.appendWhereEscapeString(str7);
        i = 1;
      }
      if (paramString4 != null)
      {
        if (i != 0)
          localSQLiteQueryBuilder.appendWhere(") AND (");
        localSQLiteQueryBuilder.appendWhere("date");
        localSQLiteQueryBuilder.appendWhere(">=");
        String str8 = paramString4;
        localSQLiteQueryBuilder.appendWhereEscapeString(str8);
      }
      String[] arrayOfString1 = paramArrayOfString1;
      String str9 = paramString1;
      String[] arrayOfString2 = paramArrayOfString2;
      String str10 = paramString2;
      String str11 = localSQLiteQueryBuilder.buildQuery(arrayOfString1, str9, arrayOfString2, null, null, str10, null);
      String str12 = "queryForecast: " + str11;
      logd(paramInt, str12);
      SQLiteDatabase localSQLiteDatabase = this.weatherDB;
      String[] arrayOfString3 = paramArrayOfString1;
      String str13 = paramString1;
      String[] arrayOfString4 = paramArrayOfString2;
      String str14 = paramString2;
      localCursor = localSQLiteQueryBuilder.query(localSQLiteDatabase, arrayOfString3, str13, arrayOfString4, null, null, str14);
      localUri1 = paramUri;
      if (paramString4 != null)
      {
        if (paramString3 == null)
          break label411;
        localUri2 = WeatherMetaData.ForecastMetaData.getContentUri(null);
        str15 = paramString3;
      }
    }
    label411: for (Uri localUri1 = Uri.withAppendedPath(localUri2, str15); ; localUri1 = WeatherMetaData.ForecastMetaData.getContentUri(null))
    {
      ContentResolver localContentResolver = this.mContentResolver;
      localCursor.setNotificationUri(localContentResolver, localUri1);
      logd(paramInt, "queryForecast <<<");
      return localCursor;
      str2 = Arrays.toString(paramArrayOfString2);
      break;
    }
  }

  private Cursor querySingleDailyForecast(int paramInt1, Uri paramUri, int paramInt2, int paramInt3, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("Processing Single Daily Forecast query: cityId=");
    int i = paramInt2;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(i).append(", date=");
    int j = paramInt3;
    String str1 = j;
    int k = paramInt1;
    logd(k, str1);
    long l1 = System.currentTimeMillis();
    WeatherProvider localWeatherProvider = this;
    int m = paramInt1;
    Uri localUri1 = paramUri;
    int n = paramInt2;
    int i1 = paramInt3;
    String[] arrayOfString1 = paramArrayOfString1;
    String str2 = paramString1;
    String[] arrayOfString2 = paramArrayOfString2;
    String str3 = paramString2;
    DailyForecastCursor localDailyForecastCursor = new DailyForecastCursor(m, localUri1, n, i1, arrayOfString1, str2, arrayOfString2, str3);
    long l2 = System.currentTimeMillis();
    StringBuilder localStringBuilder3 = new StringBuilder().append("DailyForeacastCursor object created in ");
    long l3 = l2 - l1;
    String str4 = l3 + "ms";
    int i2 = paramInt1;
    logd(i2, str4);
    ContentResolver localContentResolver = this.mContentResolver;
    Uri localUri2 = paramUri;
    localDailyForecastCursor.setNotificationUri(localContentResolver, localUri2);
    int i3 = paramInt1;
    logd(i3, "Request Completed.");
    return localDailyForecastCursor;
  }

  private void updateUpdateStatusForCurrentLocation()
  {
    if (this.updateUpdateStatusCurrentStatement == null)
    {
      SQLiteDatabase localSQLiteDatabase1 = this.weatherDB;
      String str1 = this.UPDATE_UPDATE_STATUS_CURRENT_LOCATION_SQL;
      SQLiteStatement localSQLiteStatement1 = localSQLiteDatabase1.compileStatement(str1);
      this.updateUpdateStatusCurrentStatement = localSQLiteStatement1;
      SQLiteDatabase localSQLiteDatabase2 = this.weatherDB;
      String str2 = this.DELETE_UPDATE_STATUS_CURRENT_LOCATION_SQL;
      SQLiteStatement localSQLiteStatement2 = localSQLiteDatabase2.compileStatement(str2);
      this.deleteUpdateStatusCurrentStatement = localSQLiteStatement2;
      this.deleteUpdateStatusCurrentStatement.bindLong(1, 64512L);
      Uri localUri1 = WeatherMetaData.UpdateStatusMetaData.getContentUri(getContext());
      String str3 = Integer.toString(64512);
      Uri localUri2 = Uri.withAppendedPath(localUri1, str3);
      this.currentLocationUpdateStatusUri = localUri2;
    }
    this.deleteUpdateStatusCurrentStatement.execute();
    SQLiteStatement localSQLiteStatement3 = this.updateUpdateStatusCurrentStatement;
    long l = this.currentLocationCityId;
    localSQLiteStatement3.bindLong(1, l);
    this.updateUpdateStatusCurrentStatement.execute();
    ContentResolver localContentResolver = this.mContentResolver;
    Uri localUri3 = this.currentLocationUpdateStatusUri;
    localContentResolver.notifyChange(localUri3, null);
  }

  public void attachInfo(Context paramContext, ProviderInfo paramProviderInfo)
  {
    super.attachInfo(paramContext, paramProviderInfo);
    String str1 = paramProviderInfo.authority;
    String str2 = WeatherMetaData.getAuthority(paramContext);
    if (!str1.equals(str2))
    {
      String str3 = "Unexpected authority in manifest: " + str1 + ", expected: " + str2;
      throw new RuntimeException(str3);
    }
    String str4 = getClass().getName();
    StringBuilder localStringBuilder = new StringBuilder();
    String str5 = paramContext.getPackageName();
    String str6 = str5 + ".weather.provider.WeatherProvider";
    if (!str4.equals(str6))
    {
      String str7 = "Unexpected WeatherProvider class name: " + str4 + ", must be: " + str6;
      throw new RuntimeException(str7);
    }
  }

  public int bulkInsert(Uri paramUri, ContentValues[] paramArrayOfContentValues)
  {
    int i = requestCount + 1;
    requestCount = i;
    UriMatcher localUriMatcher = this.uriMatcher;
    Uri localUri1 = paramUri;
    int j = localUriMatcher.match(localUri1);
    StringBuilder localStringBuilder1 = new StringBuilder().append("bulkInsert: uri=");
    Uri localUri2 = paramUri;
    String str1 = localUri2;
    WeatherProvider localWeatherProvider1 = this;
    String str2 = str1;
    localWeatherProvider1.logd(i, str2);
    String str4;
    String str5;
    int k;
    int m;
    Object localObject;
    int n;
    int i2;
    label180: ContentValues localContentValues;
    Integer localInteger1;
    switch (j)
    {
    default:
      StringBuilder localStringBuilder2 = new StringBuilder().append("Unsupported URI: ");
      Uri localUri3 = paramUri;
      String str3 = localUri3;
      throw new IllegalArgumentException(str3);
    case 3:
      str4 = "forecast";
      str5 = "date";
      k = 0;
      m = -2147483648;
      localObject = null;
      n = 0;
      ContentValues[] arrayOfContentValues = paramArrayOfContentValues;
      int i1 = arrayOfContentValues.length;
      i2 = 0;
      if (i2 >= i1)
        break label441;
      localContentValues = arrayOfContentValues[i2];
      int i3 = 12;
      if (j == i3)
      {
        String str6 = "timestamp";
        if (localContentValues.get(str6) == null)
        {
          Long localLong1 = Long.valueOf(System.currentTimeMillis());
          String str7 = "timestamp";
          Long localLong2 = localLong1;
          localContentValues.put(str7, localLong2);
        }
      }
      SQLiteDatabase localSQLiteDatabase = this.weatherDB;
      String str8 = str4;
      if (localSQLiteDatabase.replace(str8, str5, localContentValues) <= 0L)
        break;
      String str9 = "Inserted: " + localContentValues;
      WeatherProvider localWeatherProvider2 = this;
      String str10 = str9;
      localWeatherProvider2.logd(i, str10);
      String str11 = "city_id";
      localInteger1 = localContentValues.getAsInteger(str11);
      if (localInteger1 != null);
    case 5:
    case 12:
    }
    for (int i4 = -2147483648; ; i4 = localInteger1.intValue())
    {
      k += 1;
      String str12 = "date";
      Integer localInteger2 = localContentValues.getAsInteger(str12);
      int i5 = -2147483648;
      if (i4 != i5)
        m = i4;
      int i6 = 3;
      if ((j == i6) && (localInteger2 != null))
      {
        if (!localInteger2.equals(localObject))
          n = 1;
        localObject = localInteger2;
      }
      i2 += 1;
      break label180;
      str4 = "current";
      str5 = "time";
      break;
      str4 = "update_status";
      str5 = "city_id";
      break;
    }
    label441: if (k > 0)
    {
      int i7 = 3;
      if (j == i7)
      {
        int i8 = -2147483648;
        if (m != i8)
          break label610;
        StringBuilder localStringBuilder3 = new StringBuilder().append("Notifying change URI=");
        String str13 = WeatherMetaData.DailyForecastMetaData.getContentUri(null).toString();
        String str14 = str13;
        WeatherProvider localWeatherProvider3 = this;
        String str15 = str14;
        localWeatherProvider3.logd(str15);
        ContentResolver localContentResolver1 = this.mContentResolver;
        Uri localUri4 = WeatherMetaData.DailyForecastMetaData.getContentUri(null);
        localContentResolver1.notifyChange(localUri4, null);
      }
    }
    while (true)
    {
      StringBuilder localStringBuilder4 = new StringBuilder().append("Notifying change URI=");
      String str16 = WeatherMetaData.TimeOfDayForecastMetaData.getContentUri(null).toString();
      String str17 = str16;
      WeatherProvider localWeatherProvider4 = this;
      String str18 = str17;
      localWeatherProvider4.logd(str18);
      ContentResolver localContentResolver2 = this.mContentResolver;
      Uri localUri5 = WeatherMetaData.TimeOfDayForecastMetaData.getContentUri(null);
      localContentResolver2.notifyChange(localUri5, null);
      return k;
      label610: if (n != 0)
      {
        notifyDailyForecastChanged(m);
        notifyDetailedForecastChanged(m);
        notifyForecastChanged(m);
        continue;
      }
      if (localObject == null)
        continue;
      int i9 = localObject.intValue();
      WeatherProvider localWeatherProvider5 = this;
      int i10 = i9;
      localWeatherProvider5.notifyDailyForecastChanged(m, i10);
      int i11 = localObject.intValue();
      WeatherProvider localWeatherProvider6 = this;
      int i12 = i11;
      localWeatherProvider6.notifyDetailedForecastChanged(m, i12);
      int i13 = localObject.intValue();
      WeatherProvider localWeatherProvider7 = this;
      int i14 = i13;
      localWeatherProvider7.notifyForecastChanged(m, i14);
    }
  }

  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString)
  {
    String str1 = null;
    String str3;
    StringBuilder localStringBuilder2;
    switch (this.uriMatcher.match(paramUri))
    {
    case 4:
    default:
      String str2 = "Unsupported URI: " + paramUri;
      throw new IllegalArgumentException(str2);
    case 3:
      str3 = "forecast";
      if (str1 == null)
        break;
      StringBuilder localStringBuilder1 = new StringBuilder().append(str1).append("=");
      String str4 = (String)paramUri.getPathSegments().get(1);
      localStringBuilder2 = localStringBuilder1.append(str4);
      if (TextUtils.isEmpty(paramString));
    case 5:
    case 6:
    }
    for (String str5 = " AND (" + paramString + 41; ; str5 = "")
    {
      paramString = str5;
      int i = this.weatherDB.delete(str3, paramString, paramArrayOfString);
      StringBuilder localStringBuilder3 = new StringBuilder().append("Notifying change URI=");
      String str6 = paramUri.toString();
      String str7 = str6;
      logd(str7);
      this.mContentResolver.notifyChange(paramUri, null);
      return i;
      str3 = "current";
      break;
      str3 = "current";
      str1 = "city_id";
      break;
    }
  }

  public String getType(Uri paramUri)
  {
    String str2;
    switch (this.uriMatcher.match(paramUri))
    {
    case 4:
    case 13:
    case 14:
    case 15:
    case 16:
    case 17:
    default:
      String str1 = "Unsupported URI:" + paramUri;
      throw new IllegalArgumentException(str1);
    case 3:
    case 18:
    case 19:
      str2 = "vnd.android.cursor.dir/vnd.softspb.forecast";
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
    case 10:
    case 11:
    case 12:
    }
    while (true)
    {
      return str2;
      str2 = "vnd.android.cursor.dir/vnd.softspb.current";
      continue;
      str2 = "vnd.android.cursor.item/vnd.softspb.current";
      continue;
      str2 = "vnd.android.cursor.dir/vnd.softspb.forecast.day";
      continue;
      str2 = "vnd.android.cursor.item/vnd.softspb.forecast.day";
      continue;
      str2 = "vnd.android.cursor.dir/vnd.softspb.forecast.day";
      continue;
      str2 = "vnd.android.cursor.item/vnd.softspb.eventslog";
      continue;
      str2 = "vnd.android.cursor.dir/vnd.softspb.eventslog";
    }
  }

  public Uri insert(Uri paramUri, ContentValues paramContentValues)
  {
    int i = requestCount + 1;
    requestCount = i;
    int j = this.uriMatcher.match(paramUri);
    StringBuilder localStringBuilder1 = new StringBuilder().append("insert: uri=");
    String str1 = paramUri.toString();
    String str2 = str1;
    logd(i, str2);
    String str4;
    String str5;
    long l1;
    Uri localUri1;
    label214: Integer localInteger2;
    switch (j)
    {
    default:
      String str3 = "Unsupported URI:" + paramUri;
      throw new IllegalArgumentException(str3);
    case 3:
      str4 = "forecast";
      str5 = "date";
      l1 = this.weatherDB.replace(str4, str5, paramContentValues);
      if (l1 > 0L)
      {
        String str6 = "Inserted: " + paramContentValues;
        logd(i, str6);
        if (j == 5)
        {
          long l2 = paramContentValues.getAsInteger("city_id").intValue();
          localUri1 = ContentUris.withAppendedId(paramUri, l2);
          StringBuilder localStringBuilder2 = new StringBuilder().append("Notifying change URI=");
          String str7 = localUri1.toString();
          String str8 = str7;
          logd(str8);
          this.mContentResolver.notifyChange(localUri1, null);
          if (j != 3)
            break;
          Integer localInteger1 = paramContentValues.getAsInteger("date");
          localInteger2 = paramContentValues.getAsInteger("city_id");
          if (localInteger2 == null)
            break;
          if (localInteger1 == null)
            break label569;
          int k = localInteger2.intValue();
          int m = localInteger1.intValue();
          notifyForecastChanged(k, m);
          int n = localInteger2.intValue();
          int i1 = localInteger1.intValue();
          notifyDailyForecastChanged(n, i1);
          int i2 = localInteger2.intValue();
          int i3 = localInteger1.intValue();
          notifyDetailedForecastChanged(i2, i3);
        }
      }
    case 5:
    case 12:
    }
    while (true)
    {
      return localUri1;
      str4 = "current";
      str5 = "time";
      break;
      str4 = "update_status";
      str5 = "timestamp";
      if (paramContentValues.get("timestamp") != null)
        break;
      Long localLong = Long.valueOf(System.currentTimeMillis());
      paramContentValues.put("timestamp", localLong);
      break;
      if (j == 12)
      {
        int i4 = paramContentValues.getAsInteger("city_id").intValue();
        long l3 = i4;
        localUri1 = ContentUris.withAppendedId(paramUri, l3);
        int i5 = this.currentLocationCityId;
        if (i4 != i5)
          break label214;
        Integer localInteger3 = Integer.valueOf(64512);
        paramContentValues.put("city_id", localInteger3);
        long l4 = this.weatherDB.replace(str4, str5, paramContentValues);
        String str9 = Integer.toString(64512);
        Uri localUri2 = Uri.withAppendedPath(paramUri, str9);
        StringBuilder localStringBuilder3 = new StringBuilder().append("Notifying change URI=");
        String str10 = localUri2.toString();
        String str11 = str10;
        logd(str11);
        this.mContentResolver.notifyChange(localUri2, null);
        break label214;
      }
      localUri1 = ContentUris.withAppendedId(paramUri, l1);
      break label214;
      label569: int i6 = localInteger2.intValue();
      notifyForecastChanged(i6);
      int i7 = localInteger2.intValue();
      notifyDailyForecastChanged(i7);
      int i8 = localInteger2.intValue();
      notifyDetailedForecastChanged(i8);
      continue;
      localUri1 = null;
    }
  }

  public boolean onCreate()
  {
    int i = 1;
    Context localContext = getContext();
    String str = WeatherMetaData.getAuthority(localContext);
    initAuthority(str, localContext);
    ContentResolver localContentResolver1 = localContext.getContentResolver();
    this.mContentResolver = localContentResolver1;
    WeatherDatabaseHelper localWeatherDatabaseHelper = new WeatherDatabaseHelper();
    this.weatherDBHelper = localWeatherDatabaseHelper;
    SQLiteDatabase localSQLiteDatabase = this.weatherDBHelper.getWritableDatabase();
    this.weatherDB = localSQLiteDatabase;
    ContentResolver localContentResolver2 = this.mContentResolver;
    int k = CitiesContract.CurrentLocation.queryCurrentLocationInfo(localContext, localContentResolver2).getCityId();
    this.currentLocationCityId = k;
    ContentResolver localContentResolver3 = this.mContentResolver;
    Uri localUri = CitiesContract.CurrentLocation.getContentUri(localContext);
    ContentObserver localContentObserver = this.currentLocationObserver;
    localContentResolver3.registerContentObserver(localUri, i, localContentObserver);
    if (this.weatherDB != null);
    while (true)
    {
      return i;
      int j = 0;
    }
  }

  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    int i = requestCount + 1;
    requestCount = i;
    String str1 = null;
    List localList = paramUri.getPathSegments();
    String str2 = null;
    String str3 = null;
    String str4 = null;
    StringBuilder localStringBuilder1 = new StringBuilder().append("Received QUERY: ");
    String str5 = paramUri.toString();
    String str6 = str5;
    logd(i, str6);
    StringBuilder localStringBuilder2 = new StringBuilder().append("    projection=");
    String str7 = Arrays.toString(paramArrayOfString1);
    String str8 = str7;
    logd(i, str8);
    StringBuilder localStringBuilder3 = new StringBuilder().append("    selection=");
    String str9 = paramString1;
    String str10 = str9;
    logd(i, str10);
    StringBuilder localStringBuilder4 = new StringBuilder().append("    selectionArgs=");
    String str11 = Arrays.toString(paramArrayOfString2);
    String str12 = str11;
    logd(i, str12);
    StringBuilder localStringBuilder5 = new StringBuilder().append("    sort=");
    String str13 = paramString2;
    String str14 = str13;
    logd(i, str14);
    UriMatcher localUriMatcher = this.uriMatcher;
    Uri localUri1 = paramUri;
    Cursor localCursor1;
    String str20;
    String str21;
    label507: String str22;
    label519: StringBuilder localStringBuilder10;
    StringBuilder localStringBuilder11;
    String str25;
    switch (localUriMatcher.match(localUri1))
    {
    case 4:
    case 15:
    case 16:
    case 17:
    default:
      StringBuilder localStringBuilder6 = new StringBuilder().append("Unssuported URI, throwing exception: uri=");
      String str15 = paramUri.toString();
      String str16 = str15;
      logw(i, str16);
      StringBuilder localStringBuilder7 = new StringBuilder().append("Unsupported URI:");
      Uri localUri2 = paramUri;
      String str17 = localUri2;
      throw new IllegalArgumentException(str17);
    case 19:
      str4 = (String)localList.get(2);
    case 18:
      str3 = (String)localList.get(1);
    case 3:
      WeatherProvider localWeatherProvider1 = this;
      Uri localUri3 = paramUri;
      String[] arrayOfString1 = paramArrayOfString1;
      String str18 = paramString1;
      String[] arrayOfString2 = paramArrayOfString2;
      String str19 = paramString2;
      localCursor1 = localWeatherProvider1.queryForecast(i, localUri3, arrayOfString1, str18, arrayOfString2, str19, str3, str4);
      return localCursor1;
    case 6:
      str1 = "city_id";
      str2 = (String)localList.get(1);
    case 5:
      str20 = "current";
      str21 = "date,time";
      if (TextUtils.isEmpty(paramString2))
      {
        str22 = str21;
        if (str1 == null)
          break;
        StringBuilder localStringBuilder8 = new StringBuilder();
        String str23 = str1;
        StringBuilder localStringBuilder9 = localStringBuilder8.append(str23).append("=");
        String str24 = str2;
        localStringBuilder10 = localStringBuilder9.append(str24);
        if (TextUtils.isEmpty(paramString1))
          break label1327;
        localStringBuilder11 = new StringBuilder().append(" AND (");
        str25 = paramString1;
      }
    case 11:
    case 12:
    case 9:
    case 8:
    case 7:
    case 10:
    case 13:
    case 14:
    }
    label1327: for (String str26 = str25 + 41; ; str26 = "")
    {
      paramString1 = str26;
      String str27 = null;
      if ((paramArrayOfString1 != null) && (paramArrayOfString1.length == 2) && (paramArrayOfString1[1].equalsIgnoreCase("date")))
        str27 = "date";
      String[] arrayOfString3 = paramArrayOfString1;
      String str28 = paramString1;
      String str29 = SQLiteQueryBuilder.buildQueryString(0, str20, arrayOfString3, str28, str27, null, str22, null);
      long l1 = System.currentTimeMillis();
      StringBuilder localStringBuilder12 = new StringBuilder().append("Doing Raw Query: ");
      String str30 = str29;
      String str31 = str30;
      logd(i, str31);
      SQLiteDatabase localSQLiteDatabase = this.weatherDB;
      String str32 = str29;
      String[] arrayOfString4 = paramArrayOfString2;
      localCursor1 = localSQLiteDatabase.rawQuery(str32, arrayOfString4);
      long l2 = System.currentTimeMillis();
      StringBuilder localStringBuilder13 = new StringBuilder().append("Query completed in ");
      long l3 = l2 - l1;
      String str33 = l3 + "ms";
      logd(i, str33);
      StringBuilder localStringBuilder14 = new StringBuilder().append("Registering cursor [");
      Cursor localCursor2 = localCursor1;
      StringBuilder localStringBuilder15 = localStringBuilder14.append(localCursor2).append("] with notification URI: ");
      String str34 = paramUri.toString();
      String str35 = str34;
      logd(i, str35);
      ContentResolver localContentResolver = this.mContentResolver;
      Cursor localCursor3 = localCursor1;
      Uri localUri4 = paramUri;
      localCursor3.setNotificationUri(localContentResolver, localUri4);
      logd(i, "Request Completed.");
      break;
      str1 = "city_id";
      str2 = (String)localList.get(1);
      str20 = "update_status";
      str21 = null;
      break label507;
      int j = Integer.parseInt((String)localList.get(1));
      int k = Integer.parseInt((String)localList.get(2));
      WeatherProvider localWeatherProvider2 = this;
      int m = i;
      Uri localUri5 = paramUri;
      String[] arrayOfString5 = paramArrayOfString1;
      String str36 = paramString1;
      String[] arrayOfString6 = paramArrayOfString2;
      String str37 = paramString2;
      localCursor1 = localWeatherProvider2.querySingleDailyForecast(m, localUri5, j, k, arrayOfString5, str36, arrayOfString6, str37);
      break;
      int n = Integer.parseInt((String)localList.get(1));
      WeatherProvider localWeatherProvider3 = this;
      int i1 = i;
      Uri localUri6 = paramUri;
      int i2 = n;
      String[] arrayOfString7 = paramArrayOfString1;
      String str38 = paramString1;
      String[] arrayOfString8 = paramArrayOfString2;
      String str39 = paramString2;
      localCursor1 = localWeatherProvider3.queryAllDailyForecastsForCity(i1, localUri6, i2, arrayOfString7, str38, arrayOfString8, str39);
      break;
      WeatherProvider localWeatherProvider4 = this;
      Uri localUri7 = paramUri;
      String[] arrayOfString9 = paramArrayOfString1;
      String str40 = paramString1;
      String[] arrayOfString10 = paramArrayOfString2;
      String str41 = paramString2;
      localCursor1 = localWeatherProvider4.queryAllDailyForecasts(i, localUri7, arrayOfString9, str40, arrayOfString10, str41);
      break;
      WeatherProvider localWeatherProvider5 = this;
      int i3 = i;
      Uri localUri8 = paramUri;
      String[] arrayOfString11 = paramArrayOfString1;
      String str42 = paramString1;
      String[] arrayOfString12 = paramArrayOfString2;
      String str43 = paramString2;
      localCursor1 = localWeatherProvider5.queryDetailedForecasts(i3, localUri8, arrayOfString11, 65535, 65535, str42, arrayOfString12, str43);
      break;
      int i4 = Integer.parseInt((String)localList.get(2));
      WeatherProvider localWeatherProvider6 = this;
      int i5 = i;
      Uri localUri9 = paramUri;
      String[] arrayOfString13 = paramArrayOfString1;
      int i6 = i4;
      String str44 = paramString1;
      String[] arrayOfString14 = paramArrayOfString2;
      String str45 = paramString2;
      localCursor1 = localWeatherProvider6.queryDetailedForecasts(i5, localUri9, arrayOfString13, i6, 65535, str44, arrayOfString14, str45);
      break;
      int i7 = Integer.parseInt((String)localList.get(2));
      int i8 = Integer.parseInt((String)localList.get(3));
      WeatherProvider localWeatherProvider7 = this;
      int i9 = i;
      Uri localUri10 = paramUri;
      String[] arrayOfString15 = paramArrayOfString1;
      int i10 = i7;
      int i11 = i8;
      String str46 = paramString1;
      String[] arrayOfString16 = paramArrayOfString2;
      String str47 = paramString2;
      localCursor1 = localWeatherProvider7.queryDetailedForecasts(i9, localUri10, arrayOfString15, i10, i11, str46, arrayOfString16, str47);
      break;
      str22 = paramString2;
      break label519;
    }
  }

  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString)
  {
    String str1 = null;
    String str3;
    StringBuilder localStringBuilder2;
    switch (this.uriMatcher.match(paramUri))
    {
    case 4:
    default:
      String str2 = "Unsupported URI: " + paramUri;
      throw new IllegalArgumentException(str2);
    case 3:
      str3 = "forecast";
      if (str1 == null)
        break;
      StringBuilder localStringBuilder1 = new StringBuilder().append(str1).append("=");
      String str4 = (String)paramUri.getPathSegments().get(1);
      localStringBuilder2 = localStringBuilder1.append(str4);
      if (TextUtils.isEmpty(paramString));
    case 5:
    case 6:
    }
    for (String str5 = " AND (" + paramString + 41; ; str5 = "")
    {
      paramString = str5;
      int i = this.weatherDB.update(str3, paramContentValues, paramString, paramArrayOfString);
      StringBuilder localStringBuilder3 = new StringBuilder().append("Notifying change URI=");
      String str6 = paramUri.toString();
      String str7 = str6;
      logd(str7);
      this.mContentResolver.notifyChange(paramUri, null);
      return i;
      str3 = "current";
      break;
      str3 = "current";
      str1 = "city_id";
      break;
    }
  }

  class DailyForecastCursor extends AbstractCursor
  {
    private static final int TIME_2_PM = 1400;
    private SQLiteCursor cloudPrecipCur;
    private int columnCount;
    private String[] columnNames;
    private Cursor cur;
    private int cursorId;
    private Object[] data;
    private String query;
    private int requestId;
    private int rowCount = 0;

    public DailyForecastCursor(int paramUri, Uri paramInt1, int paramInt2, int paramArrayOfString1, String[] paramString1, String paramArrayOfString2, String[] paramString2, String arg9)
    {
    }

    public DailyForecastCursor(int paramUri, Uri paramInt1, int paramArrayOfString1, String[] paramString1, String paramArrayOfString2, String[] paramString2, String arg8)
    {
    }

    public DailyForecastCursor(int paramUri, Uri paramArrayOfString1, String[] paramString1, String paramArrayOfString2, String[] paramString2, String arg7)
    {
      int i = WeatherProvider.access$404();
      this.cursorId = i;
      String str1 = paramString1;
      this.columnNames = str1;
      int j = this.columnNames.length;
      this.columnCount = j;
      int k = paramUri;
      this.requestId = k;
      int m = paramUri;
      WeatherProvider.this.logd(m, "Initializing DailyForecastCursor object...");
      String[] arrayOfString1 = WeatherMetaData.ForecastMetaData.DAY_FORECAST_PROJECTION;
      String str2 = WeatherProvider.CITY_DATE_GROUPING;
      String[] arrayOfString2 = paramArrayOfString2;
      Object localObject1;
      Object localObject2 = localObject1;
      String str3 = SQLiteQueryBuilder.buildQueryString(0, "forecast", arrayOfString1, arrayOfString2, str2, null, localObject2, null);
      this.query = str3;
      long l1 = System.currentTimeMillis();
      StringBuilder localStringBuilder1 = new StringBuilder().append("Doing raw query: ");
      String str4 = this.query;
      String str5 = str4;
      int n = paramUri;
      WeatherProvider.this.logd(n, str5);
      StringBuilder localStringBuilder2 = new StringBuilder().append("  selectionArgs: ");
      String str6 = Arrays.toString(paramString2);
      String str7 = str6;
      int i1 = paramUri;
      WeatherProvider.this.logd(i1, str7);
      SQLiteDatabase localSQLiteDatabase1 = WeatherProvider.this.weatherDB;
      String str8 = this.query;
      String str9 = paramString2;
      Cursor localCursor = localSQLiteDatabase1.rawQuery(str8, str9);
      this.cur = localCursor;
      long l2 = System.currentTimeMillis();
      StringBuilder localStringBuilder3 = new StringBuilder().append("Query completed in ");
      long l3 = l2 - l1;
      String str10 = l3 + "ms";
      int i2 = paramUri;
      WeatherProvider.this.logd(i2, str10);
      String[] arrayOfString3 = WeatherProvider.CLOUD_PRECIP_PROJECTION;
      String str11 = WeatherProvider.CITY_DATE_SELECTION;
      String str12 = SQLiteQueryBuilder.buildQueryString(0, "forecast", arrayOfString3, str11, null, null, null, null);
      long l4 = System.currentTimeMillis();
      String str13 = "Doing raw query: " + str12;
      int i3 = paramUri;
      WeatherProvider.this.logd(i3, str13);
      int i4 = paramUri;
      WeatherProvider.this.logd(i4, "  selectionArgs: 0, 0");
      SQLiteDatabase localSQLiteDatabase2 = WeatherProvider.this.weatherDB;
      String[] arrayOfString4 = new String[2];
      arrayOfString4[0] = "0";
      arrayOfString4[1] = "0";
      SQLiteCursor localSQLiteCursor = (SQLiteCursor)localSQLiteDatabase2.rawQuery(str12, arrayOfString4);
      this.cloudPrecipCur = localSQLiteCursor;
      long l5 = System.currentTimeMillis();
      StringBuilder localStringBuilder4 = new StringBuilder().append("Query completed in ");
      long l6 = l5 - l4;
      String str14 = l6 + "ms";
      int i5 = paramUri;
      WeatherProvider.this.logd(i5, str14);
      updateData_Sql();
    }

    private void addRow(Object[] paramArrayOfObject)
    {
      int i = paramArrayOfObject.length;
      int j = this.columnCount;
      if (i != j)
      {
        StringBuilder localStringBuilder1 = new StringBuilder().append("columnNames.length = ");
        int k = this.columnCount;
        StringBuilder localStringBuilder2 = localStringBuilder1.append(k).append(", columnValues.length = ");
        int m = paramArrayOfObject.length;
        String str = m;
        throw new IllegalArgumentException(str);
      }
      int n = this.rowCount;
      int i1 = n + 1;
      this.rowCount = i1;
      int i2 = this.columnCount;
      int i3 = n * i2;
      int i4 = this.columnCount + i3;
      ensureCapacity(i4);
      Object[] arrayOfObject = this.data;
      int i5 = this.columnCount;
      System.arraycopy(paramArrayOfObject, 0, arrayOfObject, i3, i5);
    }

    private void ensureCapacity(int paramInt)
    {
      int i = this.data.length;
      if (paramInt > i)
      {
        Object[] arrayOfObject1 = this.data;
        int j = this.data.length * 2;
        if (j < paramInt)
          j = paramInt;
        Object[] arrayOfObject2 = new Object[j];
        this.data = arrayOfObject2;
        Object[] arrayOfObject3 = this.data;
        int k = arrayOfObject1.length;
        System.arraycopy(arrayOfObject1, 0, arrayOfObject3, 0, k);
      }
    }

    private Object get(int paramInt)
    {
      if (paramInt >= 0)
      {
        int i = this.columnCount;
        if (paramInt < i);
      }
      else
      {
        StringBuilder localStringBuilder = new StringBuilder().append("Requested column: ").append(paramInt).append(", # of columns: ");
        int j = this.columnCount;
        String str = j;
        throw new CursorIndexOutOfBoundsException(str);
      }
      if (this.mPos < 0)
        throw new CursorIndexOutOfBoundsException("Before first row.");
      int k = this.mPos;
      int m = this.rowCount;
      if (k >= m)
        throw new CursorIndexOutOfBoundsException("After last row.");
      Object[] arrayOfObject = this.data;
      int n = this.mPos;
      int i1 = this.columnCount;
      int i2 = n * i1 + paramInt;
      return arrayOfObject[i2];
    }

    private int[] getCloudPrecip(int paramInt1, int paramInt2)
    {
      long l1 = System.currentTimeMillis();
      SQLiteCursor localSQLiteCursor = this.cloudPrecipCur;
      String[] arrayOfString = new String[2];
      String str1 = Integer.toString(paramInt1);
      arrayOfString[0] = str1;
      String str2 = Integer.toString(paramInt2);
      arrayOfString[1] = str2;
      localSQLiteCursor.setSelectionArguments(arrayOfString);
      int[] arrayOfInt;
      if (!this.cloudPrecipCur.requery())
        arrayOfInt = null;
      while (true)
      {
        return arrayOfInt;
        arrayOfInt = new int[2];
        if (this.cloudPrecipCur.moveToFirst())
        {
          int i = 2147483647;
          while (!this.cloudPrecipCur.isAfterLast())
          {
            int j = Math.abs(this.cloudPrecipCur.getInt(2) + -1400);
            if (j < i)
            {
              int k = this.cloudPrecipCur.getInt(0);
              arrayOfInt[0] = k;
              int m = this.cloudPrecipCur.getInt(1);
              arrayOfInt[1] = m;
              i = j;
            }
            boolean bool = this.cloudPrecipCur.moveToNext();
          }
        }
        this.cloudPrecipCur.deactivate();
        long l2 = System.currentTimeMillis();
      }
    }

    private void initCapacity(int paramInt)
    {
      if (paramInt < 1)
        paramInt = 1;
      Object[] arrayOfObject = new Object[this.columnCount * paramInt];
      this.data = arrayOfObject;
      this.rowCount = 0;
      this.mPos = -1;
    }

    private void updateData_Sql()
    {
      WeatherProvider localWeatherProvider1 = WeatherProvider.this;
      int i = this.requestId;
      localWeatherProvider1.logd(i, "Updating DailyForecastCursor data...");
      int j = this.cur.getCount();
      initCapacity(j);
      int k = 0;
      boolean bool1 = this.cur.moveToFirst();
      while (!this.cur.isAfterLast())
      {
        int m = this.cur.getInt(0);
        int n = this.cur.getInt(1);
        WeatherProvider localWeatherProvider2 = WeatherProvider.this;
        int i1 = this.requestId;
        String str1 = "Generating cursor data for cityId=" + m + ", date=" + n;
        localWeatherProvider2.logd(i1, str1);
        int i2 = this.cur.getInt(3);
        int i3 = this.cur.getInt(2);
        int[] arrayOfInt = getCloudPrecip(m, n);
        Object[] arrayOfObject = new Object[this.columnCount];
        int i4 = 0;
        int i5 = this.columnCount;
        if (i4 < i5)
        {
          String str2 = this.columnNames[i4];
          if ("_id".equals(str2))
          {
            Integer localInteger1 = Integer.valueOf(k);
            arrayOfObject[i4] = localInteger1;
          }
          while (true)
          {
            i4 += 1;
            break;
            if ("city_id".equals(str2))
            {
              Integer localInteger2 = Integer.valueOf(m);
              arrayOfObject[i4] = localInteger2;
              continue;
            }
            if ("cloud".equals(str2))
            {
              Integer localInteger3 = Integer.valueOf(arrayOfInt[0]);
              arrayOfObject[i4] = localInteger3;
              continue;
            }
            if ("date".equals(str2))
            {
              Integer localInteger4 = Integer.valueOf(n);
              arrayOfObject[i4] = localInteger4;
              continue;
            }
            if ("precip".equals(str2))
            {
              Integer localInteger5 = Integer.valueOf(arrayOfInt[1]);
              arrayOfObject[i4] = localInteger5;
              continue;
            }
            if ("temp_max".equals(str2))
            {
              Integer localInteger6 = Integer.valueOf(i3);
              arrayOfObject[i4] = localInteger6;
              continue;
            }
            if (!"temp_min".equals(str2))
              continue;
            Integer localInteger7 = Integer.valueOf(i2);
            arrayOfObject[i4] = localInteger7;
          }
        }
        addRow(arrayOfObject);
        boolean bool2 = this.cur.moveToNext();
        k += 1;
      }
      this.cur.deactivate();
    }

    public void close()
    {
      super.close();
      this.cur.close();
      this.cloudPrecipCur.close();
    }

    public String[] getColumnNames()
    {
      return this.columnNames;
    }

    public int getCount()
    {
      return this.rowCount;
    }

    public double getDouble(int paramInt)
    {
      Object localObject = get(paramInt);
      double d;
      if (localObject == null)
        d = 0.0D;
      while (true)
      {
        return d;
        if ((localObject instanceof Number))
        {
          d = ((Number)localObject).doubleValue();
          continue;
        }
        d = Double.parseDouble(localObject.toString());
      }
    }

    public float getFloat(int paramInt)
    {
      Object localObject = get(paramInt);
      float f;
      if (localObject == null)
        f = 0.0F;
      while (true)
      {
        return f;
        if ((localObject instanceof Number))
        {
          f = ((Number)localObject).floatValue();
          continue;
        }
        f = Float.parseFloat(localObject.toString());
      }
    }

    public int getInt(int paramInt)
    {
      Object localObject = get(paramInt);
      int i;
      if (localObject == null)
        i = 0;
      while (true)
      {
        return i;
        if ((localObject instanceof Number))
        {
          i = ((Number)localObject).intValue();
          continue;
        }
        i = Integer.parseInt(localObject.toString());
      }
    }

    public long getLong(int paramInt)
    {
      Object localObject = get(paramInt);
      long l;
      if (localObject == null)
        l = 0L;
      while (true)
      {
        return l;
        if ((localObject instanceof Number))
        {
          l = ((Number)localObject).longValue();
          continue;
        }
        l = Long.parseLong(localObject.toString());
      }
    }

    String getQuery()
    {
      return this.query;
    }

    public short getShort(int paramInt)
    {
      Object localObject = get(paramInt);
      int i;
      if (localObject == null)
        i = 0;
      while (true)
      {
        return i;
        if ((localObject instanceof Number))
        {
          i = ((Number)localObject).shortValue();
          continue;
        }
        i = Short.parseShort(localObject.toString());
      }
    }

    public String getString(int paramInt)
    {
      Object localObject = get(paramInt);
      if (localObject == null);
      for (String str = null; ; str = localObject.toString())
        return str;
    }

    public boolean isNull(int paramInt)
    {
      if (get(paramInt) == null);
      for (int i = 1; ; i = 0)
        return i;
    }

    protected void onChange(boolean paramBoolean)
    {
      WeatherProvider localWeatherProvider1 = WeatherProvider.this;
      int i = this.requestId;
      localWeatherProvider1.logd(i, "DailyForecastCursor.onChange");
      long l1 = System.currentTimeMillis();
      if (this.cur.requery())
      {
        updateData_Sql();
        long l2 = System.currentTimeMillis();
        WeatherProvider localWeatherProvider2 = WeatherProvider.this;
        int j = this.requestId;
        StringBuilder localStringBuilder = new StringBuilder().append("Cursor updated in ");
        long l3 = l2 - l1;
        String str = l3 + "ms";
        localWeatherProvider2.logd(j, str);
      }
      super.onChange(paramBoolean);
    }
  }

  class WeatherDatabaseHelper extends SQLiteOpenHelper
  {
    private static final String CITIES_INDEX_BEFORE_VERSION_15 = "idx_cities";
    private static final String CITIES_TABLE_BEFORE_VERSION_15 = "cities";
    private static final String DB_NAME = "weather.db";
    private static final int DB_VERSION_15 = 15;
    private static final int DB_VERSION_6 = 6;
    private static final int DB_VERSION_7 = 7;
    private static final int DB_VERSION_8 = 8;
    private static final String EVENTS_LOG_TABLE_NAME_BEFORE_VERSION_7 = "events_log";
    private static final String TIMEZONES_TABLE_BEFORE_VERSION_15 = "timezones";

    public WeatherDatabaseHelper()
    {
      super("weather.db", null, 15);
    }

    private static void logd(String paramString)
    {
      WeatherProvider.logger.d(paramString);
    }

    public void onCreate(SQLiteDatabase paramSQLiteDatabase)
    {
      logd("onCreate");
      paramSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS forecast (_id INTEGER PRIMARY KEY AUTOINCREMENT, city_id INTEGER NOT NULL, date INTEGER, time INTEGER NOT NULL, temp_min INTEGER, temp_max INTEGER, cloud INTEGER, precip INTEGER, press_min INTEGER, press_max INTEGER, humidity_min INTEGER, humidity_max INTEGER, heat_min INTEGER, heat_max INTEGER, wind_min INTEGER, wind_max INTEGER, wind_dir INTEGER, UNIQUE (city_id, date, time));");
      paramSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS current (_id INTEGER PRIMARY KEY AUTOINCREMENT, city_id INTEGER, station TEXT, date INTEGER, time INTEGER, temp INTEGER, wind_dir TEXT, wind_speed REAL, pressure REAL, humidity REAL, dew_point INTEGER, sky_icon INTEGER,  UNIQUE (city_id, station));");
      paramSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS update_status (_id INTEGER PRIMARY KEY AUTOINCREMENT, city_id INTEGER NOT NULL, status INTEGER NOT NULL, timestamp LONG NOT NULL, type INTEGER NOT NULL,  UNIQUE (city_id,status,type));");
    }

    public void onOpen(SQLiteDatabase paramSQLiteDatabase)
    {
      super.onOpen(paramSQLiteDatabase);
      int i = DecimalDateTimeEncoding.getTodayDateEncoded();
      Time localTime = new Time();
      localTime.setToNow();
      int j = localTime.monthDay + -1;
      localTime.monthDay = j;
      long l = localTime.normalize(0);
      int k = DecimalDateTimeEncoding.encodeDate(localTime);
      logd("Deleting outdated forecasts: currentDate=" + i);
      String[] arrayOfString1 = new String[1];
      String str1 = Integer.toString(i);
      arrayOfString1[0] = str1;
      int m = paramSQLiteDatabase.delete("forecast", "date < ?", arrayOfString1);
      logd("Deleted " + m + " rows from " + "forecast" + " table.");
      logd("Deleting outdated current data: yesterdayDate=" + k);
      String[] arrayOfString2 = new String[1];
      String str2 = Integer.toString(k);
      arrayOfString2[0] = str2;
      int n = paramSQLiteDatabase.delete("current", "date < ?", arrayOfString2);
      logd("Deleted " + n + " rows from " + "current" + " table.");
    }

    public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2)
    {
      logd("onUpgrade: oldVersion=" + paramInt1 + " newVersion=" + paramInt2);
      if (paramInt1 < 6)
      {
        paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS forecast");
        paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS current");
        paramSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS forecast (_id INTEGER PRIMARY KEY AUTOINCREMENT, city_id INTEGER NOT NULL, date INTEGER, time INTEGER NOT NULL, temp_min INTEGER, temp_max INTEGER, cloud INTEGER, precip INTEGER, press_min INTEGER, press_max INTEGER, humidity_min INTEGER, humidity_max INTEGER, heat_min INTEGER, heat_max INTEGER, wind_min INTEGER, wind_max INTEGER, wind_dir INTEGER, UNIQUE (city_id, date, time));");
        paramSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS current (_id INTEGER PRIMARY KEY AUTOINCREMENT, city_id INTEGER, station TEXT, date INTEGER, time INTEGER, temp INTEGER, wind_dir TEXT, wind_speed REAL, pressure REAL, humidity REAL, dew_point INTEGER, sky_icon INTEGER,  UNIQUE (city_id, station));");
      }
      if (paramInt1 < 7)
        paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS events_log");
      while (true)
      {
        if (paramInt1 < 8)
          paramSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS update_status (_id INTEGER PRIMARY KEY AUTOINCREMENT, city_id INTEGER NOT NULL, status INTEGER NOT NULL, timestamp LONG NOT NULL, type INTEGER NOT NULL,  UNIQUE (city_id,status,type));");
        if (paramInt1 < 15)
        {
          paramSQLiteDatabase.execSQL("DROP INDEX IF EXISTS idx_cities");
          paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS cities");
          paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS timezones");
        }
        return;
        if (paramInt1 >= 8)
          continue;
        paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS update_status");
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.provider.WeatherProvider
 * JD-Core Version:    0.6.0
 */