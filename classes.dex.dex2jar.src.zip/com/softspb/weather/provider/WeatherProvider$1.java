package com.softspb.weather.provider;

import android.content.ContentResolver;
import android.content.Context;
import android.database.ContentObserver;
import android.os.Handler;
import com.spb.cities.CurrentLocationInfo;
import com.spb.cities.provider.CitiesContract.CurrentLocation;

class WeatherProvider$1 extends ContentObserver
{
  public void onChange(boolean paramBoolean)
  {
    Context localContext = this.this$0.getContext();
    ContentResolver localContentResolver = WeatherProvider.access$000(this.this$0);
    int i = CitiesContract.CurrentLocation.queryCurrentLocationInfo(localContext, localContentResolver).getCityId();
    int j = WeatherProvider.access$100(this.this$0);
    if (i != j)
    {
      int k = WeatherProvider.access$102(this.this$0, i);
      WeatherProvider.access$200(this.this$0);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.weather.provider.WeatherProvider.1
 * JD-Core Version:    0.6.0
 */