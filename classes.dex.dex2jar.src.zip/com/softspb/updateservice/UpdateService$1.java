package com.softspb.updateservice;

class UpdateService$1 extends Thread
{
  public void run()
  {
    try
    {
      UpdateService localUpdateService = this.this$0;
      int[] arrayOfInt = this.val$updateIds;
      localUpdateService.doUpdate(arrayOfInt);
      return;
    }
    finally
    {
      this.this$0.releaseWakeLock();
      this.this$0.stopSelf();
    }
    throw localObject;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.updateservice.UpdateService.1
 * JD-Core Version:    0.6.0
 */