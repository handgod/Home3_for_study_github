package com.softspb.updateservice;

import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.DefaultHttpClient;

public abstract class DownloadClient<ParamType, DataType>
{
  public static final int COMM_TIMEOUT_MILLIS = 120000;
  private static final Object TIMEOUT = new Object();
  protected Logger logger;
  private int reqCount;
  private int serverCount;
  protected String[] serverUrls;
  private final Object stateChangedMonitor;
  private boolean stopFlag = 0;

  public DownloadClient(String[] paramArrayOfString)
  {
    Object localObject = new Object();
    this.stateChangedMonitor = localObject;
    this.reqCount = 0;
    Logger localLogger = Loggers.getLogger(getClass().getName());
    this.logger = localLogger;
    this.serverUrls = paramArrayOfString;
    int i = paramArrayOfString.length;
    this.serverCount = i;
  }

  private DataType download(HttpClient paramHttpClient, ParamType paramParamType, String paramString)
  {
    Logger localLogger = this.logger;
    String str1 = "download >>> param=" + paramParamType + " serverUri=" + paramString;
    localLogger.d(str1);
    String str2 = createUrl(paramString, paramParamType);
    HttpGet localHttpGet = new HttpGet(str2);
    Object[] arrayOfObject = new Object[2];
    StringBuilder localStringBuilder = new StringBuilder().append("DownloadClient-Request-");
    int i = this.reqCount + 1;
    this.reqCount = i;
    String str3 = i;
    Object localObject1 = TIMEOUT;
    arrayOfObject[1] = localObject1;
    try
    {
      DownloadClient localDownloadClient = this;
      HttpClient localHttpClient = paramHttpClient;
      ParamType ? = paramParamType;
      new DownloadClient.1(localDownloadClient, str3, arrayOfObject, localHttpClient, localHttpGet, ?).start();
      synchronized (this.stateChangedMonitor)
      {
        this.stateChangedMonitor.wait(120000L);
        Object localObject3 = arrayOfObject[1];
        Object localObject4 = TIMEOUT;
        if (localObject3 == localObject4)
          this.logger.w("TIMEOUT expired, aborting request...");
        if (localHttpGet != null)
          localHttpGet.abort();
        return arrayOfObject[0];
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        int j = 1;
        ??? = null;
        arrayOfObject[j] = ???;
        Object localObject7 = arrayOfObject[1];
        Object localObject8 = TIMEOUT;
        if (localObject7 == localObject8)
          this.logger.w("TIMEOUT expired, aborting request...");
        if (localHttpGet == null)
          continue;
        localHttpGet.abort();
      }
    }
    finally
    {
      Object localObject9 = arrayOfObject[1];
      Object localObject10 = TIMEOUT;
      if (localObject9 == localObject10)
        this.logger.w("TIMEOUT expired, aborting request...");
      if (localHttpGet != null)
        localHttpGet.abort();
    }
  }

  private DataType sendRequest(HttpClient paramHttpClient, HttpGet paramHttpGet, ParamType paramParamType)
    throws Exception
  {
    HttpEntity localHttpEntity = null;
    HttpResponse localHttpResponse;
    try
    {
      Logger localLogger1 = this.logger;
      String str1 = "sendRequest: using httpClient=" + paramHttpClient;
      localLogger1.d(str1);
      Logger localLogger2 = this.logger;
      StringBuilder localStringBuilder1 = new StringBuilder().append("sendRequest: Sending HTTP request: ");
      URI localURI = paramHttpGet.getURI();
      String str2 = localURI;
      localLogger2.d(str2);
      localHttpResponse = paramHttpClient.execute(paramHttpGet);
      StatusLine localStatusLine = localHttpResponse.getStatusLine();
      if (localStatusLine.getStatusCode() != 200)
      {
        StringBuilder localStringBuilder2 = new StringBuilder().append("sendRequest: Received error HTTP status code: ");
        int i = localStatusLine.getStatusCode();
        String str3 = i;
        throw new DownloadException();
      }
    }
    finally
    {
      if (localHttpEntity == null);
    }
    try
    {
      localHttpEntity.consumeContent();
      label172: throw localObject1;
      this.logger.d("sendRequest: Received status OK");
      localHttpEntity = localHttpResponse.getEntity();
      if (localHttpEntity == null)
        throw new DownloadException();
      InputStream localInputStream = localHttpEntity.getContent();
      this.logger.d("sendRequest: Parsing the received content...");
      Object localObject2 = parseResponse(localInputStream, paramParamType);
      if (localObject2 == null)
        throw new DownloadException();
      if (localHttpEntity != null);
      try
      {
        localHttpEntity.consumeContent();
        label262: return localObject2;
      }
      catch (IOException localIOException1)
      {
        break label262;
      }
    }
    catch (IOException localIOException2)
    {
      break label172;
    }
  }

  public void abort()
  {
    this.stopFlag = 1;
  }

  protected abstract String createUrl(String paramString, ParamType paramParamType);

  public DataType download(ParamType paramParamType)
  {
    Logger localLogger = this.logger;
    String str1 = "Attempting to download data for param=" + paramParamType;
    localLogger.d(str1);
    int i = this.serverCount;
    String[] arrayOfString = this.serverUrls;
    Object localObject1 = null;
    this.stopFlag = 0;
    HttpClient localHttpClient = obtainHttpClient();
    int j = 0;
    while (true)
    {
      if (j < i);
      try
      {
        if (!this.stopFlag)
        {
          String str2 = arrayOfString[j];
          Object localObject2 = download(localHttpClient, paramParamType, str2);
          localObject1 = localObject2;
          if (localObject1 == null);
        }
        else
        {
          return localObject1;
        }
        j += 1;
      }
      finally
      {
        releaseHttpClient(localHttpClient);
      }
    }
  }

  protected HttpClient obtainHttpClient()
  {
    return new DefaultHttpClient();
  }

  protected abstract DataType parseResponse(InputStream paramInputStream, ParamType paramParamType)
    throws Exception;

  protected void releaseHttpClient(HttpClient paramHttpClient)
  {
    ClientConnectionManager localClientConnectionManager = paramHttpClient.getConnectionManager();
    if (localClientConnectionManager != null)
      localClientConnectionManager.shutdown();
  }

  class DownloadException extends Exception
  {
    public DownloadException()
    {
    }

    public DownloadException()
    {
      super();
    }

    public DownloadException(Throwable arg2)
    {
      super(localThrowable);
    }

    public DownloadException()
    {
      super();
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.updateservice.DownloadClient
 * JD-Core Version:    0.6.0
 */