package com.softspb.updateservice;

import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.util.Arrays;

public abstract class UpdateService<DataType> extends Service
{
  public static final String ACTION_SET_PREFERENCES = "com.softspb.weather.updateservice.action.SetPreferences";
  public static final String ACTION_UPDATE_PREFIX = "com.softspb.weather.updateservice.action.Update";
  public static final String PARAM_FORCE_UPDATE = "force_update";
  public static final String PREFERENCE_USE_ONLY_WIFI = "use-only-wifi";
  public static final String UPDATE_IDS_INT_ARRAY = "update_ids";
  protected final String TAG;
  private DownloadClient<Integer, DataType> downloadClient;
  protected final Logger logger;
  private PowerManager.WakeLock wakeLock;

  public UpdateService()
  {
    String str = getClass().getSimpleName();
    this.TAG = str;
    Logger localLogger = Loggers.getLogger(getClass().getName());
    this.logger = localLogger;
  }

  public static boolean checkNetworkAvailabilityAndSettings(Context paramContext, boolean paramBoolean1, boolean paramBoolean2, Logger paramLogger)
  {
    int i = 0;
    ConnectivityManager localConnectivityManager;
    if (!paramBoolean1)
    {
      localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
      if (!localConnectivityManager.getBackgroundDataSetting())
        paramLogger.d("Background data setting is off, not updating");
    }
    while (true)
    {
      return i;
      NetworkInfo localNetworkInfo = localConnectivityManager.getActiveNetworkInfo();
      if ((localNetworkInfo == null) || (!localNetworkInfo.isAvailable()))
      {
        paramLogger.d("Network is not available, not updating");
        continue;
      }
      if (paramBoolean2)
      {
        if (localNetworkInfo == null);
        for (int j = -2147483648; ; j = localNetworkInfo.getType())
        {
          String str = "onStartCommand: netType=" + j;
          paramLogger.d(str);
          if (j == 1)
            break label130;
          paramLogger.d("onStartCommand: network is not Wifi - not doing update");
          break;
        }
      }
      label130: i = 1;
    }
  }

  private void handleSetPreferences(Intent paramIntent)
  {
    this.logger.d("handleSetPreference >>>");
    SharedPreferences localSharedPreferences = getSharedPreferences();
    if (paramIntent.hasExtra("use-only-wifi"))
    {
      boolean bool1 = paramIntent.getBooleanExtra("use-only-wifi", 0);
      Logger localLogger = this.logger;
      String str = "handleSetPreference: use-only-wifi=" + bool1;
      localLogger.d(str);
      boolean bool2 = localSharedPreferences.edit().putBoolean("use-only-wifi", bool1).commit();
    }
    while (true)
    {
      this.logger.d("handleSetPreference <<<");
      return;
      this.logger.d("handleSetPreference: use-only-wifi not set");
    }
  }

  public static void setUseOnlyWifiPreference(Context paramContext, boolean paramBoolean)
  {
    Intent localIntent1 = new Intent("com.softspb.weather.updateservice.action.SetPreferences");
    Intent localIntent2 = localIntent1.putExtra("use-only-wifi", paramBoolean);
    String str = paramContext.getPackageName();
    Intent localIntent3 = localIntent1.setPackage(str);
    ComponentName localComponentName = paramContext.startService(localIntent1);
  }

  protected abstract DownloadClient<Integer, DataType> createDownloadClient(Context paramContext);

  void doUpdate(int[] paramArrayOfInt)
  {
    try
    {
      onStartedUpdate();
      int[] arrayOfInt = paramArrayOfInt;
      int i = arrayOfInt.length;
      j = 0;
      if (j < i)
      {
        k = arrayOfInt[j];
        m = 0;
        onStartedUpdateId(k);
      }
    }
    finally
    {
      try
      {
        int j;
        Logger localLogger1 = this.logger;
        String str1 = "Attempting to update data for city_id=" + k;
        localLogger1.i(str1);
        DownloadClient localDownloadClient = this.downloadClient;
        Integer localInteger = Integer.valueOf(k);
        Object localObject1 = localDownloadClient.download(localInteger);
        Logger localLogger2 = this.logger;
        String str2 = "Received data: " + localObject1;
        localLogger2.d(str2);
        if (localObject1 != null)
        {
          int n = onDataReceived(localObject1);
          m = n;
        }
        onFinishedUpdateId(k, m);
        j += 1;
      }
      finally
      {
        int k;
        int m;
        onFinishedUpdateId(k, m);
      }
      this.logger.d("Finished update.");
      onFinishedUpdate();
    }
    this.logger.d("Finished update.");
    onFinishedUpdate();
  }

  protected abstract SharedPreferences getSharedPreferences();

  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }

  public void onCreate()
  {
    this.logger.d("onCreate");
    super.onCreate();
    DownloadClient localDownloadClient = createDownloadClient(this);
    this.downloadClient = localDownloadClient;
    PowerManager localPowerManager = (PowerManager)getSystemService("power");
    String str = this.TAG;
    PowerManager.WakeLock localWakeLock = localPowerManager.newWakeLock(1, str);
    this.wakeLock = localWakeLock;
  }

  protected abstract boolean onDataReceived(DataType paramDataType);

  public void onDestroy()
  {
    this.logger.d("onDestroy");
    this.logger.d("Aborting download client...");
    if (this.downloadClient != null)
    {
      this.downloadClient.abort();
      this.logger.d("Download client aborted");
    }
  }

  protected void onFinishedUpdate()
  {
  }

  protected void onFinishedUpdateId(int paramInt, boolean paramBoolean)
  {
  }

  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    Logger localLogger1 = this.logger;
    StringBuilder localStringBuilder1 = new StringBuilder().append("onStartCommand: intent=");
    String str1 = paramIntent.getAction();
    String str2 = str1;
    localLogger1.d(str2);
    super.onStart(paramIntent, paramInt2);
    String str3 = paramIntent.getAction();
    if (str3 == null)
      stopSelf();
    while (true)
    {
      return 2;
      if ("com.softspb.weather.updateservice.action.SetPreferences".equals(str3))
      {
        handleSetPreferences(paramIntent);
        stopSelf();
        continue;
      }
      int[] arrayOfInt = paramIntent.getExtras().getIntArray("update_ids");
      boolean bool1 = paramIntent.getBooleanExtra("force_update", 0);
      boolean bool2 = getSharedPreferences().getBoolean("use-only-wifi", 0);
      Logger localLogger2 = this.logger;
      String str4 = "onStartCommand: useOnlyWifi=" + bool2 + " forceUpdate=" + bool1;
      localLogger2.d(str4);
      Logger localLogger3 = this.logger;
      StringBuilder localStringBuilder2 = new StringBuilder().append("onStartCommand: action=").append(str3).append(", updateIds=");
      if (arrayOfInt == null);
      for (String str5 = "null"; ; str5 = Arrays.toString(arrayOfInt))
      {
        String str6 = str5;
        localLogger3.d(str6);
        Logger localLogger4 = this.logger;
        if (checkNetworkAvailabilityAndSettings(this, bool1, bool2, localLogger4))
          break label281;
        this.logger.d("Update is not allowed, stop.");
        stopSelf();
        break;
      }
      label281: if ((arrayOfInt == null) || (arrayOfInt.length == 0))
      {
        this.logger.w("update IDs not specified, doing nothing.");
        stopSelf();
        continue;
      }
      UpdateService.1 local1 = new UpdateService.1(this, arrayOfInt);
      this.wakeLock.acquire();
      local1.start();
    }
  }

  protected void onStartedUpdate()
  {
  }

  protected void onStartedUpdateId(int paramInt)
  {
  }

  void releaseWakeLock()
  {
    if ((this.wakeLock != null) && (this.wakeLock.isHeld()))
      this.wakeLock.release();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.updateservice.UpdateService
 * JD-Core Version:    0.6.0
 */