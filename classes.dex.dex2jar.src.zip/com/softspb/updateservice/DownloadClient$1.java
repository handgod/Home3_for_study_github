package com.softspb.updateservice;

import com.softspb.util.log.Logger;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;

class DownloadClient$1 extends Thread
{
  public void run()
  {
    try
    {
      Object[] arrayOfObject = this.val$res;
      DownloadClient localDownloadClient = this.this$0;
      HttpClient localHttpClient = this.val$httpClient;
      HttpGet localHttpGet = this.val$req;
      Object localObject1 = this.val$param;
      Object localObject2 = DownloadClient.access$000(localDownloadClient, localHttpClient, localHttpGet, localObject1);
      arrayOfObject[0] = localObject2;
    }
    catch (Exception localException)
    {
      synchronized (DownloadClient.access$100(this.this$0))
      {
        this.val$res[1] = 0;
        DownloadClient.access$100(this.this$0).notify();
        return;
        localException = localException;
        Logger localLogger = this.this$0.logger;
        String str = "Error occurred while processing HTTP request: " + localException;
        localLogger.e(str, localException);
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.updateservice.DownloadClient.1
 * JD-Core Version:    0.6.0
 */