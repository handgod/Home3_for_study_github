package com.softspb.updateservice;

public abstract interface UpdatePreferences
{
  public static final String PREFERENCE_ONLY_WIFI = "use-only-wifi";
  public static final String PREFERENCE_UPDATE_INTERVAL = "update-interval";

  public abstract long getUpdateIntervalMs();

  public abstract boolean isUseOnlyWifi();

  public abstract void setUpdateIntervalMs(long paramLong);

  public abstract void setUseOnlyWifi(boolean paramBoolean);
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.updateservice.UpdatePreferences
 * JD-Core Version:    0.6.0
 */