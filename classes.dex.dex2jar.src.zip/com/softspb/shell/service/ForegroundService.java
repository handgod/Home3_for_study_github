package com.softspb.shell.service;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import com.softspb.shell.Home;
import com.spb.shell3d.R.string;

public class ForegroundService extends Service
{
  public static final String ACTION_FOREGROUND = "com.spb.shell3d.FOREGROUND";

  void handleCommand(Intent paramIntent)
  {
    if (paramIntent == null);
    while (true)
    {
      return;
      String str = paramIntent.getAction();
      if (!"com.spb.shell3d.FOREGROUND".equals(str))
        continue;
      int i = R.string.app_name;
      CharSequence localCharSequence1 = getText(i);
      long l = System.currentTimeMillis();
      Notification localNotification = new Notification(0, localCharSequence1, l);
      Intent localIntent = new Intent(this, Home.class);
      PendingIntent localPendingIntent = PendingIntent.getActivity(this, 0, localIntent, 0);
      int j = R.string.app_name;
      CharSequence localCharSequence2 = getText(j);
      localNotification.setLatestEventInfo(this, localCharSequence2, localCharSequence1, localPendingIntent);
      int k = R.string.app_name;
      startForeground(k, localNotification);
    }
  }

  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }

  public void onDestroy()
  {
    stopForeground(1);
  }

  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    handleCommand(paramIntent);
    return 1;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.service.ForegroundService
 * JD-Core Version:    0.6.0
 */