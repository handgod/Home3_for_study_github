package com.softspb.shell;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

class Home$3 extends BroadcastReceiver
{
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    String str = paramIntent.getData().getSchemeSpecificPart();
    if (paramIntent.getBooleanExtra("android.intent.extra.REPLACING", 0));
    while (true)
    {
      return;
      this.this$0.widgetsDelete(str);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.Home.3
 * JD-Core Version:    0.6.0
 */