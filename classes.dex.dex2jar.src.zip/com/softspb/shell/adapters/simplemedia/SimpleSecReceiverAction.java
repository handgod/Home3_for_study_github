package com.softspb.shell.adapters.simplemedia;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import com.softspb.util.broadcastreceiver.DecoratedBroadcastReceiver.IActionListener;

class SimpleSecReceiverAction
  implements DecoratedBroadcastReceiver.IActionListener
{
  private static final String EXTRA_IS_STOP = "isStop";
  private static final String EXTRA_MEDIAURI = "mediauri";
  private static final String EXTRA_PLAYING = "playing";
  private SimpleMediaAdapterAndroid adapter;

  public SimpleSecReceiverAction(SimpleMediaAdapterAndroid paramSimpleMediaAdapterAndroid)
  {
    this.adapter = paramSimpleMediaAdapterAndroid;
  }

  public void onAction(Context paramContext, Intent paramIntent)
  {
    boolean bool1 = paramIntent.getBooleanExtra("playing", 0);
    boolean bool2 = paramIntent.getBooleanExtra("isStop", 1);
    Object localObject = paramIntent.getExtras().get("mediauri");
    if (!(localObject instanceof Uri))
      this.adapter.onPlaybackCompleted();
    while (true)
    {
      return;
      Uri localUri = (Uri)localObject;
      if (bool2)
      {
        this.adapter.onPlayStateUpdated(0);
        continue;
      }
      if (bool1)
        this.adapter.onPlayStateUpdated(2);
      Cursor localCursor;
      int i;
      int j;
      while (true)
      {
        localCursor = paramContext.getContentResolver().query(localUri, null, null, null, null);
        if (!localCursor.moveToFirst())
          break label214;
        i = localCursor.getColumnIndex("artist");
        j = localCursor.getColumnIndex("title");
        if ((i != -1) && (j != -1))
          break label163;
        localCursor.close();
        break;
        this.adapter.onPlayStateUpdated(1);
      }
      label163: String str1 = localCursor.getString(i);
      String str2 = localCursor.getString(j);
      if (str1 == null)
        str1 = "";
      if (str2 == null)
        str2 = "";
      this.adapter.onMediaInfoUpdated(str1, str2);
      label214: localCursor.close();
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.simplemedia.SimpleSecReceiverAction
 * JD-Core Version:    0.6.0
 */