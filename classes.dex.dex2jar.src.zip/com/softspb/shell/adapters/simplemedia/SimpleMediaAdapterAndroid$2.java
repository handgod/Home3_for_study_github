package com.softspb.shell.adapters.simplemedia;

class SimpleMediaAdapterAndroid$2
  implements SimpleMediaFactory.PlaybackService.OnConnectionListener
{
  public void onConnect()
  {
    if (SimpleMediaAdapterAndroid.access$000(this.this$0).isPlaying())
      this.this$0.onPlayStateUpdated(2);
    while (true)
    {
      SimpleMediaAdapterAndroid localSimpleMediaAdapterAndroid = this.this$0;
      String str1 = SimpleMediaAdapterAndroid.access$000(this.this$0).getArtistName();
      String str2 = SimpleMediaAdapterAndroid.access$000(this.this$0).getTrackName();
      localSimpleMediaAdapterAndroid.onMediaInfoUpdated(str1, str2);
      this.this$0.updatePlayState();
      return;
      this.this$0.onPlayStateUpdated(1);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.simplemedia.SimpleMediaAdapterAndroid.2
 * JD-Core Version:    0.6.0
 */