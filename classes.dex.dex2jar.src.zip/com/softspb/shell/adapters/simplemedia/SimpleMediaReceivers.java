package com.softspb.shell.adapters.simplemedia;

import android.content.Context;
import android.content.Intent;
import com.softspb.util.broadcastreceiver.DecoratedBroadcastReceiver;
import com.softspb.util.broadcastreceiver.DecoratedBroadcastReceiver.IActionListener;

class SimpleMediaReceivers
{
  public static DecoratedBroadcastReceiver getGeneralMediaReceiver(SimpleMediaAdapterAndroid paramSimpleMediaAdapterAndroid, String paramString)
  {
    PlayBackAction localPlayBackAction = new PlayBackAction();
    MetaChangedListener localMetaChangedListener = new MetaChangedListener();
    PlayStateAction localPlayStateAction = new PlayStateAction();
    return new MediaReceiver(paramString, localPlayBackAction, localMetaChangedListener, localPlayStateAction);
  }

  public static DecoratedBroadcastReceiver getMediaReceiverWithService(SimpleMediaAdapterAndroid paramSimpleMediaAdapterAndroid, String paramString)
  {
    PlayBackAction localPlayBackAction = new PlayBackAction();
    MetaChangedAction localMetaChangedAction = new MetaChangedAction();
    ServicedPlayStateAction localServicedPlayStateAction = new ServicedPlayStateAction();
    return new MediaReceiver(paramString, localPlayBackAction, localMetaChangedAction, localServicedPlayStateAction);
  }

  class PlayStateAction
    implements DecoratedBroadcastReceiver.IActionListener
  {
    public PlayStateAction()
    {
    }

    public void onAction(Context paramContext, Intent paramIntent)
    {
      if (paramIntent.getBooleanExtra("playing", 0))
        SimpleMediaReceivers.this.onPlayStateUpdated(2);
      while (true)
      {
        return;
        SimpleMediaReceivers.this.onPlayStateUpdated(1);
      }
    }
  }

  class MetaChangedListener extends SimpleMediaReceivers.MetaChangedAction
  {
    public MetaChangedListener()
    {
      super();
    }

    public void onAction(Context paramContext, Intent paramIntent)
    {
      super.onAction(paramContext, paramIntent);
    }
  }

  class MetaChangedAction
    implements DecoratedBroadcastReceiver.IActionListener
  {
    public MetaChangedAction()
    {
    }

    private String getSafeStringExtra(Intent paramIntent, String paramString)
    {
      String str;
      if (!paramIntent.hasExtra(paramString))
        str = "";
      while (true)
      {
        return str;
        str = paramIntent.getStringExtra(paramString);
        if (str != null)
          continue;
        str = "";
      }
    }

    public void onAction(Context paramContext, Intent paramIntent)
    {
      String str1 = getSafeStringExtra(paramIntent, "artist");
      String str2 = getSafeStringExtra(paramIntent, "album");
      String str3 = getSafeStringExtra(paramIntent, "track");
      SimpleMediaReceivers.this.onMediaInfoUpdated(str1, str3);
    }
  }

  class PlayBackAction
    implements DecoratedBroadcastReceiver.IActionListener
  {
    public PlayBackAction()
    {
    }

    public void onAction(Context paramContext, Intent paramIntent)
    {
      SimpleMediaReceivers.this.onPlaybackCompleted();
    }
  }

  class ServicedPlayStateAction
    implements DecoratedBroadcastReceiver.IActionListener
  {
    public ServicedPlayStateAction()
    {
    }

    public void onAction(Context paramContext, Intent paramIntent)
    {
      SimpleMediaReceivers.this.updatePlayState();
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.simplemedia.SimpleMediaReceivers
 * JD-Core Version:    0.6.0
 */