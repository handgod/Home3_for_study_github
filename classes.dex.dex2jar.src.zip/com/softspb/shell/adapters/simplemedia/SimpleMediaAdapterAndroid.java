package com.softspb.shell.adapters.simplemedia;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import com.softspb.shell.adapters.AdaptersHolder;
import com.softspb.shell.opengl.NativeCallbacks;
import com.softspb.util.broadcastreceiver.DecoratedBroadcastReceiver;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.util.Iterator;
import java.util.List;

public class SimpleMediaAdapterAndroid extends SimpleMediaAdapter
{
  private static final int MAX_SERVICES = 50;
  public static final int MESSAGE_PLAYING = 0;
  public static final int MESSAGE_STOP = 1;
  public static final int PLAYSTATE_PAUSED = 1;
  public static final int PLAYSTATE_PLAYING = 2;
  public static final int PLAYSTATE_STOPPED = 0;
  private static final String TAG = "SimpleMedia";
  private static Logger logger = Loggers.getLogger(SimpleMediaAdapterAndroid.class);
  private SimpleMediaCommander commander;
  private Context context;
  private String packageName;
  private Handler playstateHandler;
  private DecoratedBroadcastReceiver receiver;
  private int sToken;
  private SimpleMediaFactory.PlaybackService service;
  private int vendor;

  public SimpleMediaAdapterAndroid(AdaptersHolder paramAdaptersHolder)
  {
    super(paramAdaptersHolder);
    SimpleMediaAdapterAndroid.1 local1 = new SimpleMediaAdapterAndroid.1(this);
    this.playstateHandler = local1;
    this.packageName = "";
    this.sToken = 0;
  }

  private boolean isServiceAlive()
  {
    boolean bool;
    if (this.service != null)
      bool = this.service.isServiceAlive();
    while (true)
    {
      return bool;
      Iterator localIterator = ((ActivityManager)this.context.getSystemService("activity")).getRunningServices(50).iterator();
      while (true)
        if (localIterator.hasNext())
        {
          String str1 = ((ActivityManager.RunningServiceInfo)localIterator.next()).service.getPackageName();
          String str2 = this.packageName;
          if (!str1.equals(str2))
            continue;
          bool = true;
          break;
        }
      bool = false;
    }
  }

  private native void onMediaInfoUpdated(int paramInt, String paramString1, String paramString2);

  private native void onPlayStateUpdated(int paramInt1, int paramInt2);

  private native void onPlaybackUpdated(int paramInt1, int paramInt2, int paramInt3);

  public boolean doNext()
  {
    this.commander.doNext();
    return isServiceAlive();
  }

  public boolean doPrev()
  {
    this.commander.doPrevious();
    return isServiceAlive();
  }

  public boolean doTogglePause()
  {
    this.commander.doTogglePause();
    return isServiceAlive();
  }

  public boolean isSupportingPlayback()
  {
    if (this.service != null);
    for (int i = 1; ; i = 0)
      return i;
  }

  public void onCreate(Context paramContext, NativeCallbacks paramNativeCallbacks)
  {
    this.context = paramContext;
    int i = SimpleMediaFactory.getCurrentVendor(paramContext);
    this.vendor = i;
    Logger localLogger = logger;
    StringBuilder localStringBuilder = new StringBuilder().append("SimpleMedia vendor ");
    int j = this.vendor;
    String str1 = j;
    localLogger.i(str1);
    if (this.vendor == -1);
    while (true)
    {
      return;
      String str2 = SimpleMediaFactory.getIntentPrefix(this.vendor);
      String str3 = SimpleMediaFactory.getPackage(this.vendor);
      this.packageName = str3;
      SimpleMediaCommander localSimpleMediaCommander = new SimpleMediaCommander(str2, paramContext);
      this.commander = localSimpleMediaCommander;
      int k = this.vendor;
      SimpleMediaFactory.PlaybackService localPlaybackService1 = SimpleMediaFactory.getServiceWrapper(paramContext, k);
      this.service = localPlaybackService1;
      if (this.service != null)
      {
        SimpleMediaFactory.PlaybackService localPlaybackService2 = this.service;
        SimpleMediaAdapterAndroid.2 local2 = new SimpleMediaAdapterAndroid.2(this);
        localPlaybackService2.setOnConnectionListener(local2);
        DecoratedBroadcastReceiver localDecoratedBroadcastReceiver1 = SimpleMediaReceivers.getMediaReceiverWithService(this, str2);
        this.receiver = localDecoratedBroadcastReceiver1;
        continue;
      }
      DecoratedBroadcastReceiver localDecoratedBroadcastReceiver2 = SimpleMediaFactory.getSpecificBroadCastReceiver(this.vendor, this);
      this.receiver = localDecoratedBroadcastReceiver2;
    }
  }

  public void onMediaInfoUpdated(String paramString1, String paramString2)
  {
    int i = this.sToken;
    onMediaInfoUpdated(i, paramString1, paramString2);
  }

  public void onPlayStateUpdated(int paramInt)
  {
    int i = this.sToken;
    onPlayStateUpdated(i, paramInt);
  }

  public void onPlaybackCompleted()
  {
    this.playstateHandler.removeMessages(0);
    onPlaybackUpdated(0, 0);
    onPlayStateUpdated(0);
  }

  public void onPlaybackUpdated(int paramInt1, int paramInt2)
  {
    int i = this.sToken;
    onPlaybackUpdated(i, paramInt1, paramInt2);
  }

  protected void onStart(int paramInt)
  {
    this.sToken = paramInt;
    Context localContext = this.context;
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver = this.receiver;
    IntentFilter localIntentFilter = this.receiver.getIntentFilter();
    Intent localIntent = localContext.registerReceiver(localDecoratedBroadcastReceiver, localIntentFilter);
    if (this.service == null)
      this.commander.checkPlayStatus();
    while (true)
    {
      return;
      this.service.start();
    }
  }

  public void onStop()
  {
    Context localContext = this.context;
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver = this.receiver;
    localContext.unregisterReceiver(localDecoratedBroadcastReceiver);
    if (this.service == null);
    while (true)
    {
      return;
      this.service.stop();
    }
  }

  public void updatePlayState()
  {
    int i = 1;
    this.service.reconnectIfNeeded();
    boolean bool1 = this.service.isPlaying();
    Logger localLogger = logger;
    String str = "MediaPlayerAdapterAndroid.updatePlayStateisPlaying = " + bool1;
    localLogger.i(str);
    if (bool1)
    {
      int j = this.service.getTrackDuration();
      int k = this.service.getTrackPosition();
      onPlaybackUpdated(j, k);
      boolean bool2 = this.playstateHandler.sendEmptyMessage(0);
    }
    while (true)
    {
      if (bool1)
        i = 2;
      int m = this.sToken;
      onPlayStateUpdated(m, i);
      return;
      int n = this.service.getTrackDuration();
      int i1 = this.service.getTrackPosition();
      onPlaybackUpdated(n, i1);
      boolean bool3 = this.playstateHandler.sendEmptyMessage(1);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.simplemedia.SimpleMediaAdapterAndroid
 * JD-Core Version:    0.6.0
 */