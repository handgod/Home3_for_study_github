package com.softspb.shell.adapters.simplemedia;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import com.softspb.util.broadcastreceiver.DecoratedBroadcastReceiver;

class SimpleMediaFactory
{
  private static final String ANDROID_PACKAGE = "com.android.music";
  private static final String ANDROID_PACKAGE_UP2_2_1 = "com.google.android.music";
  private static final String CMDAPPWIDGETUPDATE = "appwidgetupdate";
  private static final String HTC_PACKAGE = "com.htc.music";
  private static final String SAMSUNG_BRAND = "samsung";
  private static final String SAMSUNG_GENERAL_PACKAGE = "com.sec";
  private static final String SAMSUNG_MUSIC_PACKAGE = "com.sec.android.app.music";
  private static final int VENDOR_GOOGLE = 1;
  private static final int VENDOR_GOOGLE_2_3 = 6;
  private static final int VENDOR_GOOGLE_UP2_2_1 = 5;
  private static final int VENDOR_HTC = 2;
  public static final int VENDOR_NONE = 255;
  private static final int VENDOR_SAMSUNG_ECLAIR_MR1 = 3;
  private static final int VENDOR_SAMSUNG_FROYO = 4;

  public static PlaybackService getAndroidServiceWrapper(Context paramContext)
  {
    AndroidWrapper localAndroidWrapper = new AndroidWrapper();
    return new PlaybackService("com.android.music", paramContext);
  }

  public static PlaybackService getAndroidServiceWrapper2_2_1(Context paramContext)
  {
    AndroidWrapper localAndroidWrapper = new AndroidWrapper();
    return new PlaybackService("com.google.android.music", "com.android.music.MediaPlaybackService", paramContext);
  }

  public static int getCurrentVendor(Context paramContext)
  {
    int i;
    if (hasPackage(paramContext, "com.sec.android.app.music"))
      i = 3;
    while (true)
    {
      return i;
      if (hasPackage(paramContext, "com.htc.music"))
      {
        i = 2;
        continue;
      }
      if (hasPackage(paramContext, "com.android.music"))
      {
        if (Build.BRAND.equals("samsung"))
        {
          i = 4;
          continue;
        }
        i = 1;
        continue;
      }
      if (hasPackage(paramContext, "com.google.android.music"))
      {
        if (Build.VERSION.SDK_INT == 9)
        {
          i = 6;
          continue;
        }
        i = 5;
        continue;
      }
      i = -1;
    }
  }

  public static PlaybackService getHtcServiceWrapper(Context paramContext)
  {
    HtcWrapper localHtcWrapper = new HtcWrapper();
    return new PlaybackService("com.htc.music", paramContext);
  }

  public static String getIntentPrefix(int paramInt)
  {
    if (paramInt == 6);
    for (String str = "com.android.music"; ; str = getPackage(paramInt))
      return str;
  }

  public static String getPackage(int paramInt)
  {
    String str;
    switch (paramInt)
    {
    default:
      str = "";
    case 1:
    case 4:
    case 5:
    case 6:
    case 2:
    case 3:
    }
    while (true)
    {
      return str;
      str = "com.android.music";
      continue;
      str = "com.google.android.music";
      continue;
      str = "com.htc.music";
      continue;
      str = "com.sec.android.app.music";
    }
  }

  public static PlaybackService getServiceWrapper(Context paramContext, int paramInt)
  {
    PlaybackService localPlaybackService;
    switch (paramInt)
    {
    case 3:
    case 4:
    default:
      localPlaybackService = null;
    case 1:
    case 5:
    case 2:
    }
    while (true)
    {
      return localPlaybackService;
      localPlaybackService = getAndroidServiceWrapper(paramContext);
      continue;
      localPlaybackService = getAndroidServiceWrapper2_2_1(paramContext);
      continue;
      localPlaybackService = getHtcServiceWrapper(paramContext);
    }
  }

  public static DecoratedBroadcastReceiver getSpecificBroadCastReceiver(int paramInt, SimpleMediaAdapterAndroid paramSimpleMediaAdapterAndroid)
  {
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver = new DecoratedBroadcastReceiver();
    if (paramInt == 3)
    {
      SimpleSecReceiverAction localSimpleSecReceiverAction1 = new SimpleSecReceiverAction(paramSimpleMediaAdapterAndroid);
      localDecoratedBroadcastReceiver.addActionListener("com.sec.android.app.music.musicservicecommand.mediainfo", localSimpleSecReceiverAction1);
    }
    if (paramInt == 4)
    {
      SimpleSecReceiverAction localSimpleSecReceiverAction2 = new SimpleSecReceiverAction(paramSimpleMediaAdapterAndroid);
      localDecoratedBroadcastReceiver.addActionListener("com.android.music.musicservicecommand.mediainfo", localSimpleSecReceiverAction2);
    }
    if (paramInt == 6)
    {
      String str = getIntentPrefix(paramInt);
      localDecoratedBroadcastReceiver = SimpleMediaReceivers.getGeneralMediaReceiver(paramSimpleMediaAdapterAndroid, str);
    }
    return localDecoratedBroadcastReceiver;
  }

  private static boolean hasPackage(Context paramContext, String paramString)
  {
    int i = 0;
    PackageManager localPackageManager = paramContext.getPackageManager();
    try
    {
      ApplicationInfo localApplicationInfo = localPackageManager.getApplicationInfo(paramString, 0);
      i = 1;
      label17: return i;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      break label17;
    }
  }

  public class PlaybackService
    implements ServiceConnection, SimpleMediaFactory.SimplePlaybackServiceWrapper
  {
    private String activityName;
    private Context context;
    private boolean isConnected = 0;
    private OnConnectionListener listener;
    private String packageName;

    public PlaybackService(String paramContext, Context arg3)
    {
      this(paramContext, str, localContext);
    }

    public PlaybackService(String paramString1, String paramContext, Context arg4)
    {
      this.packageName = paramString1;
      this.activityName = paramContext;
      Object localObject;
      this.context = localObject;
    }

    private void connectToService()
    {
      Intent localIntent = makeServiceIntent();
      ComponentName localComponentName = this.context.startService(localIntent);
      boolean bool = this.context.bindService(localIntent, this, 0);
    }

    private Intent makeServiceIntent()
    {
      Intent localIntent1 = new Intent();
      String str1 = this.packageName;
      String str2 = this.activityName;
      Intent localIntent2 = localIntent1.setClassName(str1, str2);
      Intent localIntent3 = localIntent1.putExtra("command", "appwidgetupdate");
      return localIntent1;
    }

    public String getArtistName()
    {
      try
      {
        String str1 = SimpleMediaFactory.this.getArtistName();
        str2 = str1;
        return str2;
      }
      catch (RemoteException localRemoteException)
      {
        while (true)
        {
          localRemoteException.printStackTrace();
          String str2 = "";
        }
      }
    }

    public int getTrackDuration()
    {
      int i = 0;
      if (!this.isConnected);
      while (true)
      {
        return i;
        try
        {
          int j = SimpleMediaFactory.this.getTrackDuration();
          i = j;
        }
        catch (RemoteException localRemoteException)
        {
          localRemoteException.printStackTrace();
        }
      }
    }

    public String getTrackName()
    {
      try
      {
        String str1 = SimpleMediaFactory.this.getTrackName();
        str2 = str1;
        return str2;
      }
      catch (RemoteException localRemoteException)
      {
        while (true)
        {
          localRemoteException.printStackTrace();
          String str2 = "";
        }
      }
    }

    public int getTrackPosition()
    {
      int i = 0;
      if (!this.isConnected);
      while (true)
      {
        return i;
        try
        {
          int j = SimpleMediaFactory.this.getTrackPosition();
          i = j;
        }
        catch (RemoteException localRemoteException)
        {
          localRemoteException.printStackTrace();
        }
      }
    }

    public boolean isPlaying()
    {
      int i = 0;
      if (!this.isConnected);
      while (true)
      {
        return i;
        try
        {
          int j = SimpleMediaFactory.this.isPlaying();
          i = j;
        }
        catch (RemoteException localRemoteException)
        {
          localRemoteException.printStackTrace();
        }
      }
    }

    public boolean isServiceAlive()
    {
      try
      {
        boolean bool1 = SimpleMediaFactory.this.isServiceAlive();
        bool2 = bool1;
        return bool2;
      }
      catch (RemoteException localRemoteException)
      {
        while (true)
        {
          localRemoteException.printStackTrace();
          boolean bool2 = false;
        }
      }
    }

    public boolean isServiceConneted()
    {
      return false;
    }

    public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
    {
      this.isConnected = 1;
      SimpleMediaFactory.this.init(paramIBinder);
      if (this.listener != null)
        this.listener.onConnect();
    }

    public void onServiceDisconnected(ComponentName paramComponentName)
    {
      int i = Log.e("Disconnected", "service");
      this.isConnected = 0;
    }

    public void reconnectIfNeeded()
    {
      if (this.isConnected);
      while (true)
      {
        return;
        connectToService();
      }
    }

    public void setOnConnectionListener(OnConnectionListener paramOnConnectionListener)
    {
      this.listener = paramOnConnectionListener;
    }

    public void start()
    {
      connectToService();
    }

    public void stop()
    {
      this.context.unbindService(this);
    }

    public abstract interface OnConnectionListener
    {
      public abstract void onConnect();
    }
  }

  class AndroidWrapper
    implements SimpleMediaFactory.InitableServiceWrapper
  {
    com.android.music.IMediaPlaybackService service;

    public String getArtistName()
      throws RemoteException
    {
      return this.service.getArtistName();
    }

    public int getTrackDuration()
      throws RemoteException
    {
      return (int)this.service.duration();
    }

    public String getTrackName()
      throws RemoteException
    {
      return this.service.getTrackName();
    }

    public int getTrackPosition()
      throws RemoteException
    {
      return (int)this.service.position();
    }

    public void init(IBinder paramIBinder)
    {
      com.android.music.IMediaPlaybackService localIMediaPlaybackService = com.android.music.IMediaPlaybackService.Stub.asInterface(paramIBinder);
      this.service = localIMediaPlaybackService;
    }

    public boolean isPlaying()
      throws RemoteException
    {
      return this.service.isPlaying();
    }

    public boolean isServiceAlive()
      throws RemoteException
    {
      return this.service.asBinder().pingBinder();
    }
  }

  class HtcWrapper
    implements SimpleMediaFactory.InitableServiceWrapper
  {
    com.htc.music.IMediaPlaybackService service;

    public String getArtistName()
      throws RemoteException
    {
      return this.service.getArtistName();
    }

    public int getTrackDuration()
      throws RemoteException
    {
      return (int)this.service.duration();
    }

    public String getTrackName()
      throws RemoteException
    {
      return this.service.getTrackName();
    }

    public int getTrackPosition()
      throws RemoteException
    {
      return (int)this.service.position();
    }

    public void init(IBinder paramIBinder)
    {
      com.htc.music.IMediaPlaybackService localIMediaPlaybackService = com.htc.music.IMediaPlaybackService.Stub.asInterface(paramIBinder);
      this.service = localIMediaPlaybackService;
    }

    public boolean isPlaying()
      throws RemoteException
    {
      return this.service.isPlaying();
    }

    public boolean isServiceAlive()
      throws RemoteException
    {
      return this.service.asBinder().pingBinder();
    }
  }

  abstract interface InitableServiceWrapper extends SimpleMediaFactory.SimplePlaybackServiceWrapper, SimpleMediaFactory.Initable
  {
  }

  abstract interface Initable
  {
    public abstract void init(IBinder paramIBinder);
  }

  public abstract interface SimplePlaybackServiceWrapper
  {
    public abstract String getArtistName()
      throws RemoteException;

    public abstract int getTrackDuration()
      throws RemoteException;

    public abstract String getTrackName()
      throws RemoteException;

    public abstract int getTrackPosition()
      throws RemoteException;

    public abstract boolean isPlaying()
      throws RemoteException;

    public abstract boolean isServiceAlive()
      throws RemoteException;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.simplemedia.SimpleMediaFactory
 * JD-Core Version:    0.6.0
 */