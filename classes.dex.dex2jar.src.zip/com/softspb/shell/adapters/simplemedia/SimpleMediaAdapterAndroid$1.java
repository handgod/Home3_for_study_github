package com.softspb.shell.adapters.simplemedia;

import android.os.Handler;
import android.os.Message;

class SimpleMediaAdapterAndroid$1 extends Handler
{
  public void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default:
    case 0:
    case 1:
    }
    while (true)
    {
      return;
      SimpleMediaAdapterAndroid localSimpleMediaAdapterAndroid = this.this$0;
      int i = SimpleMediaAdapterAndroid.access$000(this.this$0).getTrackDuration();
      int j = SimpleMediaAdapterAndroid.access$000(this.this$0).getTrackPosition();
      localSimpleMediaAdapterAndroid.onPlaybackUpdated(i, j);
      SimpleMediaAdapterAndroid.access$100(this.this$0).removeMessages(0);
      if (!SimpleMediaAdapterAndroid.access$000(this.this$0).isPlaying())
        continue;
      boolean bool = SimpleMediaAdapterAndroid.access$100(this.this$0).sendEmptyMessageDelayed(0, 1000L);
      continue;
      SimpleMediaAdapterAndroid.access$100(this.this$0).removeMessages(0);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.simplemedia.SimpleMediaAdapterAndroid.1
 * JD-Core Version:    0.6.0
 */