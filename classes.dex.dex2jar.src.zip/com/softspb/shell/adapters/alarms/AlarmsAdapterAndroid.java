package com.softspb.shell.adapters.alarms;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.database.MergeCursor;
import android.net.Uri;
import android.provider.BaseColumns;
import android.text.format.DateUtils;
import com.softspb.shell.adapters.AbstractContentAdapter.ContentItem;
import com.softspb.util.log.Logger;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

public class AlarmsAdapterAndroid extends BaseAlarmsAdapter
{
  public static final String ACTION_ALARM_IS_RUN = "com.spb.shell3d.adapters.ACTION_ALARM_IS_RUN";
  static final String ALARMS_URI_PATH = "alarm";
  static final String ALARM_MAGIC_WORD = "alarm";
  private static final String AUTHORITY_ALARM_SAMSUNG = "com.samsung.sec.android.clockpackage";
  private static final String COLUMN_ALARMTIME_SAMSUNG = "alarmtime";
  private static final String COLUMN_ALERTTIME_SAMSUNG = "alerttime";
  private static final String COLUMN_ENABLED_SAMSUNG = "active";
  private static final String COLUMN_REPEATTYPE_SAMSUNG = "repeattype";
  PendingIntent alarmIntent;
  private AlarmIsRunReceiver alarmIsRunReceiver;
  private long nextAlarmTime;
  private Calendar now;
  private long nowMillis;
  boolean samsung = 0;

  public AlarmsAdapterAndroid(int paramInt, Context paramContext)
  {
    super(paramInt, paramContext);
    Uri[] arrayOfUri = findAlarmsContentUris(paramContext);
    setContentUris(arrayOfUri);
  }

  public static Uri checkAlarmProvider(ProviderInfo paramProviderInfo)
  {
    StringBuilder localStringBuilder;
    String str;
    if ((paramProviderInfo.name.toLowerCase().contains("alarm")) || (paramProviderInfo.authority.toLowerCase().contains("alarm")))
    {
      localStringBuilder = new StringBuilder().append("content://");
      str = paramProviderInfo.authority;
    }
    for (Uri localUri = Uri.parse(str + "/" + "alarm"); ; localUri = null)
      return localUri;
  }

  static Uri[] findAlarmsContentUris(Context paramContext)
  {
    List localList = paramContext.getPackageManager().queryContentProviders(null, 0, 0);
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Uri localUri = checkAlarmProvider((ProviderInfo)localIterator.next());
      if (localUri == null)
        continue;
      boolean bool = localArrayList.add(localUri);
    }
    Uri[] arrayOfUri = new Uri[localArrayList.size()];
    return (Uri[])localArrayList.toArray(arrayOfUri);
  }

  private boolean processRowSamsung(Cursor paramCursor, boolean paramBoolean)
  {
    this.logger.d("processRowSamsung");
    logRow("Alarm", paramCursor);
    try
    {
      int i = paramCursor.getColumnIndex("active");
      int j;
      long l1;
      if (paramCursor.getInt(i) != 0)
      {
        j = 1;
        if (j != 0)
        {
          int k = paramCursor.getColumnIndex("alarmtime");
          int m = paramCursor.getInt(k);
          int n = m / 100;
          int i1 = m % 100;
          int i2 = paramCursor.getColumnIndex("alerttime");
          l1 = paramCursor.getLong(i2);
          int i3 = paramCursor.getColumnIndex("repeattype");
          String str1 = paramCursor.getString(i3);
          Logger localLogger1 = this.logger;
          String str2 = "processRow: hour=" + n + " minutes=" + i1 + " alerttime=" + l1 + " repeattype=" + str1;
          localLogger1.d(str2);
          if (l1 == 0L)
            break label271;
          Logger localLogger2 = this.logger;
          StringBuilder localStringBuilder = new StringBuilder().append("processRow: alarmTime: ");
          String str3 = DateUtils.formatDateTime(this.context, l1, 17);
          String str4 = str3;
          localLogger2.d(str4);
        }
      }
      while (true)
      {
        long l2 = this.nextAlarmTime;
        if (l1 < l2)
          this.nextAlarmTime = l1;
        return true;
        j = 0;
        break;
        label271: this.logger.d("processRow: alarmTime: N/A");
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        Logger localLogger3 = this.logger;
        String str5 = "Error occurred while processing an alarm row: " + localException;
        localLogger3.w(str5, localException);
      }
    }
  }

  protected Alarm createContentItem(int paramInt, Cursor paramCursor)
  {
    return new Alarm(paramCursor);
  }

  protected int getContentItemId(Cursor paramCursor)
  {
    int i = paramCursor.getColumnIndex("_id");
    return (int)paramCursor.getLong(i);
  }

  void logRow(String paramString, Cursor paramCursor)
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    StringBuilder localStringBuilder2 = localStringBuilder1.append(paramString).append("[");
    int i = 0;
    while (true)
    {
      int j = paramCursor.getColumnCount();
      if (i >= j)
        break;
      String str1 = paramCursor.getString(i);
      if (str1 != null)
      {
        StringBuilder localStringBuilder3 = localStringBuilder1.append(" ");
        String str2 = paramCursor.getColumnName(i);
        StringBuilder localStringBuilder4 = localStringBuilder3.append(str2).append("=").append(str1);
      }
      i += 1;
    }
    StringBuilder localStringBuilder5 = localStringBuilder1.append("]");
    Logger localLogger = this.logger;
    String str3 = localStringBuilder1.toString();
    localLogger.d(str3);
  }

  public void onStop()
  {
    super.onStop();
    if (this.alarmIsRunReceiver != null)
    {
      Context localContext = this.context;
      AlarmIsRunReceiver localAlarmIsRunReceiver = this.alarmIsRunReceiver;
      localContext.unregisterReceiver(localAlarmIsRunReceiver);
    }
  }

  protected boolean processRow(Cursor paramCursor, boolean paramBoolean)
  {
    if (this.samsung);
    for (boolean bool = processRowSamsung(paramCursor, paramBoolean); ; bool = processRowDefault(paramCursor, paramBoolean))
      return bool;
  }

  protected boolean processRowDefault(Cursor paramCursor, boolean paramBoolean)
  {
    this.logger.d("processRowDefault");
    logRow("Alarm", paramCursor);
    try
    {
      int i = paramCursor.getColumnIndex("enabled");
      int j;
      int m;
      long l1;
      if (paramCursor.getInt(i) != 0)
      {
        j = 1;
        if (j != 0)
        {
          int k = paramCursor.getColumnIndex("daysofweek");
          m = paramCursor.getInt(k);
          Logger localLogger1 = this.logger;
          String str1 = "processRow: daysOfWeek=" + m;
          localLogger1.d(str1);
          if (m != 0)
            break label239;
          int n = paramCursor.getColumnIndex("alarmtime");
          l1 = paramCursor.getLong(n);
          label127: if (l1 == 9223372036854775807L)
            break label359;
          Logger localLogger2 = this.logger;
          StringBuilder localStringBuilder = new StringBuilder().append("processRow: alarmTime: ");
          String str2 = DateUtils.formatDateTime(this.context, l1, 17);
          String str3 = str2;
          localLogger2.d(str3);
        }
      }
      while (true)
      {
        if (l1 != 0L)
        {
          long l2 = this.nextAlarmTime;
          if (l1 < l2)
          {
            long l3 = this.nowMillis;
            if (l1 > l3)
              this.nextAlarmTime = l1;
          }
        }
        return true;
        j = 0;
        break;
        label239: int i1 = paramCursor.getColumnIndex("hour");
        int i2 = paramCursor.getInt(i1);
        int i3 = paramCursor.getColumnIndex("minutes");
        int i4 = paramCursor.getInt(i3);
        Logger localLogger3 = this.logger;
        String str4 = "processRow: hour=" + i2 + " minutes=" + i4 + " daysOfWeek=" + m;
        localLogger3.d(str4);
        Calendar localCalendar = this.now;
        l1 = findNextAlarmTime(i2, i4, m, localCalendar);
        break label127;
        label359: this.logger.d("processRow: alarmTime: N/A");
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        Logger localLogger4 = this.logger;
        String str5 = "Error occurred while processing an alarm row: " + localException;
        localLogger4.w(str5, localException);
      }
    }
  }

  protected Cursor query()
  {
    ArrayList localArrayList = new ArrayList();
    this.samsung = 0;
    Uri[] arrayOfUri = this.contentUris;
    int i = arrayOfUri.length;
    int j = 0;
    while (true)
    {
      Uri localUri;
      if (j < i)
      {
        localUri = arrayOfUri[j];
        boolean bool1 = this.samsung;
        String str1 = localUri.getAuthority();
        boolean bool2 = "com.samsung.sec.android.clockpackage".equals(str1);
        boolean bool3 = bool1 | bool2;
        this.samsung = bool3;
      }
      try
      {
        Logger localLogger1 = this.logger;
        String str2 = "query: uri=" + localUri;
        localLogger1.d(str2);
        Cursor localCursor = this.contentResolver.query(localUri, null, null, null, null);
        Logger localLogger2 = this.logger;
        String str3 = "query: cursor=" + localCursor;
        localLogger2.d(str3);
        if (localCursor != null)
          boolean bool4 = localArrayList.add(localCursor);
        label172: j += 1;
        continue;
        int k = localArrayList.size();
        if (k == 0);
        Cursor[] arrayOfCursor2;
        for (MergeCursor localMergeCursor = null; ; localMergeCursor = new MergeCursor(arrayOfCursor2))
        {
          return localMergeCursor;
          Cursor[] arrayOfCursor1 = new Cursor[k];
          arrayOfCursor2 = (Cursor[])localArrayList.toArray(arrayOfCursor1);
        }
      }
      catch (Exception localException)
      {
        break label172;
      }
    }
  }

  /** @deprecated */
  // ERROR //
  public void reload(boolean paramBoolean)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 334	com/softspb/shell/adapters/alarms/AlarmsAdapterAndroid:reloadLock	Ljava/lang/Object;
    //   6: astore_2
    //   7: aload_2
    //   8: monitorenter
    //   9: aload_0
    //   10: getfield 69	com/softspb/shell/adapters/alarms/AlarmsAdapterAndroid:logger	Lcom/softspb/util/log/Logger;
    //   13: astore_3
    //   14: new 91	java/lang/StringBuilder
    //   17: dup
    //   18: invokespecial 94	java/lang/StringBuilder:<init>	()V
    //   21: ldc_w 336
    //   24: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   27: iload_1
    //   28: invokevirtual 339	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
    //   31: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   34: astore 4
    //   36: aload_3
    //   37: aload 4
    //   39: invokevirtual 169	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   42: aload_0
    //   43: ldc2_w 282
    //   46: putfield 222	com/softspb/shell/adapters/alarms/AlarmsAdapterAndroid:nextAlarmTime	J
    //   49: new 341	java/util/GregorianCalendar
    //   52: dup
    //   53: invokespecial 342	java/util/GregorianCalendar:<init>	()V
    //   56: astore 5
    //   58: aload_0
    //   59: aload 5
    //   61: putfield 293	com/softspb/shell/adapters/alarms/AlarmsAdapterAndroid:now	Ljava/util/Calendar;
    //   64: aload_0
    //   65: getfield 293	com/softspb/shell/adapters/alarms/AlarmsAdapterAndroid:now	Ljava/util/Calendar;
    //   68: invokevirtual 348	java/util/Calendar:getTimeInMillis	()J
    //   71: lstore 6
    //   73: aload_0
    //   74: lload 6
    //   76: putfield 285	com/softspb/shell/adapters/alarms/AlarmsAdapterAndroid:nowMillis	J
    //   79: aload_0
    //   80: invokevirtual 350	com/softspb/shell/adapters/alarms/AlarmsAdapterAndroid:query	()Landroid/database/Cursor;
    //   83: astore 8
    //   85: aload 8
    //   87: ifnull +67 -> 154
    //   90: aload 8
    //   92: invokeinterface 353 1 0
    //   97: ifeq +57 -> 154
    //   100: aload 8
    //   102: invokeinterface 356 1 0
    //   107: ifne +13 -> 120
    //   110: aload_0
    //   111: aload 8
    //   113: iload_1
    //   114: invokevirtual 358	com/softspb/shell/adapters/alarms/AlarmsAdapterAndroid:processRow	(Landroid/database/Cursor;Z)Z
    //   117: ifne +64 -> 181
    //   120: aload_0
    //   121: getfield 222	com/softspb/shell/adapters/alarms/AlarmsAdapterAndroid:nextAlarmTime	J
    //   124: ldc2_w 282
    //   127: lcmp
    //   128: ifne +10 -> 138
    //   131: aload_0
    //   132: ldc2_w 207
    //   135: putfield 222	com/softspb/shell/adapters/alarms/AlarmsAdapterAndroid:nextAlarmTime	J
    //   138: aload_0
    //   139: getfield 222	com/softspb/shell/adapters/alarms/AlarmsAdapterAndroid:nextAlarmTime	J
    //   142: lstore 9
    //   144: aload_0
    //   145: lload 9
    //   147: invokevirtual 362	com/softspb/shell/adapters/alarms/AlarmsAdapterAndroid:setNativeNextAlarm	(J)V
    //   150: aload_0
    //   151: invokevirtual 365	com/softspb/shell/adapters/alarms/AlarmsAdapterAndroid:resetAlarmReceiver	()V
    //   154: aload 8
    //   156: ifnull +10 -> 166
    //   159: aload 8
    //   161: invokeinterface 368 1 0
    //   166: aload_0
    //   167: getfield 69	com/softspb/shell/adapters/alarms/AlarmsAdapterAndroid:logger	Lcom/softspb/util/log/Logger;
    //   170: ldc_w 370
    //   173: invokevirtual 169	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   176: aload_2
    //   177: monitorexit
    //   178: aload_0
    //   179: monitorexit
    //   180: return
    //   181: aload 8
    //   183: invokeinterface 373 1 0
    //   188: istore 11
    //   190: goto -90 -> 100
    //   193: astore 12
    //   195: aload_0
    //   196: getfield 69	com/softspb/shell/adapters/alarms/AlarmsAdapterAndroid:logger	Lcom/softspb/util/log/Logger;
    //   199: astore 13
    //   201: new 91	java/lang/StringBuilder
    //   204: dup
    //   205: invokespecial 94	java/lang/StringBuilder:<init>	()V
    //   208: ldc_w 375
    //   211: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   214: aload 12
    //   216: invokevirtual 229	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   219: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   222: astore 14
    //   224: aload 13
    //   226: aload 14
    //   228: aload 12
    //   230: invokevirtual 378	com/softspb/util/log/Logger:e	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   233: aload 8
    //   235: ifnull +10 -> 245
    //   238: aload 8
    //   240: invokeinterface 368 1 0
    //   245: aload_0
    //   246: getfield 69	com/softspb/shell/adapters/alarms/AlarmsAdapterAndroid:logger	Lcom/softspb/util/log/Logger;
    //   249: ldc_w 370
    //   252: invokevirtual 169	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   255: goto -79 -> 176
    //   258: astore 15
    //   260: aload_2
    //   261: monitorexit
    //   262: aload 15
    //   264: athrow
    //   265: astore 16
    //   267: aload_0
    //   268: monitorexit
    //   269: aload 16
    //   271: athrow
    //   272: astore 15
    //   274: aload 8
    //   276: ifnull +10 -> 286
    //   279: aload 8
    //   281: invokeinterface 368 1 0
    //   286: aload_0
    //   287: getfield 69	com/softspb/shell/adapters/alarms/AlarmsAdapterAndroid:logger	Lcom/softspb/util/log/Logger;
    //   290: ldc_w 370
    //   293: invokevirtual 169	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   296: aload 15
    //   298: athrow
    //   299: astore 17
    //   301: goto -135 -> 166
    //   304: astore 18
    //   306: goto -61 -> 245
    //   309: astore 19
    //   311: goto -25 -> 286
    //
    // Exception table:
    //   from	to	target	type
    //   79	154	193	java/lang/Exception
    //   181	190	193	java/lang/Exception
    //   9	79	258	finally
    //   159	166	258	finally
    //   166	178	258	finally
    //   238	245	258	finally
    //   245	258	258	finally
    //   279	286	258	finally
    //   286	299	258	finally
    //   2	9	265	finally
    //   262	265	265	finally
    //   79	154	272	finally
    //   181	190	272	finally
    //   195	233	272	finally
    //   159	166	299	java/lang/Exception
    //   238	245	304	java/lang/Exception
    //   279	286	309	java/lang/Exception
  }

  void resetAlarmReceiver()
  {
    if (this.samsung);
    while (true)
    {
      return;
      if (this.alarmIsRunReceiver == null)
      {
        AlarmIsRunReceiver localAlarmIsRunReceiver1 = new AlarmIsRunReceiver();
        this.alarmIsRunReceiver = localAlarmIsRunReceiver1;
        Context localContext1 = this.context;
        AlarmIsRunReceiver localAlarmIsRunReceiver2 = this.alarmIsRunReceiver;
        IntentFilter localIntentFilter = new IntentFilter("com.spb.shell3d.adapters.ACTION_ALARM_IS_RUN");
        Intent localIntent1 = localContext1.registerReceiver(localAlarmIsRunReceiver2, localIntentFilter);
      }
      AlarmManager localAlarmManager = (AlarmManager)this.context.getSystemService("alarm");
      if (this.alarmIntent != null)
      {
        PendingIntent localPendingIntent1 = this.alarmIntent;
        localAlarmManager.cancel(localPendingIntent1);
        this.alarmIntent = null;
      }
      if (this.nextAlarmTime == 0L)
        continue;
      long l1 = this.nextAlarmTime;
      long l2 = this.nowMillis;
      if (l1 <= l2)
        continue;
      Logger localLogger = this.logger;
      StringBuilder localStringBuilder = new StringBuilder().append("resetAlarmReceiver: nextAlarmTime=");
      long l3 = this.nextAlarmTime;
      String str = l3;
      localLogger.d(str);
      Context localContext2 = this.context;
      Intent localIntent2 = new Intent("com.spb.shell3d.adapters.ACTION_ALARM_IS_RUN");
      PendingIntent localPendingIntent2 = PendingIntent.getBroadcast(localContext2, 0, localIntent2, 1073741824);
      this.alarmIntent = localPendingIntent2;
      long l4 = this.nextAlarmTime;
      PendingIntent localPendingIntent3 = this.alarmIntent;
      localAlarmManager.set(1, l4, localPendingIntent3);
    }
  }

  class AlarmIsRunReceiver extends BroadcastReceiver
  {
    AlarmIsRunReceiver()
    {
    }

    public void onReceive(Context paramContext, Intent paramIntent)
    {
      AlarmsAdapterAndroid.this.logger.d("AlarmIsRunReceiver.onReceive");
      String str = paramIntent.getAction();
      if ("com.spb.shell3d.adapters.ACTION_ALARM_IS_RUN".equals(str))
        AlarmsAdapterAndroid.this.reload(1);
    }
  }

  class Alarm extends AbstractContentAdapter.ContentItem
    implements AlarmsAdapterAndroid.AlarmColumns
  {
    int daysOfWeek;
    boolean enabled;
    int hour;
    int minutes;

    Alarm(Cursor arg2)
    {
      super(localCursor);
      int i = localCursor.getColumnIndex("hour");
      int j = localCursor.getInt(i);
      this.hour = j;
      int k = localCursor.getColumnIndex("minutes");
      int m = localCursor.getInt(k);
      this.minutes = m;
      int n = localCursor.getColumnIndex("daysofweek");
      int i1 = localCursor.getInt(n);
      this.daysOfWeek = i1;
      int i2 = localCursor.getColumnIndex("enabled");
      if (localCursor.getInt(i2) != 0);
      for (int i3 = 1; ; i3 = 0)
      {
        this.enabled = i3;
        return;
      }
    }

    protected void formatFields(StringBuilder paramStringBuilder)
    {
      StringBuilder localStringBuilder1 = paramStringBuilder.append(" hour=");
      int i = this.hour;
      StringBuilder localStringBuilder2 = localStringBuilder1.append(i);
      StringBuilder localStringBuilder3 = paramStringBuilder.append(" minutes=");
      int j = this.minutes;
      StringBuilder localStringBuilder4 = localStringBuilder3.append(j);
      StringBuilder localStringBuilder5 = paramStringBuilder.append(" daysOfWeek=");
      int k = this.daysOfWeek;
      StringBuilder localStringBuilder6 = localStringBuilder5.append(k);
      StringBuilder localStringBuilder7 = paramStringBuilder.append(" enabled=");
      boolean bool = this.enabled;
      StringBuilder localStringBuilder8 = localStringBuilder7.append(bool);
    }

    public boolean update(Cursor paramCursor)
    {
      int i = 0;
      int j = paramCursor.getColumnIndex("hour");
      int k = paramCursor.getInt(j);
      int m = paramCursor.getColumnIndex("minutes");
      int n = paramCursor.getInt(m);
      int i1 = paramCursor.getColumnIndex("daysofweek");
      int i2 = paramCursor.getInt(i1);
      int i3 = paramCursor.getColumnIndex("enabled");
      if (paramCursor.getInt(i3) != 0);
      for (int i4 = 1; ; i4 = 0)
      {
        int i5 = this.hour;
        if (k != i5)
        {
          i = 1;
          this.hour = k;
        }
        int i6 = this.minutes;
        if (n != i6)
        {
          i = 1;
          this.minutes = n;
        }
        int i7 = this.daysOfWeek;
        if (i2 != i7)
        {
          i = 1;
          this.daysOfWeek = i2;
        }
        int i8 = this.enabled;
        if (i4 != i8)
        {
          i = 1;
          this.enabled = i4;
        }
        return i;
      }
    }
  }

  abstract interface AlarmColumns extends BaseColumns
  {
    public static final String ALARM_TIME = "alarmtime";
    public static final String ALERT = "alert";
    public static final String DAYS_OF_WEEK = "daysofweek";
    public static final String ENABLED = "enabled";
    public static final String HOUR = "hour";
    public static final String MESSAGE = "message";
    public static final String MINUTES = "minutes";
    public static final String VIBRATE = "vibrate";
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.alarms.AlarmsAdapterAndroid
 * JD-Core Version:    0.6.0
 */