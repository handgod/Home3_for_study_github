package com.softspb.shell.adapters.alarms;

import android.content.Context;
import com.softspb.shell.adapters.AbstractContentAdapter;
import com.softspb.util.log.Logger;
import java.util.Calendar;
import java.util.GregorianCalendar;

public abstract class AlarmsAdapter extends AbstractContentAdapter<AlarmsAdapterAndroid.Alarm>
{
  public static final long ALARM_NOT_SET;
  protected int nativePeer;

  public AlarmsAdapter(int paramInt, Context paramContext)
  {
    super(paramContext);
    this.nativePeer = paramInt;
  }

  public static long findAlarmTime(int paramInt1, int paramInt2, int paramInt3, Calendar paramCalendar)
  {
    int i = paramCalendar.get(11) * 60;
    int j = paramCalendar.get(12);
    int k = i + j;
    int m = paramCalendar.get(7) + -2;
    if (m < 0)
      m += 7;
    int n = paramInt1 * 60 + paramInt2;
    int i1 = paramInt3 + 7 - m;
    while (i1 >= 7)
      i1 += -7;
    int i2;
    long l;
    if (i1 == 0)
      if (n > k)
      {
        i2 = 0;
        if (i2 == 2147483647)
          break label183;
        int i3 = paramCalendar.get(1);
        int i4 = paramCalendar.get(2);
        int i5 = paramCalendar.get(5);
        int i6 = paramInt1;
        int i7 = paramInt2;
        GregorianCalendar localGregorianCalendar = new GregorianCalendar(i3, i4, i5, i6, i7);
        localGregorianCalendar.add(5, i2);
        l = localGregorianCalendar.getTimeInMillis();
      }
    while (true)
    {
      return l;
      i2 = 7;
      break;
      i2 = i1;
      break;
      label183: l = 9223372036854775807L;
    }
  }

  public static long findNextAlarmTime(int paramInt1, int paramInt2, int paramInt3, Calendar paramCalendar)
  {
    int i = paramCalendar.get(11) * 60;
    int j = paramCalendar.get(12);
    int k = i + j;
    int m = paramCalendar.get(7) + -2;
    if (m < 0)
      m += 7;
    int n = paramInt1 * 60 + paramInt2;
    int i1 = 2147483647;
    int i2 = 0;
    int i3;
    long l;
    if (i2 <= 6)
    {
      if ((paramInt3 & 0x1) == 0)
        break label201;
      i3 = i2 + 7 - m;
      while (i3 >= 7)
        i3 += -7;
      if (i3 != 0)
        break label214;
      if (n > k)
        i1 = 0;
    }
    else
    {
      if (i1 == 2147483647)
        break label228;
      int i4 = paramCalendar.get(1);
      int i5 = paramCalendar.get(2);
      int i6 = paramCalendar.get(5);
      int i7 = paramInt1;
      int i8 = paramInt2;
      GregorianCalendar localGregorianCalendar = new GregorianCalendar(i4, i5, i6, i7, i8);
      localGregorianCalendar.add(5, i1);
      l = localGregorianCalendar.getTimeInMillis();
    }
    while (true)
    {
      return l;
      if (i1 > 7)
        i1 = 7;
      while (true)
      {
        label201: i2 += 1;
        paramInt3 >>= 1;
        break;
        label214: if (i3 >= i1)
          continue;
        i1 = i3;
      }
      label228: l = 9223372036854775807L;
    }
  }

  protected void addNativeContentItem(AlarmsAdapterAndroid.Alarm paramAlarm)
  {
  }

  protected native void onDateChanged(int paramInt);

  public void onStop()
  {
    super.onStop();
    this.nativePeer = 0;
  }

  protected void removeNativeContentItem(AlarmsAdapterAndroid.Alarm paramAlarm)
  {
  }

  protected void setNativeNextAlarm(long paramLong)
  {
    Logger localLogger = this.logger;
    StringBuilder localStringBuilder = new StringBuilder().append("Invoking setNextAlarm: nativePeer=0x");
    String str1 = Integer.toHexString(this.nativePeer);
    String str2 = str1 + " nextAlarmTime=" + paramLong;
    localLogger.d(str2);
    if (this.nativePeer == 0)
      throw new IllegalStateException("No nativePeer in AlarmsAdapter");
    int i = this.nativePeer;
    setNextAlarm(i, paramLong);
  }

  protected native void setNextAlarm(int paramInt, long paramLong);

  protected void updateNativeContentItem(AlarmsAdapterAndroid.Alarm paramAlarm)
  {
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.alarms.AlarmsAdapter
 * JD-Core Version:    0.6.0
 */