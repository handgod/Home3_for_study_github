package com.softspb.shell.adapters.alarms;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
import android.provider.Settings.System;
import android.text.TextUtils;
import android.text.format.DateUtils;
import com.softspb.shell.Home;
import com.softspb.shell.Home.PauseResumeListener;
import com.softspb.util.log.Logger;
import java.util.GregorianCalendar;

public class AlarmsAdapterAndroid2 extends BaseAlarmsAdapter
  implements Home.PauseResumeListener
{
  private String KEY_ALARM_REC = "key_alarm_rec";
  private String KEY_ALARM_TIME = "key_alarm_time";
  long nextAlarm = 0L;

  public AlarmsAdapterAndroid2(int paramInt, Context paramContext)
  {
    super(paramInt, paramContext);
  }

  private static long parseDate(String paramString)
  {
    String str1 = paramString;
    String str2 = "[ ]+";
    String[] arrayOfString1 = TextUtils.split(str1, str2);
    int i = 0;
    int j = 0;
    String str3 = DateUtils.getAMPMString(0);
    String str4 = DateUtils.getAMPMString(1);
    Object localObject1 = null;
    String[] arrayOfString2 = arrayOfString1;
    int k = arrayOfString2.length;
    int m = 0;
    String str5;
    boolean bool1;
    while (m < k)
    {
      str5 = arrayOfString2[m];
      String str6 = str5;
      String str7 = ":";
      if (str6.contains(str7))
        localObject1 = str5;
      String str8 = str5;
      boolean bool2 = str3.equalsIgnoreCase(str8);
      String str9 = str4;
      String str10 = str5;
      boolean bool3 = str9.equalsIgnoreCase(str10);
      if ((bool2 | bool3))
      {
        i = 1;
        String str11 = str5;
        bool1 = str3.equalsIgnoreCase(str11);
      }
      m += 1;
    }
    long l;
    if (localObject1 == null)
      l = 0L;
    int i2;
    int i4;
    label296: int i8;
    while (true)
    {
      return l;
      Object localObject2 = localObject1;
      String str12 = ":";
      String[] arrayOfString3 = TextUtils.split(localObject2, str12);
      int n = arrayOfString3.length;
      int i1 = 2;
      if (n != i1)
      {
        l = 0L;
        continue;
      }
      try
      {
        String str13 = arrayOfString3[0];
        i2 = new Integer(str13).intValue();
        String str14 = arrayOfString3[1];
        int i3 = new Integer(str14).intValue();
        i4 = i3;
        int i5 = 59;
        if (i4 <= i5)
        {
          int i6 = 23;
          if (i2 <= i6)
          {
            if (i == 0)
              break label296;
            int i7 = 13;
            if (i2 <= i7)
              break label296;
          }
        }
        l = 0L;
      }
      catch (Exception localException)
      {
        l = 0L;
      }
      continue;
      String[] arrayOfString4 = new String[7];
      String str15 = DateUtils.getDayOfWeekString(2, 20);
      arrayOfString4[0] = str15;
      String str16 = DateUtils.getDayOfWeekString(3, 20);
      arrayOfString4[1] = str16;
      String str17 = DateUtils.getDayOfWeekString(4, 20);
      arrayOfString4[2] = str17;
      String str18 = DateUtils.getDayOfWeekString(5, 20);
      arrayOfString4[3] = str18;
      String str19 = DateUtils.getDayOfWeekString(6, 20);
      arrayOfString4[4] = str19;
      String str20 = DateUtils.getDayOfWeekString(7, 20);
      arrayOfString4[5] = str20;
      String str21 = DateUtils.getDayOfWeekString(1, 20);
      arrayOfString4[6] = str21;
      i8 = -1;
      arrayOfString2 = arrayOfString1;
      k = arrayOfString2.length;
      m = 0;
      if (m < k)
      {
        str5 = arrayOfString2[m];
        int i9 = 0;
        while (true)
        {
          int i10 = arrayOfString4.length;
          if (i9 < i10)
          {
            String str22 = arrayOfString4[i9];
            String str23 = str5;
            String str24 = str22;
            if (str23.equals(str24))
              i8 = i9;
          }
          else
          {
            m += 1;
            break;
          }
          i9 += 1;
        }
      }
      int i11 = 65535;
      if (i8 != i11)
        break;
      l = 0L;
    }
    if (i != 0)
      if (!bool1)
        break label580;
    label580: for (int i12 = 0; ; i12 = 12)
    {
      int i13 = 12;
      if (i2 == i13)
        i12 += 12;
      i2 = (i2 + i12) % 24;
      GregorianCalendar localGregorianCalendar = new GregorianCalendar();
      l = findAlarmTime(i2, i4, i8, localGregorianCalendar);
      break;
    }
  }

  private void saveAlarmsInPreferences(String paramString, long paramLong)
  {
    SharedPreferences.Editor localEditor1 = PreferenceManager.getDefaultSharedPreferences(this.context).edit();
    String str1 = this.KEY_ALARM_REC;
    SharedPreferences.Editor localEditor2 = localEditor1.putString(str1, paramString);
    String str2 = this.KEY_ALARM_TIME;
    boolean bool = localEditor2.putLong(str2, paramLong).commit();
  }

  private long tryToGetSavedValue(String paramString)
  {
    long l = 0L;
    SharedPreferences localSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.context);
    String str1 = this.KEY_ALARM_REC;
    if (!localSharedPreferences.contains(str1));
    while (true)
    {
      return l;
      String str2 = this.KEY_ALARM_REC;
      String str3 = localSharedPreferences.getString(str2, null);
      if (!paramString.equals(str3))
        continue;
      String str4 = this.KEY_ALARM_TIME;
      l = localSharedPreferences.getLong(str4, 0L);
    }
  }

  public void onPause()
  {
  }

  public void onResume()
  {
    reload(0);
  }

  public void onStart()
  {
    super.onStart();
    ((Home)this.context).setOnPauseResumeListener(this);
    reload(0);
  }

  public void onStop()
  {
    super.onStop();
    ((Home)this.context).removeOnPauseResumeListener(this);
  }

  public void reload(boolean paramBoolean)
  {
    String str1 = Settings.System.getString(this.contentResolver, "next_alarm_formatted");
    long l1 = 0L;
    if (!TextUtils.isEmpty(str1))
    {
      l1 = parseDate(str1);
      if (l1 == 9223372036854775807L)
        l1 = 0L;
      if (l1 == 0L)
        l1 = tryToGetSavedValue(str1);
    }
    long l2 = this.nextAlarm;
    if (l1 != l2)
    {
      this.nextAlarm = l1;
      long l3 = this.nextAlarm;
      saveAlarmsInPreferences(str1, l3);
      Logger localLogger = this.logger;
      StringBuilder localStringBuilder = new StringBuilder().append("set new alarm at ");
      long l4 = this.nextAlarm;
      String str2 = l4;
      localLogger.d(str2);
      long l5 = this.nextAlarm;
      setNativeNextAlarm(l5);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.alarms.AlarmsAdapterAndroid2
 * JD-Core Version:    0.6.0
 */