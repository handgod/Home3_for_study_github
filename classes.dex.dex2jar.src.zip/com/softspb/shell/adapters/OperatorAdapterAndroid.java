package com.softspb.shell.adapters;

import android.content.Context;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import com.softspb.shell.Home;
import com.softspb.shell.Home.PauseResumeListener;
import com.softspb.shell.opengl.NativeCallbacks;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;

public class OperatorAdapterAndroid extends OperatorAdapter
  implements Home.PauseResumeListener
{
  private static final Logger logger = Loggers.getLogger(OperatorAdapterAndroid.class.getName());
  private boolean isRegistered;
  private PhoneStateListener listener;
  private int oldLevel;
  private int oldMaxLevel;
  private int oldNetworkType;
  private String oldOperator;
  private int oldOperatorState;
  private int oldPhoneType;
  private int oldSimState;
  private TelephonyManager telephonyManager;

  public OperatorAdapterAndroid(AdaptersHolder paramAdaptersHolder)
  {
    super(paramAdaptersHolder);
    OperatorAdapterAndroid.1 local1 = new OperatorAdapterAndroid.1(this);
    this.listener = local1;
    this.isRegistered = 0;
    logger.d("constructor");
  }

  private int convertToNetworkType(int paramInt)
  {
    int i;
    switch (paramInt)
    {
    default:
      i = 11;
    case 7:
    case 4:
    case 2:
    case 5:
    case 6:
    case 1:
    case 8:
    case 10:
    case 9:
    case 3:
    case 11:
    }
    while (true)
    {
      return i;
      i = 0;
      continue;
      i = 1;
      continue;
      i = 2;
      continue;
      i = 3;
      continue;
      i = 4;
      continue;
      i = 5;
      continue;
      i = 6;
      continue;
      i = 7;
      continue;
      i = 8;
      continue;
      i = 10;
      continue;
      i = 9;
    }
  }

  private int convertToOperatorState(int paramInt)
  {
    int i = 0;
    switch (paramInt)
    {
    default:
      Logger localLogger = logger;
      String str = "operatorState=" + paramInt + "  is not supported - check native to java constants mapping";
      localLogger.w(str);
    case 3:
    case 0:
    case 1:
    case 2:
    }
    while (true)
    {
      return i;
      i = 4;
      continue;
      i = 3;
      continue;
      i = 1;
    }
  }

  private int convertToPhoneType(int paramInt)
  {
    int i;
    switch (paramInt)
    {
    default:
      i = 2;
    case 1:
    case 2:
    }
    while (true)
    {
      return i;
      i = 1;
      continue;
      i = 0;
    }
  }

  private int convertToSimState(int paramInt)
  {
    int i;
    switch (paramInt)
    {
    default:
      i = 5;
    case 1:
    case 4:
    case 2:
    case 3:
    case 5:
    }
    while (true)
    {
      return i;
      i = 0;
      continue;
      i = 1;
      continue;
      i = 2;
      continue;
      i = 3;
      continue;
      i = 4;
    }
  }

  private void notifyChange(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, String paramString)
  {
    if ((this.oldOperatorState == paramInt1) && (this.oldSimState == paramInt2) && (this.oldPhoneType == paramInt3) && (this.oldNetworkType == paramInt4) && (this.oldLevel == paramInt5) && (this.oldMaxLevel == paramInt6) && (TextUtils.equals(this.oldOperator, paramString)))
      logger.d("notifyChange: skipped!");
    while (true)
    {
      return;
      this.oldOperatorState = paramInt1;
      this.oldSimState = paramInt2;
      this.oldPhoneType = paramInt3;
      this.oldNetworkType = paramInt4;
      this.oldLevel = paramInt5;
      this.oldMaxLevel = paramInt6;
      this.oldOperator = paramString;
      Logger localLogger = logger;
      String str = "notifyChange: operatorState = " + paramInt1 + ", " + "simState = " + paramInt2 + ", " + "phoneType = " + paramInt3 + ", " + "networkType = " + paramInt4 + ", " + "level = " + paramInt5 + ", " + "maxLevel = " + paramInt6 + ", " + "operator = " + paramString;
      localLogger.d(str);
      setStatus(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramString);
    }
  }

  public static native void setStatus(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, String paramString);

  public boolean isOperatorSupported()
  {
    logger.d(">>>isOperatorSupported");
    Logger localLogger = logger;
    String str = "<<<isOperatorSupported: result=" + 1;
    localLogger.d(str);
    return true;
  }

  /** @deprecated */
  protected void onCreate(Context paramContext, NativeCallbacks paramNativeCallbacks)
  {
    monitorenter;
    try
    {
      Logger localLogger = logger;
      String str = ">>>onCreate: context=" + paramContext;
      localLogger.d(str);
      this.isRegistered = 1;
      TelephonyManager localTelephonyManager1 = (TelephonyManager)paramContext.getSystemService("phone");
      this.telephonyManager = localTelephonyManager1;
      TelephonyManager localTelephonyManager2 = this.telephonyManager;
      PhoneStateListener localPhoneStateListener = this.listener;
      localTelephonyManager2.listen(localPhoneStateListener, 289);
      ((Home)paramContext).setOnPauseResumeListener(this);
      logger.d("<<<onCreate");
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  /** @deprecated */
  protected void onDestroy(Context paramContext)
  {
    monitorenter;
    try
    {
      Logger localLogger = logger;
      String str = ">>>onDestroy: context=" + paramContext;
      localLogger.d(str);
      ((Home)paramContext).removeOnPauseResumeListener(this);
      TelephonyManager localTelephonyManager = this.telephonyManager;
      PhoneStateListener localPhoneStateListener = this.listener;
      localTelephonyManager.listen(localPhoneStateListener, 0);
      logger.d("<<<onDestroy");
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  /** @deprecated */
  public void onPause()
  {
    monitorenter;
    try
    {
      if (this.isRegistered)
      {
        this.isRegistered = 0;
        TelephonyManager localTelephonyManager = this.telephonyManager;
        PhoneStateListener localPhoneStateListener = this.listener;
        localTelephonyManager.listen(localPhoneStateListener, 0);
      }
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  /** @deprecated */
  public void onResume()
  {
    monitorenter;
    try
    {
      if (!this.isRegistered)
      {
        this.isRegistered = 1;
        TelephonyManager localTelephonyManager = this.telephonyManager;
        PhoneStateListener localPhoneStateListener = this.listener;
        localTelephonyManager.listen(localPhoneStateListener, 289);
      }
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.OperatorAdapterAndroid
 * JD-Core Version:    0.6.0
 */