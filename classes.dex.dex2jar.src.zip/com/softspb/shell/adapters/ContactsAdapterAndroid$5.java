package com.softspb.shell.adapters;

import com.softspb.shell.Home;

class ContactsAdapterAndroid$5
  implements Runnable
{
  public void run()
  {
    ContactsAdapterAndroid localContactsAdapterAndroid = this.this$0;
    int i = this.val$token;
    localContactsAdapterAndroid.contactPickingToken = i;
    ((Home)this.this$0.context).startPickContact(0);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.ContactsAdapterAndroid.5
 * JD-Core Version:    0.6.0
 */