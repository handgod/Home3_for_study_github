package com.softspb.shell.adapters;

import android.content.Context;
import com.softspb.util.CollectionFactory;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class AdaptersHolder
{
  private boolean closing;
  private Set<Adapter> createdAdapters;
  private Set<Adapter> startedAdapters;

  public AdaptersHolder()
  {
    HashSet localHashSet1 = CollectionFactory.newHashSet();
    this.createdAdapters = localHashSet1;
    HashSet localHashSet2 = CollectionFactory.newHashSet();
    this.startedAdapters = localHashSet2;
    this.closing = 0;
  }

  public void addCreated(Adapter paramAdapter)
  {
    if (!this.createdAdapters.add(paramAdapter))
    {
      StringBuilder localStringBuilder = new StringBuilder().append("Adapter ");
      String str1 = paramAdapter.toString();
      String str2 = str1 + "already has been created";
      throw new IllegalStateException(str2);
    }
  }

  public void addStarted(Adapter paramAdapter)
  {
    if (!this.createdAdapters.contains(paramAdapter))
    {
      StringBuilder localStringBuilder1 = new StringBuilder().append("Adapter ");
      String str1 = paramAdapter.toString();
      String str2 = str1 + " hasn't been created";
      throw new IllegalStateException(str2);
    }
    if (!this.startedAdapters.add(paramAdapter))
    {
      StringBuilder localStringBuilder2 = new StringBuilder().append("Adapter ");
      String str3 = paramAdapter.toString();
      String str4 = str3 + " already has been started";
      throw new IllegalStateException(str4);
    }
  }

  public void closeHeldAdapters(Context paramContext)
  {
    this.closing = 1;
    Iterator localIterator = this.startedAdapters.iterator();
    while (localIterator.hasNext())
      ((Adapter)localIterator.next()).stop();
    this.startedAdapters.clear();
    localIterator = this.createdAdapters.iterator();
    while (localIterator.hasNext())
      ((Adapter)localIterator.next()).destroy(paramContext);
    this.createdAdapters.clear();
    this.closing = 0;
  }

  public void destroyed(Adapter paramAdapter)
  {
    if (this.closing);
    do
      return;
    while (this.createdAdapters.remove(paramAdapter));
    StringBuilder localStringBuilder = new StringBuilder().append("Adapter ");
    String str1 = paramAdapter.toString();
    String str2 = str1 + " hasn't been created";
    throw new IllegalStateException(str2);
  }

  public void stopped(Adapter paramAdapter)
  {
    if (this.closing);
    do
      return;
    while (this.startedAdapters.remove(paramAdapter));
    StringBuilder localStringBuilder = new StringBuilder().append("Adapter ");
    String str1 = paramAdapter.toString();
    String str2 = str1 + " hasn't been started";
    throw new IllegalStateException(str2);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.AdaptersHolder
 * JD-Core Version:    0.6.0
 */