package com.softspb.shell.adapters;

import android.telephony.PhoneStateListener;
import android.telephony.ServiceState;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import com.softspb.util.log.Logger;

class OperatorAdapterAndroid$1 extends PhoneStateListener
{
  private static final int maxLevel = 4;
  private int level;
  int mPhoneState = 0;
  ServiceState mServiceState;
  SignalStrength mSignalStrength;
  private int networkType;
  private String operator;
  private int operatorState;
  private int phoneType;
  private int simState;

  private int getCdmaLevel()
  {
    int i = this.mSignalStrength.getCdmaDbm();
    int j = this.mSignalStrength.getCdmaEcio();
    int k;
    int m;
    if (i >= 65461)
    {
      k = 4;
      if (j < 65446)
        break label79;
      m = 4;
      label33: if (k >= m)
        break label121;
    }
    while (true)
    {
      return k;
      if (i >= 65451)
      {
        k = 3;
        break;
      }
      if (i >= 65441)
      {
        k = 2;
        break;
      }
      if (i >= 65436)
      {
        k = 1;
        break;
      }
      k = 0;
      break;
      label79: if (j >= 65426)
      {
        m = 3;
        break label33;
      }
      if (j >= 65406)
      {
        m = 2;
        break label33;
      }
      if (j >= 65386)
      {
        m = 1;
        break label33;
      }
      m = 0;
      break label33;
      label121: k = m;
    }
  }

  private int getEvdoLevel()
  {
    int i = this.mSignalStrength.getEvdoDbm();
    int j = this.mSignalStrength.getEvdoSnr();
    int k;
    int m;
    if (i >= 65471)
    {
      k = 4;
      if (j < 7)
        break label79;
      m = 4;
      label33: if (k >= m)
        break label118;
    }
    while (true)
    {
      return k;
      if (i >= 65461)
      {
        k = 3;
        break;
      }
      if (i >= 65446)
      {
        k = 2;
        break;
      }
      if (i >= 65431)
      {
        k = 1;
        break;
      }
      k = 0;
      break;
      label79: if (j >= 5)
      {
        m = 3;
        break label33;
      }
      if (j >= 3)
      {
        m = 2;
        break label33;
      }
      if (j >= 1)
      {
        m = 1;
        break label33;
      }
      m = 0;
      break label33;
      label118: k = m;
    }
  }

  private boolean isCdma()
  {
    if ((this.mSignalStrength != null) && (!this.mSignalStrength.isGsm()));
    for (int i = 1; ; i = 0)
      return i;
  }

  private boolean isEvdo()
  {
    int i = OperatorAdapterAndroid.access$100(this.this$0).getNetworkType();
    if ((this.mServiceState != null) && ((i == 5) || (i == 6)));
    for (int j = 1; ; j = 0)
      return j;
  }

  private void notifyChangeInternal()
  {
    OperatorAdapterAndroid.access$500().d(">>>notifyChangeInternal");
    OperatorAdapterAndroid localOperatorAdapterAndroid = this.this$0;
    int i = this.operatorState;
    int j = this.simState;
    int k = this.phoneType;
    int m = this.networkType;
    int n = this.level;
    String str = this.operator;
    OperatorAdapterAndroid.access$600(localOperatorAdapterAndroid, i, j, k, m, n, 4, str);
    OperatorAdapterAndroid.access$500().d("<<<notifyChangeInternal");
  }

  private void updateSignalStrength()
  {
    int i;
    if (!isCdma())
    {
      i = this.mSignalStrength.getGsmSignalStrength();
      if ((i <= 2) || (i == 99))
        this.level = 0;
    }
    while (true)
    {
      notifyChangeInternal();
      return;
      if (i >= 12)
      {
        this.level = 4;
        continue;
      }
      if (i >= 8)
      {
        this.level = 3;
        continue;
      }
      if (i >= 5)
      {
        this.level = 2;
        continue;
      }
      this.level = 1;
      continue;
      if ((this.mPhoneState == 0) && (isEvdo()))
      {
        int j = getEvdoLevel();
        this.level = j;
        continue;
      }
      int k = getCdmaLevel();
      this.level = k;
    }
  }

  public void onCallStateChanged(int paramInt, String paramString)
  {
    this.mPhoneState = paramInt;
    if (isCdma())
      updateSignalStrength();
  }

  public void onServiceStateChanged(ServiceState paramServiceState)
  {
    this.mServiceState = paramServiceState;
    OperatorAdapterAndroid localOperatorAdapterAndroid1 = this.this$0;
    int i = paramServiceState.getState();
    int j = OperatorAdapterAndroid.access$000(localOperatorAdapterAndroid1, i);
    this.operatorState = j;
    OperatorAdapterAndroid localOperatorAdapterAndroid2 = this.this$0;
    int k = OperatorAdapterAndroid.access$100(this.this$0).getSimState();
    int m = OperatorAdapterAndroid.access$200(localOperatorAdapterAndroid2, k);
    this.simState = m;
    OperatorAdapterAndroid localOperatorAdapterAndroid3 = this.this$0;
    int n = OperatorAdapterAndroid.access$100(this.this$0).getPhoneType();
    int i1 = OperatorAdapterAndroid.access$300(localOperatorAdapterAndroid3, n);
    this.phoneType = i1;
    OperatorAdapterAndroid localOperatorAdapterAndroid4 = this.this$0;
    int i2 = OperatorAdapterAndroid.access$100(this.this$0).getNetworkType();
    int i3 = OperatorAdapterAndroid.access$400(localOperatorAdapterAndroid4, i2);
    this.networkType = i3;
    String str;
    if (this.operatorState == 4)
      str = OperatorAdapterAndroid.access$100(this.this$0).getNetworkOperatorName();
    for (this.operator = str; ; this.operator = null)
    {
      notifyChangeInternal();
      return;
    }
  }

  public void onSignalStrengthsChanged(SignalStrength paramSignalStrength)
  {
    this.mSignalStrength = paramSignalStrength;
    updateSignalStrength();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.OperatorAdapterAndroid.1
 * JD-Core Version:    0.6.0
 */