package com.softspb.shell.adapters;

public class GSensorAdapterEmpty extends GSensorAdapter
{
  public GSensorAdapterEmpty(AdaptersHolder paramAdaptersHolder)
  {
    super(paramAdaptersHolder);
  }

  public void EnableGSensor(boolean paramBoolean)
  {
  }

  public void askEvents()
  {
  }

  public boolean isPresent()
  {
    return false;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.GSensorAdapterEmpty
 * JD-Core Version:    0.6.0
 */