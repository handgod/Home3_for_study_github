package com.softspb.shell.adapters;

import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.net.Uri;
import com.softspb.shell.opengl.NativeCallbacks;
import com.spb.programlist.ProgramsUtil;
import java.io.InputStream;

public class NetworkAdapterAndroid extends NetworkAdapter
{
  private static final boolean DEBUG;
  private Context context;
  private Thread receiverThread;
  private Thread receiverThreadTcp;
  private Runnable runnable;
  private Runnable runnableTcp;

  public NetworkAdapterAndroid(AdaptersHolder paramAdaptersHolder)
  {
    super(paramAdaptersHolder);
    init();
  }

  private boolean haveUIBuilder()
  {
    int i = 0;
    try
    {
      InputStream localInputStream = this.context.getAssets().open("skins/skins/uibuilder.dat");
      if (localInputStream != null)
      {
        localInputStream.close();
        i = 1;
      }
      label25: return i;
    }
    catch (Throwable localThrowable)
    {
      break label25;
    }
  }

  private void init()
  {
    if (this.runnable == null)
    {
      NetworkAdapterAndroid.1 local1 = new NetworkAdapterAndroid.1(this);
      this.runnable = local1;
    }
    if (this.runnableTcp == null)
    {
      NetworkAdapterAndroid.2 local2 = new NetworkAdapterAndroid.2(this);
      this.runnableTcp = local2;
    }
  }

  private static void logd(String paramString)
  {
  }

  public static native String onCmd(String paramString);

  protected void onCreate(Context paramContext, NativeCallbacks paramNativeCallbacks)
  {
    this.context = paramContext;
    startServer();
  }

  protected void onDestroy(Context paramContext)
  {
    stopServer();
  }

  public void openBrowser(String paramString)
  {
    if (paramString == null);
    while (true)
    {
      return;
      Intent localIntent1 = new Intent("android.intent.action.VIEW");
      Uri localUri = Uri.parse(paramString);
      Intent localIntent2 = localIntent1.setData(localUri);
      ProgramsUtil.startActivitySafely(this.context, localIntent1);
    }
  }

  public void startServer()
  {
    if (haveUIBuilder())
    {
      Runnable localRunnable1 = this.runnable;
      Thread localThread1 = new Thread(localRunnable1);
      this.receiverThread = localThread1;
      this.receiverThread.start();
      Runnable localRunnable2 = this.runnableTcp;
      Thread localThread2 = new Thread(localRunnable2);
      this.receiverThreadTcp = localThread2;
      this.receiverThreadTcp.start();
    }
  }

  public void stopServer()
  {
    if (haveUIBuilder())
    {
      this.receiverThread.interrupt();
      this.receiverThreadTcp.interrupt();
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.NetworkAdapterAndroid
 * JD-Core Version:    0.6.0
 */