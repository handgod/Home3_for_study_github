package com.softspb.shell.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import com.softspb.shell.browser.service.BrowserClient;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;

public class BookmarksAdapterAndroid extends BookmarksAdapter
{
  private static final long BROWSER_SERVICE_TIMEOUT_MS = 5000L;
  static final String ICON_URI_PREFIX = ;
  static final String IMAGE_PATH_ICON = "icon";
  static final String IMAGE_PATH_THUMBNAIL = "thumbnail";
  static final String SCHEMA_BOOKMARK_IMAGE_INT = "bookmark-image" + "://";
  static final String THUMBNAIL_URI_PREFIX;
  private static final Logger logger;
  BrowserClientImpl browserClient;
  private Context context;
  private int nativePeer;

  static
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str1 = SCHEMA_BOOKMARK_IMAGE_INT;
    ICON_URI_PREFIX = str1 + "icon" + 47;
    StringBuilder localStringBuilder2 = new StringBuilder();
    String str2 = SCHEMA_BOOKMARK_IMAGE_INT;
    THUMBNAIL_URI_PREFIX = str2 + "thumbnail" + 47;
    logger = Loggers.getLogger(BookmarksAdapterAndroid.class);
  }

  public BookmarksAdapterAndroid(int paramInt, Context paramContext)
  {
    this.context = paramContext;
    this.nativePeer = paramInt;
  }

  private Bitmap getIcon(int paramInt)
  {
    Logger localLogger = logger;
    String str = "getIcon: bookmarkId=" + paramInt;
    localLogger.d(str);
    Bitmap localBitmap = null;
    if (this.browserClient != null)
      localBitmap = this.browserClient.loadIcon(paramInt);
    return localBitmap;
  }

  private Bitmap getThumbnail(int paramInt)
  {
    Logger localLogger = logger;
    String str = "getThumbnail: bookmarkId=" + paramInt;
    localLogger.d(str);
    Bitmap localBitmap = null;
    if (this.browserClient != null)
      localBitmap = this.browserClient.loadThumbnail(paramInt);
    return localBitmap;
  }

  protected void deleteNativeBookmark(int paramInt)
  {
    if (this.nativePeer == 0)
      throw new IllegalStateException("BookmarksAdapter is dead");
    int i = this.nativePeer;
    removeBookmark(i, paramInt);
  }

  public Bitmap getImage(String paramString)
  {
    Logger localLogger1 = logger;
    String str1 = "getImage: imageUrl=" + paramString;
    localLogger1.d(str1);
    String str2 = ICON_URI_PREFIX;
    Bitmap localBitmap;
    Logger localLogger2;
    StringBuilder localStringBuilder1;
    if (paramString.startsWith(str2))
    {
      int i = ICON_URI_PREFIX.length();
      int j = Integer.parseInt(paramString.substring(i));
      localBitmap = getIcon(j);
      localLogger2 = logger;
      localStringBuilder1 = new StringBuilder().append("returning image=").append(localBitmap);
      if (localBitmap != null)
        break label200;
    }
    label200: StringBuilder localStringBuilder3;
    int i1;
    for (String str3 = ""; ; str3 = i1)
    {
      String str4 = str3;
      localLogger2.d(str4);
      return localBitmap;
      String str5 = THUMBNAIL_URI_PREFIX;
      if (paramString.startsWith(str5))
      {
        int k = THUMBNAIL_URI_PREFIX.length();
        int m = Integer.parseInt(paramString.substring(k));
        localBitmap = getThumbnail(m);
        break;
      }
      String str6 = "Invalid bookmark image URI: " + paramString;
      throw new IllegalArgumentException(str6);
      StringBuilder localStringBuilder2 = new StringBuilder().append(" w=");
      int n = localBitmap.getWidth();
      localStringBuilder3 = localStringBuilder2.append(n).append(" h=");
      i1 = localBitmap.getHeight();
    }
  }

  public void onStart()
  {
    logger.d("onStart >>>");
    Context localContext = this.context;
    BrowserClientImpl localBrowserClientImpl = new BrowserClientImpl(localContext);
    this.browserClient = localBrowserClientImpl;
    this.browserClient.connect();
    logger.d("onStart <<<");
  }

  public void onStop()
  {
    logger.d("onStop >>>");
    this.browserClient.disconnect();
    this.browserClient = null;
    this.nativePeer = 0;
    logger.d("onStop <<<");
  }

  public boolean openBookmark(String paramString)
  {
    Logger localLogger1 = logger;
    String str1 = "openBookmark: url=" + paramString;
    localLogger1.d(str1);
    Intent localIntent1 = new Intent("android.intent.action.VIEW");
    try
    {
      Uri localUri1 = Uri.parse(paramString);
      Uri localUri2 = localUri1;
      Intent localIntent2 = localIntent1.setData(localUri2);
      this.context.startActivity(localIntent1);
      i = 1;
      return i;
    }
    catch (Exception localException)
    {
      while (true)
      {
        Logger localLogger2 = logger;
        String str2 = "Failed to parse url: " + paramString;
        localLogger2.e(str2, localException);
        int i = 0;
      }
    }
  }

  protected void updateNativeBookmark(int paramInt, String paramString1, String paramString2)
  {
    if (this.nativePeer == 0)
      throw new IllegalStateException("BookmarksAdapter is dead");
    int i = this.nativePeer;
    addBookmark(i, paramInt, paramString1, paramString2);
  }

  class BrowserClientImpl extends BrowserClient
  {
    BrowserClientImpl(Context arg2)
    {
      super();
    }

    protected void onBookmarkDeleted(int paramInt)
    {
      Logger localLogger = BookmarksAdapterAndroid.logger;
      String str = "BrowserClient.onBookmarkDeleted: bookmarkId=" + paramInt;
      localLogger.d(str);
      BookmarksAdapterAndroid.this.deleteNativeBookmark(paramInt);
    }

    protected void onBookmarkUpdated(int paramInt, String paramString1, String paramString2)
    {
      Logger localLogger = BookmarksAdapterAndroid.logger;
      String str = "BrowserClient.onBookmarkUpdated: bookmarkId=" + paramInt + " title=" + paramString1 + " url=" + paramString2;
      localLogger.d(str);
      BookmarksAdapterAndroid.this.updateNativeBookmark(paramInt, paramString1, paramString2);
    }

    protected void onConnected()
    {
      BookmarksAdapterAndroid.logger.d("BrowserClient.onConnected");
      postLoadBookmarks();
    }

    protected void onDisconnected()
    {
      BookmarksAdapterAndroid.logger.d("BrowserClient.onDisconnected");
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.BookmarksAdapterAndroid
 * JD-Core Version:    0.6.0
 */