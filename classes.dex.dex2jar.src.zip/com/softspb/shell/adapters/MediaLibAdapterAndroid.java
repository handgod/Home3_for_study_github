package com.softspb.shell.adapters;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.MergeCursor;
import android.graphics.BitmapFactory.Options;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Environment;
import android.os.FileObserver;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.MediaStore.Audio.Albums;
import android.text.TextUtils;
import android.util.SparseArray;
import com.softspb.shell.SDCardReceiver;
import com.softspb.shell.SDCardReceiver.SDCardListener;
import com.softspb.util.DelayedHandler;
import com.softspb.util.log.Logger;
import java.io.File;
import java.util.HashMap;

public class MediaLibAdapterAndroid extends MediaLibAdapter
  implements SDCardReceiver.SDCardListener
{
  static final String[] ALBUMS_PROJECTION = ;
  static final String ALBUMS_SELECTION_HAVING_ART_NOT_NULL = ;
  static final String ALBUMS_SELECTION_HAVING_ART_NULL = ;
  static final String ALBUM_THUMB_FOLDER = "albumthumbs";
  static final String ALBUM_THUMB_PATH = ;
  static final int INDEX_ALBUM = 1;
  static final int INDEX_ALBUM_ART = 2;
  static final int INDEX_ALBUM_ID = 0;
  static final int INDEX_ALBUM_KEY = 3;
  static final int INDEX_ARTIST = 4;
  static final int INDEX_NUMBER_OF_SONGS = 5;
  static final int MSG_REQUEST_THUMB = 1;
  static final String externalStoragePath;
  private static final Uri sArtworkUri;
  private static final BitmapFactory.Options sBitmapOptionsCache = new BitmapFactory.Options();
  private final HashMap<String, Integer> albumThumbs2Ids;
  private ThumbFileObserver albumThumbsObserver;
  private int nativePeer;
  private Handler thumbGeneratorHandler;

  static
  {
    String[] arrayOfString = new String[6];
    arrayOfString[0] = "_id";
    arrayOfString[1] = "album";
    arrayOfString[2] = "album_art";
    arrayOfString[3] = "album_key";
    arrayOfString[4] = "artist";
    arrayOfString[5] = "numsongs";
    ALBUMS_PROJECTION = arrayOfString;
    ALBUMS_SELECTION_HAVING_ART_NOT_NULL = "album_art" + " NOT NULL";
    ALBUMS_SELECTION_HAVING_ART_NULL = "album_art" + " IS NULL";
    externalStoragePath = Environment.getExternalStorageDirectory().getPath();
    StringBuilder localStringBuilder = new StringBuilder();
    String str = externalStoragePath;
    ALBUM_THUMB_PATH = str + "/" + "albumthumbs";
    sArtworkUri = Uri.parse("content://media/external/audio/albumart");
  }

  public MediaLibAdapterAndroid(int paramInt, Context paramContext)
  {
    super(paramContext);
    HashMap localHashMap = new HashMap();
    this.albumThumbs2Ids = localHashMap;
    this.nativePeer = paramInt;
  }

  private void checkThumb(Album paramAlbum)
  {
    String str = Album.getAlbumImagePathName(paramAlbum.imageUrl);
    if (str != null)
    {
      HashMap localHashMap = this.albumThumbs2Ids;
      Integer localInteger = Integer.valueOf(paramAlbum.id);
      Object localObject = localHashMap.put(str, localInteger);
    }
    if ((paramAlbum.imageUrl != null) && (!paramAlbum.imageFileExists))
    {
      int i = paramAlbum.id;
      postRequestGenerateThumb(i);
    }
  }

  private static ComponentName getComponentNameOnSamsung()
  {
    String str1;
    if (Build.VERSION.SDK_INT < 8)
      str1 = "com.sec.android.app.music" + ".list.activity.MpListActivity";
    String str2;
    for (ComponentName localComponentName = new ComponentName("com.sec.android.music", str1); ; localComponentName = new ComponentName("com.android.music", str2))
    {
      return localComponentName;
      str2 = "com.android.music" + ".list.activity.MpListActivity";
    }
  }

  // ERROR //
  private void requestGenerateThumbnail_Blocking(int paramInt)
  {
    // Byte code:
    //   0: getstatic 125	com/softspb/shell/adapters/MediaLibAdapterAndroid:sArtworkUri	Landroid/net/Uri;
    //   3: astore_2
    //   4: iload_1
    //   5: i2l
    //   6: lstore_3
    //   7: aload_2
    //   8: lload_3
    //   9: invokestatic 201	android/content/ContentUris:withAppendedId	(Landroid/net/Uri;J)Landroid/net/Uri;
    //   12: astore 5
    //   14: aload 5
    //   16: ifnull +68 -> 84
    //   19: aconst_null
    //   20: astore 6
    //   22: aload_0
    //   23: getfield 205	com/softspb/shell/adapters/MediaLibAdapterAndroid:logger	Lcom/softspb/util/log/Logger;
    //   26: astore 7
    //   28: new 81	java/lang/StringBuilder
    //   31: dup
    //   32: invokespecial 82	java/lang/StringBuilder:<init>	()V
    //   35: ldc 207
    //   37: invokevirtual 86	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   40: aload 5
    //   42: invokevirtual 210	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   45: invokevirtual 92	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   48: astore 8
    //   50: aload 7
    //   52: aload 8
    //   54: invokevirtual 216	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   57: aload_0
    //   58: getfield 220	com/softspb/shell/adapters/MediaLibAdapterAndroid:contentResolver	Landroid/content/ContentResolver;
    //   61: aload 5
    //   63: ldc 222
    //   65: invokevirtual 228	android/content/ContentResolver:openFileDescriptor	(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;
    //   68: astore 9
    //   70: aload 9
    //   72: astore 6
    //   74: aload 6
    //   76: ifnull +8 -> 84
    //   79: aload 6
    //   81: invokevirtual 233	android/os/ParcelFileDescriptor:close	()V
    //   84: return
    //   85: astore 10
    //   87: aload_0
    //   88: getfield 205	com/softspb/shell/adapters/MediaLibAdapterAndroid:logger	Lcom/softspb/util/log/Logger;
    //   91: astore 11
    //   93: new 81	java/lang/StringBuilder
    //   96: dup
    //   97: invokespecial 82	java/lang/StringBuilder:<init>	()V
    //   100: ldc 235
    //   102: invokevirtual 86	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   105: aload 10
    //   107: invokevirtual 210	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   110: invokevirtual 92	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   113: astore 12
    //   115: aload 11
    //   117: aload 12
    //   119: aload 10
    //   121: invokevirtual 239	com/softspb/util/log/Logger:e	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   124: aload 6
    //   126: ifnull -42 -> 84
    //   129: aload 6
    //   131: invokevirtual 233	android/os/ParcelFileDescriptor:close	()V
    //   134: goto -50 -> 84
    //   137: astore 13
    //   139: goto -55 -> 84
    //   142: astore 14
    //   144: aload 6
    //   146: ifnull +8 -> 154
    //   149: aload 6
    //   151: invokevirtual 233	android/os/ParcelFileDescriptor:close	()V
    //   154: aload 14
    //   156: athrow
    //   157: astore 15
    //   159: goto -75 -> 84
    //   162: astore 16
    //   164: goto -10 -> 154
    //
    // Exception table:
    //   from	to	target	type
    //   22	70	85	java/io/FileNotFoundException
    //   129	134	137	java/io/IOException
    //   22	70	142	finally
    //   87	124	142	finally
    //   79	84	157	java/io/IOException
    //   149	154	162	java/io/IOException
  }

  protected void addContentItem(Album paramAlbum)
  {
    checkThumb(paramAlbum);
    super.addContentItem(paramAlbum);
  }

  protected void addNativeContentItem(Album paramAlbum)
  {
    if (this.nativePeer == 0)
      throw new IllegalStateException("MediaLibAdapter is dead");
    int i = this.nativePeer;
    int j = paramAlbum.id;
    String str1 = paramAlbum.title;
    String str2 = paramAlbum.imageUrl;
    addAlbum(i, j, str1, str2);
  }

  protected Album createContentItem(int paramInt, Cursor paramCursor)
  {
    return new Album(paramCursor);
  }

  protected void deleteContentItem(int paramInt)
  {
    Album localAlbum = (Album)this.contentItems.get(paramInt);
    if (localAlbum != null)
    {
      String str = Album.getAlbumImagePathName(localAlbum.imageUrl);
      if (str != null)
        Object localObject = this.albumThumbs2Ids.remove(str);
    }
    super.deleteContentItem(paramInt);
  }

  protected int getContentItemId(Cursor paramCursor)
  {
    return paramCursor.getInt(0);
  }

  void logRow(String paramString, Cursor paramCursor)
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    StringBuilder localStringBuilder2 = localStringBuilder1.append(paramString).append("[");
    int i = 0;
    while (true)
    {
      int j = paramCursor.getColumnCount();
      if (i >= j)
        break;
      String str1 = paramCursor.getString(i);
      if (str1 != null)
      {
        StringBuilder localStringBuilder3 = localStringBuilder1.append(" ");
        String str2 = paramCursor.getColumnName(i);
        StringBuilder localStringBuilder4 = localStringBuilder3.append(str2).append("=").append(str1);
      }
      i += 1;
    }
    StringBuilder localStringBuilder5 = localStringBuilder1.append("]");
    Logger localLogger = this.logger;
    String str3 = localStringBuilder1.toString();
    localLogger.d(str3);
  }

  void onAlbumThumbChanged(String paramString)
  {
    Logger localLogger = this.logger;
    String str = "onAlbumThumbChanged: path=" + paramString;
    localLogger.d(str);
    if (this.albumThumbs2Ids.containsKey(paramString))
    {
      int i = ((Integer)this.albumThumbs2Ids.get(paramString)).intValue();
      Album localAlbum = (Album)this.contentItems.get(i);
      if (localAlbum != null)
        updateNativeContentItem(localAlbum);
    }
  }

  public void onReceive(Intent paramIntent)
  {
    String str1 = paramIntent.getAction();
    Uri localUri = paramIntent.getData();
    if (localUri != null)
    {
      String str2 = localUri.getScheme();
      if ("file".equals(str2))
      {
        String str3 = externalStoragePath;
        String str4 = localUri.getPath();
        if (str3.equals(str4))
        {
          if (!"android.intent.action.MEDIA_MOUNTED".equals(str1))
            break label70;
          this.albumThumbsObserver.startWatching();
        }
      }
    }
    while (true)
    {
      return;
      label70: if ("android.intent.action.MEDIA_UNMOUNTED".equals(str1))
      {
        this.albumThumbsObserver.stopWatching();
        continue;
      }
    }
  }

  public void onStart()
  {
    super.onStart();
    Uri[] arrayOfUri = new Uri[1];
    Uri localUri = MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI;
    arrayOfUri[0] = localUri;
    setContentUris(arrayOfUri);
    ThumbFileObserver localThumbFileObserver = new ThumbFileObserver();
    this.albumThumbsObserver = localThumbFileObserver;
    this.albumThumbsObserver.startWatching();
    SDCardReceiver.registerListener(this);
    Looper localLooper = this.observerHandler.getLooper();
    ThumbGeneratorHandler localThumbGeneratorHandler = new ThumbGeneratorHandler(localLooper);
    this.thumbGeneratorHandler = localThumbGeneratorHandler;
  }

  public void onStop()
  {
    super.onStop();
    this.thumbGeneratorHandler.removeCallbacksAndMessages(null);
    this.albumThumbsObserver.stopWatching();
    SDCardReceiver.unregisterListener(this);
    this.nativePeer = 0;
  }

  public boolean playAlbum(int paramInt)
  {
    int i = 1;
    Intent localIntent1 = new Intent("android.intent.action.PICK");
    Uri localUri1 = Uri.EMPTY;
    Intent localIntent2 = localIntent1.setDataAndType(localUri1, "vnd.android.cursor.dir/track");
    String str1 = Integer.toString(paramInt);
    Intent localIntent3 = localIntent1.putExtra("album", str1);
    try
    {
      this.context.startActivity(localIntent1);
      return i;
    }
    catch (Exception localException1)
    {
      while (true)
      {
        Logger localLogger1 = this.logger;
        String str2 = "Failed to start playing album: " + localException1;
        localLogger1.w(str2, localException1);
        Uri localUri2 = MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI;
        long l = paramInt;
        Uri localUri3 = ContentUris.withAppendedId(localUri2, l);
        localIntent1 = new Intent("android.intent.action.VIEW");
        Intent localIntent4 = localIntent1.setDataAndType(localUri3, "vnd.android.cursor.item/album");
        ComponentName localComponentName = getComponentNameOnSamsung();
        Intent localIntent5 = localIntent1.setComponent(localComponentName);
        try
        {
          this.context.startActivity(localIntent1);
        }
        catch (Exception localException2)
        {
          Logger localLogger2 = this.logger;
          String str3 = "Failed to start playing album: " + localException2;
          localLogger2.w(str3, localException2);
          localIntent1 = new Intent("android.intent.action.VIEW");
          Intent localIntent6 = localIntent1.setDataAndType(localUri3, "vnd.android.cursor.item/album");
          try
          {
            this.context.startActivity(localIntent1);
          }
          catch (Exception localException3)
          {
            Logger localLogger3 = this.logger;
            String str4 = "Failed to start playing album: " + localException3;
            localLogger3.w(str4, localException3);
            i = 0;
          }
        }
      }
    }
  }

  void postRequestGenerateThumb(int paramInt)
  {
    Integer localInteger = Integer.valueOf(paramInt);
    if (!this.thumbGeneratorHandler.hasMessages(1, localInteger))
    {
      Handler localHandler = this.thumbGeneratorHandler;
      Message localMessage = Message.obtain(this.thumbGeneratorHandler, 1, localInteger);
      boolean bool = localHandler.sendMessage(localMessage);
    }
  }

  protected Cursor query()
  {
    int i = 0;
    this.logger.d("query");
    Object localObject1 = null;
    Object localObject2 = null;
    Object localObject3;
    try
    {
      ContentResolver localContentResolver1 = this.contentResolver;
      Uri localUri1 = MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI;
      String[] arrayOfString1 = ALBUMS_PROJECTION;
      String str1 = ALBUMS_SELECTION_HAVING_ART_NOT_NULL;
      localCursor = localContentResolver1.query(localUri1, arrayOfString1, str1, null, "album");
      localObject1 = localCursor;
    }
    catch (Exception localException1)
    {
      try
      {
        while (true)
        {
          ContentResolver localContentResolver2 = this.contentResolver;
          Uri localUri2 = MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI;
          String[] arrayOfString2 = ALBUMS_PROJECTION;
          String str2 = ALBUMS_SELECTION_HAVING_ART_NULL;
          Cursor localCursor = localContentResolver2.query(localUri2, arrayOfString2, str2, null, "album");
          localObject2 = localCursor;
          if (localObject1 != null)
            break;
          localObject3 = localObject2;
          if (localObject3 != null)
            break label324;
          this.logger.d("query: Reading columns from cursor...");
          int j = 0;
          while (j < i)
          {
            Logger localLogger1 = this.logger;
            StringBuilder localStringBuilder = new StringBuilder().append("query: column #").append(j).append(": ");
            String str3 = ((Cursor)localObject3).getColumnName(j);
            String str4 = str3;
            localLogger1.d(str4);
            j += 1;
          }
          localException1 = localException1;
          Logger localLogger2 = this.logger;
          String str5 = "Failed to query albums with art: " + localException1;
          localLogger2.e(str5, localException1);
        }
      }
      catch (Exception localException2)
      {
        while (true)
        {
          Logger localLogger3 = this.logger;
          String str6 = "Failed to query albums with no art: " + localException2;
          localLogger3.e(str6, localException2);
          continue;
          if (localObject2 == null)
          {
            localObject3 = localObject1;
            continue;
          }
          Cursor[] arrayOfCursor = new Cursor[2];
          arrayOfCursor[0] = localObject1;
          arrayOfCursor[1] = localObject2;
          localObject3 = new MergeCursor(arrayOfCursor);
          continue;
          label324: i = ((Cursor)localObject3).getColumnCount();
        }
      }
    }
    return (Cursor)localObject3;
  }

  public void reload(boolean paramBoolean)
  {
    super.reload(paramBoolean);
  }

  protected void removeNativeContentItem(Album paramAlbum)
  {
    if (this.nativePeer == 0)
      throw new IllegalStateException("MediaLibAdapter is dead");
    int i = this.nativePeer;
    int j = paramAlbum.id;
    removeAlbum(i, j);
  }

  protected void updateContentItem(Album paramAlbum)
  {
    checkThumb(paramAlbum);
    super.updateContentItem(paramAlbum);
  }

  protected void updateNativeContentItem(Album paramAlbum)
  {
    if (this.nativePeer == 0)
      throw new IllegalStateException("MediaLibAdapter is dead");
    int i = this.nativePeer;
    int j = paramAlbum.id;
    String str1 = paramAlbum.title;
    if (paramAlbum.imageFileExists);
    for (String str2 = paramAlbum.imageUrl; ; str2 = null)
    {
      updateAlbum(i, j, str1, str2);
      return;
    }
  }

  class ThumbGeneratorHandler extends Handler
  {
    public ThumbGeneratorHandler(Looper arg2)
    {
      super();
    }

    public void handleMessage(Message paramMessage)
    {
      if (paramMessage.what == 1)
      {
        int i = ((Integer)paramMessage.obj).intValue();
        Logger localLogger = MediaLibAdapterAndroid.this.logger;
        String str = "ThumbGeneratorHandler: request generate thumb albumId=" + i;
        localLogger.d(str);
        MediaLibAdapterAndroid.this.requestGenerateThumbnail_Blocking(i);
      }
    }
  }

  class ThumbFileObserver extends FileObserver
  {
    ThumbFileObserver()
    {
      super(520);
    }

    public void onEvent(int paramInt, String paramString)
    {
      if ((paramInt & 0x208) != 0)
      {
        StringBuilder localStringBuilder = new StringBuilder();
        String str1 = MediaLibAdapterAndroid.ALBUM_THUMB_PATH;
        String str2 = str1 + "/" + paramString;
        DelayedHandler localDelayedHandler = MediaLibAdapterAndroid.this.observerHandler;
        MediaLibAdapterAndroid.ThumbFileObserver.1 local1 = new MediaLibAdapterAndroid.ThumbFileObserver.1(this, str2);
        boolean bool = localDelayedHandler.post(local1);
      }
    }
  }

  class Album extends AbstractContentAdapter.ContentItem
  {
    String albumKey;
    String artist;
    boolean imageFileExists;
    String imageUrl;
    int numberOfSongs;
    String title;

    Album(Cursor arg2)
    {
      super(localCursor);
      String str1 = localCursor.getString(1);
      this.title = str1;
      String str2 = localCursor.getString(3);
      this.albumKey = str2;
      String str3 = localCursor.getString(4);
      this.artist = str3;
      int i = localCursor.getInt(5);
      this.numberOfSongs = i;
      String str4 = localCursor.getString(2);
      this.imageUrl = str4;
      if (this.imageUrl != null)
      {
        String str5 = getAlbumImagePathName(this.imageUrl);
        if (str5 != null)
        {
          boolean bool = new File(str5).exists();
          this.imageFileExists = bool;
        }
      }
    }

    static String getAlbumImagePathName(String paramString)
    {
      if ((paramString != null) && (paramString.startsWith("file://")))
        paramString = paramString.substring(7);
      return paramString;
    }

    protected void formatFields(StringBuilder paramStringBuilder)
    {
      StringBuilder localStringBuilder1 = paramStringBuilder.append(" title=");
      String str1 = this.title;
      StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
      StringBuilder localStringBuilder3 = paramStringBuilder.append(" artist=");
      String str2 = this.artist;
      StringBuilder localStringBuilder4 = localStringBuilder3.append(str2);
      StringBuilder localStringBuilder5 = paramStringBuilder.append(" imageUrl=");
      String str3 = this.imageUrl;
      StringBuilder localStringBuilder6 = localStringBuilder5.append(str3);
      StringBuilder localStringBuilder7 = paramStringBuilder.append(" albumKey=");
      String str4 = this.albumKey;
      StringBuilder localStringBuilder8 = localStringBuilder7.append(str4);
      StringBuilder localStringBuilder9 = paramStringBuilder.append(" numberOfSongs=");
      int i = this.numberOfSongs;
      StringBuilder localStringBuilder10 = localStringBuilder9.append(i);
      StringBuilder localStringBuilder11 = paramStringBuilder.append(" imageFileExists=");
      boolean bool = this.imageFileExists;
      StringBuilder localStringBuilder12 = localStringBuilder11.append(bool);
    }

    public boolean update(Cursor paramCursor)
    {
      int i = 0;
      String str1 = paramCursor.getString(1);
      String str2 = paramCursor.getString(3);
      String str3 = paramCursor.getString(4);
      int j = paramCursor.getInt(5);
      String str4 = paramCursor.getString(2);
      int k = 0;
      if (!TextUtils.equals(this.title, str1))
      {
        i = 1;
        this.title = str1;
      }
      if (!TextUtils.equals(this.albumKey, str2))
      {
        i = 1;
        this.albumKey = str2;
      }
      if (!TextUtils.equals(this.artist, str3))
      {
        i = 1;
        this.artist = str3;
      }
      if (this.numberOfSongs != j)
      {
        i = 1;
        this.numberOfSongs = j;
      }
      if (!TextUtils.equals(this.imageUrl, str4))
      {
        i = 1;
        this.imageUrl = str4;
      }
      boolean bool1;
      if (str4 != null)
      {
        String str5 = getAlbumImagePathName(str4);
        if (str5 != null)
          bool1 = new File(str5).exists();
      }
      boolean bool2 = this.imageFileExists;
      if (bool1 != bool2)
      {
        i = 1;
        this.imageFileExists = bool1;
      }
      return i;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.MediaLibAdapterAndroid
 * JD-Core Version:    0.6.0
 */