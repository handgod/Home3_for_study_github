package com.softspb.shell.adapters;

class ContactsAdapterAndroid$6
  implements Runnable
{
  public void run()
  {
    int i = this.this$0.contactsAdapterToken;
    int j = this.val$contactId;
    boolean bool = this.val$isFavorite;
    ContactsAdapterAndroid.access$2000(i, j, bool);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.ContactsAdapterAndroid.6
 * JD-Core Version:    0.6.0
 */