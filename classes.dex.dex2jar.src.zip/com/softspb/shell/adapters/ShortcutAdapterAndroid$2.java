package com.softspb.shell.adapters;

import android.content.Context;
import android.content.Intent;
import com.softspb.shell.data.ShortcutInfo;
import com.softspb.util.broadcastreceiver.DecoratedBroadcastReceiver.IActionListener;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.locks.Lock;

class ShortcutAdapterAndroid$2
  implements DecoratedBroadcastReceiver.IActionListener
{
  public void onAction(Context paramContext, Intent paramIntent)
  {
    try
    {
      ShortcutAdapterAndroid.access$000(this.this$0).lock();
      Iterator localIterator = ShortcutAdapterAndroid.access$100(this.this$0).iterator();
      while (localIterator.hasNext())
      {
        ShortcutInfo localShortcutInfo = (ShortcutInfo)localIterator.next();
        if (!ShortcutAdapterAndroid.access$200(this.this$0, localShortcutInfo))
          continue;
        localIterator.remove();
      }
    }
    finally
    {
      ShortcutAdapterAndroid.access$000(this.this$0).unlock();
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.ShortcutAdapterAndroid.2
 * JD-Core Version:    0.6.0
 */