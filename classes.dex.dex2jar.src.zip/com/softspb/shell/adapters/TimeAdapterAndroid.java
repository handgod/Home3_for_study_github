package com.softspb.shell.adapters;

import android.content.ContentResolver;
import android.content.Context;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;
import android.provider.Settings.System;
import android.text.format.DateFormat;
import android.text.format.DateUtils;
import com.softspb.shell.opengl.NativeCallbacks;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.util.Arrays;
import java.util.Calendar;

public class TimeAdapterAndroid extends TimeAdapter
{
  private static final int FORMAT_TIME_COMMON = 2569;
  private static final Logger logger = Loggers.getLogger(TimeAdapterAndroid.class.getName());
  private ContentResolver contentResolver;
  private Context context;
  private DateTimeFormatChangeObserver dateTimeFormatChangeObserver;
  private int timeAdapterToken;

  public TimeAdapterAndroid(AdaptersHolder paramAdaptersHolder)
  {
    super(paramAdaptersHolder);
    logger.d("constructor");
  }

  private static native void onDateTimeFormatChanged(int paramInt);

  private void startListeningDateTimeFormatChanges()
  {
    logger.d("startListeningDateTimeFormatChanges");
    Uri localUri1 = Settings.System.getUriFor("date_format");
    Uri localUri2 = Settings.System.getUriFor("time_12_24");
    Handler localHandler = new Handler();
    DateTimeFormatChangeObserver localDateTimeFormatChangeObserver1 = new DateTimeFormatChangeObserver(localHandler);
    this.dateTimeFormatChangeObserver = localDateTimeFormatChangeObserver1;
    ContentResolver localContentResolver1 = this.contentResolver;
    DateTimeFormatChangeObserver localDateTimeFormatChangeObserver2 = this.dateTimeFormatChangeObserver;
    localContentResolver1.registerContentObserver(localUri1, 1, localDateTimeFormatChangeObserver2);
    ContentResolver localContentResolver2 = this.contentResolver;
    DateTimeFormatChangeObserver localDateTimeFormatChangeObserver3 = this.dateTimeFormatChangeObserver;
    localContentResolver2.registerContentObserver(localUri2, 1, localDateTimeFormatChangeObserver3);
  }

  private void stopListeningDateTimeFormatChanges()
  {
    logger.d("stopListeningDateTimeFormatChanges");
    if (this.dateTimeFormatChangeObserver != null)
    {
      ContentResolver localContentResolver = this.contentResolver;
      DateTimeFormatChangeObserver localDateTimeFormatChangeObserver = this.dateTimeFormatChangeObserver;
      localContentResolver.unregisterContentObserver(localDateTimeFormatChangeObserver);
    }
  }

  private void throwException(int paramInt)
  {
    String str1 = "format " + paramInt + " is not yet supported!";
    IllegalArgumentException localIllegalArgumentException = new IllegalArgumentException(str1);
    localIllegalArgumentException.printStackTrace();
    Logger localLogger = logger;
    String str2 = "format " + paramInt + " is not yet supported!";
    localLogger.d(str2, localIllegalArgumentException);
  }

  public String format(long paramLong, int paramInt)
  {
    Logger localLogger1 = logger;
    StringBuilder localStringBuilder1 = new StringBuilder().append(">>>format: dateLong=");
    long l1 = paramLong;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(l1).append(", nativeFlags=");
    int i = paramInt;
    String str1 = i;
    localLogger1.d(str1);
    String str2 = "XXXX";
    int j = paramInt & 0xFFFFFFF0;
    int k = paramInt & 0xFFFFF00F;
    switch (j)
    {
    default:
      TimeAdapterAndroid localTimeAdapterAndroid1 = this;
      int m = paramInt;
      localTimeAdapterAndroid1.throwException(m);
    case 64:
    case 80:
    case 144:
    case 560:
    case 592:
    case 2192:
    case 2128:
    case 1072:
    case 2096:
    case 2704:
    case 128:
    case 2048:
    case 512:
    case 256:
    case 336:
    case 0:
    }
    while (true)
    {
      Logger localLogger2 = logger;
      String str3 = "<<<format: result=" + str2;
      localLogger2.d(str3);
      return str2;
      Calendar localCalendar = Calendar.getInstance();
      long l2 = paramLong;
      localCalendar.setTimeInMillis(l2);
      int n = 2;
      str2 = DateUtils.getMonthString(localCalendar.get(n), 20);
      continue;
      int i1 = 65544;
      int i2 = 5;
      if (k == i2)
        i1 |= 2569;
      Context localContext1 = this.context;
      long l3 = paramLong;
      str2 = DateUtils.formatDateTime(localContext1, l3, i1);
      continue;
      i1 = 8;
      int i3 = 5;
      if (k == i3)
        i1 |= 2569;
      Context localContext2 = this.context;
      long l4 = paramLong;
      str2 = DateUtils.formatDateTime(localContext2, l4, i1);
      continue;
      i1 = 131098;
      int i4 = 5;
      if (k == i4)
        i1 |= 2569;
      Context localContext3 = this.context;
      long l5 = paramLong;
      str2 = DateUtils.formatDateTime(localContext3, l5, i1);
      continue;
      i1 = 65562;
      int i5 = 5;
      if (k == i5)
        i1 |= 2569;
      Context localContext4 = this.context;
      long l6 = paramLong;
      str2 = DateUtils.formatDateTime(localContext4, l6, i1);
      continue;
      i1 = 4;
      int i6 = 5;
      if (k == i6)
        i1 |= 2569;
      Context localContext5 = this.context;
      long l7 = paramLong;
      str2 = DateUtils.formatDateTime(localContext5, l7, i1);
      continue;
      i1 = 65540;
      int i7 = 5;
      if (k == i7)
        i1 |= 2569;
      Context localContext6 = this.context;
      long l8 = paramLong;
      str2 = DateUtils.formatDateTime(localContext6, l8, i1);
      continue;
      i1 = 131076;
      int i8 = 5;
      if (k == i8)
        i1 |= 2569;
      Context localContext7 = this.context;
      long l9 = paramLong;
      str2 = DateUtils.formatDateTime(localContext7, l9, i1);
      continue;
      i1 = 22;
      int i9 = 5;
      if (k == i9)
        i1 |= 2569;
      Context localContext8 = this.context;
      long l10 = paramLong;
      str2 = DateUtils.formatDateTime(localContext8, l10, i1);
      continue;
      if (k != 0)
      {
        TimeAdapterAndroid localTimeAdapterAndroid2 = this;
        int i10 = paramInt;
        localTimeAdapterAndroid2.throwException(i10);
      }
      char[] arrayOfChar1 = new char[4];
      int i11 = 77;
      Arrays.fill(arrayOfChar1, i11);
      String str4 = new String(arrayOfChar1);
      long l11 = paramLong;
      str2 = DateFormat.format(str4, l11).toString();
      continue;
      if (k != 0)
      {
        TimeAdapterAndroid localTimeAdapterAndroid3 = this;
        int i12 = paramInt;
        localTimeAdapterAndroid3.throwException(i12);
      }
      char[] arrayOfChar2 = new char[4];
      int i13 = 121;
      Arrays.fill(arrayOfChar2, i13);
      String str5 = new java/lang/String;
      str5.<init>(arrayOfChar2);
      String str6 = str5;
      long l12 = paramLong;
      str2 = DateFormat.format(str6, l12).toString();
      continue;
      if (k != 0)
      {
        TimeAdapterAndroid localTimeAdapterAndroid4 = this;
        int i14 = paramInt;
        localTimeAdapterAndroid4.throwException(i14);
      }
      char[] arrayOfChar3 = new char[4];
      int i15 = 69;
      Arrays.fill(arrayOfChar3, i15);
      String str7 = new String(arrayOfChar3);
      long l13 = paramLong;
      str2 = DateFormat.format(str7, l13).toString();
      continue;
      if (k != 0)
      {
        TimeAdapterAndroid localTimeAdapterAndroid5 = this;
        int i16 = paramInt;
        localTimeAdapterAndroid5.throwException(i16);
      }
      char[] arrayOfChar4 = new char[2];
      int i17 = 69;
      Arrays.fill(arrayOfChar4, i17);
      String str8 = new java/lang/String;
      str8.<init>(arrayOfChar4);
      String str9 = str8;
      long l14 = paramLong;
      str2 = DateFormat.format(str9, l14).toString();
      continue;
      i1 = 524314;
      int i18 = 5;
      if (k == i18)
        i1 |= 2569;
      Context localContext9 = this.context;
      long l15 = paramLong;
      str2 = DateUtils.formatDateTime(localContext9, l15, i1);
      continue;
      int i19 = 5;
      if (k == i19)
      {
        Context localContext10 = this.context;
        long l16 = paramLong;
        str2 = DateUtils.formatDateTime(localContext10, l16, 2569);
        continue;
      }
      int i20 = 13;
      if (k == i20)
      {
        if (DateFormat.is24HourFormat(this.context));
        for (int i21 = 107; ; i21 = 104)
        {
          char[] arrayOfChar5 = new char[8];
          arrayOfChar5[0] = i21;
          arrayOfChar5[1] = i21;
          arrayOfChar5[2] = ':';
          arrayOfChar5[3] = 'm';
          arrayOfChar5[4] = 'm';
          arrayOfChar5[5] = ':';
          arrayOfChar5[6] = 's';
          arrayOfChar5[7] = 's';
          String str10 = new java/lang/String;
          str10.<init>(arrayOfChar5);
          String str11 = str10;
          long l17 = paramLong;
          str2 = DateFormat.format(str11, l17).toString();
          if (DateFormat.is24HourFormat(this.context))
            break;
          StringBuilder localStringBuilder3 = new StringBuilder().append(str2).append(" ");
          String str12 = getAMPMString(paramLong);
          str2 = str12;
          break;
        }
      }
      TimeAdapterAndroid localTimeAdapterAndroid6 = this;
      int i22 = paramInt;
      localTimeAdapterAndroid6.throwException(i22);
    }
  }

  public String getAMPMString(long paramLong)
  {
    Logger localLogger1 = logger;
    String str1 = ">>>getAMPMString: time=" + paramLong;
    localLogger1.d(str1);
    if (DateFormat.is24HourFormat(this.context));
    Calendar localCalendar;
    for (String str2 = ""; ; str2 = DateUtils.getAMPMString(localCalendar.get(9)))
    {
      Logger localLogger2 = logger;
      String str3 = "<<<getAMPMString: result=" + str2;
      localLogger2.d(str3);
      return str2;
      localCalendar = Calendar.getInstance();
      localCalendar.setTimeInMillis(paramLong);
    }
  }

  public int getFirstDayOfWeek()
  {
    logger.d(">>>getFirstDayOfWeek");
    if (Calendar.getInstance().getFirstDayOfWeek() == 2);
    for (int i = 2; ; i = 1)
    {
      Logger localLogger = logger;
      String str = "<<<getFirstDayOfWeek: result=" + i;
      localLogger.d(str);
      return i;
    }
  }

  protected void onCreate(Context paramContext, NativeCallbacks paramNativeCallbacks)
  {
    Logger localLogger = logger;
    String str = ">>>onCreate: context=" + paramContext;
    localLogger.d(str);
    this.context = paramContext;
    ContentResolver localContentResolver = paramContext.getContentResolver();
    this.contentResolver = localContentResolver;
    startListeningDateTimeFormatChanges();
    super.onCreate(paramContext, paramNativeCallbacks);
    logger.d("<<<onCreate");
  }

  protected void onDestroy(Context paramContext)
  {
    Logger localLogger = logger;
    String str = ">>>onDestroy: context=" + paramContext;
    localLogger.d(str);
    stopListeningDateTimeFormatChanges();
    logger.d("<<<onDestroy");
  }

  protected void onStart(int paramInt)
  {
    Logger localLogger = logger;
    StringBuilder localStringBuilder = new StringBuilder().append("onStart: adapterToken=");
    String str1 = Integer.toHexString(paramInt);
    String str2 = str1;
    localLogger.d(str2);
    this.timeAdapterToken = paramInt;
  }

  class DateTimeFormatChangeObserver extends ContentObserver
  {
    public DateTimeFormatChangeObserver(Handler arg2)
    {
      super();
    }

    public void onChange(boolean paramBoolean)
    {
      TimeAdapterAndroid.logger.d("DateTimeFormatChangeObserver.onChange");
      TimeAdapterAndroid.access$200(TimeAdapterAndroid.this.timeAdapterToken);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.TimeAdapterAndroid
 * JD-Core Version:    0.6.0
 */