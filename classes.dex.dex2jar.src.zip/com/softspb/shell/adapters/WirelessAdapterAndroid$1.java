package com.softspb.shell.adapters;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import com.softspb.util.log.Logger;

class WirelessAdapterAndroid$1 extends BroadcastReceiver
{
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    int i = 2;
    int j = 1;
    WirelessAdapterAndroid.access$000().d(">>>onReceive");
    Bundle localBundle = paramIntent.getExtras();
    if (paramIntent.getAction().equals("android.net.wifi.WIFI_STATE_CHANGED"))
    {
      int k = localBundle.getInt("wifi_state");
      WirelessAdapterAndroid localWirelessAdapterAndroid1 = this.this$0;
      int m = WirelessAdapterAndroid.access$100(this.this$0, k);
      localWirelessAdapterAndroid1.notifyChange(1, m);
    }
    if (paramIntent.getAction().equals("android.bluetooth.adapter.action.STATE_CHANGED"))
    {
      int n = localBundle.getInt("android.bluetooth.adapter.extra.STATE");
      WirelessAdapterAndroid localWirelessAdapterAndroid2 = this.this$0;
      int i1 = WirelessAdapterAndroid.access$200(this.this$0, n);
      localWirelessAdapterAndroid2.notifyChange(2, i1);
    }
    if (paramIntent.getAction().equals("android.intent.action.AIRPLANE_MODE"))
    {
      int i2 = this.this$0.getWirelessState(1);
      int i3 = this.this$0.getWirelessState(2);
      this.this$0.notifyChange(1, i2);
      this.this$0.notifyChange(2, i3);
      if (localBundle != null)
      {
        boolean bool = localBundle.getBoolean("state");
        WirelessAdapterAndroid localWirelessAdapterAndroid3 = this.this$0;
        i = 4;
        if (!bool)
          break label274;
        int i5 = 1;
        localWirelessAdapterAndroid3.notifyChange(i, i5);
      }
    }
    WirelessAdapterAndroid localWirelessAdapterAndroid4;
    int i4;
    if (paramIntent.getAction().equals("android.net.conn.CONNECTIVITY_CHANGE"))
    {
      NetworkInfo localNetworkInfo = WirelessAdapterAndroid.access$300(this.this$0).getActiveNetworkInfo();
      if ((localNetworkInfo != null) && (localNetworkInfo.getType() == 1))
      {
        localWirelessAdapterAndroid4 = this.this$0;
        i4 = 5;
        if (!localNetworkInfo.isConnected())
          break label280;
      }
    }
    while (true)
    {
      localWirelessAdapterAndroid4.notifyChange(i4, j);
      WirelessAdapterAndroid.access$000().d("<<<onReceive");
      return;
      label274: int i6 = 0;
      break;
      label280: j = 0;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.WirelessAdapterAndroid.1
 * JD-Core Version:    0.6.0
 */