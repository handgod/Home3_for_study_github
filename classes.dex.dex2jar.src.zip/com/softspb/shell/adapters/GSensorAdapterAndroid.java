package com.softspb.shell.adapters;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build.VERSION;
import android.view.Display;
import android.view.WindowManager;
import com.softspb.shell.opengl.NativeCallbacks;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;

public class GSensorAdapterAndroid extends GSensorAdapter
  implements SensorEventListener
{
  private static final Object lock = new Object();
  private static Logger logger = Loggers.getLogger(GSensorAdapterAndroid.class.getName());
  private float aX;
  private float aY;
  private float aZ;
  private Display display;
  private boolean enabled = 0;
  boolean isAccurate = 1;
  private boolean listening = 0;
  private Sensor sensor;
  private SensorManager sm;

  public GSensorAdapterAndroid(AdaptersHolder paramAdaptersHolder)
  {
    super(paramAdaptersHolder);
  }

  public static native void sensorMove(float paramFloat1, float paramFloat2, float paramFloat3, int paramInt);

  public void EnableGSensor(boolean paramBoolean)
  {
    this.enabled = paramBoolean;
    if (paramBoolean)
      onStart();
    while (true)
    {
      return;
      onStop();
    }
  }

  public void askEvents()
  {
    if (Build.VERSION.SDK_INT >= 8)
    {
      float f1 = this.aX;
      float f2 = this.aY;
      float f3 = this.aZ;
      int i = this.display.getRotation();
      sensorMove(f1, f2, f3, i);
    }
    while (true)
    {
      return;
      float f4 = this.aX;
      float f5 = this.aY;
      float f6 = this.aZ;
      int j = this.display.getOrientation();
      sensorMove(f4, f5, f6, j);
    }
  }

  public boolean isPresent()
  {
    if (this.sensor != null);
    for (int i = 1; ; i = 0)
      return i;
  }

  public void onAccuracyChanged(Sensor paramSensor, int paramInt)
  {
    switch (paramInt)
    {
    default:
    case 1:
    case 2:
    case 3:
    case 0:
    }
    while (true)
    {
      return;
      this.isAccurate = 1;
      continue;
      this.isAccurate = 0;
    }
  }

  public void onCreate(Context paramContext, NativeCallbacks paramNativeCallbacks)
  {
    SensorManager localSensorManager = (SensorManager)paramContext.getSystemService("sensor");
    this.sm = localSensorManager;
    Sensor localSensor = this.sm.getDefaultSensor(1);
    this.sensor = localSensor;
    this.enabled = 1;
    Display localDisplay = ((Activity)paramContext).getWindowManager().getDefaultDisplay();
    this.display = localDisplay;
  }

  public void onSensorChanged(SensorEvent paramSensorEvent)
  {
    int i = paramSensorEvent.values[0];
    this.aX = i;
    int j = paramSensorEvent.values[1];
    this.aY = j;
    int k = paramSensorEvent.values[2];
    this.aZ = k;
    askEvents();
  }

  protected void onStart()
  {
    logger.d("GSensorAdapterAndroid::onStart()");
    if ((this.enabled) && (!this.listening) && (isPresent()))
    {
      SensorManager localSensorManager = this.sm;
      Sensor localSensor = this.sensor;
      boolean bool = localSensorManager.registerListener(this, localSensor, 1);
      this.listening = 1;
    }
  }

  protected void onStop()
  {
    logger.d("GSensorAdapterAndroid::onStop()");
    if ((this.listening) && (isPresent()))
    {
      this.sm.unregisterListener(this);
      this.listening = 0;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.GSensorAdapterAndroid
 * JD-Core Version:    0.6.0
 */