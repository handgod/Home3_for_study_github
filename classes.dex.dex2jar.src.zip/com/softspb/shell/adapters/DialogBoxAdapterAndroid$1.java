package com.softspb.shell.adapters;

class DialogBoxAdapterAndroid$1
  implements Runnable
{
  public void run()
  {
    this.val$inst.show();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.DialogBoxAdapterAndroid.1
 * JD-Core Version:    0.6.0
 */