package com.softspb.shell.adapters;

import android.content.Context;
import android.content.Intent;
import com.softspb.util.broadcastreceiver.DecoratedBroadcastReceiver.IActionListener;

class ShortcutAdapterAndroid$1
  implements DecoratedBroadcastReceiver.IActionListener
{
  public void onAction(Context paramContext, Intent paramIntent)
  {
    this.this$0.addShortcut(paramIntent, 0);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.ShortcutAdapterAndroid.1
 * JD-Core Version:    0.6.0
 */