package com.softspb.shell.adapters;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import com.spb.contacts.IPhoneNumberResolvingService;
import com.spb.contacts.IPhoneNumberResolvingService.Stub;
import com.spb.contacts.IPhoneNumberResolvingServiceCallback;
import java.util.concurrent.CountDownLatch;

class ContactsAdapterAndroid$4
  implements ServiceConnection
{
  public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
  {
    ContactsAdapterAndroid localContactsAdapterAndroid1 = this.this$0;
    String str1 = "onServiceConnected: PhoneNumberService name=" + paramComponentName;
    ContactsAdapterAndroid.access$000(localContactsAdapterAndroid1, str1);
    ContactsAdapterAndroid localContactsAdapterAndroid2 = this.this$0;
    StringBuilder localStringBuilder1 = new StringBuilder().append("onServiceConnected: PhoneNumberService Thread ");
    long l = Thread.currentThread().getId();
    StringBuilder localStringBuilder2 = localStringBuilder1.append(l).append(" ");
    String str2 = Thread.currentThread().getName();
    String str3 = str2;
    ContactsAdapterAndroid.access$000(localContactsAdapterAndroid2, str3);
    ContactsAdapterAndroid localContactsAdapterAndroid3 = this.this$0;
    IPhoneNumberResolvingService localIPhoneNumberResolvingService1 = IPhoneNumberResolvingService.Stub.asInterface(paramIBinder);
    localContactsAdapterAndroid3.phoneNumberService = localIPhoneNumberResolvingService1;
    try
    {
      IPhoneNumberResolvingService localIPhoneNumberResolvingService2 = this.this$0.phoneNumberService;
      IPhoneNumberResolvingServiceCallback localIPhoneNumberResolvingServiceCallback = this.this$0.phoneNumberCallback;
      localIPhoneNumberResolvingService2.registerCallback(localIPhoneNumberResolvingServiceCallback);
      label147: this.this$0.serviceConnectionCountDown.countDown();
      return;
    }
    catch (RemoteException localRemoteException)
    {
      break label147;
    }
  }

  public void onServiceDisconnected(ComponentName paramComponentName)
  {
    ContactsAdapterAndroid.access$000(this.this$0, "onServiceDisconnected: PhoneNumberService");
    this.this$0.phoneNumberService = null;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.ContactsAdapterAndroid.4
 * JD-Core Version:    0.6.0
 */