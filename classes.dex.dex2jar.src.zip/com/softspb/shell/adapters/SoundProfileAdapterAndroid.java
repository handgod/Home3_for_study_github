package com.softspb.shell.adapters;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import com.softspb.shell.opengl.NativeCallbacks;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;

public class SoundProfileAdapterAndroid extends SoundProfileAdapter
{
  private static final int INVALID_MODE = 255;
  private static final Logger logger = Loggers.getLogger(SoundProfileAdapterAndroid.class.getName());
  private Context context;
  private BroadcastReceiver modeChangedReceiver;
  private volatile boolean started = 0;

  public SoundProfileAdapterAndroid(AdaptersHolder paramAdaptersHolder)
  {
    super(paramAdaptersHolder);
    SoundProfileAdapterAndroid.1 local1 = new SoundProfileAdapterAndroid.1(this);
    this.modeChangedReceiver = local1;
    logger.d("constructor");
  }

  public static native void update();

  public int getRingMode()
  {
    logger.d(">>>getRingMode");
    int i = ((AudioManager)this.context.getSystemService("audio")).getRingerMode();
    int j;
    switch (i)
    {
    default:
      Logger localLogger1 = logger;
      String str1 = "androidMode=" + i + "  is not supported - check native to java constants mapping";
      localLogger1.w(str1);
      j = 0;
    case 2:
    case 0:
    case 1:
    }
    while (true)
    {
      Logger localLogger2 = logger;
      String str2 = "<<<getRingMode, nativeMode=" + j;
      localLogger2.d(str2);
      return j;
      j = 0;
      continue;
      j = 1;
      continue;
      j = 2;
    }
  }

  public int getRingVolume()
  {
    logger.d(">>>getRingVolume");
    AudioManager localAudioManager = (AudioManager)this.context.getSystemService("audio");
    int i = localAudioManager.getStreamVolume(2) * 5;
    int j = localAudioManager.getStreamMaxVolume(2);
    int k = i / j;
    if ((k == 0) && (localAudioManager.getStreamVolume(2) != 0))
    {
      logger.d("reported level increased to 1 since native level is more than zero");
      k = 1;
    }
    if (k == 5)
    {
      int m = localAudioManager.getStreamVolume(2);
      int n = localAudioManager.getStreamMaxVolume(2);
      if (m != n)
      {
        logger.d("reported level decreased to 4 since native level is less than maximum");
        k = 4;
      }
    }
    Logger localLogger = logger;
    String str = "<<<getRingVolume: level=" + k;
    localLogger.d(str);
    return k;
  }

  public void notifyChange()
  {
    Logger localLogger = logger;
    StringBuilder localStringBuilder = new StringBuilder().append(">>>notifyChange: started=");
    boolean bool = this.started;
    String str = bool;
    localLogger.d(str);
    if (this.started)
      update();
    logger.d("<<<notifyChange");
  }

  public void onCreate(Context paramContext, NativeCallbacks paramNativeCallbacks)
  {
    Logger localLogger = logger;
    String str = ">>>onCreate: context=" + paramContext;
    localLogger.d(str);
    this.context = paramContext;
    BroadcastReceiver localBroadcastReceiver = this.modeChangedReceiver;
    IntentFilter localIntentFilter = new IntentFilter("android.media.RINGER_MODE_CHANGED");
    Intent localIntent = paramContext.registerReceiver(localBroadcastReceiver, localIntentFilter);
    this.started = 1;
    logger.d("<<<onCreate");
  }

  public void onDestroy(Context paramContext)
  {
    Logger localLogger = logger;
    String str = ">>>onDestroy: context=" + paramContext;
    localLogger.d(str);
    BroadcastReceiver localBroadcastReceiver = this.modeChangedReceiver;
    paramContext.unregisterReceiver(localBroadcastReceiver);
    this.started = 0;
    logger.d("<<<onDestroy");
  }

  public void openSettings()
  {
    Intent localIntent = new Intent("android.settings.SOUND_SETTINGS");
    this.context.startActivity(localIntent);
  }

  public void setRingMode(int paramInt)
  {
    Logger localLogger1 = logger;
    String str1 = ">>>setRingMode: nativeMode=" + paramInt;
    localLogger1.d(str1);
    int i;
    switch (paramInt)
    {
    default:
      Logger localLogger2 = logger;
      String str2 = "nativeMode=" + paramInt + " is not supported - check native to java constants mapping";
      localLogger2.w(str2);
      i = -1;
    case 0:
    case 1:
    case 2:
    }
    while (true)
    {
      Logger localLogger3 = logger;
      String str3 = "nativeMode=" + paramInt + " resolved to androidMode=" + i;
      localLogger3.d(str3);
      if (i != -1)
        ((AudioManager)this.context.getSystemService("audio")).setRingerMode(i);
      logger.d("<<<setRingMode");
      return;
      i = 2;
      continue;
      i = 0;
      continue;
      i = 1;
    }
  }

  public void setRingVolume(int paramInt)
  {
    Logger localLogger = logger;
    String str = ">>>setRingVolume: volume=" + paramInt;
    localLogger.d(str);
    AudioManager localAudioManager = (AudioManager)this.context.getSystemService("audio");
    int i = localAudioManager.getStreamMaxVolume(2) * paramInt / 5;
    localAudioManager.setStreamVolume(2, i, 0);
    logger.d("<<<setRingVolume");
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.SoundProfileAdapterAndroid
 * JD-Core Version:    0.6.0
 */