package com.softspb.shell.adapters.dialog;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnDismissListener;
import android.os.Looper;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.Spinner;
import com.spb.shell3d.R.layout;
import java.nio.CharBuffer;
import java.util.Arrays;
import java.util.HashMap;

public class ShellDialog extends IShellDialog
  implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener, DialogInterface.OnClickListener
{
  public static final int BUTTON_CANCEL = 8;
  public static final int BUTTON_NO = 4;
  public static final int BUTTON_OK = 1;
  public static final int BUTTON_YES = 2;
  public static final int ICON_DEFAULT = 0;
  public static final int ICON_ERROR = 3;
  public static final int ICON_INFO = 1;
  public static final int ICON_WARNING = 2;
  private ViewGroup contentView;
  private AlertDialog.Builder dialogBuilder;
  private final HashMap<String, View> inputs;
  LayoutInflater layoutInflater;
  private int negativeButton;
  private int positiveButton;
  final Object setValueMonitor;
  String settingValueKey;

  public ShellDialog(Context paramContext, Looper paramLooper, int paramInt1, int paramInt2)
  {
    super(paramContext, paramLooper, paramInt1, paramInt2);
    HashMap localHashMap = new HashMap();
    this.inputs = localHashMap;
    Object localObject = new Object();
    this.setValueMonitor = localObject;
    StringBuilder localStringBuilder = new StringBuilder().append("Ctor: adapterAddress=0x");
    String str1 = Integer.toHexString(paramInt1);
    String str2 = str1 + " dialogToken=" + paramInt2;
    logd(str2);
    LayoutInflater localLayoutInflater = LayoutInflater.from(paramContext);
    this.layoutInflater = localLayoutInflater;
    AlertDialog.Builder localBuilder = new AlertDialog.Builder(paramContext);
    this.dialogBuilder = localBuilder;
  }

  private ViewGroup getContentView()
  {
    if (this.contentView == null)
    {
      LayoutInflater localLayoutInflater = this.layoutInflater;
      int i = R.layout.dialog_content_view;
      ViewGroup localViewGroup1 = (ViewGroup)localLayoutInflater.inflate(i, null);
      this.contentView = localViewGroup1;
      AlertDialog.Builder localBuilder1 = this.dialogBuilder;
      ViewGroup localViewGroup2 = this.contentView;
      AlertDialog.Builder localBuilder2 = localBuilder1.setView(localViewGroup2);
    }
    return this.contentView;
  }

  private native void onButtonClicked(int paramInt1, int paramInt2, int paramInt3);

  private native void onDismiss(int paramInt1, int paramInt2);

  private native void onValueChanged(int paramInt1, int paramInt2, String paramString);

  private static boolean stripEOLs(Editable paramEditable)
  {
    int i = 0;
    int j = paramEditable.length();
    char[] arrayOfChar = new char[j];
    paramEditable.getChars(0, j, arrayOfChar, 0);
    int k = 0;
    while (k < j)
    {
      if (arrayOfChar[k] == '\n')
      {
        i = 1;
        arrayOfChar[k] = ' ';
      }
      k += 1;
    }
    if (i != 0)
    {
      CharBuffer localCharBuffer = CharBuffer.wrap(arrayOfChar);
      Editable localEditable = paramEditable.replace(0, j, localCharBuffer);
    }
    return i;
  }

  public void addCheckBox(String paramString1, String paramString2)
  {
    String str = "addCheckBox >>> key=" + paramString1 + " title=" + paramString2;
    logd(str);
    ViewGroup localViewGroup = getContentView();
    LayoutInflater localLayoutInflater = this.layoutInflater;
    int i = R.layout.dialog_check_box;
    CheckBox localCheckBox = (CheckBox)localLayoutInflater.inflate(i, localViewGroup, 0);
    localCheckBox.setText(paramString2);
    CheckBoxListener localCheckBoxListener = new CheckBoxListener(paramString1);
    localCheckBox.setOnCheckedChangeListener(localCheckBoxListener);
    localViewGroup.addView(localCheckBox);
    Object localObject = this.inputs.put(paramString1, localCheckBox);
    logd("addCheckBox <<<");
  }

  public void addComboBox(String paramString, String[] paramArrayOfString, int paramInt)
  {
    StringBuilder localStringBuilder = new StringBuilder().append("addComboBox >>> key=").append(paramString).append(" choices=");
    String str1 = Arrays.toString(paramArrayOfString);
    String str2 = str1 + " initialChoice=" + paramInt;
    logd(str2);
    ViewGroup localViewGroup = getContentView();
    LayoutInflater localLayoutInflater = this.layoutInflater;
    int i = R.layout.dialog_spinner;
    Spinner localSpinner = (Spinner)localLayoutInflater.inflate(i, localViewGroup, 0);
    Context localContext = this.context;
    ArrayAdapter localArrayAdapter = new ArrayAdapter(localContext, 17367048, paramArrayOfString);
    localArrayAdapter.setDropDownViewResource(17367049);
    localSpinner.setAdapter(localArrayAdapter);
    localSpinner.setSelection(paramInt);
    localViewGroup.addView(localSpinner);
    SpinnerListener localSpinnerListener = new SpinnerListener(paramString);
    localSpinner.setOnItemSelectedListener(localSpinnerListener);
    Object localObject = this.inputs.put(paramString, localSpinner);
    logd("addComboBox <<<");
  }

  public void addTextInput(String paramString)
  {
    String str = "addTextInput >>> key=" + paramString;
    logd(str);
    ViewGroup localViewGroup = getContentView();
    LayoutInflater localLayoutInflater = this.layoutInflater;
    int i = R.layout.dialog_text_input;
    EditText localEditText = (EditText)localLayoutInflater.inflate(i, localViewGroup, 0);
    TextChangedListener localTextChangedListener = new TextChangedListener(paramString);
    localEditText.addTextChangedListener(localTextChangedListener);
    localViewGroup.addView(localEditText);
    Object localObject = this.inputs.put(paramString, localEditText);
    logd("addTextInput <<<");
  }

  protected IShellDialog.UIHandler createUIHandler(Looper paramLooper)
  {
    return new UIHandler(paramLooper);
  }

  public boolean getCheckBoxValue(String paramString)
  {
    String str1 = "getCheckBoxValue >>> key=" + paramString;
    logd(str1);
    boolean bool = ((CheckBox)this.inputs.get(paramString)).isChecked();
    String str2 = "getCheckBoxValue <<< return " + bool;
    logd(str2);
    return bool;
  }

  public int getComboBoxValue(String paramString)
  {
    String str1 = "getComboBoxValue >>> key=" + paramString;
    logd(str1);
    int i = ((Spinner)this.inputs.get(paramString)).getSelectedItemPosition();
    String str2 = "getComboBoxValue <<< return " + i;
    logd(str2);
    return i;
  }

  public String getTextValue(String paramString)
  {
    String str1 = "getTextValue >>> key=" + paramString;
    logd(str1);
    String str2 = ((EditText)this.inputs.get(paramString)).getText().toString();
    String str3 = "getTextValue <<< return " + str2;
    logd(str3);
    return str2;
  }

  void notifyOnValueChanged(String paramString)
  {
    int i = this.adapterAddress;
    int j = this.dialogToken;
    onValueChanged(i, j, paramString);
  }

  public void onCancel(DialogInterface paramDialogInterface)
  {
    logd("onCancel");
  }

  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    String str = "onClick: which=" + paramInt;
    logd(str);
    if (paramInt == -1)
    {
      int i = this.adapterAddress;
      int j = this.dialogToken;
      int k = this.positiveButton;
      onButtonClicked(i, j, k);
    }
    while (true)
    {
      return;
      if (paramInt == -1)
      {
        int m = this.adapterAddress;
        int n = this.dialogToken;
        int i1 = this.negativeButton;
        onButtonClicked(m, n, i1);
        continue;
      }
    }
  }

  public void onDismiss(DialogInterface paramDialogInterface)
  {
    logd("onDismiss");
    int i = this.adapterAddress;
    int j = this.dialogToken;
    onDismiss(i, j);
  }

  public void setButtons(int paramInt)
  {
    if ((paramInt & 0x2) != 0)
    {
      AlertDialog.Builder localBuilder1 = this.dialogBuilder.setPositiveButton(17039379, this);
      this.positiveButton = 2;
    }
    if ((paramInt & 0x4) != 0)
    {
      AlertDialog.Builder localBuilder2 = this.dialogBuilder.setNegativeButton(17039369, this);
      this.positiveButton = 4;
    }
    if ((paramInt & 0x1) != 0)
    {
      AlertDialog.Builder localBuilder3 = this.dialogBuilder.setPositiveButton(17039370, this);
      this.positiveButton = 1;
    }
    if ((paramInt & 0x8) != 0)
    {
      AlertDialog.Builder localBuilder4 = this.dialogBuilder.setNegativeButton(17039360, this);
      this.negativeButton = 8;
    }
  }

  public void setCheckBoxValue(String paramString, boolean paramBoolean)
  {
    ((UIHandler)this.uiHandler).postSetCheckBoxValue(paramString, paramBoolean);
  }

  public void setComboBoxValue(String paramString, int paramInt)
  {
    ((UIHandler)this.uiHandler).postSetComboBoxValue(paramString, paramInt);
  }

  public void setFocus(String paramString)
  {
    ((UIHandler)this.uiHandler).postSetFocus(paramString);
  }

  public void setIcon(int paramInt)
  {
    String str1 = "setIcon: icon=" + paramInt;
    logd(str1);
    switch (paramInt)
    {
    default:
      String str2 = "Illegal icon: " + paramInt;
      throw new IllegalArgumentException(str2);
    case 0:
    case 1:
    case 2:
    case 3:
    }
    for (int i = 17301659; ; i = 17301543)
    {
      AlertDialog.Builder localBuilder = this.dialogBuilder.setIcon(i);
      return;
    }
  }

  public void setInputEnabled(String paramString, boolean paramBoolean)
  {
    ((UIHandler)this.uiHandler).postSetInputEnabled(paramString, paramBoolean);
  }

  public void setMessage(String paramString)
  {
    String str = "setMessage: " + paramString;
    logd(str);
    AlertDialog.Builder localBuilder = this.dialogBuilder.setMessage(paramString);
  }

  public void setTextValue(String paramString1, String paramString2)
  {
    ((UIHandler)this.uiHandler).postSetTextValue(paramString1, paramString2);
  }

  public void setTitle(String paramString)
  {
    String str = "setTitle: title=" + paramString;
    logd(str);
    AlertDialog.Builder localBuilder = this.dialogBuilder.setTitle(paramString);
  }

  class SpinnerListener
    implements AdapterView.OnItemSelectedListener
  {
    private final String key;

    SpinnerListener(String arg2)
    {
      Object localObject;
      this.key = localObject;
    }

    public void onItemSelected(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong)
    {
      synchronized (ShellDialog.this.setValueMonitor)
      {
        String str1 = this.key;
        String str2 = ShellDialog.this.settingValueKey;
        if (!str1.equals(str2))
        {
          ShellDialog localShellDialog1 = ShellDialog.this;
          StringBuilder localStringBuilder = new StringBuilder().append("post notify onValueChanged: key=");
          String str3 = this.key;
          String str4 = str3;
          localShellDialog1.logd(str4);
          ShellDialog localShellDialog2 = ShellDialog.this;
          String str5 = this.key;
          localShellDialog2.notifyOnValueChanged(str5);
        }
        return;
      }
    }

    public void onNothingSelected(AdapterView<?> paramAdapterView)
    {
    }
  }

  class CheckBoxListener
    implements CompoundButton.OnCheckedChangeListener
  {
    private final String key;

    CheckBoxListener(String arg2)
    {
      Object localObject;
      this.key = localObject;
    }

    public void onCheckedChanged(CompoundButton paramCompoundButton, boolean paramBoolean)
    {
      synchronized (ShellDialog.this.setValueMonitor)
      {
        String str1 = this.key;
        String str2 = ShellDialog.this.settingValueKey;
        if (!str1.equals(str2))
        {
          ShellDialog localShellDialog1 = ShellDialog.this;
          StringBuilder localStringBuilder = new StringBuilder().append("post notify onValueChanged: key=");
          String str3 = this.key;
          String str4 = str3;
          localShellDialog1.logd(str4);
          ShellDialog localShellDialog2 = ShellDialog.this;
          String str5 = this.key;
          localShellDialog2.notifyOnValueChanged(str5);
        }
        return;
      }
    }
  }

  class TextChangedListener
    implements TextWatcher
  {
    private final String key;

    TextChangedListener(String arg2)
    {
      Object localObject;
      this.key = localObject;
    }

    public void afterTextChanged(Editable paramEditable)
    {
      synchronized (ShellDialog.this.setValueMonitor)
      {
        if (!ShellDialog.access$200(paramEditable))
        {
          String str1 = this.key;
          String str2 = ShellDialog.this.settingValueKey;
          if (!str1.equals(str2))
          {
            ShellDialog localShellDialog1 = ShellDialog.this;
            StringBuilder localStringBuilder = new StringBuilder().append("post notify onValueChanged: key=");
            String str3 = this.key;
            String str4 = str3;
            localShellDialog1.logd(str4);
            ShellDialog localShellDialog2 = ShellDialog.this;
            String str5 = this.key;
            localShellDialog2.notifyOnValueChanged(str5);
          }
        }
        return;
      }
    }

    public void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3)
    {
    }

    public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3)
    {
    }
  }

  class UIHandler extends IShellDialog.UIHandler
  {
    private static final int MSG_SET_CHECK_BOX_VALUE = 3;
    private static final int MSG_SET_COMBO_BOX_VALUE = 5;
    private static final int MSG_SET_FOCUS = 6;
    private static final int MSG_SET_INPUT_ENABLED = 4;
    private static final int MSG_SET_TEXT_VALUE = 2;

    UIHandler(Looper arg2)
    {
      super(localLooper);
    }

    private void setCheckBoxValue(String paramString, boolean paramBoolean)
    {
      synchronized (ShellDialog.this.setValueMonitor)
      {
        ShellDialog.this.settingValueKey = paramString;
        ShellDialog localShellDialog = ShellDialog.this;
        String str = "setCheckBoxValue >>> key=" + paramString + " isChecked=" + paramBoolean;
        localShellDialog.logd(str);
        ((CheckBox)ShellDialog.this.inputs.get(paramString)).setChecked(paramBoolean);
        ShellDialog.this.logd("setCheckBoxValue <<<");
        ShellDialog.this.settingValueKey = null;
        return;
      }
    }

    private void setComboBoxValue(String paramString, int paramInt)
    {
      synchronized (ShellDialog.this.setValueMonitor)
      {
        ShellDialog.this.settingValueKey = paramString;
        ShellDialog localShellDialog = ShellDialog.this;
        String str = "setComboBoxValue >>> key=" + paramString + " value=" + paramInt;
        localShellDialog.logd(str);
        ((Spinner)ShellDialog.this.inputs.get(paramString)).setSelection(paramInt);
        ShellDialog.this.logd("setComboBoxValue <<<");
        ShellDialog.this.settingValueKey = null;
        return;
      }
    }

    private void setFocus(String paramString)
    {
      ShellDialog localShellDialog = ShellDialog.this;
      String str = "setFocus >>> key=" + paramString;
      localShellDialog.logd(str);
      boolean bool = ((View)ShellDialog.this.inputs.get(paramString)).requestFocus();
      ShellDialog.this.logd("setFocus <<<");
    }

    private void setInputEnabled(String paramString, boolean paramBoolean)
    {
      ShellDialog localShellDialog = ShellDialog.this;
      String str = "setInputEnabled >>> key=" + paramString + " isEnabled=" + paramBoolean;
      localShellDialog.logd(str);
      ((View)ShellDialog.this.inputs.get(paramString)).setEnabled(paramBoolean);
      ShellDialog.this.logd("setInputEnabled <<<");
    }

    private void setTextValue(String paramString1, String paramString2)
    {
      synchronized (ShellDialog.this.setValueMonitor)
      {
        ShellDialog.this.settingValueKey = paramString1;
        ShellDialog localShellDialog = ShellDialog.this;
        String str = "setTextValue >>> key=" + paramString1 + " value=" + paramString2;
        localShellDialog.logd(str);
        EditText localEditText = (EditText)ShellDialog.this.inputs.get(paramString1);
        localEditText.setText(paramString2);
        int i = paramString2.length();
        localEditText.setSelection(i);
        ShellDialog.this.logd("setTextValue <<<");
        ShellDialog.this.settingValueKey = null;
        return;
      }
    }

    public void handleMessage(Message paramMessage)
    {
      int i = 1;
      switch (paramMessage.what)
      {
      default:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      }
      while (true)
      {
        super.handleMessage(paramMessage);
        while (true)
        {
          return;
          Pair localPair = (Pair)paramMessage.obj;
          String str1 = (String)localPair.first;
          String str2 = (String)localPair.second;
          setTextValue(str1, str2);
          continue;
          String str3 = (String)paramMessage.obj;
          if (paramMessage.arg1 != 0);
          int j;
          while (true)
          {
            setCheckBoxValue(str3, i);
            break;
            j = 0;
          }
          str3 = (String)paramMessage.obj;
          if (paramMessage.arg1 != 0);
          while (true)
          {
            setInputEnabled(str3, j);
            break;
            int k = 0;
          }
          String str4 = (String)paramMessage.obj;
          int m = paramMessage.arg1;
          setComboBoxValue(str4, m);
        }
        String str5 = (String)paramMessage.obj;
        setFocus(str5);
      }
    }

    void postSetCheckBoxValue(String paramString, boolean paramBoolean)
    {
      if (paramBoolean);
      for (int i = 1; ; i = 0)
      {
        Message localMessage = Message.obtain(this, 3, i, 0, paramString);
        boolean bool = sendMessage(localMessage);
        return;
      }
    }

    void postSetComboBoxValue(String paramString, int paramInt)
    {
      Message localMessage = Message.obtain(this, 5, paramInt, 0, paramString);
      boolean bool = sendMessage(localMessage);
    }

    void postSetFocus(String paramString)
    {
      Message localMessage = Message.obtain(this, 6, paramString);
      boolean bool = sendMessage(localMessage);
    }

    void postSetInputEnabled(String paramString, boolean paramBoolean)
    {
      if (paramBoolean);
      for (int i = 1; ; i = 0)
      {
        Message localMessage = Message.obtain(this, 4, i, 0, paramString);
        boolean bool = sendMessage(localMessage);
        return;
      }
    }

    void postSetTextValue(String paramString1, String paramString2)
    {
      Pair localPair = new Pair(paramString1, paramString2);
      Message localMessage = Message.obtain(this, 2, localPair);
      boolean bool = sendMessage(localMessage);
    }

    protected void show()
    {
      ShellDialog.this.logd("show");
      AlertDialog.Builder localBuilder1 = ShellDialog.this.dialogBuilder.setCancelable(1);
      AlertDialog.Builder localBuilder2 = ShellDialog.this.dialogBuilder;
      ShellDialog localShellDialog1 = ShellDialog.this;
      AlertDialog.Builder localBuilder3 = localBuilder2.setPositiveButton(17039370, localShellDialog1);
      AlertDialog.Builder localBuilder4 = ShellDialog.this.dialogBuilder;
      ShellDialog localShellDialog2 = ShellDialog.this;
      AlertDialog.Builder localBuilder5 = localBuilder4.setOnCancelListener(localShellDialog2);
      ShellDialog localShellDialog3 = ShellDialog.this;
      AlertDialog localAlertDialog1 = ShellDialog.this.dialogBuilder.create();
      localShellDialog3.dialog = localAlertDialog1;
      AlertDialog.Builder localBuilder6 = ShellDialog.access$002(ShellDialog.this, null);
      AlertDialog localAlertDialog2 = ShellDialog.this.dialog;
      ShellDialog localShellDialog4 = ShellDialog.this;
      localAlertDialog2.setOnDismissListener(localShellDialog4);
      ShellDialog.this.dialog.setInverseBackgroundForced(1);
      ShellDialog.this.dialog.show();
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.dialog.ShellDialog
 * JD-Core Version:    0.6.0
 */