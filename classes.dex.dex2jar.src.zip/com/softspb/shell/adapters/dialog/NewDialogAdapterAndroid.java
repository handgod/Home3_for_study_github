package com.softspb.shell.adapters.dialog;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import com.softspb.shell.adapters.AdaptersHolder;
import com.softspb.shell.opengl.NativeCallbacks;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class NewDialogAdapterAndroid extends NewDialogAdapter
{
  private static Logger logger = Loggers.getLogger(NewDialogAdapterAndroid.class);
  private int adapterAddress;
  Context context;
  final List<WeakReference<IShellDialog>> shellDialogs;
  Handler uiHandler;

  public NewDialogAdapterAndroid(AdaptersHolder paramAdaptersHolder)
  {
    super(paramAdaptersHolder);
    LinkedList localLinkedList = new LinkedList();
    this.shellDialogs = localLinkedList;
  }

  private void cleanTrash()
  {
    Iterator localIterator = this.shellDialogs.iterator();
    while (localIterator.hasNext())
    {
      if ((IShellDialog)((WeakReference)localIterator.next()).get() != null)
        continue;
      localIterator.remove();
    }
  }

  private static void logd(String paramString)
  {
    Logger localLogger = logger;
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = paramString;
    localLogger.d("NewDialogAdapterAndroid", arrayOfObject);
  }

  /** @deprecated */
  public void closeAllDialogs()
  {
    monitorenter;
    try
    {
      Iterator localIterator = this.shellDialogs.iterator();
      if (localIterator.hasNext())
      {
        IShellDialog localIShellDialog = (IShellDialog)((WeakReference)localIterator.next()).get();
        if (localIShellDialog != null)
          localIShellDialog.dismiss();
        localIterator.remove();
      }
    }
    finally
    {
      monitorexit;
    }
  }

  /** @deprecated */
  public ShellDatePickerDialog newShellDatePickerDialog(int paramInt)
  {
    monitorenter;
    try
    {
      Context localContext = this.context;
      Looper localLooper = this.uiHandler.getLooper();
      int i = this.adapterAddress;
      ShellDatePickerDialog localShellDatePickerDialog = new ShellDatePickerDialog(localContext, localLooper, i, paramInt);
      cleanTrash();
      WeakReference localWeakReference = new WeakReference(localShellDatePickerDialog);
      boolean bool = this.shellDialogs.add(localWeakReference);
      monitorexit;
      return localShellDatePickerDialog;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  /** @deprecated */
  public ShellDialog newShellDialog(int paramInt)
  {
    monitorenter;
    try
    {
      Context localContext = this.context;
      Looper localLooper = this.uiHandler.getLooper();
      int i = this.adapterAddress;
      ShellDialog localShellDialog = new ShellDialog(localContext, localLooper, i, paramInt);
      cleanTrash();
      WeakReference localWeakReference = new WeakReference(localShellDialog);
      boolean bool = this.shellDialogs.add(localWeakReference);
      monitorexit;
      return localShellDialog;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  protected void onCreate(Context paramContext, NativeCallbacks paramNativeCallbacks)
  {
    super.onCreate(paramContext, paramNativeCallbacks);
    this.context = paramContext;
  }

  protected void onStart(int paramInt)
  {
    StringBuilder localStringBuilder = new StringBuilder().append("onStart: adapterAddress=0x");
    String str = Integer.toHexString(paramInt);
    logd(str);
    this.adapterAddress = paramInt;
  }

  protected void onStartInUIThread()
  {
    super.onStartInUIThread();
    Handler localHandler = new Handler();
    this.uiHandler = localHandler;
  }

  public void showPopupMessage(String paramString)
  {
    logd("showPopupMessage: message=\"" + paramString + "\"");
    Handler localHandler = this.uiHandler;
    NewDialogAdapterAndroid.1 local1 = new NewDialogAdapterAndroid.1(this, paramString);
    boolean bool = localHandler.post(local1);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.dialog.NewDialogAdapterAndroid
 * JD-Core Version:    0.6.0
 */