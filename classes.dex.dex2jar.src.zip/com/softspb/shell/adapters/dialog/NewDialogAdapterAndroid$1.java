package com.softspb.shell.adapters.dialog;

import android.content.Context;
import android.widget.Toast;

class NewDialogAdapterAndroid$1
  implements Runnable
{
  public void run()
  {
    Context localContext = this.this$0.context;
    String str = this.val$message;
    Toast.makeText(localContext, str, 1).show();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.dialog.NewDialogAdapterAndroid.1
 * JD-Core Version:    0.6.0
 */