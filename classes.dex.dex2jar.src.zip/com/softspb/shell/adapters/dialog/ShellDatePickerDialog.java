package com.softspb.shell.adapters.dialog;

import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnDismissListener;
import android.os.Looper;
import android.text.format.Time;
import android.widget.DatePicker;

public class ShellDatePickerDialog extends IShellDialog
  implements DatePickerDialog.OnDateSetListener, DialogInterface.OnCancelListener, DialogInterface.OnDismissListener
{
  private int day;
  private int month;
  private int year;

  public ShellDatePickerDialog(Context paramContext, Looper paramLooper, int paramInt1, int paramInt2)
  {
    super(paramContext, paramLooper, paramInt1, paramInt2);
    StringBuilder localStringBuilder = new StringBuilder().append("Ctor: adapterAddress=0x");
    String str1 = Integer.toHexString(paramInt1);
    String str2 = str1 + " dialogToken=" + paramInt2;
    logd(str2);
    Time localTime = new Time();
    localTime.setToNow();
    int i = localTime.year;
    this.year = i;
    int j = localTime.month;
    this.month = j;
    int k = localTime.monthDay;
    this.day = k;
  }

  private native void onDateSet(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);

  private native void onDismiss(int paramInt1, int paramInt2);

  protected IShellDialog.UIHandler createUIHandler(Looper paramLooper)
  {
    return new UIHandler(paramLooper);
  }

  public void onCancel(DialogInterface paramDialogInterface)
  {
    logd("onCancel");
  }

  public void onDateSet(DatePicker paramDatePicker, int paramInt1, int paramInt2, int paramInt3)
  {
    String str = "onDateSet: year=" + paramInt1 + " month=" + paramInt2 + " day=" + paramInt3;
    logd(str);
    int i = this.adapterAddress;
    int j = this.dialogToken;
    int k = paramInt2 + 1;
    ShellDatePickerDialog localShellDatePickerDialog = this;
    int m = paramInt1;
    int n = paramInt3;
    localShellDatePickerDialog.onDateSet(i, j, m, k, n);
  }

  public void onDismiss(DialogInterface paramDialogInterface)
  {
    logd("onDismiss");
    int i = this.adapterAddress;
    int j = this.dialogToken;
    onDismiss(i, j);
  }

  public void setDate(int paramInt1, int paramInt2, int paramInt3)
  {
    this.year = paramInt1;
    int i = paramInt2 + -1;
    this.month = i;
    this.day = paramInt3;
  }

  class UIHandler extends IShellDialog.UIHandler
  {
    UIHandler(Looper arg2)
    {
      super(localLooper);
    }

    protected void show()
    {
      ShellDatePickerDialog.this.logd("show");
      Context localContext = ShellDatePickerDialog.this.context;
      ShellDatePickerDialog localShellDatePickerDialog1 = ShellDatePickerDialog.this;
      int i = ShellDatePickerDialog.this.year;
      int j = ShellDatePickerDialog.this.month;
      int k = ShellDatePickerDialog.this.day;
      DatePickerDialog localDatePickerDialog = new DatePickerDialog(localContext, localShellDatePickerDialog1, i, j, k);
      ShellDatePickerDialog.this.dialog = localDatePickerDialog;
      localDatePickerDialog.setCancelable(1);
      ShellDatePickerDialog localShellDatePickerDialog2 = ShellDatePickerDialog.this;
      localDatePickerDialog.setOnCancelListener(localShellDatePickerDialog2);
      ShellDatePickerDialog localShellDatePickerDialog3 = ShellDatePickerDialog.this;
      localDatePickerDialog.setOnDismissListener(localShellDatePickerDialog3);
      localDatePickerDialog.setInverseBackgroundForced(1);
      localDatePickerDialog.show();
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.dialog.ShellDatePickerDialog
 * JD-Core Version:    0.6.0
 */