package com.softspb.shell.adapters.wallpaper;

import android.app.WallpaperInfo;
import com.softspb.shell.Home;
import com.softspb.shell.adapters.AdaptersHolder;

public class WallpaperAdapterAndroid extends AbstractWallpaperAdapter
{
  public static final String ACTION_KILL_SHELL = "com.spb.shell3d.action.pifpaf";

  public WallpaperAdapterAndroid(AdaptersHolder paramAdaptersHolder)
  {
    super(paramAdaptersHolder);
  }

  public boolean isLiveWallpaper()
  {
    if ((useLiveWallpapers(this.context)) && (super.isLiveWallpaper()));
    for (int i = 1; ; i = 0)
      return i;
  }

  public void onWallpaperChange(WallpaperInfo paramWallpaperInfo1, WallpaperInfo paramWallpaperInfo2)
  {
    int i = 1;
    if (!useLiveWallpapers(this.context))
      reloadWallpaper();
    while (true)
    {
      return;
      int j;
      if (paramWallpaperInfo1 == null)
      {
        j = 1;
        label24: if (paramWallpaperInfo2 != null)
          break label54;
      }
      while (true)
      {
        if ((i ^ j) == 0)
          break label59;
        ((Home)this.context).restartShell();
        break;
        j = 0;
        break label24;
        label54: i = 0;
      }
      label59: if (i == 0)
        continue;
      super.reloadWallpaper();
    }
  }

  public void reloadWallpaper()
  {
    if ((useLiveWallpapers(this.context)) && (isLiveWallpaper()))
      notifyChange();
    while (true)
    {
      return;
      super.reloadWallpaper();
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.wallpaper.WallpaperAdapterAndroid
 * JD-Core Version:    0.6.0
 */