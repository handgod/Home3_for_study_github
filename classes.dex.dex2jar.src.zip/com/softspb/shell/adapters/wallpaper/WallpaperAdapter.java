package com.softspb.shell.adapters.wallpaper;

import android.app.WallpaperManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.preference.PreferenceManager;
import com.softspb.shell.adapters.Adapter;
import com.softspb.shell.adapters.AdaptersHolder;

public abstract class WallpaperAdapter extends Adapter
{
  private static String USE_LIVE_WALLPAPER = "key_use_livewallpaper";

  public WallpaperAdapter(AdaptersHolder paramAdaptersHolder)
  {
    super(paramAdaptersHolder);
  }

  public static boolean isLiveWallpaper(Context paramContext)
  {
    if (WallpaperManager.getInstance(paramContext).getWallpaperInfo() != null);
    for (int i = 1; ; i = 0)
      return i;
  }

  public static native void notifyChange();

  public static void setUseLiveWallpapers(Context paramContext, boolean paramBoolean)
  {
    SharedPreferences.Editor localEditor = PreferenceManager.getDefaultSharedPreferences(paramContext).edit();
    String str = USE_LIVE_WALLPAPER;
    boolean bool = localEditor.putBoolean(str, paramBoolean).commit();
  }

  public static boolean useLiveWallpapers(Context paramContext)
  {
    SharedPreferences localSharedPreferences = PreferenceManager.getDefaultSharedPreferences(paramContext);
    String str = USE_LIVE_WALLPAPER;
    return localSharedPreferences.getBoolean(str, 0);
  }

  public abstract void checkWallpaperChange();

  public abstract Bitmap getWallpaper();

  public abstract String getWallpaperSkin();

  public abstract boolean isLiveWallpaper();

  public abstract void openSetWallPaperDialog();

  public abstract void reloadWallpaper();

  public abstract void setWallpaperFromFile(String paramString);
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.wallpaper.WallpaperAdapter
 * JD-Core Version:    0.6.0
 */