package com.softspb.shell.adapters.wallpaper;

import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import com.softspb.shell.view.FilterPickDialogBuilder.IFilter;

class AbstractWallpaperAdapter$3
  implements FilterPickDialogBuilder.IFilter
{
  public boolean filter(ResolveInfo paramResolveInfo)
  {
    int i = 0;
    if ((!WallpaperAdapter.useLiveWallpapers(this.this$0.context)) && (paramResolveInfo.activityInfo != null))
    {
      String str1 = paramResolveInfo.activityInfo.packageName;
      if (!"com.android.wallpaper.livepicker".equals(str1));
    }
    while (true)
    {
      return i;
      String str2 = paramResolveInfo.activityInfo.packageName;
      boolean bool1 = "com.htc.AddProgramWidget".equalsIgnoreCase(str2);
      String str3 = paramResolveInfo.activityInfo.name;
      boolean bool2 = "com.htc.AddProgramWidget.WallpaperLivePicker".equalsIgnoreCase(str3);
      if (((bool1) && (bool2)) || ((paramResolveInfo.activityInfo.applicationInfo.flags & 0x1) != 1))
        continue;
      i = 1;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.wallpaper.AbstractWallpaperAdapter.3
 * JD-Core Version:    0.6.0
 */