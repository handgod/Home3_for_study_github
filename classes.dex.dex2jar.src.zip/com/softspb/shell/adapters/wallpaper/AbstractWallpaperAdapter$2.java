package com.softspb.shell.adapters.wallpaper;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import com.softspb.shell.util.BitmapHelper;
import java.io.File;

class AbstractWallpaperAdapter$2
  implements Runnable
{
  public void run()
  {
    if ((this.val$wallpaper instanceof BitmapDrawable))
    {
      Bitmap localBitmap = ((BitmapDrawable)this.val$wallpaper).getBitmap();
      if ((localBitmap != null) && (!localBitmap.isRecycled()))
      {
        File localFile = this.this$0.context.getFilesDir();
        BitmapHelper.writeBitmap(localBitmap, "wallpaper.png", localFile);
        localBitmap.recycle();
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.wallpaper.AbstractWallpaperAdapter.2
 * JD-Core Version:    0.6.0
 */