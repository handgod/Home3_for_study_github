package com.softspb.shell.adapters.wallpaper;

import android.graphics.Bitmap;

class AbstractWallpaperAdapter$5
  implements Runnable
{
  public void run()
  {
    AbstractWallpaperAdapter localAbstractWallpaperAdapter = this.this$0;
    Bitmap localBitmap1 = this.this$0.loadWallpaper();
    Bitmap localBitmap2 = AbstractWallpaperAdapter.access$102(localAbstractWallpaperAdapter, localBitmap1);
    WallpaperAdapter.notifyChange();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.wallpaper.AbstractWallpaperAdapter.5
 * JD-Core Version:    0.6.0
 */