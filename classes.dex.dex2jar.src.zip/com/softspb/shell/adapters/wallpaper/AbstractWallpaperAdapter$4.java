package com.softspb.shell.adapters.wallpaper;

import android.content.Intent;
import com.softspb.shell.view.FilterPickDialogBuilder.DialogResult;
import com.spb.programlist.ProgramsUtil;

class AbstractWallpaperAdapter$4
  implements FilterPickDialogBuilder.DialogResult
{
  public void onResult(Intent paramIntent)
  {
    ProgramsUtil.startActivitySafely(this.this$0.context, paramIntent);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.wallpaper.AbstractWallpaperAdapter.4
 * JD-Core Version:    0.6.0
 */