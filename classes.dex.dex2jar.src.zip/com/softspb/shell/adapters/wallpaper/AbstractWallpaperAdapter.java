package com.softspb.shell.adapters.wallpaper;

import android.app.AlertDialog;
import android.app.WallpaperInfo;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import com.softspb.shell.adapters.AdaptersHolder;
import com.softspb.shell.opengl.NativeCallbacks;
import com.softspb.shell.view.FilterPickDialogBuilder;
import com.softspb.util.broadcastreceiver.DecoratedBroadcastReceiver;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import com.spb.shell3d.R.string;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public abstract class AbstractWallpaperAdapter extends WallpaperAdapter
{
  private static final String DEFAULT_PANEL_NAME = "wallpapers/default";
  private static final String DEFAULT_WALLPAPER = "files/wallpaper.jpg";
  private static final String FILE_NAME = "wallpaper.png";
  private static final String KEY_PANEL_NAME = "key_panel_name";
  private static final String WALLPAPERS_PATH = "wallpapers";
  private static final Logger logger = Loggers.getLogger(AbstractWallpaperAdapter.class.getName());
  protected Context context;
  private Runnable loadImage;
  private Bitmap mWallpaper;
  private SharedPreferences preferences;
  private DecoratedBroadcastReceiver receiver;
  protected WallpaperInfo wallpaperInfo;
  private WallpaperManager wm;

  public AbstractWallpaperAdapter(AdaptersHolder paramAdaptersHolder)
  {
    super(paramAdaptersHolder);
    AbstractWallpaperAdapter.1 local1 = new AbstractWallpaperAdapter.1(this);
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver = new DecoratedBroadcastReceiver("android.intent.action.WALLPAPER_CHANGED", local1);
    this.receiver = localDecoratedBroadcastReceiver;
    AbstractWallpaperAdapter.5 local5 = new AbstractWallpaperAdapter.5(this);
    this.loadImage = local5;
  }

  private Size getWallpaperSize(Drawable paramDrawable)
  {
    int i = paramDrawable.getMinimumWidth();
    int j = paramDrawable.getMinimumHeight();
    Size localSize = new Size(j);
    if ((localSize.cx <= 0) || (localSize.cy <= 0))
    {
      Display localDisplay = ((WindowManager)this.context.getSystemService("window")).getDefaultDisplay();
      DisplayMetrics localDisplayMetrics = new DisplayMetrics();
      localDisplay.getMetrics(localDisplayMetrics);
      int k = localDisplayMetrics.heightPixels;
      localSize.cy = k;
      int m = localDisplayMetrics.widthPixels;
      localSize.cx = m;
    }
    return localSize;
  }

  private void setNewWallpaperInfo(WallpaperInfo paramWallpaperInfo)
  {
    WallpaperInfo localWallpaperInfo1 = this.wallpaperInfo;
    WallpaperInfo localWallpaperInfo2 = this.wm.getWallpaperInfo();
    this.wallpaperInfo = localWallpaperInfo2;
    WallpaperInfo localWallpaperInfo3 = this.wallpaperInfo;
    onWallpaperChange(localWallpaperInfo1, localWallpaperInfo3);
  }

  private static boolean wallpaperInfoEqual(WallpaperInfo paramWallpaperInfo1, WallpaperInfo paramWallpaperInfo2)
  {
    int i = 1;
    if (((paramWallpaperInfo1 != null) && (paramWallpaperInfo2 == null)) || ((paramWallpaperInfo1 == null) && (paramWallpaperInfo2 != null)))
      i = 0;
    while (true)
    {
      return i;
      if (paramWallpaperInfo1 == null)
        continue;
      String str1 = paramWallpaperInfo1.getPackageName();
      String str2 = paramWallpaperInfo2.getPackageName();
      if (str1.equals(str2))
      {
        String str3 = paramWallpaperInfo1.getServiceName();
        String str4 = paramWallpaperInfo2.getServiceName();
        if (str3.equals(str4))
          continue;
      }
      i = 0;
    }
  }

  public void checkWallpaperChange()
  {
    WallpaperInfo localWallpaperInfo1 = this.wm.getWallpaperInfo();
    WallpaperInfo localWallpaperInfo2 = this.wallpaperInfo;
    if (!wallpaperInfoEqual(localWallpaperInfo1, localWallpaperInfo2))
    {
      WallpaperInfo localWallpaperInfo3 = this.wm.getWallpaperInfo();
      setNewWallpaperInfo(localWallpaperInfo3);
    }
  }

  public Bitmap getWallpaper()
  {
    return this.mWallpaper;
  }

  public String getWallpaperSkin()
  {
    String str1 = this.preferences.getString("key_panel_name", "wallpapers/default");
    Logger localLogger = logger;
    String str2 = "getWallpaper skin" + str1;
    localLogger.i(str2);
    return str1;
  }

  public boolean isLiveWallpaper()
  {
    if (this.wm.getWallpaperInfo() != null);
    for (int i = 1; ; i = 0)
      return i;
  }

  protected final Bitmap loadDefaultSpbWallpaper()
  {
    try
    {
      Bitmap localBitmap1 = BitmapFactory.decodeStream(this.context.getAssets().open("files/wallpaper.jpg"));
      localBitmap2 = localBitmap1;
      return localBitmap2;
    }
    catch (IOException localIOException)
    {
      while (true)
      {
        localIOException.printStackTrace();
        Bitmap localBitmap2 = null;
      }
    }
  }

  protected final Bitmap loadSavedWallpaper()
  {
    File localFile1 = this.context.getFilesDir();
    File localFile2 = new File(localFile1, "wallpaper.png");
    try
    {
      Bitmap localBitmap1 = BitmapFactory.decodeStream(new FileInputStream(localFile2));
      localBitmap2 = localBitmap1;
      return localBitmap2;
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      while (true)
      {
        localFileNotFoundException.printStackTrace();
        Bitmap localBitmap2 = null;
      }
    }
  }

  protected Bitmap loadWallpaper()
  {
    Drawable localDrawable = this.wm.getDrawable();
    if ((localDrawable instanceof BitmapDrawable))
    {
      Bitmap localBitmap1 = ((BitmapDrawable)localDrawable).getBitmap();
      if ((localBitmap1 != null) && (!localBitmap1.isRecycled()));
    }
    for (Bitmap localBitmap2 = loadSavedWallpaper(); ; localBitmap2 = loadDefaultSpbWallpaper())
    {
      return localBitmap2;
      if (localDrawable != null)
        break;
    }
    Size localSize = getWallpaperSize(localDrawable);
    Rect localRect1 = localDrawable.getBounds();
    Rect localRect2 = new Rect(localRect1);
    int i = localSize.cx;
    int j = localSize.cy;
    localDrawable.setBounds(0, 0, i, j);
    if (localDrawable.getOpacity() != -1);
    for (Bitmap.Config localConfig = Bitmap.Config.ARGB_8888; ; localConfig = Bitmap.Config.RGB_565)
    {
      int k = localSize.cx;
      int m = localSize.cy;
      localBitmap2 = Bitmap.createBitmap(k, m, localConfig);
      Canvas localCanvas = new Canvas(localBitmap2);
      PaintFlagsDrawFilter localPaintFlagsDrawFilter = new PaintFlagsDrawFilter(4, 0);
      localCanvas.setDrawFilter(localPaintFlagsDrawFilter);
      localDrawable.draw(localCanvas);
      localDrawable.setBounds(localRect2);
      AbstractWallpaperAdapter.2 local2 = new AbstractWallpaperAdapter.2(this, localDrawable);
      new Thread(local2).start();
      break;
    }
  }

  protected void onCreate(Context paramContext, NativeCallbacks paramNativeCallbacks)
  {
    this.context = paramContext;
    WallpaperManager localWallpaperManager = (WallpaperManager)paramContext.getSystemService("wallpaper");
    this.wm = localWallpaperManager;
    WallpaperInfo localWallpaperInfo = this.wm.getWallpaperInfo();
    this.wallpaperInfo = localWallpaperInfo;
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver = this.receiver;
    IntentFilter localIntentFilter = this.receiver.getIntentFilter();
    Intent localIntent = paramContext.registerReceiver(localDecoratedBroadcastReceiver, localIntentFilter);
    SharedPreferences localSharedPreferences = PreferenceManager.getDefaultSharedPreferences(paramContext);
    this.preferences = localSharedPreferences;
  }

  protected void onDestroy(Context paramContext)
  {
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver = this.receiver;
    paramContext.unregisterReceiver(localDecoratedBroadcastReceiver);
  }

  public abstract void onWallpaperChange(WallpaperInfo paramWallpaperInfo1, WallpaperInfo paramWallpaperInfo2);

  public void openSetWallPaperDialog()
  {
    Context localContext = this.context;
    Intent localIntent = new Intent("android.intent.action.SET_WALLPAPER");
    FilterPickDialogBuilder localFilterPickDialogBuilder1 = new FilterPickDialogBuilder(localContext, localIntent);
    AbstractWallpaperAdapter.3 local3 = new AbstractWallpaperAdapter.3(this);
    FilterPickDialogBuilder localFilterPickDialogBuilder2 = localFilterPickDialogBuilder1.setFilter(local3);
    AbstractWallpaperAdapter.4 local4 = new AbstractWallpaperAdapter.4(this);
    FilterPickDialogBuilder localFilterPickDialogBuilder3 = localFilterPickDialogBuilder1.setDialogResult(local4);
    int i = R.string.chooser_wallpaper;
    FilterPickDialogBuilder localFilterPickDialogBuilder4 = localFilterPickDialogBuilder1.setTitle(i);
    localFilterPickDialogBuilder1.create().show();
  }

  public void reloadWallpaper()
  {
    Runnable localRunnable = this.loadImage;
    new Thread(localRunnable).start();
  }

  public void setWallpaperFromFile(String paramString)
  {
    File localFile = new File(paramString);
    try
    {
      WallpaperManager localWallpaperManager = this.wm;
      FileInputStream localFileInputStream = new FileInputStream(localFile);
      localWallpaperManager.setStream(localFileInputStream);
      return;
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      while (true)
        localFileNotFoundException.printStackTrace();
    }
    catch (IOException localIOException)
    {
      while (true)
        localIOException.printStackTrace();
    }
  }

  class Size
  {
    public int cx;
    public int cy;

    public Size(int arg2)
    {
      this.cx = this$1;
      int i;
      this.cy = i;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.wallpaper.AbstractWallpaperAdapter
 * JD-Core Version:    0.6.0
 */