package com.softspb.shell.adapters.wallpaper;

import android.content.Context;
import android.content.Intent;
import com.softspb.util.broadcastreceiver.DecoratedBroadcastReceiver.IActionListener;

class AbstractWallpaperAdapter$1
  implements DecoratedBroadcastReceiver.IActionListener
{
  public void onAction(Context paramContext, Intent paramIntent)
  {
    AbstractWallpaperAdapter.access$000(this.this$0, null);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.wallpaper.AbstractWallpaperAdapter.1
 * JD-Core Version:    0.6.0
 */