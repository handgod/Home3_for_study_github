package com.softspb.shell.adapters.wallpaper;

import android.app.WallpaperInfo;
import android.graphics.Bitmap;
import com.softspb.shell.adapters.AdaptersHolder;

public class LiteWallpaperAndroid extends AbstractWallpaperAdapter
{
  public LiteWallpaperAndroid(AdaptersHolder paramAdaptersHolder)
  {
    super(paramAdaptersHolder);
  }

  protected Bitmap loadWallpaper()
  {
    return super.loadWallpaper();
  }

  public void onWallpaperChange(WallpaperInfo paramWallpaperInfo1, WallpaperInfo paramWallpaperInfo2)
  {
    reloadWallpaper();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.wallpaper.LiteWallpaperAndroid
 * JD-Core Version:    0.6.0
 */