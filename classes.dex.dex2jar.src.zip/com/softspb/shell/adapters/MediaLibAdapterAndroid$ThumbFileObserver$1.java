package com.softspb.shell.adapters;

class MediaLibAdapterAndroid$ThumbFileObserver$1
  implements Runnable
{
  public void run()
  {
    MediaLibAdapterAndroid localMediaLibAdapterAndroid = this.this$1.this$0;
    String str = this.val$fullPath;
    localMediaLibAdapterAndroid.onAlbumThumbChanged(str);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.MediaLibAdapterAndroid.ThumbFileObserver.1
 * JD-Core Version:    0.6.0
 */