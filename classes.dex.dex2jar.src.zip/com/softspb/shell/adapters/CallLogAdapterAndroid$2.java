package com.softspb.shell.adapters;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import com.softspb.util.log.Logger;
import com.spb.contacts.IPhoneNumberResolvingService;
import com.spb.contacts.IPhoneNumberResolvingService.Stub;
import com.spb.contacts.IPhoneNumberResolvingServiceCallback;
import java.util.concurrent.CountDownLatch;

class CallLogAdapterAndroid$2
  implements ServiceConnection
{
  public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
  {
    Logger localLogger = CallLogAdapterAndroid.logger;
    String str = "onServiceConnected: PhoneNumberService name=" + paramComponentName;
    localLogger.d(str);
    CallLogAdapterAndroid localCallLogAdapterAndroid = this.this$0;
    IPhoneNumberResolvingService localIPhoneNumberResolvingService1 = IPhoneNumberResolvingService.Stub.asInterface(paramIBinder);
    IPhoneNumberResolvingService localIPhoneNumberResolvingService2 = CallLogAdapterAndroid.access$602(localCallLogAdapterAndroid, localIPhoneNumberResolvingService1);
    try
    {
      IPhoneNumberResolvingService localIPhoneNumberResolvingService3 = CallLogAdapterAndroid.access$600(this.this$0);
      IPhoneNumberResolvingServiceCallback localIPhoneNumberResolvingServiceCallback = this.this$0.phoneNumberCallback;
      localIPhoneNumberResolvingService3.registerCallback(localIPhoneNumberResolvingServiceCallback);
      label79: CallLogAdapterAndroid.access$700(this.this$0).countDown();
      return;
    }
    catch (RemoteException localRemoteException)
    {
      break label79;
    }
  }

  public void onServiceDisconnected(ComponentName paramComponentName)
  {
    IPhoneNumberResolvingService localIPhoneNumberResolvingService = CallLogAdapterAndroid.access$602(this.this$0, null);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.CallLogAdapterAndroid.2
 * JD-Core Version:    0.6.0
 */