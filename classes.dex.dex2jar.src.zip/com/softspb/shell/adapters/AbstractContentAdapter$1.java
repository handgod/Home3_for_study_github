package com.softspb.shell.adapters;

class AbstractContentAdapter$1
  implements Runnable
{
  public void run()
  {
    this.this$0.reload(1);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.AbstractContentAdapter.1
 * JD-Core Version:    0.6.0
 */