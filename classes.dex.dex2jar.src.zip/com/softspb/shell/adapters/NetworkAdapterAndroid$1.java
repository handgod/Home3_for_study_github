package com.softspb.shell.adapters;

import java.net.DatagramPacket;
import java.net.DatagramSocket;

class NetworkAdapterAndroid$1
  implements Runnable
{
  public void run()
  {
    try
    {
      DatagramSocket localDatagramSocket = new DatagramSocket(18093);
      byte[] arrayOfByte1 = new byte[65535];
      while (true)
      {
        int i = arrayOfByte1.length;
        DatagramPacket localDatagramPacket = new DatagramPacket(arrayOfByte1, i);
        localDatagramSocket.receive(localDatagramPacket);
        byte[] arrayOfByte2 = localDatagramPacket.getData();
        int j = localDatagramPacket.getOffset();
        int k = localDatagramPacket.getLength();
        String str = NetworkAdapterAndroid.onCmd(new String(arrayOfByte2, j, k));
      }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.NetworkAdapterAndroid.1
 * JD-Core Version:    0.6.0
 */