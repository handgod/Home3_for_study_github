package com.softspb.shell.adapters;

import android.os.RemoteException;
import com.spb.contacts.IPhoneNumberResolvingServiceCallback.Stub;

class ContactsAdapterAndroid$2 extends IPhoneNumberResolvingServiceCallback.Stub
{
  public void onResolvedPhonesChanged(int paramInt)
    throws RemoteException
  {
    ContactsAdapterAndroid localContactsAdapterAndroid = this.this$0;
    String str = "IPhoneNumberResolvingService.onResolvedPhonesChanged: contactId=" + paramInt;
    ContactsAdapterAndroid.access$000(localContactsAdapterAndroid, str);
    ContactsAdapterAndroid.access$1800(this.this$0.contactsAdapterToken, paramInt);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.ContactsAdapterAndroid.2
 * JD-Core Version:    0.6.0
 */