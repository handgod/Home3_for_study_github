package com.softspb.shell.adapters.program.adapter;

import android.content.Context;
import com.softspb.shell.adapters.AdaptersHolder;
import com.softspb.shell.adapters.ProgramListAdapter;
import com.softspb.shell.adapters.ProgramListAdapterAndroid;
import com.softspb.shell.opengl.NativeCallbacks;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import com.spb.programlist.ProgramInfo;
import com.spb.programlist.ProgramList;
import com.spb.programlist.ProgramListListener;

public class ProgramListAdapterAndroid2 extends ProgramListAdapter
  implements ProgramListListener
{
  private static Logger logger = Loggers.getLogger(ProgramListAdapterAndroid2.class.getName());
  ProgramList programList;

  public ProgramListAdapterAndroid2(AdaptersHolder paramAdaptersHolder)
  {
    super(paramAdaptersHolder);
  }

  /** @deprecated */
  public void findByTag(String paramString)
  {
    monitorenter;
    try
    {
      Logger localLogger = logger;
      String str = "findByTag: tag=" + paramString;
      localLogger.d(str);
      ProgramInfo localProgramInfo = this.programList.findByTag(paramString);
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  /** @deprecated */
  public boolean launch(String paramString)
  {
    monitorenter;
    try
    {
      Logger localLogger = logger;
      String str = "launch: tag=" + paramString;
      localLogger.d(str);
      boolean bool1 = this.programList.launch(paramString);
      boolean bool2 = bool1;
      monitorexit;
      return bool2;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  /** @deprecated */
  public boolean launch(String paramString1, String paramString2)
  {
    monitorenter;
    try
    {
      Logger localLogger = logger;
      String str = "launch: packageName=" + paramString1 + " activityClassName=" + paramString2;
      localLogger.d(str);
      boolean bool1 = this.programList.launch(paramString1, paramString2);
      boolean bool2 = bool1;
      monitorexit;
      return bool2;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void onAdded(ProgramInfo paramProgramInfo)
  {
    Logger localLogger = logger;
    StringBuilder localStringBuilder1 = new StringBuilder().append("onAdded >>> package=");
    String str1 = paramProgramInfo.packageName;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1).append(" activity=");
    String str2 = paramProgramInfo.activityClassName;
    StringBuilder localStringBuilder3 = localStringBuilder2.append(str2).append(" tag=");
    String str3 = paramProgramInfo.widgetTag;
    String str4 = str3;
    localLogger.d(str4);
    String str5 = paramProgramInfo.packageName;
    String str6 = paramProgramInfo.activityClassName;
    String str7 = paramProgramInfo.activityLabel;
    String str8 = paramProgramInfo.activityIconResource;
    String str9 = paramProgramInfo.widgetTag;
    boolean bool1 = paramProgramInfo.addToPrograms;
    boolean bool2 = paramProgramInfo.isDefault;
    boolean bool3 = paramProgramInfo.isUninstallable;
    ProgramListAdapterAndroid.launcherPut(str5, str6, str7, str8, str9, bool1, bool2, bool3);
    logger.d("onAdded <<<");
  }

  protected void onCreate(Context paramContext, NativeCallbacks paramNativeCallbacks)
  {
    super.onCreate(paramContext, paramNativeCallbacks);
    ProgramList localProgramList = ProgramList.getInstance(paramContext);
    this.programList = localProgramList;
  }

  public void onDeleted(String paramString)
  {
    Logger localLogger = logger;
    String str = "onDeleted >>> packageName=" + paramString;
    localLogger.d(str);
    ProgramListAdapterAndroid.launcherDelete(paramString);
    logger.d("onDeleted <<<");
  }

  protected void onStart()
  {
    logger.d("onStart >>>");
    this.programList.registerListener(this);
    this.programList.start();
    logger.d("onStart <<<");
  }

  protected void onStop()
  {
    logger.d("onStop >>>");
    this.programList.stop();
    this.programList.unregisterListener(this);
    logger.d("onStop <<<");
  }

  public void uninstall(String paramString)
  {
    Logger localLogger = logger;
    String str = "uninstall: packageName=" + paramString;
    localLogger.d(str);
    this.programList.uninstall(paramString);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.program.adapter.ProgramListAdapterAndroid2
 * JD-Core Version:    0.6.0
 */