package com.softspb.shell.adapters;

import android.text.InputFilter;
import android.text.Spanned;
import android.widget.EditText;

class DialogBoxAdapterAndroid$DialogBoxInstance$1
  implements InputFilter
{
  public CharSequence filter(CharSequence paramCharSequence, int paramInt1, int paramInt2, Spanned paramSpanned, int paramInt3, int paramInt4)
  {
    Object localObject;
    if (DialogBoxAdapterAndroid.DialogBoxInstance.access$200(this.this$1).isEnabled())
      localObject = null;
    while (true)
    {
      return localObject;
      if (paramCharSequence.length() < 1)
      {
        localObject = paramSpanned.subSequence(paramInt3, paramInt4);
        continue;
      }
      localObject = "";
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.DialogBoxAdapterAndroid.DialogBoxInstance.1
 * JD-Core Version:    0.6.0
 */