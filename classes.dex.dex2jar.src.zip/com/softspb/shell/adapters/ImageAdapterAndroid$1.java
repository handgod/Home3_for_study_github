package com.softspb.shell.adapters;

import java.io.IOException;
import java.io.InputStream;
import java.nio.Buffer;
import java.nio.ByteBuffer;

final class ImageAdapterAndroid$1 extends InputStream
{
  public int available()
    throws IOException
  {
    return this.val$buf.remaining();
  }

  /** @deprecated */
  public int read()
    throws IOException
  {
    monitorenter;
    try
    {
      boolean bool = this.val$buf.hasRemaining();
      if (!bool);
      int i;
      for (int j = -1; ; j = i & 0xFF)
      {
        return j;
        i = this.val$buf.get();
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  /** @deprecated */
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    monitorenter;
    try
    {
      boolean bool = this.val$buf.hasRemaining();
      if (!bool);
      for (int i = -1; ; i = paramInt2)
      {
        return i;
        int j = this.val$buf.remaining();
        paramInt2 = Math.min(paramInt2, j);
        ByteBuffer localByteBuffer = this.val$buf.get(paramArrayOfByte, paramInt1, paramInt2);
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public long skip(long paramLong)
    throws IOException
  {
    long l1 = 0L;
    if (paramLong < l1);
    while (true)
    {
      return l1;
      long l2 = this.val$buf.remaining();
      l1 = Math.min(paramLong, l2);
      ByteBuffer localByteBuffer = this.val$buf;
      int i = (int)(this.val$buf.position() + l1);
      Buffer localBuffer = localByteBuffer.position(i);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.ImageAdapterAndroid.1
 * JD-Core Version:    0.6.0
 */