package com.softspb.shell.adapters;

import android.os.RemoteException;
import com.softspb.util.log.Logger;
import com.spb.contacts.IPhoneNumberResolvingServiceCallback.Stub;

class CallLogAdapterAndroid$1 extends IPhoneNumberResolvingServiceCallback.Stub
{
  public void onResolvedPhonesChanged(int paramInt)
    throws RemoteException
  {
    Logger localLogger = CallLogAdapterAndroid.logger;
    String str = "onResolvedPhonesChanged: contactId=" + paramInt;
    localLogger.d(str);
    CallLogAdapterAndroid localCallLogAdapterAndroid = this.this$0;
    CallLogAdapterAndroid.CallLogAction localCallLogAction = CallLogAdapterAndroid.CallLogAction.notifyCallLogChanged();
    CallLogAdapterAndroid.access$500(localCallLogAdapterAndroid, localCallLogAction);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.CallLogAdapterAndroid.1
 * JD-Core Version:    0.6.0
 */