package com.softspb.shell.adapters;

public class ProgramListAdapterAndroid
{
  public static native void launcherDelete(String paramString);

  public static native void launcherDeleteWithClassName(String paramString1, String paramString2);

  public static native void launcherPut(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.ProgramListAdapterAndroid
 * JD-Core Version:    0.6.0
 */