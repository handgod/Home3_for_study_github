package com.softspb.shell.adapters;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import com.softspb.util.log.Logger;
import com.spb.contacts.IPhoneNumberResolvingService;
import com.spb.contacts.IPhoneNumberResolvingService.Stub;
import com.spb.contacts.IPhoneNumberResolvingServiceCallback;
import java.util.concurrent.CountDownLatch;

class MessagingAdapterAndroid$2
  implements ServiceConnection
{
  public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
  {
    Logger localLogger = MessagingAdapterAndroid.access$000();
    String str = "onServiceConnected: PhoneNumberService name=" + paramComponentName;
    localLogger.d(str);
    MessagingAdapterAndroid localMessagingAdapterAndroid = this.this$0;
    IPhoneNumberResolvingService localIPhoneNumberResolvingService1 = IPhoneNumberResolvingService.Stub.asInterface(paramIBinder);
    IPhoneNumberResolvingService localIPhoneNumberResolvingService2 = MessagingAdapterAndroid.access$202(localMessagingAdapterAndroid, localIPhoneNumberResolvingService1);
    try
    {
      IPhoneNumberResolvingService localIPhoneNumberResolvingService3 = MessagingAdapterAndroid.access$200(this.this$0);
      IPhoneNumberResolvingServiceCallback localIPhoneNumberResolvingServiceCallback = this.this$0.phoneNumberCallback;
      localIPhoneNumberResolvingService3.registerCallback(localIPhoneNumberResolvingServiceCallback);
      label79: MessagingAdapterAndroid.access$300(this.this$0).countDown();
      return;
    }
    catch (RemoteException localRemoteException)
    {
      break label79;
    }
  }

  public void onServiceDisconnected(ComponentName paramComponentName)
  {
    MessagingAdapterAndroid.access$000().d("onServiceDisconnected: PhoneNumberService");
    IPhoneNumberResolvingService localIPhoneNumberResolvingService = MessagingAdapterAndroid.access$202(this.this$0, null);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.MessagingAdapterAndroid.2
 * JD-Core Version:    0.6.0
 */