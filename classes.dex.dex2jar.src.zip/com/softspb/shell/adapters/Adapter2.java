package com.softspb.shell.adapters;

public abstract interface Adapter2
{
  public abstract void onStart();

  public abstract void onStop();
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.Adapter2
 * JD-Core Version:    0.6.0
 */