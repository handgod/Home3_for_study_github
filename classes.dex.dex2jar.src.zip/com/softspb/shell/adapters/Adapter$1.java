package com.softspb.shell.adapters;

class Adapter$1
  implements Runnable
{
  public void run()
  {
    this.this$0.onStartInUIThread();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.Adapter.1
 * JD-Core Version:    0.6.0
 */