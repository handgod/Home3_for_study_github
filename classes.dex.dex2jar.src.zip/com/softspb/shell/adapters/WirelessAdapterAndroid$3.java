package com.softspb.shell.adapters;

import android.bluetooth.BluetoothAdapter;
import java.util.Map;

class WirelessAdapterAndroid$3
  implements Runnable
{
  public void run()
  {
    WirelessAdapterAndroid localWirelessAdapterAndroid = this.this$0;
    BluetoothAdapter localBluetoothAdapter1 = BluetoothAdapter.getDefaultAdapter();
    BluetoothAdapter localBluetoothAdapter2 = WirelessAdapterAndroid.access$402(localWirelessAdapterAndroid, localBluetoothAdapter1);
    Map localMap = WirelessAdapterAndroid.access$500(this.this$0);
    Integer localInteger1 = Integer.valueOf(2);
    Integer localInteger2 = Integer.valueOf(this.this$0.getWirelessState(2));
    Object localObject = localMap.put(localInteger1, localInteger2);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.WirelessAdapterAndroid.3
 * JD-Core Version:    0.6.0
 */