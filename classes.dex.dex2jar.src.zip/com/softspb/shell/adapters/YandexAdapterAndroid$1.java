package com.softspb.shell.adapters;

import java.util.HashMap;

final class YandexAdapterAndroid$1 extends HashMap<Integer, String>
{
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.YandexAdapterAndroid.1
 * JD-Core Version:    0.6.0
 */