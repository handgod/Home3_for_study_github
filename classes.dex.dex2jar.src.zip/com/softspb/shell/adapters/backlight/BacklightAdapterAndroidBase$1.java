package com.softspb.shell.adapters.backlight;

import android.database.ContentObserver;
import android.os.Handler;

class BacklightAdapterAndroidBase$1 extends ContentObserver
{
  public void onChange(boolean paramBoolean)
  {
    BacklightAdapterAndroidBase.setLevelNative(this.this$0.getLevel());
    Handler localHandler = BacklightAdapterAndroidBase.access$000(this.this$0);
    BacklightAdapterAndroidBase localBacklightAdapterAndroidBase = this.this$0;
    boolean bool = localHandler.postDelayed(localBacklightAdapterAndroidBase, 100L);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.backlight.BacklightAdapterAndroidBase.1
 * JD-Core Version:    0.6.0
 */