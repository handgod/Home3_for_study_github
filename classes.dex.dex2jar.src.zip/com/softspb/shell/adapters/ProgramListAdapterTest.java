package com.softspb.shell.adapters;

import android.app.Activity;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;

public class ProgramListAdapterTest extends Activity
{
  private static Logger logger = Loggers.getLogger("programlistTester");
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.ProgramListAdapterTest
 * JD-Core Version:    0.6.0
 */