package com.softspb.shell.adapters;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import com.softspb.shell.opengl.NativeCallbacks;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import com.spb.programlist.ProgramsUtil;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import ru.yandex.searchplugin.MainActivity;
import ru.yandex.searchplugin.Utils;

public class YandexAdapterAndroid extends YandexSearchAdapter
{
  private static final String SEARCH_URI_TEMPLATE = "searchWidget://search/?source=%s";
  private static final Map<Integer, String> SOURCE_MAP;
  private static final Set<String> YANDEX_ISO_COUNTRIES;
  private static final Set<String> YANDEX_ISO_LANGS;
  private static String YANDEX_SEARCH_PACKAGE;
  private static final Logger logger = Loggers.getLogger(YandexAdapterAndroid.class);
  private static BroadcastReceiver packageInstall;
  private Context context;

  static
  {
    SOURCE_MAP = Collections.unmodifiableMap(new YandexAdapterAndroid.1());
    YANDEX_ISO_LANGS = Collections.unmodifiableSet(new YandexAdapterAndroid.2());
    YANDEX_ISO_COUNTRIES = Collections.unmodifiableSet(new YandexAdapterAndroid.3());
    YANDEX_SEARCH_PACKAGE = "ru.yandex.searchplugin";
    packageInstall = new YandexAdapterAndroid.4();
  }

  public YandexAdapterAndroid(AdaptersHolder paramAdaptersHolder)
  {
    super(paramAdaptersHolder);
  }

  private Intent getYandexIntent(String paramString1, String paramString2)
  {
    Context localContext = this.context;
    ComponentName localComponentName = new ComponentName(localContext, MainActivity.class);
    if (this.context.getPackageManager().getComponentEnabledSetting(localComponentName) == 2);
    for (String str1 = YANDEX_SEARCH_PACKAGE; ; str1 = this.context.getPackageName())
    {
      Intent localIntent = new Intent(paramString1).addCategory(paramString2);
      String str2 = MainActivity.class.getName();
      return localIntent.setClassName(str1, str2);
    }
  }

  private static boolean isYSearchInstalled(Context paramContext)
  {
    int i = 0;
    PackageManager localPackageManager = paramContext.getPackageManager();
    Intent localIntent1 = new Intent();
    String str1 = YANDEX_SEARCH_PACKAGE;
    String str2 = MainActivity.class.getName();
    Intent localIntent2 = localIntent1.setClassName(str1, str2);
    if (!localPackageManager.queryIntentActivities(localIntent1, i).isEmpty())
      i = 1;
    return i;
  }

  private static void setYComponentState(Context paramContext, int paramInt)
  {
    Logger localLogger = logger;
    Object[] arrayOfObject = new Object[1];
    Integer localInteger = Integer.valueOf(paramInt);
    arrayOfObject[0] = localInteger;
    localLogger.d("setYcomponent state: %d", arrayOfObject);
    PackageManager localPackageManager = paramContext.getPackageManager();
    ComponentName localComponentName = new ComponentName(paramContext, MainActivity.class);
    localPackageManager.setComponentEnabledSetting(localComponentName, paramInt, 1);
  }

  public boolean isVoiceSearchAvailable()
  {
    return Utils.voiceSearchV8APIAvailability(this.context);
  }

  public boolean isYandexCountry()
  {
    int i = 0;
    String str1 = Locale.getDefault().getLanguage();
    String str2 = Locale.getDefault().getCountry();
    Logger localLogger = logger;
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[i] = str1;
    arrayOfObject[1] = str2;
    localLogger.d("lang: %s, country: %s", arrayOfObject);
    if ((YANDEX_ISO_COUNTRIES.contains(str2)) || (YANDEX_ISO_LANGS.contains(str1)))
      i = 1;
    return i;
  }

  protected void onCreate(Context paramContext, NativeCallbacks paramNativeCallbacks)
  {
    this.context = paramContext;
    IntentFilter localIntentFilter = new IntentFilter();
    localIntentFilter.addAction("android.intent.action.PACKAGE_ADDED");
    localIntentFilter.addAction("android.intent.action.PACKAGE_REMOVED");
    localIntentFilter.addAction("android.intent.action.PACKAGE_CHANGED");
    localIntentFilter.addDataScheme("package");
    BroadcastReceiver localBroadcastReceiver = packageInstall;
    Intent localIntent = paramContext.registerReceiver(localBroadcastReceiver, localIntentFilter);
    if ((isYSearchInstalled(paramContext)) || (!isYandexCountry()))
      setYComponentState(paramContext, 2);
    while (true)
    {
      return;
      setYComponentState(paramContext, 1);
    }
  }

  protected void onDestroy(Context paramContext)
  {
    super.onDestroy(paramContext);
    BroadcastReceiver localBroadcastReceiver = packageInstall;
    paramContext.unregisterReceiver(localBroadcastReceiver);
  }

  public void startSearch(int paramInt)
  {
    Map localMap1 = SOURCE_MAP;
    Integer localInteger1 = Integer.valueOf(paramInt);
    if (!localMap1.containsKey(localInteger1))
    {
      Logger localLogger = logger;
      String str = "Starting search from unknown source " + paramInt;
      localLogger.e(str);
    }
    while (true)
    {
      return;
      Intent localIntent1 = getYandexIntent("android.intent.action.MAIN", "android.intent.category.DEFAULT");
      Object[] arrayOfObject = new Object[1];
      Map localMap2 = SOURCE_MAP;
      Integer localInteger2 = Integer.valueOf(paramInt);
      Object localObject = localMap2.get(localInteger2);
      arrayOfObject[0] = localObject;
      Uri localUri = Uri.parse(String.format("searchWidget://search/?source=%s", arrayOfObject));
      Intent localIntent2 = localIntent1.setData(localUri);
      ProgramsUtil.startActivitySafely(this.context, localIntent1);
    }
  }

  public void startVoiceSearch()
  {
    Intent localIntent1 = getYandexIntent("android.intent.action.MAIN", "android.intent.category.LAUNCHER");
    Object[] arrayOfObject = new Object[1];
    Map localMap = SOURCE_MAP;
    Integer localInteger = Integer.valueOf(SOURCE_WIDGET);
    Object localObject = localMap.get(localInteger);
    arrayOfObject[0] = localObject;
    String str = String.format("searchWidget://search/?source=%s", arrayOfObject);
    Uri localUri = Uri.parse(str + "&voice=true");
    Intent localIntent2 = localIntent1.setData(localUri);
    ProgramsUtil.startActivitySafely(this.context, localIntent1);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.YandexAdapterAndroid
 * JD-Core Version:    0.6.0
 */