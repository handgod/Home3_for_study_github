package com.softspb.shell.adapters;

import android.os.RemoteException;
import android.util.SparseIntArray;
import com.spb.contacts.IContactsServiceCallback.Stub;

class ContactsAdapterAndroid$1 extends IContactsServiceCallback.Stub
{
  public void onBirthdayDeleted(int paramInt)
  {
    ContactsAdapterAndroid localContactsAdapterAndroid = this.this$0;
    String str = "IContactsServiceCallback.onBirthdayDeleted: dataId=" + paramInt;
    ContactsAdapterAndroid.access$000(localContactsAdapterAndroid, str);
    ContactsAdapterAndroid.access$100(this.this$0);
    ContactsAdapterAndroid.access$500(this.this$0.contactsAdapterToken, paramInt);
  }

  public void onBirthdayUpdated(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    ContactsAdapterAndroid localContactsAdapterAndroid = this.this$0;
    String str = "IContactsServiceCallback.onBirthdayUpdated: type=" + paramInt1 + " contactId=" + paramInt2 + " dataId=" + paramInt3 + " year=" + paramInt4 + " month=" + paramInt5 + " dayOfMonth=" + paramInt6;
    ContactsAdapterAndroid.access$000(localContactsAdapterAndroid, str);
    int i = ContactsAdapterAndroid.eventType2NativeEventType(paramInt1);
    ContactsAdapterAndroid.access$100(this.this$0);
    int j = this.this$0.contactsAdapterToken;
    int k = paramInt2;
    int m = paramInt3;
    int n = paramInt4;
    int i1 = paramInt5;
    int i2 = paramInt6;
    ContactsAdapterAndroid.access$300(j, i, k, m, n, i1, i2);
  }

  public void onConnectionDeleted(int paramInt1, int paramInt2, int paramInt3)
    throws RemoteException
  {
    ContactsAdapterAndroid localContactsAdapterAndroid = this.this$0;
    String str = "IContactsServiceCallback.onConnectionDeleted: contactId=" + paramInt1 + " connectionId=" + paramInt2 + " kind=" + paramInt3;
    ContactsAdapterAndroid.access$000(localContactsAdapterAndroid, str);
    ContactsAdapterAndroid.access$100(this.this$0);
    if (paramInt3 == 2);
    for (paramInt3 = 1; ; paramInt3 = 0)
    {
      ContactsAdapterAndroid.access$700(this.this$0.contactsAdapterToken, paramInt1, paramInt2, paramInt3);
      return;
    }
  }

  public void onConnectionUpdated(int paramInt1, int paramInt2, String paramString1, int paramInt3, String paramString2, String paramString3, int paramInt4)
    throws RemoteException
  {
    ContactsAdapterAndroid localContactsAdapterAndroid = this.this$0;
    String str1 = "IContactsServiceCallback.onConnectionUpdated: contactId=" + paramInt1 + " dataId=" + paramInt2 + " mimetype=" + paramString1 + " locationType=" + paramInt3 + " numberAddress=" + paramString2 + " label=" + paramString3 + " dataVersion=" + paramInt4;
    ContactsAdapterAndroid.access$000(localContactsAdapterAndroid, str1);
    ContactsAdapterAndroid.access$100(this.this$0);
    int i = ContactsAdapterAndroid.locationType2NativeLocationType(paramInt3);
    int j = ContactsAdapterAndroid.dataMimetype2NativeAddressType(paramString1);
    int k = this.this$0.contactsAdapterToken;
    int m = paramInt1;
    int n = paramInt2;
    int i1 = i;
    String str2 = paramString2;
    String str3 = paramString3;
    int i2 = paramInt4;
    ContactsAdapterAndroid.access$800(k, m, n, j, i1, str2, str3, i2);
  }

  public void onContactDeleted(int paramInt1, int paramInt2)
    throws RemoteException
  {
    ContactsAdapterAndroid localContactsAdapterAndroid = this.this$0;
    String str = "IContactsServiceCallback.onContactDeleted: contactId=" + paramInt1 + " kind=" + paramInt2;
    ContactsAdapterAndroid.access$000(localContactsAdapterAndroid, str);
    this.this$0.contactIds.delete(paramInt1);
    ContactsAdapterAndroid.access$100(this.this$0);
    if (paramInt2 == 2);
    for (paramInt2 = 1; ; paramInt2 = 0)
    {
      ContactsAdapterAndroid.access$900(this.this$0.contactsAdapterToken, paramInt1, paramInt2);
      return;
    }
  }

  public void onContactPhotoUpdated(int paramInt1, int paramInt2, int paramInt3)
    throws RemoteException
  {
    ContactsAdapterAndroid localContactsAdapterAndroid = this.this$0;
    String str = "IContactsServiceCallback.onContactPhotoUpdated: contactId=" + paramInt1 + " datatId=" + paramInt2 + " dataVersion=" + paramInt3;
    ContactsAdapterAndroid.access$000(localContactsAdapterAndroid, str);
    ContactsAdapterAndroid.access$100(this.this$0);
    ContactsAdapterAndroid.access$600(this.this$0.contactsAdapterToken, paramInt1, paramInt2, paramInt3);
  }

  public void onContactUpdated(int paramInt1, String paramString1, String paramString2, boolean paramBoolean, int paramInt2, int paramInt3)
    throws RemoteException
  {
    ContactsAdapterAndroid localContactsAdapterAndroid = this.this$0;
    String str1 = "IContactsServiceCallback.onContactUpdated: contactId=" + paramInt1 + " lookupKey=" + paramString1 + " displayName=" + paramString2 + " isStarred=" + paramBoolean + " photoId=" + paramInt2 + " photoVersion=" + paramInt3;
    ContactsAdapterAndroid.access$000(localContactsAdapterAndroid, str1);
    this.this$0.contactIds.put(paramInt1, 1);
    ContactsAdapterAndroid.access$100(this.this$0);
    int i = this.this$0.contactsAdapterToken;
    int j = paramInt1;
    String str2 = paramString1;
    String str3 = paramString2;
    boolean bool = paramBoolean;
    int k = paramInt2;
    int m = paramInt3;
    ContactsAdapterAndroid.access$1000(i, j, str2, str3, bool, k, m);
  }

  public void onEventDeleted(int paramInt1, int paramInt2, int paramInt3)
    throws RemoteException
  {
    ContactsAdapterAndroid localContactsAdapterAndroid = this.this$0;
    String str = "IContactsServiceCallback.onEventDeleted: contactId=" + paramInt1 + " eventId=" + paramInt2 + " kind=" + paramInt3;
    ContactsAdapterAndroid.access$000(localContactsAdapterAndroid, str);
    ContactsAdapterAndroid.access$100(this.this$0);
    if (paramInt3 == 2);
    for (paramInt3 = 1; ; paramInt3 = 0)
    {
      ContactsAdapterAndroid.access$1200(this.this$0.contactsAdapterToken, paramInt1, paramInt2, paramInt3);
      return;
    }
  }

  public void onEventUpdated(int paramInt1, int paramInt2, int paramInt3, long paramLong, int paramInt4)
    throws RemoteException
  {
    ContactsAdapterAndroid localContactsAdapterAndroid = this.this$0;
    String str = "IContactsServiceCallback.onEventUpdated: contactId=" + paramInt1 + " dataId=" + paramInt2 + " eventType=" + paramInt3 + " eventDate=" + paramLong + " dataVersion=" + paramInt4;
    ContactsAdapterAndroid.access$000(localContactsAdapterAndroid, str);
    ContactsAdapterAndroid.access$100(this.this$0);
    int i = ContactsAdapterAndroid.eventType2NativeEventType(paramInt3);
    int j = this.this$0.contactsAdapterToken;
    int k = paramInt1;
    int m = paramInt2;
    int n = i;
    long l = paramLong;
    int i1 = paramInt4;
    ContactsAdapterAndroid.access$1300(j, k, m, n, l, i1);
  }

  public void onFinishedReload(int paramInt)
    throws RemoteException
  {
    ContactsAdapterAndroid localContactsAdapterAndroid = this.this$0;
    String str = "IContactsServiceCallback.onFinishedReload: kind=" + paramInt;
    ContactsAdapterAndroid.access$000(localContactsAdapterAndroid, str);
    ContactsAdapterAndroid.access$100(this.this$0);
    if (paramInt == 2);
    for (paramInt = 1; ; paramInt = 0)
    {
      ContactsAdapterAndroid.access$1600(this.this$0.contactsAdapterToken, paramInt);
      return;
    }
  }

  public void onFinishedReloadingBirthdays()
    throws RemoteException
  {
    ContactsAdapterAndroid.access$000(this.this$0, "IContactsServiceCallback.onFinishedReloadingBirthdays");
    ContactsAdapterAndroid.access$100(this.this$0);
    ContactsAdapterAndroid.access$400(this.this$0.contactsAdapterToken);
  }

  public void onFinishedUpdatingContact(int paramInt1, int paramInt2)
    throws RemoteException
  {
    ContactsAdapterAndroid localContactsAdapterAndroid = this.this$0;
    String str = "IContactsServiceCallback.onFinishedUpdatingContact: contactId=" + paramInt1 + " kind=" + paramInt2;
    ContactsAdapterAndroid.access$000(localContactsAdapterAndroid, str);
    ContactsAdapterAndroid.access$100(this.this$0);
    if (paramInt2 == 2);
    for (paramInt2 = 1; ; paramInt2 = 0)
    {
      ContactsAdapterAndroid.access$1400(this.this$0.contactsAdapterToken, paramInt1, paramInt2);
      return;
    }
  }

  public void onStartedReload(int paramInt)
    throws RemoteException
  {
    ContactsAdapterAndroid localContactsAdapterAndroid = this.this$0;
    String str = "IContactsServiceCallback.onStartedReload: kind=" + paramInt;
    ContactsAdapterAndroid.access$000(localContactsAdapterAndroid, str);
    ContactsAdapterAndroid.access$100(this.this$0);
    if (paramInt == 2);
    for (paramInt = 1; ; paramInt = 0)
    {
      ContactsAdapterAndroid.access$1700(this.this$0.contactsAdapterToken, paramInt);
      return;
    }
  }

  public void onStartedReloadingBirthdays()
    throws RemoteException
  {
    ContactsAdapterAndroid.access$000(this.this$0, "IContactsServiceCallback.onStartedReloadingBirthdays");
    ContactsAdapterAndroid.access$100(this.this$0);
    ContactsAdapterAndroid.access$200(this.this$0.contactsAdapterToken);
  }

  public void onStartedUpdatingContact(int paramInt1, int paramInt2)
    throws RemoteException
  {
    ContactsAdapterAndroid localContactsAdapterAndroid = this.this$0;
    String str = "IContactsServiceCallback.onStartedUpdatingContact: contactId=" + paramInt1 + " kind=" + paramInt2;
    ContactsAdapterAndroid.access$000(localContactsAdapterAndroid, str);
    ContactsAdapterAndroid.access$100(this.this$0);
    if (paramInt2 == 2);
    for (paramInt2 = 1; ; paramInt2 = 0)
    {
      ContactsAdapterAndroid.access$1500(this.this$0.contactsAdapterToken, paramInt1, paramInt2);
      return;
    }
  }

  public void onStructuredNameUpdated(int paramInt, String paramString1, String paramString2)
    throws RemoteException
  {
    ContactsAdapterAndroid localContactsAdapterAndroid = this.this$0;
    String str = "IContactsServiceCallback.onStructuredNameUpdated: contactId=" + paramInt + " firstName=" + paramString1 + " lastName=" + paramString2;
    ContactsAdapterAndroid.access$000(localContactsAdapterAndroid, str);
    ContactsAdapterAndroid.access$100(this.this$0);
    ContactsAdapterAndroid.access$1100(this.this$0.contactsAdapterToken, paramInt, paramString1, paramString2);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.ContactsAdapterAndroid.1
 * JD-Core Version:    0.6.0
 */