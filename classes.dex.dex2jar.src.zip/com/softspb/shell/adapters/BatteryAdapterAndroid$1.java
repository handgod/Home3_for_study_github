package com.softspb.shell.adapters;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.softspb.util.log.Logger;

class BatteryAdapterAndroid$1 extends BroadcastReceiver
{
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    BatteryAdapterAndroid.access$000().d(">>>onReceive");
    int i;
    switch (paramIntent.getIntExtra("status", -1))
    {
    default:
      i = 1;
    case 2:
    case 3:
    case 5:
    case 4:
    }
    while (true)
    {
      int j = paramIntent.getIntExtra("level", 0);
      int k = paramIntent.getIntExtra("scale", 0);
      BatteryAdapterAndroid.access$100(this.this$0, i, j, k);
      BatteryAdapterAndroid.access$000().d("<<<onReceive");
      return;
      i = 2;
      continue;
      i = 3;
      continue;
      i = 5;
      continue;
      i = 4;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.BatteryAdapterAndroid.1
 * JD-Core Version:    0.6.0
 */