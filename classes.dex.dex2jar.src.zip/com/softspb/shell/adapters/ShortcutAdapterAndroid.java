package com.softspb.shell.adapters;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.Intent.ShortcutIconResource;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Parcelable;
import android.util.Log;
import com.softspb.shell.data.ShortcutInfo;
import com.softspb.shell.data.WidgetsContract.ShortcutInfoContract;
import com.softspb.shell.opengl.NativeCallbacks;
import com.softspb.shell.util.orm.CursorDataAdapter;
import com.softspb.shell.util.orm.DataBuilder;
import com.softspb.util.CollectionFactory;
import com.softspb.util.broadcastreceiver.DecoratedBroadcastReceiver;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ShortcutAdapterAndroid extends ShortcutAdapter
{
  private static final String ACTION_INSTALL_SHORTCUT = "com.android.launcher.action.INSTALL_SHORTCUT";
  private int adapterToken;
  private DataBuilder<ShortcutInfo> builder;
  private Context context;
  private DecoratedBroadcastReceiver installShortcutReceiver;
  private Lock lock;
  private Set<ShortcutInfo> notInited;
  private ContentResolver resolver;
  private Uri shortcutsContentUri;

  public ShortcutAdapterAndroid(AdaptersHolder paramAdaptersHolder)
  {
    super(paramAdaptersHolder);
    DataBuilder localDataBuilder = DataBuilder.createBuilder(ShortcutInfo.class);
    this.builder = localDataBuilder;
    ReentrantLock localReentrantLock = new ReentrantLock();
    this.lock = localReentrantLock;
    HashSet localHashSet = CollectionFactory.newHashSet();
    this.notInited = localHashSet;
    ShortcutAdapterAndroid.1 local1 = new ShortcutAdapterAndroid.1(this);
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver = new DecoratedBroadcastReceiver("com.android.launcher.action.INSTALL_SHORTCUT", local1);
    this.installShortcutReceiver = localDecoratedBroadcastReceiver;
  }

  public static native void addShortcut(int paramInt1, boolean paramBoolean, int paramInt2, String paramString1, String paramString2, String paramString3);

  public static native void deleteShortcut(int paramInt1, int paramInt2);

  private String getPackageName(Intent paramIntent)
  {
    ResolveInfo localResolveInfo = this.context.getPackageManager().resolveActivity(paramIntent, 0);
    if ((localResolveInfo == null) || (localResolveInfo.activityInfo == null) || (localResolveInfo.activityInfo.packageName == null));
    for (String str1 = ""; ; str1 = localResolveInfo.activityInfo.packageName)
    {
      return str1;
      StringBuilder localStringBuilder = new StringBuilder().append("package ");
      String str2 = localResolveInfo.activityInfo.packageName;
      String str3 = str2;
      int i = Log.i("shortcuts resolve", str3);
    }
  }

  private boolean init(ShortcutInfo paramShortcutInfo)
  {
    Intent localIntent = paramShortcutInfo.getIntent();
    String str1 = getPackageName(localIntent);
    if (str1.length() == 0);
    for (int i = 0; ; i = 1)
    {
      return i;
      int j = this.adapterToken;
      int k = paramShortcutInfo.getId();
      String str2 = paramShortcutInfo.getTitle();
      Context localContext = this.context;
      String str3 = paramShortcutInfo.getImageUri(localContext).toString();
      initShortcut(j, k, str2, str3, str1);
    }
  }

  public static native void initShortcut(int paramInt1, int paramInt2, String paramString1, String paramString2, String paramString3);

  public void addShortcut(Intent paramIntent, boolean paramBoolean)
  {
    String str1 = paramIntent.getStringExtra("android.intent.extra.shortcut.NAME");
    Intent localIntent = (Intent)paramIntent.getParcelableExtra("android.intent.extra.shortcut.INTENT");
    ShortcutInfo localShortcutInfo = new ShortcutInfo(str1, localIntent);
    Parcelable localParcelable1 = paramIntent.getParcelableExtra("android.intent.extra.shortcut.ICON");
    if ((localParcelable1 instanceof Bitmap))
    {
      Bitmap localBitmap = (Bitmap)localParcelable1;
      localShortcutInfo.setIcon(localBitmap);
    }
    try
    {
      while (true)
      {
        ContentResolver localContentResolver = this.resolver;
        Uri localUri = this.shortcutsContentUri;
        ContentValues localContentValues = localShortcutInfo.toContentValues();
        String str2 = localContentResolver.insert(localUri, localContentValues).getLastPathSegment();
        int i = new Integer(str2).intValue();
        localShortcutInfo.setId(i);
        int j = this.adapterToken;
        String str3 = localShortcutInfo.getTitle();
        Context localContext = this.context;
        String str4 = localShortcutInfo.getImageUri(localContext).toString();
        String str5 = getPackageName(localIntent);
        boolean bool = paramBoolean;
        addShortcut(j, bool, i, str3, str4, str5);
        return;
        Parcelable localParcelable2 = paramIntent.getParcelableExtra("android.intent.extra.shortcut.ICON_RESOURCE");
        if (!(localParcelable2 instanceof Intent.ShortcutIconResource))
          continue;
        Intent.ShortcutIconResource localShortcutIconResource = (Intent.ShortcutIconResource)localParcelable2;
        localShortcutInfo.setIconResource(localShortcutIconResource);
      }
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
  }

  public void launch(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    Uri localUri1 = this.shortcutsContentUri;
    long l = paramInt1;
    Uri localUri2 = ContentUris.withAppendedId(localUri1, l);
    ContentResolver localContentResolver = this.resolver;
    String str1 = null;
    String[] arrayOfString = null;
    String str2 = null;
    Cursor localCursor = localContentResolver.query(localUri2, null, str1, arrayOfString, str2);
    if (localCursor == null);
    while (true)
    {
      return;
      if (!localCursor.moveToFirst())
      {
        localCursor.close();
        continue;
      }
      try
      {
        DataBuilder localDataBuilder = this.builder;
        CursorDataAdapter localCursorDataAdapter = new CursorDataAdapter(localCursor);
        Intent localIntent = ((ShortcutInfo)localDataBuilder.newInstance(localCursorDataAdapter)).getIntent();
        Rect localRect = new Rect(paramInt2, paramInt3, paramInt4, paramInt5);
        localIntent.setSourceBounds(localRect);
        this.context.startActivity(localIntent);
        localCursor.close();
      }
      catch (Exception localException)
      {
        while (true)
          localException.printStackTrace();
      }
    }
  }

  protected void onCreate(Context paramContext, NativeCallbacks paramNativeCallbacks)
  {
    super.onCreate(paramContext, paramNativeCallbacks);
    this.context = paramContext;
    ContentResolver localContentResolver = paramContext.getContentResolver();
    this.resolver = localContentResolver;
    Uri localUri = WidgetsContract.ShortcutInfoContract.getContentUri(paramContext);
    this.shortcutsContentUri = localUri;
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver1 = this.installShortcutReceiver;
    ShortcutAdapterAndroid.2 local2 = new ShortcutAdapterAndroid.2(this);
    localDecoratedBroadcastReceiver1.addActionListener("android.intent.action.EXTERNAL_APPLICATIONS_AVAILABLE", local2);
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver2 = this.installShortcutReceiver;
    IntentFilter localIntentFilter = this.installShortcutReceiver.getIntentFilter();
    Intent localIntent = paramContext.registerReceiver(localDecoratedBroadcastReceiver2, localIntentFilter);
  }

  protected void onDestroy(Context paramContext)
  {
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver = this.installShortcutReceiver;
    paramContext.unregisterReceiver(localDecoratedBroadcastReceiver);
  }

  // ERROR //
  protected void onStart(int paramInt)
  {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: putfield 146	com/softspb/shell/adapters/ShortcutAdapterAndroid:adapterToken	I
    //   5: aload_0
    //   6: getfield 193	com/softspb/shell/adapters/ShortcutAdapterAndroid:resolver	Landroid/content/ContentResolver;
    //   9: astore_2
    //   10: aload_0
    //   11: getfield 195	com/softspb/shell/adapters/ShortcutAdapterAndroid:shortcutsContentUri	Landroid/net/Uri;
    //   14: astore_3
    //   15: aconst_null
    //   16: astore 4
    //   18: aconst_null
    //   19: astore 5
    //   21: aconst_null
    //   22: astore 6
    //   24: aload_2
    //   25: aload_3
    //   26: aconst_null
    //   27: aload 4
    //   29: aload 5
    //   31: aload 6
    //   33: invokevirtual 245	android/content/ContentResolver:query	(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   36: astore 7
    //   38: aload 7
    //   40: ifnonnull +4 -> 44
    //   43: return
    //   44: aload_0
    //   45: getfield 48	com/softspb/shell/adapters/ShortcutAdapterAndroid:lock	Ljava/util/concurrent/locks/Lock;
    //   48: invokeinterface 322 1 0
    //   53: aload 7
    //   55: invokeinterface 325 1 0
    //   60: istore 8
    //   62: iload 8
    //   64: ifeq +104 -> 168
    //   67: aload_0
    //   68: getfield 41	com/softspb/shell/adapters/ShortcutAdapterAndroid:builder	Lcom/softspb/shell/util/orm/DataBuilder;
    //   71: astore 9
    //   73: new 256	com/softspb/shell/util/orm/CursorDataAdapter
    //   76: dup
    //   77: aload 7
    //   79: invokespecial 259	com/softspb/shell/util/orm/CursorDataAdapter:<init>	(Landroid/database/Cursor;)V
    //   82: astore 10
    //   84: aload 9
    //   86: aload 10
    //   88: invokevirtual 263	com/softspb/shell/util/orm/DataBuilder:newInstance	(Lcom/softspb/shell/util/orm/DataProvider;)Ljava/lang/Object;
    //   91: checkcast 33	com/softspb/shell/data/ShortcutInfo
    //   94: astore 11
    //   96: aload_0
    //   97: aload 11
    //   99: invokespecial 78	com/softspb/shell/adapters/ShortcutAdapterAndroid:init	(Lcom/softspb/shell/data/ShortcutInfo;)Z
    //   102: ifne -49 -> 53
    //   105: aload_0
    //   106: getfield 56	com/softspb/shell/adapters/ShortcutAdapterAndroid:notInited	Ljava/util/Set;
    //   109: aload 11
    //   111: invokeinterface 331 2 0
    //   116: istore 12
    //   118: goto -65 -> 53
    //   121: astore 13
    //   123: aload 13
    //   125: invokevirtual 332	java/lang/InstantiationException:printStackTrace	()V
    //   128: goto -75 -> 53
    //   131: astore 14
    //   133: aload 7
    //   135: invokeinterface 254 1 0
    //   140: aload_0
    //   141: getfield 48	com/softspb/shell/adapters/ShortcutAdapterAndroid:lock	Ljava/util/concurrent/locks/Lock;
    //   144: invokeinterface 335 1 0
    //   149: aload 14
    //   151: athrow
    //   152: astore 13
    //   154: aload 13
    //   156: invokevirtual 336	java/lang/IllegalAccessException:printStackTrace	()V
    //   159: goto -106 -> 53
    //   162: invokevirtual 337	java/lang/reflect/InvocationTargetException:printStackTrace	()V
    //   165: goto -112 -> 53
    //   168: aload 7
    //   170: invokeinterface 254 1 0
    //   175: aload_0
    //   176: getfield 48	com/softspb/shell/adapters/ShortcutAdapterAndroid:lock	Ljava/util/concurrent/locks/Lock;
    //   179: invokeinterface 335 1 0
    //   184: goto -141 -> 43
    //
    // Exception table:
    //   from	to	target	type
    //   67	118	121	java/lang/InstantiationException
    //   44	62	131	finally
    //   67	118	131	finally
    //   123	128	131	finally
    //   154	165	131	finally
    //   67	118	152	java/lang/IllegalAccessException
    //   67	118	162	java/lang/reflect/InvocationTargetException
  }

  protected void onStop()
  {
    this.adapterToken = 0;
    super.onStop();
  }

  public void remove(int paramInt)
  {
    Uri localUri1 = this.shortcutsContentUri;
    long l = paramInt;
    Uri localUri2 = ContentUris.withAppendedId(localUri1, l);
    try
    {
      int i = this.resolver.delete(localUri2, null, null);
      deleteShortcut(this.adapterToken, paramInt);
      return;
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.ShortcutAdapterAndroid
 * JD-Core Version:    0.6.0
 */