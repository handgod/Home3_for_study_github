package com.softspb.shell.adapters;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.softspb.util.log.Logger;

class SoundProfileAdapterAndroid$1 extends BroadcastReceiver
{
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    SoundProfileAdapterAndroid.access$000().d(">>>onReceive");
    this.this$0.notifyChange();
    SoundProfileAdapterAndroid.access$000().d("<<<onReceive");
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.SoundProfileAdapterAndroid.1
 * JD-Core Version:    0.6.0
 */