package com.softspb.shell.adapters;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import com.spb.contacts.IContactsService;
import com.spb.contacts.IContactsService.Stub;
import com.spb.contacts.IContactsServiceCallback;
import java.util.concurrent.CountDownLatch;

class ContactsAdapterAndroid$3
  implements ServiceConnection
{
  public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
  {
    ContactsAdapterAndroid localContactsAdapterAndroid1 = this.this$0;
    String str1 = "onServiceConnected: ContactsService name=" + paramComponentName;
    ContactsAdapterAndroid.access$000(localContactsAdapterAndroid1, str1);
    ContactsAdapterAndroid localContactsAdapterAndroid2 = this.this$0;
    StringBuilder localStringBuilder1 = new StringBuilder().append("onServiceConnected: ContactsService Thread ");
    long l = Thread.currentThread().getId();
    StringBuilder localStringBuilder2 = localStringBuilder1.append(l).append(" ");
    String str2 = Thread.currentThread().getName();
    String str3 = str2;
    ContactsAdapterAndroid.access$000(localContactsAdapterAndroid2, str3);
    ContactsAdapterAndroid localContactsAdapterAndroid3 = this.this$0;
    IContactsService localIContactsService1 = IContactsService.Stub.asInterface(paramIBinder);
    localContactsAdapterAndroid3.contactsService = localIContactsService1;
    try
    {
      IContactsService localIContactsService2 = this.this$0.contactsService;
      IContactsServiceCallback localIContactsServiceCallback = ContactsAdapterAndroid.access$1900(this.this$0);
      localIContactsService2.registerCallback(localIContactsServiceCallback);
      label147: this.this$0.serviceConnectionCountDown.countDown();
      return;
    }
    catch (RemoteException localRemoteException)
    {
      break label147;
    }
  }

  public void onServiceDisconnected(ComponentName paramComponentName)
  {
    ContactsAdapterAndroid.access$000(this.this$0, "onServiceDisconnected: ContactsService");
    this.this$0.contactsService = null;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.ContactsAdapterAndroid.3
 * JD-Core Version:    0.6.0
 */