package com.softspb.shell.adapters;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

class NetworkAdapterAndroid$2
  implements Runnable
{
  public void run()
  {
    while (true)
    {
      char[] arrayOfChar;
      StringBuilder localStringBuilder1;
      int i;
      try
      {
        ServerSocket localServerSocket = new ServerSocket(18093);
        arrayOfChar = new char[32000];
        Socket localSocket = localServerSocket.accept();
        InputStream localInputStream = localSocket.getInputStream();
        InputStreamReader localInputStreamReader = new InputStreamReader(localInputStream);
        BufferedReader localBufferedReader = new BufferedReader(localInputStreamReader);
        OutputStream localOutputStream = localSocket.getOutputStream();
        PrintWriter localPrintWriter = new PrintWriter(localOutputStream, 1);
        localStringBuilder1 = new StringBuilder();
        i = localBufferedReader.read(arrayOfChar);
        if (i <= 0)
          continue;
        if (i > 0)
        {
          int j = i + -1;
          if (arrayOfChar[j] == 0)
          {
            int k = i + -1;
            StringBuilder localStringBuilder2 = localStringBuilder1.append(arrayOfChar, 0, k);
            String str = NetworkAdapterAndroid.onCmd(localStringBuilder1.toString());
            if ((str == null) || (str.length() <= 0))
              continue;
            localPrintWriter.println(str);
            localPrintWriter.flush();
            localSocket.close();
            continue;
          }
        }
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
        return;
      }
      int m = 0;
      StringBuilder localStringBuilder3 = localStringBuilder1.append(arrayOfChar, m, i);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.NetworkAdapterAndroid.2
 * JD-Core Version:    0.6.0
 */