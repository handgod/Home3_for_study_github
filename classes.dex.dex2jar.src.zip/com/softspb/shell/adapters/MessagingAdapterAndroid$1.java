package com.softspb.shell.adapters;

import android.os.RemoteException;
import com.softspb.util.log.Logger;
import com.spb.contacts.IPhoneNumberResolvingServiceCallback.Stub;

class MessagingAdapterAndroid$1 extends IPhoneNumberResolvingServiceCallback.Stub
{
  public void onResolvedPhonesChanged(int paramInt)
    throws RemoteException
  {
    Logger localLogger = MessagingAdapterAndroid.access$000();
    String str = "onResolvedPhonesChanged: contactId=" + paramInt;
    localLogger.d(str);
    MessagingAdapterAndroid.access$100(this.this$0, paramInt);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.MessagingAdapterAndroid.1
 * JD-Core Version:    0.6.0
 */