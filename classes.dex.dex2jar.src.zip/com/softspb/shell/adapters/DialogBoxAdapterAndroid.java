package com.softspb.shell.adapters;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnDismissListener;
import android.os.Handler;
import android.os.IBinder;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.TextView;
import com.softspb.shell.opengl.NativeCallbacks;
import com.softspb.util.CollectionFactory;
import com.spb.shell3d.R.id;
import com.spb.shell3d.R.layout;
import com.spb.shell3d.R.string;
import java.util.ArrayList;
import java.util.List;

public class DialogBoxAdapterAndroid extends DialogBoxAdapter
{
  private static final int[] checkboxViewIds;
  private Context context;
  private List<DialogBoxInstance> list;
  private Handler myUiHandler;

  static
  {
    int[] arrayOfInt = new int[4];
    int i = R.id.dialog_box_checkbox01;
    arrayOfInt[0] = i;
    int j = R.id.dialog_box_checkbox02;
    arrayOfInt[1] = j;
    int k = R.id.dialog_box_checkbox03;
    arrayOfInt[2] = k;
    int m = R.id.dialog_box_checkbox04;
    arrayOfInt[3] = m;
    checkboxViewIds = arrayOfInt;
  }

  public DialogBoxAdapterAndroid(AdaptersHolder paramAdaptersHolder)
  {
    super(paramAdaptersHolder);
    ArrayList localArrayList = CollectionFactory.newArrayList();
    this.list = localArrayList;
  }

  public void closeAllDialogs()
  {
    int i = this.list.size() + -1;
    while (true)
    {
      if (i >= 0);
      try
      {
        AlertDialog localAlertDialog = ((DialogBoxInstance)this.list.get(i)).dialog;
        if (localAlertDialog != null)
          localAlertDialog.dismiss();
        label42: i += -1;
        continue;
        return;
      }
      catch (Exception localException)
      {
        break label42;
      }
    }
  }

  protected void onCreate(Context paramContext, NativeCallbacks paramNativeCallbacks)
  {
    super.onCreate(paramContext, paramNativeCallbacks);
    this.context = paramContext;
  }

  protected void onStartInUIThread()
  {
    Handler localHandler = new Handler();
    this.myUiHandler = localHandler;
  }

  public boolean startDialogBox(int paramInt1, String paramString1, String paramString2, String paramString3, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, String paramString4, int[] paramArrayOfInt1, String[] paramArrayOfString, int[] paramArrayOfInt2)
  {
    DialogBoxAdapterAndroid localDialogBoxAdapterAndroid = this;
    int i = paramInt1;
    String str1 = paramString1;
    String str2 = paramString2;
    String str3 = paramString3;
    int j = paramInt2;
    int k = paramInt3;
    boolean bool1 = paramBoolean1;
    boolean bool2 = paramBoolean2;
    String str4 = paramString4;
    int[] arrayOfInt1 = paramArrayOfInt1;
    String[] arrayOfString = paramArrayOfString;
    int[] arrayOfInt2 = paramArrayOfInt2;
    DialogBoxInstance localDialogBoxInstance = new DialogBoxInstance(i, str1, str2, str3, j, k, bool1, bool2, str4, arrayOfInt1, arrayOfString, arrayOfInt2);
    boolean bool3 = this.list.add(localDialogBoxInstance);
    Handler localHandler = this.myUiHandler;
    DialogBoxAdapterAndroid.1 local1 = new DialogBoxAdapterAndroid.1(this, localDialogBoxInstance);
    boolean bool4 = localHandler.post(local1);
    return true;
  }

  public class DialogBoxInstance
    implements DialogInterface.OnClickListener, DialogInterface.OnDismissListener, DialogInterface.OnCancelListener, CompoundButton.OnCheckedChangeListener, TextWatcher
  {
    private final int buttons;
    private final int[] checkboxFlags;
    private final int[] checkboxIds;
    private final String[] checkboxTitles;
    private CheckBox[] checkboxes;
    private boolean closed = 0;
    private final String defaultValue;
    private AlertDialog dialog;
    private EditText editView;
    private final boolean forbidEmpty;
    private final String greyedText;
    private final int icon;
    private final boolean isInput;
    private final int nativeId;
    private final String text;
    private final String title;

    static
    {
      if (!DialogBoxAdapterAndroid.class.desiredAssertionStatus());
      for (int i = 1; ; i = 0)
      {
        $assertionsDisabled = i;
        return;
      }
    }

    DialogBoxInstance(int paramString1, String paramString2, String paramString3, String paramInt1, int paramInt2, int paramBoolean1, boolean paramBoolean2, boolean paramString4, String paramArrayOfInt1, int[] paramArrayOfString, String[] paramArrayOfInt2, int[] arg13)
    {
      this.nativeId = paramString1;
      this.title = paramString2;
      this.text = paramString3;
      this.defaultValue = paramInt1;
      this.buttons = paramInt2;
      this.icon = paramBoolean1;
      this.isInput = paramBoolean2;
      this.forbidEmpty = paramString4;
      this.greyedText = paramArrayOfInt1;
      this.checkboxIds = paramArrayOfString;
      this.checkboxTitles = paramArrayOfInt2;
      Object localObject;
      this.checkboxFlags = localObject;
      if (!$assertionsDisabled)
      {
        int i = paramArrayOfString.length;
        int j = paramArrayOfInt2.length;
        if (i == j)
        {
          int k = paramArrayOfString.length;
          int m = localObject.length;
          if (k == m);
        }
        else
        {
          throw new AssertionError();
        }
      }
    }

    private boolean isInputDisabled()
    {
      int i = 0;
      int j = 0;
      while (true)
      {
        int k = this.checkboxes.length;
        if (j < k)
        {
          if ((this.checkboxes[j].isChecked()) && ((this.checkboxFlags[j] & 0x1) != 0))
            i = 1;
        }
        else
          return i;
        j += 1;
      }
    }

    private void updateButtonState()
    {
      if (!this.forbidEmpty)
        return;
      if ((this.dialog != null) && (this.dialog.getButton(-1) != null))
        if ((!isInputDisabled()) && (this.editView.getText().toString().equals("")))
          break label71;
      label71: int j;
      for (int i = 1; ; j = 0)
      {
        this.dialog.getButton(-1).setEnabled(i);
        break;
        break;
      }
    }

    private void updateCheckState()
    {
      int i = 0;
      boolean bool1 = isInputDisabled();
      if ((bool1) && (this.editView.isEnabled()))
      {
        EditText localEditText1 = this.editView;
        String str1 = this.editView.getText().toString();
        localEditText1.setTag(str1);
        EditText localEditText2 = this.editView;
        String str2 = this.greyedText;
        localEditText2.setText(str2);
      }
      if ((!bool1) && (!this.editView.isEnabled()))
      {
        String str3 = (String)this.editView.getTag();
        this.editView.setText(str3);
      }
      if (bool1)
      {
        InputMethodManager localInputMethodManager = (InputMethodManager)DialogBoxAdapterAndroid.this.context.getSystemService("input_method");
        IBinder localIBinder = this.editView.getWindowToken();
        boolean bool2 = localInputMethodManager.hideSoftInputFromWindow(localIBinder, 0);
      }
      EditText localEditText3 = this.editView;
      if (!bool1)
        i = 1;
      localEditText3.setEnabled(i);
    }

    public void afterTextChanged(Editable paramEditable)
    {
    }

    public void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3)
    {
    }

    public void onCancel(DialogInterface paramDialogInterface)
    {
      assert ((this.buttons & 0x8) != 0);
      sendDialogResult(8);
    }

    public void onCheckedChanged(CompoundButton paramCompoundButton, boolean paramBoolean)
    {
      updateCheckState();
    }

    public void onClick(DialogInterface paramDialogInterface, int paramInt)
    {
      if ((paramInt != -1) && (paramInt != -1));
      while (true)
      {
        return;
        i = 8;
        switch (paramInt)
        {
        default:
          sendDialogResult(i);
        case -1:
        case -2:
        }
      }
      if ((this.buttons & 0x2) != 0);
      for (int i = 2; ; i = 1)
        break;
      if ((this.buttons & 0x8) != 0);
      for (i = 8; ; i = 4)
        break;
    }

    public void onDismiss(DialogInterface paramDialogInterface)
    {
      this.closed = 1;
      boolean bool = DialogBoxAdapterAndroid.this.list.remove(this);
      this.dialog = null;
    }

    public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3)
    {
      updateButtonState();
    }

    public void sendDialogResult(int paramInt)
    {
      boolean bool = DialogBoxAdapterAndroid.this.list.remove(this);
      if (this.closed);
      while (true)
      {
        return;
        Object localObject = "";
        int i;
        if (this.isInput)
        {
          assert (this.editView != null);
          if (this.editView.isEnabled())
            localObject = this.editView.getText().toString();
        }
        else
        {
          i = 0;
          int j = 0;
          while (true)
          {
            int k = this.checkboxes.length;
            if (j >= k)
              break;
            if (this.checkboxes[j].isChecked())
            {
              int m = this.checkboxIds[j];
              int n = 1 << m;
              i |= n;
            }
            j += 1;
          }
        }
        String str = (String)this.editView.getTag();
        if (str != null);
        for (localObject = str; ; localObject = "")
          break;
        this.closed = 1;
        DialogBoxAdapterAndroid localDialogBoxAdapterAndroid = DialogBoxAdapterAndroid.this;
        int i1 = this.nativeId;
        localDialogBoxAdapterAndroid.onDialogResult(i1, paramInt, (String)localObject, i);
      }
    }

    void show()
    {
      int i = 0;
      assert (this.dialog == null);
      Context localContext = DialogBoxAdapterAndroid.this.context;
      AlertDialog.Builder localBuilder1 = new AlertDialog.Builder(localContext);
      int j = 0;
      View localView;
      label176: EditText localEditText5;
      switch (this.icon)
      {
      default:
        String str1 = this.title;
        AlertDialog.Builder localBuilder2 = localBuilder1.setTitle(str1);
        if (j != 0)
          AlertDialog.Builder localBuilder3 = localBuilder1.setIcon(j);
        LayoutInflater localLayoutInflater = LayoutInflater.from(DialogBoxAdapterAndroid.this.context);
        int k = R.layout.generic_dialog_box;
        localView = localLayoutInflater.inflate(k, null);
        int m = R.id.dialog_box_prompt;
        TextView localTextView = (TextView)localView.findViewById(m);
        String str2 = this.text;
        localTextView.setText(str2);
        if (!this.text.equals(""))
          break;
        n = 8;
        localTextView.setVisibility(n);
        int i2 = R.id.dialog_box_input;
        EditText localEditText1 = (EditText)localView.findViewById(i2);
        this.editView = localEditText1;
        EditText localEditText2 = this.editView;
        String str3 = this.defaultValue;
        localEditText2.setText(str3);
        EditText localEditText3 = this.editView;
        InputFilter[] arrayOfInputFilter = new InputFilter[1];
        DialogBoxAdapterAndroid.DialogBoxInstance.1 local1 = new DialogBoxAdapterAndroid.DialogBoxInstance.1(this);
        arrayOfInputFilter[0] = local1;
        localEditText3.setFilters(arrayOfInputFilter);
        EditText localEditText4 = this.editView;
        int i3 = this.editView.getText().length();
        localEditText4.setSelection(i3);
        this.editView.addTextChangedListener(this);
        localEditText5 = this.editView;
        if (this.isInput);
      case 1:
      case 2:
      case 3:
      }
      for (int n = 8; ; n = 0)
      {
        localEditText5.setVisibility(n);
        if ($assertionsDisabled)
          break label381;
        int i4 = this.checkboxIds.length;
        int i5 = DialogBoxAdapterAndroid.checkboxViewIds.length;
        if (i4 < i5)
          break label381;
        throw new AssertionError();
        j = 17301659;
        break;
        j = 17301543;
        break;
        n = 0;
        break label176;
      }
      label381: CheckBox[] arrayOfCheckBox = new CheckBox[this.checkboxIds.length];
      this.checkboxes = arrayOfCheckBox;
      int i6 = 0;
      int i7 = this.checkboxIds.length;
      CheckBox localCheckBox;
      int i1;
      if (i6 < i7)
      {
        int i8 = DialogBoxAdapterAndroid.checkboxViewIds[i6];
        localCheckBox = (CheckBox)localView.findViewById(i8);
        if ((this.checkboxFlags[i6] & 0x2) != 0);
        for (n = 1; ; i1 = 0)
        {
          localCheckBox.setChecked(n);
          String str4 = this.checkboxTitles[i6];
          localCheckBox.setText(str4);
          localCheckBox.setOnCheckedChangeListener(this);
          this.checkboxes[i6] = localCheckBox;
          i6 += 1;
          break;
        }
      }
      i6 = 0;
      int i9 = DialogBoxAdapterAndroid.checkboxViewIds.length;
      if (i6 < i9)
      {
        int i10 = DialogBoxAdapterAndroid.checkboxViewIds[i6];
        localCheckBox = (CheckBox)localView.findViewById(i10);
        int i11 = this.checkboxIds.length;
        if (i6 >= i11);
        for (i1 = 8; ; i1 = 0)
        {
          localCheckBox.setVisibility(i1);
          i6 += 1;
          break;
        }
      }
      AlertDialog.Builder localBuilder4 = localBuilder1.setView(localView);
      if ((this.buttons & 0xC) != 0)
        i = 1;
      AlertDialog.Builder localBuilder5 = localBuilder1.setCancelable(i);
      if ((this.buttons & 0x2) != 0)
      {
        int i12 = R.string.yes;
        AlertDialog.Builder localBuilder6 = localBuilder1.setPositiveButton(i12, this);
      }
      if ((this.buttons & 0x1) != 0)
        AlertDialog.Builder localBuilder7 = localBuilder1.setPositiveButton(17039370, this);
      if ((this.buttons & 0x8) != 0)
        AlertDialog.Builder localBuilder8 = localBuilder1.setNegativeButton(17039360, this);
      if ((this.buttons & 0x4) != 0)
        AlertDialog.Builder localBuilder9 = localBuilder1.setNegativeButton(17039369, this);
      AlertDialog localAlertDialog = localBuilder1.create();
      this.dialog = localAlertDialog;
      this.dialog.setInverseBackgroundForced(1);
      this.dialog.setOnDismissListener(this);
      this.dialog.setOnCancelListener(this);
      this.dialog.show();
      updateCheckState();
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.DialogBoxAdapterAndroid
 * JD-Core Version:    0.6.0
 */