package com.softspb.shell.adapters;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.PaintDrawable;
import android.net.Uri;
import android.os.Environment;
import android.util.DisplayMetrics;
import com.softspb.shell.data.WidgetsContract;
import com.softspb.shell.opengl.NativeCallbacks;
import com.softspb.util.IOHelper;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.io.File;
import java.io.InputStream;
import java.nio.ByteBuffer;

public class ImageAdapterAndroid extends ImageAdapter
{
  private static final String ASSETS_PREFIX = "@assets/";
  private static final String CONTENT_PREFIX = "content";
  private static final float HIGH_DENSITY_DPI = 1.5F;
  private static final int PixelFormat_A8 = 6;
  private static final int PixelFormat_B8G8R8 = 3;
  private static final int PixelFormat_B8G8R8A8 = 5;
  private static final int PixelFormat_L8 = 7;
  private static final int PixelFormat_L8A8 = 8;
  private static final int PixelFormat_R5G6B5 = 1;
  private static final int PixelFormat_R8G8B8 = 2;
  private static final int PixelFormat_R8G8B8A8 = 4;
  private static final String RESOURCE_PREFIX = "android.resource";
  private static final Logger logger = Loggers.getLogger(ImageAdapterAndroid.class.getName());
  private Context context;
  private String externalStorageRootPath;
  String widgetsAuthority;

  public ImageAdapterAndroid(AdaptersHolder paramAdaptersHolder)
  {
    super(paramAdaptersHolder);
  }

  private Bitmap decodeAsset(String paramString)
  {
    Logger localLogger1 = logger;
    String str1 = "decodeAsset: path=" + paramString;
    localLogger1.d(str1);
    Object localObject1 = null;
    InputStream localInputStream = null;
    if (paramString != null);
    while (true)
    {
      try
      {
        String str2 = paramString.toLowerCase();
        localInputStream = this.context.getAssets().open(str2);
        Bitmap localBitmap = BitmapFactory.decodeStream(localInputStream);
        localObject1 = localBitmap;
        IOHelper.closeSilent(localInputStream);
        Logger localLogger2 = logger;
        StringBuilder localStringBuilder = new StringBuilder().append("Asset is null?: ");
        if (localObject1 == null)
        {
          int i = 1;
          String str3 = i;
          localLogger2.d(str3);
          Object localObject2 = localObject1;
          return localObject2;
          localObject2 = null;
          IOHelper.closeSilent(null);
          continue;
        }
      }
      catch (Exception localException)
      {
        Logger localLogger3 = logger;
        String str4 = "decodeAsset failed: " + localException;
        localLogger3.e(str4, localException);
        IOHelper.closeSilent(localInputStream);
        continue;
      }
      finally
      {
        IOHelper.closeSilent(localInputStream);
      }
      int j = 0;
    }
  }

  private Bitmap decodeFile(String paramString)
  {
    Logger localLogger1 = logger;
    String str1 = "decodeFile: path=" + paramString;
    localLogger1.d(str1);
    Object localObject = null;
    try
    {
      Bitmap localBitmap = BitmapFactory.decodeFile(paramString);
      localObject = localBitmap;
      Logger localLogger2 = logger;
      StringBuilder localStringBuilder = new StringBuilder().append("File is null? ");
      if (localObject == null)
      {
        int i = 1;
        String str2 = i;
        localLogger2.d(str2);
        return localObject;
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        Logger localLogger3 = logger;
        String str3 = "decodeFile failed: " + localException;
        localLogger3.e(str3, localException);
        continue;
        int j = 0;
      }
    }
  }

  // ERROR //
  private Bitmap decodeFromExternalStorage(String paramString)
  {
    // Byte code:
    //   0: getstatic 57	com/softspb/shell/adapters/ImageAdapterAndroid:logger	Lcom/softspb/util/log/Logger;
    //   3: astore_2
    //   4: new 67	java/lang/StringBuilder
    //   7: dup
    //   8: invokespecial 69	java/lang/StringBuilder:<init>	()V
    //   11: ldc 142
    //   13: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   16: aload_1
    //   17: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   20: invokevirtual 78	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   23: astore_3
    //   24: aload_2
    //   25: aload_3
    //   26: invokevirtual 84	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   29: new 144	java/io/File
    //   32: dup
    //   33: aload_1
    //   34: invokespecial 146	java/io/File:<init>	(Ljava/lang/String;)V
    //   37: astore 4
    //   39: aconst_null
    //   40: astore 5
    //   42: aconst_null
    //   43: astore 6
    //   45: new 148	java/io/FileInputStream
    //   48: dup
    //   49: aload 4
    //   51: invokespecial 151	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   54: astore 7
    //   56: aload 7
    //   58: invokestatic 109	android/graphics/BitmapFactory:decodeStream	(Ljava/io/InputStream;)Landroid/graphics/Bitmap;
    //   61: astore 8
    //   63: aload 8
    //   65: astore 6
    //   67: aload 7
    //   69: invokestatic 115	com/softspb/util/IOHelper:closeSilent	(Ljava/io/Closeable;)V
    //   72: aload 7
    //   74: astore 9
    //   76: getstatic 57	com/softspb/shell/adapters/ImageAdapterAndroid:logger	Lcom/softspb/util/log/Logger;
    //   79: astore 10
    //   81: new 67	java/lang/StringBuilder
    //   84: dup
    //   85: invokespecial 69	java/lang/StringBuilder:<init>	()V
    //   88: ldc 137
    //   90: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   93: astore 11
    //   95: aload 6
    //   97: ifnonnull +85 -> 182
    //   100: ldc 28
    //   102: istore 12
    //   104: aload 11
    //   106: iload 12
    //   108: invokevirtual 120	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
    //   111: invokevirtual 78	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   114: astore 13
    //   116: aload 10
    //   118: aload 13
    //   120: invokevirtual 84	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   123: aload 6
    //   125: areturn
    //   126: astore 14
    //   128: getstatic 57	com/softspb/shell/adapters/ImageAdapterAndroid:logger	Lcom/softspb/util/log/Logger;
    //   131: astore 15
    //   133: new 67	java/lang/StringBuilder
    //   136: dup
    //   137: invokespecial 69	java/lang/StringBuilder:<init>	()V
    //   140: ldc 153
    //   142: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   145: aload 14
    //   147: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   150: invokevirtual 78	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   153: astore 16
    //   155: aload 15
    //   157: aload 16
    //   159: aload 14
    //   161: invokevirtual 129	com/softspb/util/log/Logger:e	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   164: aload 5
    //   166: invokestatic 115	com/softspb/util/IOHelper:closeSilent	(Ljava/io/Closeable;)V
    //   169: goto -93 -> 76
    //   172: astore 12
    //   174: aload 5
    //   176: invokestatic 115	com/softspb/util/IOHelper:closeSilent	(Ljava/io/Closeable;)V
    //   179: aload 12
    //   181: athrow
    //   182: ldc 130
    //   184: istore 12
    //   186: goto -82 -> 104
    //   189: astore 12
    //   191: aload 7
    //   193: astore 5
    //   195: goto -21 -> 174
    //   198: astore 14
    //   200: aload 7
    //   202: astore 5
    //   204: goto -76 -> 128
    //
    // Exception table:
    //   from	to	target	type
    //   45	56	126	java/lang/Exception
    //   45	56	172	finally
    //   128	164	172	finally
    //   56	63	189	finally
    //   56	63	198	java/lang/Exception
  }

  public static Bitmap decodeResourceUri(Context paramContext, String paramString)
  {
    Logger localLogger1 = logger;
    String str1 = "decodeResourceUri: " + paramString;
    localLogger1.d(str1);
    try
    {
      Uri localUri = Uri.parse(paramString);
      String str2 = localUri.getHost();
      int i = Integer.valueOf(localUri.getLastPathSegment()).intValue();
      Resources localResources = paramContext.createPackageContext(str2, 2).getResources();
      Drawable localDrawable = null;
      if (isSW600dp(localResources.getDisplayMetrics()))
        localDrawable = getDrawableForDensity(localResources, i, 240, 1.5F);
      if (localDrawable == null)
        localDrawable = localResources.getDrawable(i);
      localBitmap = resizeDrawable(paramContext, localDrawable);
      Logger localLogger2 = logger;
      Object[] arrayOfObject = new Object[2];
      Integer localInteger1 = Integer.valueOf(localBitmap.getWidth());
      arrayOfObject[0] = localInteger1;
      Integer localInteger2 = Integer.valueOf(localBitmap.getHeight());
      arrayOfObject[1] = localInteger2;
      localLogger2.d("resulting bitmap width %d height: %d", arrayOfObject);
      return localBitmap;
    }
    catch (Exception localException)
    {
      while (true)
      {
        Logger localLogger3 = logger;
        String str3 = "Failed to get resource URI: " + localException;
        localLogger3.e(str3, localException);
        Bitmap localBitmap = null;
      }
    }
  }

  public static Drawable getDrawableForDensity(Resources paramResources, int paramInt1, int paramInt2, float paramFloat)
  {
    Configuration localConfiguration = paramResources.getConfiguration();
    DisplayMetrics localDisplayMetrics = paramResources.getDisplayMetrics();
    float f = localDisplayMetrics.density;
    int i = localDisplayMetrics.densityDpi;
    localDisplayMetrics.density = paramFloat;
    localDisplayMetrics.densityDpi = paramInt2;
    paramResources.updateConfiguration(localConfiguration, localDisplayMetrics);
    Drawable localDrawable = paramResources.getDrawable(paramInt1);
    localDisplayMetrics.density = f;
    localDisplayMetrics.densityDpi = i;
    paramResources.updateConfiguration(localConfiguration, localDisplayMetrics);
    return localDrawable;
  }

  private static boolean isSW600dp(DisplayMetrics paramDisplayMetrics)
  {
    float f1 = paramDisplayMetrics.widthPixels;
    float f2 = paramDisplayMetrics.density;
    float f3 = 600.0F * f2;
    if (f1 >= f3);
    for (int i = 1; ; i = 0)
      return i;
  }

  public static InputStream newInputStream(ByteBuffer paramByteBuffer)
  {
    return new ImageAdapterAndroid.1(paramByteBuffer);
  }

  // ERROR //
  private static byte[] readByteBuffer(ByteBuffer paramByteBuffer)
  {
    // Byte code:
    //   0: new 262	java/io/ByteArrayOutputStream
    //   3: dup
    //   4: invokespecial 263	java/io/ByteArrayOutputStream:<init>	()V
    //   7: astore_1
    //   8: aload_0
    //   9: invokestatic 265	com/softspb/shell/adapters/ImageAdapterAndroid:newInputStream	(Ljava/nio/ByteBuffer;)Ljava/io/InputStream;
    //   12: astore_2
    //   13: sipush 1024
    //   16: newarray byte
    //   18: astore_3
    //   19: aload_2
    //   20: aload_3
    //   21: invokevirtual 271	java/io/InputStream:read	([B)I
    //   24: istore 4
    //   26: iload 4
    //   28: bipush 255
    //   30: if_icmpeq +67 -> 97
    //   33: aload_1
    //   34: aload_3
    //   35: iconst_0
    //   36: iload 4
    //   38: invokevirtual 275	java/io/ByteArrayOutputStream:write	([BII)V
    //   41: goto -22 -> 19
    //   44: astore 5
    //   46: getstatic 57	com/softspb/shell/adapters/ImageAdapterAndroid:logger	Lcom/softspb/util/log/Logger;
    //   49: astore 6
    //   51: new 67	java/lang/StringBuilder
    //   54: dup
    //   55: invokespecial 69	java/lang/StringBuilder:<init>	()V
    //   58: ldc_w 277
    //   61: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: aload 5
    //   66: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   69: invokevirtual 78	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   72: astore 7
    //   74: aload 6
    //   76: aload 7
    //   78: aload 5
    //   80: invokevirtual 129	com/softspb/util/log/Logger:e	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   83: aload_2
    //   84: ifnull +7 -> 91
    //   87: aload_2
    //   88: invokevirtual 280	java/io/InputStream:close	()V
    //   91: aconst_null
    //   92: astore 8
    //   94: aload 8
    //   96: areturn
    //   97: aload_1
    //   98: invokevirtual 284	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   101: astore 9
    //   103: aload 9
    //   105: astore 8
    //   107: aload_2
    //   108: ifnull -14 -> 94
    //   111: aload_2
    //   112: invokevirtual 280	java/io/InputStream:close	()V
    //   115: goto -21 -> 94
    //   118: astore 10
    //   120: goto -26 -> 94
    //   123: astore 8
    //   125: aload_2
    //   126: ifnull +7 -> 133
    //   129: aload_2
    //   130: invokevirtual 280	java/io/InputStream:close	()V
    //   133: aload 8
    //   135: athrow
    //   136: astore 11
    //   138: goto -47 -> 91
    //   141: astore 12
    //   143: goto -10 -> 133
    //
    // Exception table:
    //   from	to	target	type
    //   8	41	44	java/lang/Exception
    //   97	103	44	java/lang/Exception
    //   111	115	118	java/io/IOException
    //   8	41	123	finally
    //   46	83	123	finally
    //   97	103	123	finally
    //   87	91	136	java/io/IOException
    //   129	133	141	java/io/IOException
  }

  public static Bitmap resizeDrawable(Context paramContext, Drawable paramDrawable)
  {
    try
    {
      int i = paramDrawable.getIntrinsicWidth();
      int j = paramDrawable.getIntrinsicHeight();
      Resources localResources = paramContext.getResources();
      int k = (int)localResources.getDimension(17104896);
      int m = (int)localResources.getDimension(17104896);
      DisplayMetrics localDisplayMetrics = localResources.getDisplayMetrics();
      if (isSW600dp(localDisplayMetrics))
      {
        float f1 = localDisplayMetrics.density;
        k = (int)(72.0F * f1);
        float f2 = localDisplayMetrics.density;
        m = (int)(72.0F * f2);
      }
      if ((paramDrawable instanceof PaintDrawable))
      {
        PaintDrawable localPaintDrawable = (PaintDrawable)paramDrawable;
        localPaintDrawable.setIntrinsicWidth(k);
        localPaintDrawable.setIntrinsicHeight(m);
      }
      if ((k > 0) && (m > 0))
      {
        float f3 = i;
        float f4 = j;
        float f5 = f3 / f4;
        if (i > j)
        {
          m = (int)(k / f5);
          if (paramDrawable.getOpacity() == -1)
            break label264;
        }
        label264: for (Bitmap.Config localConfig = Bitmap.Config.ARGB_8888; ; localConfig = Bitmap.Config.RGB_565)
        {
          localBitmap = Bitmap.createBitmap(k, m, localConfig);
          Canvas localCanvas = new Canvas(localBitmap);
          PaintFlagsDrawFilter localPaintFlagsDrawFilter = new PaintFlagsDrawFilter(4, 0);
          localCanvas.setDrawFilter(localPaintFlagsDrawFilter);
          Rect localRect1 = paramDrawable.getBounds();
          Rect localRect2 = new Rect(localRect1);
          paramDrawable.setBounds(0, 0, k, m);
          paramDrawable.draw(localCanvas);
          paramDrawable.setBounds(localRect2);
          return localBitmap;
          if (j <= i)
            break;
          k = (int)(m * f5);
          break;
        }
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        Logger localLogger = logger;
        String str = "Failed to get resource URI: " + localException;
        localLogger.e(str, localException);
        Bitmap localBitmap = null;
      }
    }
  }

  // ERROR //
  private static void writeToSDCard(Context paramContext, byte[] paramArrayOfByte, String paramString)
  {
    // Byte code:
    //   0: getstatic 57	com/softspb/shell/adapters/ImageAdapterAndroid:logger	Lcom/softspb/util/log/Logger;
    //   3: astore_3
    //   4: new 67	java/lang/StringBuilder
    //   7: dup
    //   8: invokespecial 69	java/lang/StringBuilder:<init>	()V
    //   11: ldc_w 360
    //   14: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   17: aload_2
    //   18: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   21: ldc_w 362
    //   24: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   27: astore 4
    //   29: aload_1
    //   30: arraylength
    //   31: istore 5
    //   33: aload 4
    //   35: iload 5
    //   37: invokevirtual 365	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   40: invokevirtual 78	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   43: astore 6
    //   45: aload_3
    //   46: aload 6
    //   48: invokevirtual 84	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   51: aload_0
    //   52: aconst_null
    //   53: invokevirtual 369	android/content/Context:getExternalFilesDir	(Ljava/lang/String;)Ljava/io/File;
    //   56: astore 7
    //   58: aload 7
    //   60: ifnonnull +13 -> 73
    //   63: getstatic 57	com/softspb/shell/adapters/ImageAdapterAndroid:logger	Lcom/softspb/util/log/Logger;
    //   66: ldc_w 371
    //   69: invokevirtual 374	com/softspb/util/log/Logger:w	(Ljava/lang/String;)V
    //   72: return
    //   73: new 144	java/io/File
    //   76: dup
    //   77: aload 7
    //   79: aload_2
    //   80: invokespecial 377	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   83: astore 8
    //   85: aconst_null
    //   86: astore 9
    //   88: new 379	java/io/FileOutputStream
    //   91: dup
    //   92: aload 8
    //   94: invokespecial 380	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   97: astore 10
    //   99: aload 10
    //   101: aload_1
    //   102: invokevirtual 385	java/io/OutputStream:write	([B)V
    //   105: aload 10
    //   107: ifnull +8 -> 115
    //   110: aload 10
    //   112: invokevirtual 386	java/io/OutputStream:close	()V
    //   115: getstatic 57	com/softspb/shell/adapters/ImageAdapterAndroid:logger	Lcom/softspb/util/log/Logger;
    //   118: astore 11
    //   120: new 67	java/lang/StringBuilder
    //   123: dup
    //   124: invokespecial 69	java/lang/StringBuilder:<init>	()V
    //   127: ldc_w 388
    //   130: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   133: astore 12
    //   135: aload 8
    //   137: invokevirtual 391	java/io/File:getPath	()Ljava/lang/String;
    //   140: astore 13
    //   142: aload 12
    //   144: aload 13
    //   146: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   149: invokevirtual 78	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   152: astore 14
    //   154: aload 11
    //   156: aload 14
    //   158: invokevirtual 84	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   161: goto -89 -> 72
    //   164: astore 15
    //   166: getstatic 57	com/softspb/shell/adapters/ImageAdapterAndroid:logger	Lcom/softspb/util/log/Logger;
    //   169: astore 16
    //   171: new 67	java/lang/StringBuilder
    //   174: dup
    //   175: invokespecial 69	java/lang/StringBuilder:<init>	()V
    //   178: ldc_w 393
    //   181: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   184: astore 17
    //   186: aload 8
    //   188: invokevirtual 391	java/io/File:getPath	()Ljava/lang/String;
    //   191: astore 18
    //   193: aload 17
    //   195: aload 18
    //   197: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   200: ldc_w 395
    //   203: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   206: aload 15
    //   208: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   211: invokevirtual 78	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   214: astore 19
    //   216: aload 16
    //   218: aload 19
    //   220: aload 15
    //   222: invokevirtual 129	com/softspb/util/log/Logger:e	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   225: aload 9
    //   227: ifnull -155 -> 72
    //   230: aload 9
    //   232: invokevirtual 386	java/io/OutputStream:close	()V
    //   235: goto -163 -> 72
    //   238: astore 20
    //   240: goto -168 -> 72
    //   243: astore 21
    //   245: aload 9
    //   247: ifnull +8 -> 255
    //   250: aload 9
    //   252: invokevirtual 386	java/io/OutputStream:close	()V
    //   255: aload 21
    //   257: athrow
    //   258: astore 22
    //   260: goto -145 -> 115
    //   263: astore 23
    //   265: goto -10 -> 255
    //   268: astore 21
    //   270: aload 10
    //   272: astore 9
    //   274: goto -29 -> 245
    //   277: astore 15
    //   279: aload 10
    //   281: astore 9
    //   283: goto -117 -> 166
    //
    // Exception table:
    //   from	to	target	type
    //   88	99	164	java/io/IOException
    //   230	235	238	java/io/IOException
    //   88	99	243	finally
    //   166	225	243	finally
    //   110	115	258	java/io/IOException
    //   250	255	263	java/io/IOException
    //   99	105	268	finally
    //   99	105	277	java/io/IOException
  }

  // ERROR //
  public boolean SaveCompressed(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, int paramInt3, String paramString)
  {
    // Byte code:
    //   0: iload 4
    //   2: tableswitch	default:+38 -> 40, 1:+79->81, 2:+38->40, 3:+38->40, 4:+175->177, 5:+38->40, 6:+167->169
    //   41: nop
    //   42: dstore 58
    //   44: iconst_3
    //   45: new 67	java/lang/StringBuilder
    //   48: dup
    //   49: invokespecial 69	java/lang/StringBuilder:<init>	()V
    //   52: ldc_w 401
    //   55: invokevirtual 75	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   58: iload 4
    //   60: invokevirtual 365	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   63: invokevirtual 78	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   66: astore 7
    //   68: aload 6
    //   70: aload 7
    //   72: invokevirtual 403	com/softspb/util/log/Logger:e	(Ljava/lang/String;)V
    //   75: iconst_0
    //   76: istore 8
    //   78: iload 8
    //   80: ireturn
    //   81: getstatic 356	android/graphics/Bitmap$Config:RGB_565	Landroid/graphics/Bitmap$Config;
    //   84: astore 9
    //   86: aconst_null
    //   87: astore 10
    //   89: aconst_null
    //   90: astore 11
    //   92: new 144	java/io/File
    //   95: dup
    //   96: aload 5
    //   98: invokespecial 146	java/io/File:<init>	(Ljava/lang/String;)V
    //   101: astore 12
    //   103: new 379	java/io/FileOutputStream
    //   106: dup
    //   107: aload 12
    //   109: invokespecial 380	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   112: astore 13
    //   114: iload_2
    //   115: iload_3
    //   116: aload 9
    //   118: invokestatic 320	android/graphics/Bitmap:createBitmap	(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;
    //   121: astore 11
    //   123: aload 11
    //   125: aload_1
    //   126: invokevirtual 407	android/graphics/Bitmap:copyPixelsFromBuffer	(Ljava/nio/Buffer;)V
    //   129: getstatic 413	android/graphics/Bitmap$CompressFormat:JPEG	Landroid/graphics/Bitmap$CompressFormat;
    //   132: astore 14
    //   134: aload 11
    //   136: aload 14
    //   138: bipush 75
    //   140: aload 13
    //   142: invokevirtual 417	android/graphics/Bitmap:compress	(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z
    //   145: istore 15
    //   147: iload 15
    //   149: istore 8
    //   151: aload 13
    //   153: invokestatic 115	com/softspb/util/IOHelper:closeSilent	(Ljava/io/Closeable;)V
    //   156: aload 11
    //   158: ifnull -80 -> 78
    //   161: aload 11
    //   163: invokevirtual 420	android/graphics/Bitmap:recycle	()V
    //   166: goto -88 -> 78
    //   169: getstatic 423	android/graphics/Bitmap$Config:ALPHA_8	Landroid/graphics/Bitmap$Config;
    //   172: astore 9
    //   174: goto -88 -> 86
    //   177: getstatic 316	android/graphics/Bitmap$Config:ARGB_8888	Landroid/graphics/Bitmap$Config;
    //   180: astore 9
    //   182: goto -96 -> 86
    //   185: astore 16
    //   187: aload 16
    //   189: invokevirtual 426	java/lang/Throwable:printStackTrace	()V
    //   192: iconst_0
    //   193: istore 8
    //   195: aload 10
    //   197: invokestatic 115	com/softspb/util/IOHelper:closeSilent	(Ljava/io/Closeable;)V
    //   200: aload 11
    //   202: ifnull -124 -> 78
    //   205: aload 11
    //   207: invokevirtual 420	android/graphics/Bitmap:recycle	()V
    //   210: goto -132 -> 78
    //   213: astore 17
    //   215: aload 10
    //   217: invokestatic 115	com/softspb/util/IOHelper:closeSilent	(Ljava/io/Closeable;)V
    //   220: aload 11
    //   222: ifnull +8 -> 230
    //   225: aload 11
    //   227: invokevirtual 420	android/graphics/Bitmap:recycle	()V
    //   230: aload 17
    //   232: athrow
    //   233: astore 17
    //   235: aload 13
    //   237: astore 10
    //   239: goto -24 -> 215
    //   242: astore 16
    //   244: aload 13
    //   246: astore 10
    //   248: goto -61 -> 187
    //
    // Exception table:
    //   from	to	target	type
    //   92	114	185	java/lang/Throwable
    //   92	114	213	finally
    //   187	192	213	finally
    //   114	147	233	finally
    //   114	147	242	java/lang/Throwable
  }

  public Bitmap decodeContentUri(String paramString)
  {
    Logger localLogger1 = logger;
    String str1 = "decodeContentUri: " + paramString;
    localLogger1.d(str1);
    try
    {
      ContentResolver localContentResolver = this.context.getContentResolver();
      Uri localUri = Uri.parse(paramString);
      localInputStream = localContentResolver.openInputStream(localUri);
      localObject1 = BitmapFactory.decodeStream(localInputStream);
      if (((Bitmap)localObject1).getConfig() == null)
      {
        Bitmap.Config localConfig = Bitmap.Config.ARGB_8888;
        Bitmap localBitmap = ((Bitmap)localObject1).copy(localConfig, 0);
        ((Bitmap)localObject1).recycle();
        localObject1 = localBitmap;
      }
      return localObject1;
    }
    catch (Exception localException)
    {
      while (true)
      {
        Logger localLogger2 = logger;
        String str2 = "Failed to get content URI: " + localException;
        localLogger2.e(str2, localException);
        IOHelper.closeSilent(localInputStream);
        Object localObject1 = null;
      }
    }
    finally
    {
      InputStream localInputStream;
      IOHelper.closeSilent(localInputStream);
    }
    throw localObject2;
  }

  public Bitmap decodeShortcutContentUri(String paramString)
  {
    Object localObject1 = null;
    ContentResolver localContentResolver = this.context.getContentResolver();
    Uri localUri = Uri.parse(paramString);
    Object localObject2 = localObject1;
    Object localObject3 = localObject1;
    Object localObject4 = localObject1;
    Cursor localCursor = localContentResolver.query(localUri, localObject1, localObject2, localObject3, localObject4);
    if (localCursor == null);
    while (true)
    {
      return localObject1;
      int i = localCursor.getColumnIndex("icon");
      if ((i == -1) || (!localCursor.moveToFirst()))
        continue;
      byte[] arrayOfByte = localCursor.getBlob(i);
      if (arrayOfByte == null)
        continue;
      int j = arrayOfByte.length;
      Bitmap localBitmap = BitmapFactory.decodeByteArray(arrayOfByte, 0, j);
      localCursor.close();
      localObject1 = localBitmap;
    }
  }

  /** @deprecated */
  public Bitmap getByBuffer(ByteBuffer paramByteBuffer)
  {
    monitorenter;
    try
    {
      logger.d("getByBuffer >>>");
      Bitmap localBitmap = BitmapFactory.decodeStream(newInputStream(paramByteBuffer));
      if (localBitmap == null)
        logger.w("getByBuffer <<< decoding bitmap failed");
      while (true)
      {
        return localBitmap;
        Logger localLogger = logger;
        StringBuilder localStringBuilder1 = new StringBuilder().append("getByBuffer <<< decoded bitmap w=");
        int i = localBitmap.getWidth();
        StringBuilder localStringBuilder2 = localStringBuilder1.append(i).append(" h=");
        int j = localBitmap.getHeight();
        String str = j;
        localLogger.d(str);
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public Bitmap getByBuffer(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2)
  {
    Object localObject = BitmapFactory.decodeStream(newInputStream(paramByteBuffer));
    int i = ((Bitmap)localObject).getWidth();
    int j = paramInt1;
    if (i <= j)
    {
      int k = ((Bitmap)localObject).getHeight();
      int m = paramInt2;
      if (k <= m)
        return localObject;
    }
    double d1 = ((Bitmap)localObject).getWidth();
    double d2 = ((Bitmap)localObject).getHeight();
    double d3 = paramInt1;
    double d4 = paramInt2;
    double d5 = d1 / d3;
    double d6 = d2 / d4;
    double d7;
    double d8;
    if (d5 > d6)
    {
      d7 = d1 / d5;
      d8 = d2 / d5;
    }
    while (true)
    {
      Logger localLogger = logger;
      StringBuilder localStringBuilder1 = new StringBuilder().append("Scaling image ");
      int n = ((Bitmap)localObject).getWidth();
      StringBuilder localStringBuilder2 = localStringBuilder1.append(n).append("x");
      int i1 = ((Bitmap)localObject).getHeight();
      String str = i1 + " downto " + d7 + "x" + d8;
      localLogger.d(str);
      int i2 = (int)d7;
      int i3 = (int)d8;
      int i4 = i2;
      int i5 = i3;
      int i6 = 1;
      Bitmap localBitmap = Bitmap.createScaledBitmap((Bitmap)localObject, i4, i5, i6);
      ((Bitmap)localObject).recycle();
      localObject = localBitmap;
      break;
      d7 = d1 / d6;
      d8 = d2 / d6;
    }
  }

  public Bitmap getByPath(String paramString)
  {
    Logger localLogger = logger;
    String str1 = "getByPath: path=" + paramString;
    localLogger.d(str1);
    StringBuilder localStringBuilder = new StringBuilder().append("content://");
    String str2 = this.widgetsAuthority;
    String str3 = str2;
    Bitmap localBitmap;
    if (paramString.startsWith(str3))
      localBitmap = decodeShortcutContentUri(paramString);
    while (true)
    {
      return localBitmap;
      if (paramString.startsWith("android.resource"))
      {
        localBitmap = decodeResourceUri(this.context, paramString);
        continue;
      }
      if (paramString.startsWith("content"))
      {
        localBitmap = decodeContentUri(paramString);
        continue;
      }
      if (paramString.startsWith("@assets/"))
      {
        int i = "@assets/".length();
        String str4 = paramString.substring(i);
        localBitmap = decodeAsset(str4);
        continue;
      }
      String str5 = this.externalStorageRootPath;
      if (paramString.startsWith(str5))
      {
        localBitmap = decodeFromExternalStorage(paramString);
        continue;
      }
      localBitmap = decodeFile(paramString);
    }
  }

  public void onCreate(Context paramContext, NativeCallbacks paramNativeCallbacks)
  {
    this.context = paramContext;
    String str1 = WidgetsContract.getAuthority(paramContext);
    this.widgetsAuthority = str1;
    String str2 = Environment.getExternalStorageDirectory().getPath();
    this.externalStorageRootPath = str2;
    Logger localLogger = logger;
    StringBuilder localStringBuilder = new StringBuilder().append("Created ImageAdapterAndroid: external storage root: ");
    String str3 = this.externalStorageRootPath;
    String str4 = str3;
    localLogger.d(str4);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.ImageAdapterAndroid
 * JD-Core Version:    0.6.0
 */