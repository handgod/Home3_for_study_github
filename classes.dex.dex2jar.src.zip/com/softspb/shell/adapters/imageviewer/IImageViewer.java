package com.softspb.shell.adapters.imageviewer;

import android.graphics.Bitmap;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public abstract interface IImageViewer extends IInterface
{
  public abstract Bitmap getBitmap(String paramString)
    throws RemoteException;

  public abstract class Stub extends Binder
    implements IImageViewer
  {
    private static final String DESCRIPTOR = "com.softspb.shell.adapters.imageviewer.IImageViewer";
    static final int TRANSACTION_getBitmap = 1;

    public Stub()
    {
      attachInterface(this, "com.softspb.shell.adapters.imageviewer.IImageViewer");
    }

    public static IImageViewer asInterface(IBinder paramIBinder)
    {
      Object localObject;
      if (paramIBinder == null)
        localObject = null;
      while (true)
      {
        return localObject;
        localObject = paramIBinder.queryLocalInterface("com.softspb.shell.adapters.imageviewer.IImageViewer");
        if ((localObject != null) && ((localObject instanceof IImageViewer)))
        {
          localObject = (IImageViewer)localObject;
          continue;
        }
        localObject = new Proxy();
      }
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      boolean bool = true;
      switch (paramInt1)
      {
      default:
        bool = super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
      case 1:
      }
      while (true)
      {
        return bool;
        paramParcel2.writeString("com.softspb.shell.adapters.imageviewer.IImageViewer");
        continue;
        paramParcel1.enforceInterface("com.softspb.shell.adapters.imageviewer.IImageViewer");
        String str = paramParcel1.readString();
        Bitmap localBitmap = getBitmap(str);
        paramParcel2.writeNoException();
        if (localBitmap != null)
        {
          paramParcel2.writeInt(1);
          localBitmap.writeToParcel(paramParcel2, 1);
          continue;
        }
        paramParcel2.writeInt(0);
      }
    }

    class Proxy
      implements IImageViewer
    {
      Proxy()
      {
      }

      public IBinder asBinder()
      {
        return IImageViewer.Stub.this;
      }

      public Bitmap getBitmap(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.softspb.shell.adapters.imageviewer.IImageViewer");
          localParcel1.writeString(paramString);
          boolean bool = IImageViewer.Stub.this.transact(1, localParcel1, localParcel2, 0);
          localParcel2.readException();
          if (localParcel2.readInt() != 0)
          {
            localBitmap = (Bitmap)Bitmap.CREATOR.createFromParcel(localParcel2);
            return localBitmap;
          }
          Bitmap localBitmap = null;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public String getInterfaceDescriptor()
      {
        return "com.softspb.shell.adapters.imageviewer.IImageViewer";
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.imageviewer.IImageViewer
 * JD-Core Version:    0.6.0
 */