package com.softspb.shell.adapters.imageviewer;

import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory.Options;
import android.os.IBinder;
import android.provider.MediaStore.Images.Thumbnails;
import com.softspb.util.Conditions;

public class ImageViewerService extends Service
{
  private IImageViewer.Stub binder;

  public ImageViewerService()
  {
    ImageViewerService.1 local1 = new ImageViewerService.1(this);
    this.binder = local1;
  }

  private Bitmap getBitmap(String paramString)
  {
    Object localObject = Conditions.checkNotNull(paramString);
    BitmapFactory.Options localOptions = new BitmapFactory.Options();
    ContentResolver localContentResolver = getContentResolver();
    long l = Long.valueOf(paramString).longValue();
    return MediaStore.Images.Thumbnails.getThumbnail(localContentResolver, l, 1, localOptions);
  }

  public IBinder onBind(Intent paramIntent)
  {
    return this.binder;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.imageviewer.ImageViewerService
 * JD-Core Version:    0.6.0
 */