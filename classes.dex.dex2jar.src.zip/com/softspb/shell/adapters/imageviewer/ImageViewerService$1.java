package com.softspb.shell.adapters.imageviewer;

import android.graphics.Bitmap;
import android.os.RemoteException;

class ImageViewerService$1 extends IImageViewer.Stub
{
  public Bitmap getBitmap(String paramString)
    throws RemoteException
  {
    return ImageViewerService.access$000(this.this$0, paramString);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.imageviewer.ImageViewerService.1
 * JD-Core Version:    0.6.0
 */