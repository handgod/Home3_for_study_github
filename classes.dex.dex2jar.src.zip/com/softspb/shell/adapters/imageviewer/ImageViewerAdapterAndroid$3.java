package com.softspb.shell.adapters.imageviewer;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;

class ImageViewerAdapterAndroid$3
  implements ServiceConnection
{
  public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
  {
    ImageViewerAdapterAndroid localImageViewerAdapterAndroid = this.this$0;
    IImageViewer localIImageViewer1 = IImageViewer.Stub.asInterface(paramIBinder);
    IImageViewer localIImageViewer2 = ImageViewerAdapterAndroid.access$102(localImageViewerAdapterAndroid, localIImageViewer1);
  }

  public void onServiceDisconnected(ComponentName paramComponentName)
  {
    IImageViewer localIImageViewer = ImageViewerAdapterAndroid.access$102(this.this$0, null);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.imageviewer.ImageViewerAdapterAndroid.3
 * JD-Core Version:    0.6.0
 */