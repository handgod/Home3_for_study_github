package com.softspb.shell.adapters.imageviewer;

import android.database.ContentObserver;
import android.os.Handler;

class ImageViewerAdapterAndroid$6 extends ContentObserver
{
  public void onChange(boolean paramBoolean)
  {
    ImageViewerAdapterAndroid.update();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.imageviewer.ImageViewerAdapterAndroid.6
 * JD-Core Version:    0.6.0
 */