package com.softspb.shell.adapters.imageviewer;

import android.content.Context;
import android.content.Intent;
import com.softspb.util.broadcastreceiver.DecoratedBroadcastReceiver.IActionListener;

class ImageViewerAdapterAndroid$1
  implements DecoratedBroadcastReceiver.IActionListener
{
  public void onAction(Context paramContext, Intent paramIntent)
  {
    ImageViewerAdapterAndroid.update();
    ImageViewerAdapterAndroid.access$000(this.this$0);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.imageviewer.ImageViewerAdapterAndroid.1
 * JD-Core Version:    0.6.0
 */