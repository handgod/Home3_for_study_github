package com.softspb.shell.adapters.imageviewer;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore.Images.Media;
import android.text.TextUtils;
import android.util.Pair;
import com.softspb.shell.adapters.AdaptersHolder;
import com.softspb.shell.opengl.NativeCallbacks;
import com.softspb.shell.util.BitmapHelper;
import com.softspb.util.broadcastreceiver.DecoratedBroadcastReceiver;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ImageViewerAdapterAndroid extends ImageViewerAdapter
{
  private static final String BUCKET_ID_SELECTION = "bucket_id=?";
  private static final String[] ID_PROJECTION;
  private ContentObserver contentObserver;
  private Context context;
  private IImageViewer imageViewer = null;
  private boolean isBound = 0;
  private DecoratedBroadcastReceiver mediaReceiver;
  private NativeCallbacks nc;
  private DecoratedBroadcastReceiver sdReceiver;
  private ServiceConnection serviceConnection;
  private Intent serviceIntent;

  static
  {
    String[] arrayOfString = new String[2];
    arrayOfString[0] = "_id";
    arrayOfString[1] = "orientation";
    ID_PROJECTION = arrayOfString;
  }

  public ImageViewerAdapterAndroid(AdaptersHolder paramAdaptersHolder)
  {
    super(paramAdaptersHolder);
    ImageViewerAdapterAndroid.1 local1 = new ImageViewerAdapterAndroid.1(this);
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver1 = new DecoratedBroadcastReceiver("android.intent.action.MEDIA_EJECT", local1);
    this.sdReceiver = localDecoratedBroadcastReceiver1;
    ImageViewerAdapterAndroid.2 local2 = new ImageViewerAdapterAndroid.2(this);
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver2 = new DecoratedBroadcastReceiver("android.intent.action.MEDIA_SCANNER_FINISHED", local2);
    this.mediaReceiver = localDecoratedBroadcastReceiver2;
    ImageViewerAdapterAndroid.3 local3 = new ImageViewerAdapterAndroid.3(this);
    this.serviceConnection = local3;
  }

  public static native void folderAdd(int paramInt, String paramString1, String paramString2);

  private List<Pair<String, Integer>> getImagesByFolder(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    Uri localUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
    Cursor localCursor;
    if (!TextUtils.isEmpty(paramString))
    {
      ContentResolver localContentResolver1 = this.context.getContentResolver();
      String[] arrayOfString1 = ID_PROJECTION;
      String[] arrayOfString2 = new String[1];
      arrayOfString2[0] = paramString;
      localCursor = localContentResolver1.query(localUri, arrayOfString1, "bucket_id=?", arrayOfString2, "date_added DESC");
    }
    while (localCursor != null)
    {
      int i = localCursor.getColumnIndex("_id");
      int j = localCursor.getColumnIndex("orientation");
      ContentResolver localContentResolver2;
      try
      {
        if (!localCursor.moveToNext())
          break label195;
        String str = localCursor.getString(i);
        Integer localInteger = Integer.valueOf(localCursor.getInt(j));
        Pair localPair = new Pair(str, localInteger);
        boolean bool = localArrayList.add(localPair);
      }
      finally
      {
        localCursor.close();
      }
      String[] arrayOfString3 = ID_PROJECTION;
      String[] arrayOfString4 = null;
      localCursor = localContentResolver2.query(localUri, arrayOfString3, null, arrayOfString4, "date_added DESC LIMIT 50");
      continue;
      label195: localCursor.close();
    }
    return localArrayList;
  }

  private int getRotation(String paramString)
  {
    ContentResolver localContentResolver = this.context.getContentResolver();
    Uri localUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
    String[] arrayOfString1 = ID_PROJECTION;
    String[] arrayOfString2 = new String[1];
    arrayOfString2[0] = paramString;
    Cursor localCursor = localContentResolver.query(localUri, arrayOfString1, "_id=?", arrayOfString2, null);
    int i;
    if (localCursor == null)
    {
      if (localCursor != null)
        localCursor.close();
      i = 0;
    }
    while (true)
    {
      return i;
      try
      {
        int j = localCursor.getColumnIndex("orientation");
        if ((j != -1) && (localCursor.moveToFirst()))
        {
          int k = localCursor.getInt(j);
          i = k;
          if (localCursor == null)
            continue;
          localCursor.close();
          continue;
        }
        if (localCursor != null)
          localCursor.close();
        i = 0;
      }
      finally
      {
        if (localCursor != null)
          localCursor.close();
      }
    }
  }

  public static native void imageAdd(int paramInt, String paramString, Integer paramInteger);

  private void tryToBind()
  {
    if (this.isBound);
    while (true)
    {
      return;
      Context localContext = this.context;
      Intent localIntent = this.serviceIntent;
      ServiceConnection localServiceConnection = this.serviceConnection;
      boolean bool = localContext.bindService(localIntent, localServiceConnection, 1);
      this.isBound = 1;
    }
  }

  private void tryToUnbind()
  {
    if (!this.isBound);
    while (true)
    {
      return;
      Context localContext = this.context;
      ServiceConnection localServiceConnection = this.serviceConnection;
      localContext.unbindService(localServiceConnection);
      this.isBound = 0;
    }
  }

  public static native void update();

  public void getFolderIds(int paramInt)
  {
    Uri localUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI.buildUpon().appendQueryParameter("distinct", "true").build();
    ContentResolver localContentResolver = this.context.getContentResolver();
    String[] arrayOfString1 = new String[2];
    arrayOfString1[0] = "bucket_display_name";
    arrayOfString1[1] = "bucket_id";
    String[] arrayOfString2 = null;
    String str1 = null;
    Cursor localCursor = MediaStore.Images.Media.query(localContentResolver, localUri, arrayOfString1, null, arrayOfString2, str1);
    try
    {
      if (localCursor.moveToNext())
      {
        String str2 = localCursor.getString(1);
        String str3 = localCursor.getString(0);
        folderAdd(paramInt, str2, str3);
      }
    }
    finally
    {
      localCursor.close();
    }
  }

  public Bitmap getImage(String paramString)
  {
    if (this.imageViewer != null);
    while (true)
    {
      try
      {
        localBitmap = this.imageViewer.getBitmap(paramString);
        if (localBitmap != null)
          continue;
        localObject = null;
        return localObject;
        int i = getRotation(paramString);
        if (i == 0)
          continue;
        float f = i;
        localObject = BitmapHelper.rotate(localBitmap, f);
        localBitmap.recycle();
        continue;
      }
      catch (Exception localException)
      {
        Bitmap localBitmap;
        localException.printStackTrace();
        localObject = 0;
        continue;
        localObject = localBitmap;
        continue;
      }
      Object localObject = null;
    }
  }

  public void getImageList(int paramInt, String paramString)
  {
    String str1 = Environment.getExternalStorageState();
    if (!"mounted".equals(str1));
    while (true)
    {
      return;
      try
      {
        if (paramString.equals("gallery"))
          paramString = "";
        Iterator localIterator = getImagesByFolder(paramString).iterator();
        while (localIterator.hasNext())
        {
          Pair localPair = (Pair)localIterator.next();
          String str2 = (String)localPair.first;
          Integer localInteger = (Integer)localPair.second;
          imageAdd(paramInt, str2, localInteger);
        }
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
    }
  }

  public void onCreate(Context paramContext, NativeCallbacks paramNativeCallbacks)
  {
    this.context = paramContext;
    this.nc = paramNativeCallbacks;
    Intent localIntent1 = new Intent(paramContext, ImageViewerService.class);
    this.serviceIntent = localIntent1;
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver1 = this.sdReceiver;
    ImageViewerAdapterAndroid.4 local4 = new ImageViewerAdapterAndroid.4(this);
    localDecoratedBroadcastReceiver1.addActionListener("android.intent.action.MEDIA_UNMOUNTED", local4);
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver2 = this.sdReceiver;
    ImageViewerAdapterAndroid.5 local5 = new ImageViewerAdapterAndroid.5(this);
    localDecoratedBroadcastReceiver2.addActionListener("android.intent.action.MEDIA_MOUNTED", local5);
    Handler localHandler = new Handler();
    ImageViewerAdapterAndroid.6 local6 = new ImageViewerAdapterAndroid.6(this, localHandler);
    this.contentObserver = local6;
    IntentFilter localIntentFilter1 = this.sdReceiver.getIntentFilter();
    localIntentFilter1.addDataScheme("file");
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver3 = this.sdReceiver;
    Intent localIntent2 = paramContext.registerReceiver(localDecoratedBroadcastReceiver3, localIntentFilter1);
    IntentFilter localIntentFilter2 = this.mediaReceiver.getIntentFilter();
    localIntentFilter2.addDataScheme("file");
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver4 = this.mediaReceiver;
    Intent localIntent3 = paramContext.registerReceiver(localDecoratedBroadcastReceiver4, localIntentFilter2);
    tryToBind();
    ContentResolver localContentResolver = paramContext.getContentResolver();
    Uri localUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
    ContentObserver localContentObserver = this.contentObserver;
    localContentResolver.registerContentObserver(localUri, 1, localContentObserver);
  }

  public void onDestroy(Context paramContext)
  {
    ContentResolver localContentResolver = paramContext.getContentResolver();
    ContentObserver localContentObserver = this.contentObserver;
    localContentResolver.unregisterContentObserver(localContentObserver);
    tryToUnbind();
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver1 = this.sdReceiver;
    paramContext.unregisterReceiver(localDecoratedBroadcastReceiver1);
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver2 = this.mediaReceiver;
    paramContext.unregisterReceiver(localDecoratedBroadcastReceiver2);
  }

  public void openImage(String paramString)
  {
    if (TextUtils.isEmpty(paramString))
      boolean bool = this.nc.launch("gallery");
    while (true)
    {
      return;
      Uri localUri1 = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
      long l = Long.valueOf(paramString).longValue();
      Uri localUri2 = ContentUris.withAppendedId(localUri1, l);
      Intent localIntent = new Intent("android.intent.action.VIEW", localUri2);
      this.context.startActivity(localIntent);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.imageviewer.ImageViewerAdapterAndroid
 * JD-Core Version:    0.6.0
 */