package com.softspb.shell.adapters;

import java.util.HashMap;

class WirelessAdapterAndroid$2 extends HashMap<Integer, Integer>
{
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.WirelessAdapterAndroid.2
 * JD-Core Version:    0.6.0
 */