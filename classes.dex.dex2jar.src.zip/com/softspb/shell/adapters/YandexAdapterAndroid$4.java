package com.softspb.shell.adapters;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

final class YandexAdapterAndroid$4 extends BroadcastReceiver
{
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    String str1 = paramIntent.getData().getSchemeSpecificPart();
    if (!YandexAdapterAndroid.access$000().equals(str1))
      return;
    String str2 = paramIntent.getAction();
    if ("android.intent.action.PACKAGE_ADDED".equals(str2));
    for (int i = 2; ; i = 1)
    {
      YandexAdapterAndroid.access$100(paramContext, i);
      break;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.YandexAdapterAndroid.4
 * JD-Core Version:    0.6.0
 */