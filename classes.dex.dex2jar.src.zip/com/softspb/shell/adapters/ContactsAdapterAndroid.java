package com.softspb.shell.adapters;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.ContactsContract.Contacts;
import android.provider.ContactsContract.Data;
import android.provider.ContactsContract.PhoneLookup;
import android.telephony.PhoneNumberUtils;
import android.util.SparseIntArray;
import android.widget.Toast;
import com.softspb.shell.Home;
import com.softspb.shell.opengl.NativeCallbacks;
import com.softspb.util.DateChangedObserver;
import com.softspb.util.DateChangedObserver.DateChangedListener;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import com.spb.contacts.IContactsService;
import com.spb.contacts.IContactsServiceCallback;
import com.spb.contacts.IPhoneNumberResolvingService;
import com.spb.contacts.IPhoneNumberResolvingServiceCallback;
import com.spb.contacts.R.string;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;

public class ContactsAdapterAndroid extends ContactsAdapter
  implements DateChangedObserver.DateChangedListener
{
  private static final String[] CONTACT_PHONE_LOOKUP_PROJECTION = ;
  private static final String[] CONTACT_PHOTO_ID_PROJECTION = ;
  private static final int INDEX_CONTACT_LOOKUP_KEY = 0;
  private static final int INDEX_CONTACT_PHOTO_ID = 0;
  private static final int INDEX_PHOTO_DATA = 0;
  private static final String ORDER_SMS_DATE_DESC_LIMIT_1 = "date DESC LIMIT 1";
  private static final String[] PHOTO_DATA_PROJECTION;
  private static final String[] PROJECTION_PHONE_NUMBER;
  private static final String[] PROJECTION_SMS_ID;
  private static final String[] PROJECTION_SMS_ID_DATE;
  private static final String SELECTION_PHONES_BY_CONTACT_ID = "contact_id" + "=? AND " + "mimetype" + "='" + "vnd.android.cursor.item/phone_v2" + 39;
  private static Logger logger;
  final SparseIntArray contactIds;
  int contactPickingToken;
  int contactsAdapterToken;
  IContactsService contactsService;
  private IContactsServiceCallback contactsServiceCallback;
  final ServiceConnection contactsServiceConnection;
  ContentResolver contentResolver;
  Context context;
  private Handler myUiHandler;
  Handler nativeThreadHandler;
  IPhoneNumberResolvingServiceCallback phoneNumberCallback;
  IPhoneNumberResolvingService phoneNumberService;
  final ServiceConnection phoneNumberServiceConnection;
  CountDownLatch serviceConnectionCountDown;

  static
  {
    String[] arrayOfString1 = new String[1];
    arrayOfString1[0] = "data1";
    PROJECTION_PHONE_NUMBER = arrayOfString1;
    String[] arrayOfString2 = new String[1];
    arrayOfString2[0] = "_id";
    PROJECTION_SMS_ID = arrayOfString2;
    String[] arrayOfString3 = new String[2];
    arrayOfString3[0] = "_id";
    arrayOfString3[1] = "date";
    PROJECTION_SMS_ID_DATE = arrayOfString3;
    String[] arrayOfString4 = new String[1];
    arrayOfString4[0] = "lookup";
    CONTACT_PHONE_LOOKUP_PROJECTION = arrayOfString4;
    String[] arrayOfString5 = new String[1];
    arrayOfString5[0] = "data15";
    PHOTO_DATA_PROJECTION = arrayOfString5;
    String[] arrayOfString6 = new String[1];
    arrayOfString6[0] = "photo_id";
    CONTACT_PHOTO_ID_PROJECTION = arrayOfString6;
    logger = Loggers.getLogger(ContactsAdapterAndroid.class.getName());
  }

  public ContactsAdapterAndroid(AdaptersHolder paramAdaptersHolder)
  {
    super(paramAdaptersHolder);
    SparseIntArray localSparseIntArray = new SparseIntArray();
    this.contactIds = localSparseIntArray;
    ContactsAdapterAndroid.1 local1 = new ContactsAdapterAndroid.1(this);
    this.contactsServiceCallback = local1;
    ContactsAdapterAndroid.2 local2 = new ContactsAdapterAndroid.2(this);
    this.phoneNumberCallback = local2;
    ContactsAdapterAndroid.3 local3 = new ContactsAdapterAndroid.3(this);
    this.contactsServiceConnection = local3;
    ContactsAdapterAndroid.4 local4 = new ContactsAdapterAndroid.4(this);
    this.phoneNumberServiceConnection = local4;
  }

  private String buildSelectionSMSByPhones_numbers(ArrayList<String> paramArrayList)
  {
    int i;
    if (paramArrayList == null)
    {
      i = 0;
      if (i != 0)
        break label22;
    }
    label22: StringBuilder localStringBuilder1;
    for (String str1 = null; ; str1 = localStringBuilder1.toString())
    {
      return str1;
      i = paramArrayList.size();
      break;
      localStringBuilder1 = new StringBuilder();
      int j = 0;
      while (j < i)
      {
        if (j > 0)
          StringBuilder localStringBuilder2 = localStringBuilder1.append(" OR ");
        StringBuilder localStringBuilder3 = localStringBuilder1.append("PHONE_NUMBERS_EQUAL(address,'");
        String str2 = (String)paramArrayList.get(j);
        StringBuilder localStringBuilder4 = localStringBuilder3.append(str2).append("')");
        j += 1;
      }
    }
  }

  private boolean changeContactIsFavorite(int paramInt, boolean paramBoolean1, boolean paramBoolean2)
  {
    StringBuilder localStringBuilder = null;
    int i = 1;
    String str1 = "changeContactIsFavorite: contactId=" + paramInt + " isFavorite=" + paramBoolean1 + " isNativeThread=" + paramBoolean2;
    logd(str1);
    ContentValues localContentValues = new ContentValues();
    label150: ContactsAdapterAndroid.6 local6;
    if (paramBoolean1)
    {
      int j = 1;
      Integer localInteger = Integer.valueOf(j);
      localContentValues.put("starred", localInteger);
      Uri localUri1 = ContactsContract.Contacts.CONTENT_URI;
      long l = paramInt;
      Uri localUri2 = ContentUris.withAppendedId(localUri1, l);
      if (this.contentResolver.update(localUri2, localContentValues, null, null) != 1)
        break label222;
      localStringBuilder = new StringBuilder().append("Contact id=").append(paramInt);
      if (!paramBoolean1)
        break label200;
      String str2 = " was added to favorites.";
      String str4 = str2;
      logd(str4);
      local6 = new ContactsAdapterAndroid.6(this, paramInt, paramBoolean1);
      if (!paramBoolean2)
        break label208;
      local6.run();
    }
    while (true)
    {
      return i;
      int k = 0;
      break;
      label200: String str3 = " was removed from favorites.";
      break label150;
      label208: boolean bool = this.nativeThreadHandler.post(local6);
      continue;
      label222: Logger localLogger = logger;
      String str5 = "Contact id=" + paramInt + " was NOT added to favorites";
      localLogger.w(str5);
      i = 0;
    }
  }

  private void checkAdapterInitialized()
  {
    if (this.contactsAdapterToken == 0)
    {
      IllegalStateException localIllegalStateException = new IllegalStateException("Contacts adapter is not initialized");
      Throwable localThrowable = localIllegalStateException.fillInStackTrace();
      logger.e("Contacts adapter is not initialized", localIllegalStateException);
      throw localIllegalStateException;
    }
  }

  // ERROR //
  private boolean checkCanLoadContact(Uri paramUri)
  {
    // Byte code:
    //   0: new 56	java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial 59	java/lang/StringBuilder:<init>	()V
    //   7: ldc_w 366
    //   10: invokevirtual 65	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   13: aload_1
    //   14: invokevirtual 369	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   17: invokevirtual 81	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   20: astore_2
    //   21: aload_0
    //   22: aload_2
    //   23: invokespecial 158	com/softspb/shell/adapters/ContactsAdapterAndroid:logd	(Ljava/lang/String;)V
    //   26: ldc 15
    //   28: istore_3
    //   29: aload_1
    //   30: ifnull +60 -> 90
    //   33: aload_0
    //   34: getfield 307	com/softspb/shell/adapters/ContactsAdapterAndroid:contentResolver	Landroid/content/ContentResolver;
    //   37: astore 4
    //   39: aload_1
    //   40: astore 5
    //   42: aload 4
    //   44: aload 5
    //   46: aconst_null
    //   47: aconst_null
    //   48: aconst_null
    //   49: aconst_null
    //   50: invokevirtual 373	android/content/ContentResolver:query	(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   53: astore 6
    //   55: aload 6
    //   57: ifnull +63 -> 120
    //   60: aload 6
    //   62: invokeinterface 379 1 0
    //   67: istore 7
    //   69: iload 7
    //   71: ifeq +49 -> 120
    //   74: ldc_w 380
    //   77: istore_3
    //   78: aload 6
    //   80: ifnull +10 -> 90
    //   83: aload 6
    //   85: invokeinterface 383 1 0
    //   90: new 56	java/lang/StringBuilder
    //   93: dup
    //   94: invokespecial 59	java/lang/StringBuilder:<init>	()V
    //   97: ldc_w 385
    //   100: invokevirtual 65	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   103: iload_3
    //   104: invokevirtual 276	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
    //   107: invokevirtual 81	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   110: astore 8
    //   112: aload_0
    //   113: aload 8
    //   115: invokespecial 158	com/softspb/shell/adapters/ContactsAdapterAndroid:logd	(Ljava/lang/String;)V
    //   118: iload_3
    //   119: ireturn
    //   120: ldc 15
    //   122: istore_3
    //   123: goto -45 -> 78
    //   126: astore 9
    //   128: aload 6
    //   130: ifnull -40 -> 90
    //   133: aload 6
    //   135: invokeinterface 383 1 0
    //   140: goto -50 -> 90
    //   143: astore 10
    //   145: goto -55 -> 90
    //   148: astore 11
    //   150: aload 6
    //   152: ifnull +10 -> 162
    //   155: aload 6
    //   157: invokeinterface 383 1 0
    //   162: aload 11
    //   164: athrow
    //   165: astore 12
    //   167: goto -77 -> 90
    //   170: astore 13
    //   172: goto -10 -> 162
    //
    // Exception table:
    //   from	to	target	type
    //   33	69	126	java/lang/Exception
    //   133	140	143	java/lang/Exception
    //   33	69	148	finally
    //   83	90	165	java/lang/Exception
    //   155	162	170	java/lang/Exception
  }

  static int dataMimetype2NativeAddressType(String paramString)
  {
    int i;
    if ("vnd.android.cursor.item/phone_v2".equals(paramString))
      i = 0;
    while (true)
    {
      return i;
      if ("vnd.android.cursor.item/email_v2".equals(paramString))
      {
        i = 1;
        continue;
      }
      if ("vnd.android.cursor.item/im".equals(paramString))
      {
        i = 2;
        continue;
      }
      i = 3;
    }
  }

  static int eventType2NativeEventType(int paramInt)
  {
    int i;
    switch (paramInt)
    {
    case 2:
    default:
      i = 2;
    case 3:
    case 1:
    }
    while (true)
    {
      return i;
      i = 0;
      continue;
      i = 1;
    }
  }

  static int locationType2NativeLocationType(int paramInt)
  {
    int i;
    switch (paramInt)
    {
    default:
      i = 3;
    case 2:
    case 3:
    case 17:
    case 1:
    }
    while (true)
    {
      return i;
      i = 0;
      continue;
      i = 2;
      continue;
      i = 1;
    }
  }

  private void logd(String paramString)
  {
    Thread localThread = Thread.currentThread();
    StringBuilder localStringBuilder1 = new StringBuilder().append("[Thread id=");
    long l = localThread.getId();
    StringBuilder localStringBuilder2 = localStringBuilder1.append(l).append(" name=");
    String str1 = localThread.getName();
    String str2 = str1 + "; this=" + this + "] " + paramString;
    logger.d(str2);
  }

  private void loge(String paramString, Throwable paramThrowable)
  {
    Thread localThread = Thread.currentThread();
    StringBuilder localStringBuilder1 = new StringBuilder().append("[Thread id=");
    long l = localThread.getId();
    StringBuilder localStringBuilder2 = localStringBuilder1.append(l).append(" name=");
    String str1 = localThread.getName();
    String str2 = str1 + "; this=" + this + "] " + paramString;
    logger.e(str2, paramThrowable);
  }

  private long lookupContactId(String paramString)
  {
    long l1 = 0L;
    try
    {
      Uri localUri1 = ContactsContract.PhoneLookup.CONTENT_FILTER_URI;
      String str1 = Uri.encode(paramString);
      Uri localUri2 = Uri.withAppendedPath(localUri1, str1);
      ContentResolver localContentResolver = this.contentResolver;
      String[] arrayOfString = CONTACT_PHONE_LOOKUP_PROJECTION;
      localCursor = localContentResolver.query(localUri2, arrayOfString, null, null, null);
      if ((localCursor != null) && (localCursor.moveToFirst()))
      {
        String str2 = localCursor.getString(0);
        localCursor.close();
        Uri localUri3 = ContactsContract.Contacts.getLookupUri(0L, str2);
        Uri localUri4 = ContactsContract.Contacts.lookupContact(this.contentResolver, localUri3);
        if (localUri4 != null)
        {
          long l2 = ContentUris.parseId(localUri4);
          l1 = l2;
        }
      }
      do
        return l1;
      while ((localCursor == null) || (localCursor.isClosed()));
      localCursor.close();
    }
    finally
    {
      Cursor localCursor;
      if ((localCursor != null) && (!localCursor.isClosed()))
        localCursor.close();
    }
  }

  private static native void notifyContactChanged(int paramInt1, int paramInt2);

  private static native void notifyContactPicked(int paramInt1, boolean paramBoolean, int paramInt2);

  private static native void notifyNearestBirthdaysChanged(int paramInt);

  private static native void onBirthdayDeleted(int paramInt1, int paramInt2);

  private static native void onBirthdayUpdated(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);

  private static native void onConnectionDeleted(int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  private static native void onConnectionUpdated(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, String paramString1, String paramString2, int paramInt6);

  private static native void onContactDeleted(int paramInt1, int paramInt2, int paramInt3);

  private static native void onContactIsFavoriteChanged(int paramInt1, int paramInt2, boolean paramBoolean);

  private static native void onContactPhotoUpdated(int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  private static native void onContactUpdated(int paramInt1, int paramInt2, String paramString1, String paramString2, boolean paramBoolean, int paramInt3, int paramInt4);

  private static native void onEventDeleted(int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  private static native void onEventUpdated(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong, int paramInt5);

  private static native void onFinishedReload(int paramInt1, int paramInt2);

  private static native void onFinishedReloadingBirthdays(int paramInt);

  private static native void onFinishedUpdatingContact(int paramInt1, int paramInt2, int paramInt3);

  private static native void onStartedReload(int paramInt1, int paramInt2);

  private static native void onStartedReloadingBirthdays(int paramInt);

  private static native void onStartedUpdatingContact(int paramInt1, int paramInt2, int paramInt3);

  private static native void onStructuredNameChanged(int paramInt1, int paramInt2, String paramString1, String paramString2);

  private byte[] queryContactPhoto(Uri paramUri)
  {
    long l = queryContactPhotoId(paramUri);
    Uri localUri;
    if (l != 0L)
      localUri = ContentUris.withAppendedId(ContactsContract.Data.CONTENT_URI, l);
    try
    {
      ContentResolver localContentResolver = this.contentResolver;
      String[] arrayOfString = PHOTO_DATA_PROJECTION;
      localCursor = localContentResolver.query(localUri, arrayOfString, null, null, null);
      if ((localCursor != null) && (localCursor.moveToFirst()))
      {
        byte[] arrayOfByte1 = localCursor.getBlob(0);
        arrayOfByte2 = arrayOfByte1;
        return arrayOfByte2;
      }
      if (localCursor != null)
        localCursor.close();
      byte[] arrayOfByte2 = null;
    }
    finally
    {
      Cursor localCursor;
      if (localCursor != null)
        localCursor.close();
    }
  }

  private long queryContactPhotoId(Uri paramUri)
  {
    try
    {
      ContentResolver localContentResolver = this.contentResolver;
      String[] arrayOfString = CONTACT_PHOTO_ID_PROJECTION;
      Uri localUri = paramUri;
      localCursor = localContentResolver.query(localUri, arrayOfString, null, null, null);
      if ((localCursor != null) && (localCursor.moveToFirst()))
      {
        long l1 = localCursor.getLong(0);
        l2 = l1;
        return l2;
      }
      if (localCursor != null)
        localCursor.close();
      long l2 = 0L;
    }
    finally
    {
      Cursor localCursor;
      if (localCursor != null)
        localCursor.close();
    }
  }

  private ArrayList<String> queryPhoneNumbers(int paramInt)
    throws Exception
  {
    long l1 = SystemClock.uptimeMillis();
    StringBuilder localStringBuilder1 = new StringBuilder().append("queryPhoneNumbers: contactId=");
    int i = paramInt;
    String str1 = i + " >>>";
    logd(str1);
    ArrayList localArrayList = new ArrayList();
    int j = 0;
    while (true)
    {
      Cursor localCursor;
      int m;
      try
      {
        ContentResolver localContentResolver = this.contentResolver;
        Uri localUri = ContactsContract.Data.CONTENT_URI;
        String[] arrayOfString1 = PROJECTION_PHONE_NUMBER;
        String str2 = SELECTION_PHONES_BY_CONTACT_ID;
        String[] arrayOfString2 = new String[1];
        String str3 = Integer.toString(paramInt);
        arrayOfString2[0] = str3;
        localCursor = localContentResolver.query(localUri, arrayOfString1, str2, arrayOfString2, null);
        if ((localCursor != null) && (localCursor.moveToFirst()))
          if (!localCursor.isAfterLast())
          {
            String str4 = localCursor.getString(0);
            int k = 1;
            m = 0;
            if (m >= j)
              continue;
            String str5 = (String)localArrayList.get(m);
            if (PhoneNumberUtils.compare(str4, str5))
            {
              k = 0;
              if (k == 0)
                continue;
              boolean bool1 = localArrayList.add(str4);
              j += 1;
              boolean bool2 = localCursor.moveToNext();
              continue;
            }
          }
      }
      catch (Exception localException1)
      {
        StringBuilder localStringBuilder2 = new StringBuilder().append("queryPhoneNumbers: error: ").append(localException1).append(" <<< ");
        long l2 = SystemClock.uptimeMillis() - l1;
        String str6 = l2 + "ms";
        logd(str6);
        throw localException1;
      }
      finally
      {
        if (localCursor == null);
      }
      try
      {
        localCursor.close();
        label294: throw localObject;
        m += 1;
        continue;
        if (localCursor != null);
        try
        {
          localCursor.close();
          label318: StringBuilder localStringBuilder3 = new StringBuilder().append("queryPhoneNumbers: got ");
          int n = localArrayList.size();
          StringBuilder localStringBuilder4 = localStringBuilder3.append(n).append(" numbers <<< ");
          long l3 = SystemClock.uptimeMillis() - l1;
          String str7 = l3 + "ms";
          logd(str7);
          return localArrayList;
        }
        catch (Exception localException2)
        {
          break label318;
        }
      }
      catch (Exception localException3)
      {
        break label294;
      }
    }
  }

  public boolean addToFavorites(int paramInt)
  {
    String str = "addToFavorites: contactId=" + paramInt;
    logd(str);
    return changeContactIsFavorite(paramInt, 1, 1);
  }

  public void call(String paramString, boolean paramBoolean)
  {
    Uri localUri = Uri.fromParts("tel", paramString, null);
    Intent localIntent1 = new Intent();
    Intent localIntent2 = localIntent1.setData(localUri);
    if (paramBoolean)
      Intent localIntent3 = localIntent1.setAction("android.intent.action.CALL");
    while (true)
    {
      this.context.startActivity(localIntent1);
      return;
      Intent localIntent4 = localIntent1.setAction("android.intent.action.DIAL");
    }
  }

  public void disposeContactsAdapter()
  {
    logd("disposeContactsAdapter");
    if (this.contactsAdapterToken != 0)
    {
      this.contactsAdapterToken = 0;
      DateChangedObserver.getInstance().unregisterListener(this);
    }
    if (this.contactsService != null);
    try
    {
      IContactsService localIContactsService = this.contactsService;
      IContactsServiceCallback localIContactsServiceCallback = this.contactsServiceCallback;
      localIContactsService.unregisterCallback(localIContactsServiceCallback);
      label50: Context localContext1 = this.context;
      ServiceConnection localServiceConnection1 = this.contactsServiceConnection;
      localContext1.unbindService(localServiceConnection1);
      this.contactsService = null;
      if (this.phoneNumberService != null);
      try
      {
        IPhoneNumberResolvingService localIPhoneNumberResolvingService = this.phoneNumberService;
        IPhoneNumberResolvingServiceCallback localIPhoneNumberResolvingServiceCallback = this.phoneNumberCallback;
        localIPhoneNumberResolvingService.unregisterCallback(localIPhoneNumberResolvingServiceCallback);
        label100: Context localContext2 = this.context;
        ServiceConnection localServiceConnection2 = this.phoneNumberServiceConnection;
        localContext2.unbindService(localServiceConnection2);
        this.phoneNumberService = null;
        return;
      }
      catch (Exception localException1)
      {
        break label100;
      }
    }
    catch (Exception localException2)
    {
      break label50;
    }
  }

  public int getContactByPhone(String paramString)
  {
    String str1 = "getContactByPhone: phoneNumber=" + paramString;
    logd(str1);
    checkAdapterInitialized();
    int i = 0;
    int j;
    if (this.phoneNumberService == null)
    {
      logd("getContactByPhone <<< NOT bound to service, do nothing");
      j = 0;
    }
    while (true)
    {
      return j;
      try
      {
        long l = this.phoneNumberService.getResolvedContactId(paramString);
        i = (int)l;
        if (i == 0L)
        {
          logd("getContactByPhone: failed to obtain resolved contact ID from reslover service, trying to lookup...");
          i = (int)lookupContactId(paramString);
        }
        String str2 = "getContactByPhone: resolved contactId=" + i;
        logd(str2);
        if (i != 0)
          reloadContact(i);
        j = i;
      }
      catch (Exception localException)
      {
        while (true)
        {
          Logger localLogger = logger;
          String str3 = "Error invoking contacts service: " + localException;
          localLogger.e(str3, localException);
        }
      }
    }
  }

  public Bitmap getContactPic(int paramInt, String paramString)
  {
    String str1 = "getContactPic >>> contactLookupKey=" + paramString;
    logd(str1);
    checkAdapterInitialized();
    Uri localUri1 = ContactsContract.Contacts.getLookupUri(paramInt, paramString);
    Uri localUri2 = ContactsContract.Contacts.lookupContact(this.contentResolver, localUri1);
    Bitmap localBitmap = null;
    if (localUri2 != null)
    {
      byte[] arrayOfByte = queryContactPhoto(localUri2);
      if (arrayOfByte != null)
      {
        int i = arrayOfByte.length;
        localBitmap = BitmapFactory.decodeByteArray(arrayOfByte, 0, i, null);
      }
    }
    while (true)
    {
      logd("getContactPic <<<");
      return localBitmap;
      Logger localLogger1 = logger;
      String str2 = "Failed to load contact photo: " + localUri1;
      localLogger1.w(str2);
      continue;
      Logger localLogger2 = logger;
      String str3 = "Failed to lookup Contact with lookup URI: " + localUri1;
      localLogger2.w(str3);
    }
  }

  public int getLastMessage(int paramInt)
  {
    throw new UnsupportedOperationException("Unexpected use of last message feature.");
  }

  public void initContactsAdapter(int paramInt)
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("initContactsAdapter: contactsAdapterToken=0x");
    String str1 = Integer.toHexString(paramInt);
    String str2 = str1;
    logd(str2);
    StringBuilder localStringBuilder2 = new StringBuilder().append("initContactsAdapter: Thread ");
    long l = Thread.currentThread().getId();
    StringBuilder localStringBuilder3 = localStringBuilder2.append(l).append(" ");
    String str3 = Thread.currentThread().getName();
    String str4 = str3;
    logd(str4);
    this.contactsAdapterToken = paramInt;
    DateChangedObserver.getInstance().registerListener(this);
    Looper localLooper = Looper.myLooper();
    if (localLooper == null)
    {
      Looper.prepare();
      localLooper = Looper.myLooper();
    }
    Handler localHandler = new Handler(localLooper);
    this.nativeThreadHandler = localHandler;
    CountDownLatch localCountDownLatch = new CountDownLatch(2);
    this.serviceConnectionCountDown = localCountDownLatch;
    logd("initContactsAdapter: connecting to ContactsService...");
    String str5 = IContactsService.class.getName();
    Intent localIntent1 = new Intent(str5);
    String str6 = this.context.getPackageName();
    Intent localIntent2 = localIntent1.setPackage(str6);
    Context localContext1 = this.context;
    ServiceConnection localServiceConnection1 = this.contactsServiceConnection;
    boolean bool1 = localContext1.bindService(localIntent1, localServiceConnection1, 1);
    logd("initContactsAdapter: connecting to PhoneNumberService...");
    String str7 = IPhoneNumberResolvingService.class.getName();
    Intent localIntent3 = new Intent(str7);
    Intent localIntent4 = localIntent3.setPackage(str6);
    Context localContext2 = this.context;
    ServiceConnection localServiceConnection2 = this.phoneNumberServiceConnection;
    boolean bool2 = localContext2.bindService(localIntent3, localServiceConnection2, 1);
    try
    {
      this.serviceConnectionCountDown.await();
      logd("initContactsAdapter: connected to ContactsService.");
      return;
    }
    catch (InterruptedException localInterruptedException)
    {
      while (true)
      {
        Logger localLogger = logger;
        String str8 = "initContactsAdapter: connection to server interrupted: " + localInterruptedException;
        localLogger.e(str8, localInterruptedException);
      }
    }
  }

  public void onCreate(Context paramContext, NativeCallbacks paramNativeCallbacks)
  {
    this.context = paramContext;
    ContentResolver localContentResolver = paramContext.getContentResolver();
    this.contentResolver = localContentResolver;
  }

  public void onDateChanged()
  {
    logd("onDateChanged");
    notifyNearestBirthdaysChanged(this.contactsAdapterToken);
  }

  public void onPickContactResult(boolean paramBoolean, int paramInt, Intent paramIntent)
  {
    Uri localUri;
    if (paramInt == -1)
    {
      localUri = paramIntent.getData();
      if (!checkCanLoadContact(localUri))
      {
        Context localContext = this.context;
        int i = R.string.contacts_failed_pick;
        Toast.makeText(localContext, i, 1).show();
        if (!paramBoolean)
          notifyContactPicked(this.contactPickingToken, 0, 0);
      }
    }
    while (true)
    {
      return;
      if (!paramBoolean)
      {
        if (this.contactPickingToken == 0)
          continue;
        int j = (int)ContentUris.parseId(localUri);
        notifyContactPicked(this.contactPickingToken, 1, j);
        continue;
      }
      int k = (int)ContentUris.parseId(localUri);
      String str = "onPickContactResult: contactId=" + k;
      logd(str);
      if (this.contactIds.get(k, 0) == 0)
        reloadContact(k);
      boolean bool = changeContactIsFavorite(k, 1, 0);
      continue;
      if ((paramBoolean) || (this.contactPickingToken == 0))
        continue;
      notifyContactPicked(this.contactPickingToken, 0, 0);
    }
  }

  protected void onStartInUIThread()
  {
    super.onStartInUIThread();
    Handler localHandler = new Handler();
    this.myUiHandler = localHandler;
  }

  public void openContactCard(int paramInt, String paramString)
  {
    Uri localUri = ContactsContract.Contacts.getLookupUri(paramInt, paramString);
    Intent localIntent1 = new Intent("android.intent.action.VIEW");
    Intent localIntent2 = localIntent1.setData(localUri);
    this.context.startActivity(localIntent1);
  }

  public void reloadBirthdays(int paramInt)
  {
    logd("reloadBirthdays >>>");
    long l = SystemClock.uptimeMillis();
    if (this.contactsService == null)
    {
      String str1 = "reloadBirthdays <<< NOT bound to service, do nothing: " + l + " ms";
      logd(str1);
    }
    while (true)
    {
      return;
      if (paramInt == 1)
        paramInt = 2;
      try
      {
        while (true)
        {
          this.contactsService.reloadBirthdays(paramInt, 1);
          String str2 = "reloadBirthdays <<< " + l + " ms";
          logd(str2);
          break;
          paramInt = 1;
        }
      }
      catch (Exception localException)
      {
        while (true)
        {
          Logger localLogger = logger;
          String str3 = "Error invoking ContactsService: " + localException;
          localLogger.w(str3, localException);
        }
      }
    }
  }

  public void reloadContact(int paramInt)
  {
    String str1 = "reloadContact >>> contactId=" + paramInt;
    logd(str1);
    long l1 = System.currentTimeMillis();
    if (this.contactsService == null)
    {
      String str2 = "reloadContact <<< NOT bound to service, do nothing: " + l1 + " ms";
      logd(str2);
    }
    while (true)
    {
      return;
      try
      {
        this.contactsService.reloadContact(paramInt);
        StringBuilder localStringBuilder = new StringBuilder().append("reloadContact <<< ");
        long l2 = System.currentTimeMillis() - l1;
        String str3 = l2 + " ms";
        logd(str3);
      }
      catch (Exception localException)
      {
        while (true)
        {
          String str4 = "Error invoking ContactsService: " + localException;
          loge(str4, localException);
        }
      }
    }
  }

  public void reloadContacts(int paramInt)
  {
    logd("reloadContacts >>>");
    long l = SystemClock.uptimeMillis();
    if (this.contactsService == null)
    {
      String str1 = "reloadContacts <<< NOT bound to service, do nothing: " + l + " ms";
      logd(str1);
    }
    while (true)
    {
      return;
      if (paramInt == 1)
        paramInt = 2;
      try
      {
        while (true)
        {
          this.contactsService.reloadContacts(paramInt);
          String str2 = "reloadContacts <<< " + l + " ms";
          logd(str2);
          break;
          paramInt = 1;
        }
      }
      catch (Exception localException)
      {
        while (true)
        {
          String str3 = "Error invoking ContactsService: " + localException;
          loge(str3, localException);
        }
      }
    }
  }

  public boolean removeFromFavorites(int paramInt)
  {
    String str = "removeFromFavorites: contactId=" + paramInt;
    logd(str);
    return changeContactIsFavorite(paramInt, 0, 1);
  }

  public void showAddToFavoritesDialog()
  {
    ((Home)this.context).startPickContact(1);
  }

  public void showPickContactDialog(int paramInt)
  {
    Handler localHandler = this.myUiHandler;
    ContactsAdapterAndroid.5 local5 = new ContactsAdapterAndroid.5(this, paramInt);
    boolean bool = localHandler.post(local5);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.ContactsAdapterAndroid
 * JD-Core Version:    0.6.0
 */