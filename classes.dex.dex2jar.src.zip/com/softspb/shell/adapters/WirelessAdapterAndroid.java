package com.softspb.shell.adapters;

import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings.SettingNotFoundException;
import android.provider.Settings.System;
import com.softspb.shell.Home;
import com.softspb.shell.Home.PauseResumeListener;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.lang.reflect.Method;
import java.util.Map;

public class WirelessAdapterAndroid extends WirelessAdapter
  implements Home.PauseResumeListener
{
  private static final String AIRPLANE_EXTRA_STATE = "state";
  private static final Logger logger = Loggers.getLogger(WirelessAdapterAndroid.class.getName());
  private BluetoothAdapter bluetoothAdapter;
  private ConnectivityManager connectivityManager;
  private Home context;
  private boolean isRegistered;
  private Map<Integer, Integer> oldStates;
  private BroadcastReceiver receiver;
  private WifiManager wifiManager;

  public WirelessAdapterAndroid(int paramInt, Home paramHome)
  {
    super(paramInt);
    WirelessAdapterAndroid.1 local1 = new WirelessAdapterAndroid.1(this);
    this.receiver = local1;
    this.isRegistered = 0;
    WirelessAdapterAndroid.2 local2 = new WirelessAdapterAndroid.2(this);
    this.oldStates = local2;
    this.context = paramHome;
    Logger localLogger = logger;
    String str = "constructor nativePeer=" + paramInt + " context=" + paramHome;
    localLogger.d(str);
  }

  private int convertApState(int paramInt)
  {
    int i = 0;
    switch (paramInt)
    {
    default:
      Logger localLogger = logger;
      String str = "AP state=" + paramInt + " is not supported - check native to java constants mapping";
      localLogger.w(str);
    case 0:
    case 1:
    }
    while (true)
    {
      return i;
      i = 1;
    }
  }

  private int convertBtState(int paramInt)
  {
    int i = 0;
    switch (paramInt)
    {
    default:
      Logger localLogger = logger;
      String str = "bluetooth state=" + paramInt + " is not supported - check native to java constants mapping";
      localLogger.w(str);
    case 10:
    case 12:
    case 11:
    case 13:
    }
    while (true)
    {
      return i;
      i = 1;
      continue;
      i = 2;
      continue;
      i = 2;
    }
  }

  private int convertWifiState(int paramInt)
  {
    int i = 0;
    switch (paramInt)
    {
    default:
      Logger localLogger = logger;
      String str = "wifi state=" + paramInt + " is not supported - check native to java constants mapping";
      localLogger.w(str);
    case 1:
    case 4:
    case 3:
    case 2:
    case 0:
    }
    while (true)
    {
      return i;
      i = 1;
      continue;
      i = 2;
      continue;
      i = 2;
    }
  }

  private void registerReceiver()
  {
    Home localHome1 = this.context;
    BroadcastReceiver localBroadcastReceiver1 = this.receiver;
    IntentFilter localIntentFilter1 = new IntentFilter("android.bluetooth.adapter.action.STATE_CHANGED");
    Intent localIntent1 = localHome1.registerReceiver(localBroadcastReceiver1, localIntentFilter1);
    Home localHome2 = this.context;
    BroadcastReceiver localBroadcastReceiver2 = this.receiver;
    IntentFilter localIntentFilter2 = new IntentFilter("android.net.wifi.WIFI_STATE_CHANGED");
    Intent localIntent2 = localHome2.registerReceiver(localBroadcastReceiver2, localIntentFilter2);
    Home localHome3 = this.context;
    BroadcastReceiver localBroadcastReceiver3 = this.receiver;
    IntentFilter localIntentFilter3 = new IntentFilter("android.intent.action.AIRPLANE_MODE");
    Intent localIntent3 = localHome3.registerReceiver(localBroadcastReceiver3, localIntentFilter3);
    Home localHome4 = this.context;
    BroadcastReceiver localBroadcastReceiver4 = this.receiver;
    IntentFilter localIntentFilter4 = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
    Intent localIntent4 = localHome4.registerReceiver(localBroadcastReceiver4, localIntentFilter4);
    this.isRegistered = 1;
  }

  public int getWirelessState(int paramInt)
  {
    Logger localLogger1 = logger;
    String str1 = ">>>getWirelessState: type=" + paramInt;
    localLogger1.d(str1);
    int i;
    switch (paramInt)
    {
    case 3:
    default:
      i = 0;
      Logger localLogger2 = logger;
      String str2 = "wireless type=" + paramInt + " is not supported - check native to java constants mapping";
      localLogger2.w(str2);
    case 1:
    case 2:
    case 4:
    case 5:
    }
    while (true)
    {
      Logger localLogger3 = logger;
      String str3 = "<<<getWirelessState: result=" + i;
      localLogger3.d(str3);
      return i;
      int j = this.wifiManager.getWifiState();
      i = convertWifiState(j);
      continue;
      if (this.bluetoothAdapter == null)
      {
        i = 0;
        continue;
      }
      int k = this.bluetoothAdapter.getState();
      i = convertBtState(k);
      continue;
      int m = Settings.System.getInt(this.context.getContentResolver(), "airplane_mode_on", -1);
      i = convertApState(m);
      continue;
      NetworkInfo localNetworkInfo = this.connectivityManager.getActiveNetworkInfo();
      if ((localNetworkInfo != null) && (localNetworkInfo.getType() == 1) && (localNetworkInfo.isConnected()))
      {
        i = 1;
        continue;
      }
      i = 0;
    }
  }

  public boolean isBtDiscoverableSupported()
  {
    return false;
  }

  public boolean isWirelessSupported(int paramInt)
  {
    int i = 0;
    switch (paramInt)
    {
    default:
      Logger localLogger = logger;
      String str = "wireless type=" + paramInt + " is not supported - check native to java constants mapping";
      localLogger.w(str);
    case 0:
    case 3:
    case 4:
    case 1:
    case 2:
    }
    while (true)
    {
      return i;
      try
      {
        int j = Settings.System.getInt(this.context.getContentResolver(), "airplane_mode_on");
        i = 1;
      }
      catch (Settings.SettingNotFoundException localSettingNotFoundException)
      {
        logger.w("flight mode switch is not available", localSettingNotFoundException);
      }
      continue;
      i = 1;
    }
  }

  public void notifyChange(int paramInt1, int paramInt2)
  {
    Logger localLogger1 = logger;
    StringBuilder localStringBuilder = new StringBuilder().append(">>>notifyChange: type=").append(paramInt1).append(", state=").append(paramInt2).append(", old state:");
    Map localMap1 = this.oldStates;
    Integer localInteger1 = Integer.valueOf(paramInt1);
    Object localObject1 = localMap1.get(localInteger1);
    String str1 = localObject1;
    localLogger1.d(str1);
    Map localMap2 = this.oldStates;
    Integer localInteger2 = Integer.valueOf(paramInt1);
    if (((Integer)localMap2.get(localInteger2)).intValue() == paramInt2)
    {
      Logger localLogger2 = logger;
      String str2 = "state for " + paramInt1 + " not changed, skipping";
      localLogger2.d(str2);
    }
    while (true)
    {
      Map localMap3 = this.oldStates;
      Integer localInteger3 = Integer.valueOf(paramInt1);
      Integer localInteger4 = Integer.valueOf(paramInt2);
      Object localObject2 = localMap3.put(localInteger3, localInteger4);
      logger.d("<<<notifyChange");
      return;
      super.notifyChange(paramInt1, paramInt2);
    }
  }

  /** @deprecated */
  public void onPause()
  {
    monitorenter;
    try
    {
      if (this.isRegistered)
      {
        Home localHome = this.context;
        BroadcastReceiver localBroadcastReceiver = this.receiver;
        localHome.unregisterReceiver(localBroadcastReceiver);
        this.isRegistered = 0;
      }
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  /** @deprecated */
  public void onResume()
  {
    monitorenter;
    try
    {
      if (!this.isRegistered)
      {
        registerReceiver();
        int i = getWirelessState(2);
        notifyChange(2, i);
        int j = getWirelessState(4);
        notifyChange(4, j);
      }
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  /** @deprecated */
  public void onStart()
  {
    monitorenter;
    try
    {
      logger.d(">>>onCreate");
      super.onStart();
      Looper localLooper = Looper.getMainLooper();
      Handler localHandler = new Handler(localLooper);
      WirelessAdapterAndroid.3 local3 = new WirelessAdapterAndroid.3(this);
      boolean bool = localHandler.post(local3);
      WifiManager localWifiManager = (WifiManager)this.context.getSystemService("wifi");
      this.wifiManager = localWifiManager;
      ConnectivityManager localConnectivityManager = (ConnectivityManager)this.context.getSystemService("connectivity");
      this.connectivityManager = localConnectivityManager;
      Map localMap1 = this.oldStates;
      Integer localInteger1 = Integer.valueOf(1);
      Integer localInteger2 = Integer.valueOf(getWirelessState(1));
      Object localObject1 = localMap1.put(localInteger1, localInteger2);
      Map localMap2 = this.oldStates;
      Integer localInteger3 = Integer.valueOf(5);
      Integer localInteger4 = Integer.valueOf(getWirelessState(5));
      Object localObject2 = localMap2.put(localInteger3, localInteger4);
      Map localMap3 = this.oldStates;
      Integer localInteger5 = Integer.valueOf(4);
      Integer localInteger6 = Integer.valueOf(getWirelessState(4));
      Object localObject3 = localMap3.put(localInteger5, localInteger6);
      registerReceiver();
      this.context.setOnPauseResumeListener(this);
      logger.d("<<<onCreate");
      monitorexit;
      return;
    }
    finally
    {
      localObject4 = finally;
      monitorexit;
    }
    throw localObject4;
  }

  /** @deprecated */
  public void onStop()
  {
    monitorenter;
    try
    {
      logger.d(">>>onDestroy");
      super.onStop();
      this.isRegistered = 0;
      this.context.removeOnPauseResumeListener(this);
      if (this.isRegistered)
      {
        Home localHome = this.context;
        BroadcastReceiver localBroadcastReceiver = this.receiver;
        localHome.unregisterReceiver(localBroadcastReceiver);
      }
      logger.d("<<<onDestroy");
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public boolean switchWirelessState(int paramInt1, int paramInt2)
  {
    int i = 0;
    Logger localLogger1 = logger;
    String str1 = ">>>switchWirelessState: type=" + paramInt1 + ", state=" + paramInt2;
    localLogger1.d(str1);
    switch (paramInt1)
    {
    case 3:
    default:
    case 1:
    case 2:
    case 4:
    }
    int j;
    Intent localIntent1;
    while (true)
    {
      return i;
      switch (paramInt2)
      {
      default:
        Logger localLogger2 = logger;
        String str2 = "wireless state=" + paramInt2 + " is not supported for type=" + paramInt1 + " - check native to java constants mapping";
        localLogger2.w(str2);
        i = 0;
      case 1:
      case 0:
      }
      while (true)
      {
        Logger localLogger3 = logger;
        String str3 = "<<<switchWirelessState: result=" + i;
        localLogger3.d(str3);
        break;
        Method[] arrayOfMethod = this.wifiManager.getClass().getDeclaredMethods();
        int k = arrayOfMethod.length;
        int m = 0;
        while (true)
          if (m < k)
          {
            Method localMethod = arrayOfMethod[m];
            if (localMethod.getName().equals("setWifiApEnabled"));
            try
            {
              WifiManager localWifiManager = this.wifiManager;
              Object[] arrayOfObject = new Object[2];
              arrayOfObject[0] = 0;
              Boolean localBoolean = Boolean.valueOf(0);
              arrayOfObject[1] = localBoolean;
              Object localObject = localMethod.invoke(localWifiManager, arrayOfObject);
              m += 1;
            }
            catch (Throwable localThrowable)
            {
              while (true)
                logger.d("wireless AP disable failed:", localThrowable);
            }
          }
        boolean bool1 = this.wifiManager.setWifiEnabled(1);
        continue;
        bool1 = this.wifiManager.setWifiEnabled(0);
        continue;
        switch (paramInt2)
        {
        case 2:
        default:
          Logger localLogger4 = logger;
          String str4 = "wireless state=" + paramInt2 + " is not supported for type=" + paramInt1 + " - check native to java constants mapping";
          localLogger4.w(str4);
          break;
        case 1:
          bool1 = this.bluetoothAdapter.enable();
          break;
        case 0:
          bool1 = this.bluetoothAdapter.disable();
          break;
        case 3:
          j = 0;
        }
      }
      localIntent1 = new Intent("android.intent.action.AIRPLANE_MODE");
      switch (paramInt2)
      {
      default:
        Logger localLogger5 = logger;
        String str5 = "wireless state=" + paramInt2 + " is not supported for type=" + paramInt1 + " - check native to java constants mapping";
        localLogger5.w(str5);
      case 1:
      case 0:
      }
    }
    boolean bool2 = Settings.System.putInt(this.context.getContentResolver(), "airplane_mode_on", 1);
    Intent localIntent2 = localIntent1.putExtra("state", 1);
    while (true)
    {
      this.context.sendBroadcast(localIntent1);
      j = 1;
      break;
      boolean bool3 = Settings.System.putInt(this.context.getContentResolver(), "airplane_mode_on", 0);
      Intent localIntent3 = localIntent1.putExtra("state", 0);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.adapters.WirelessAdapterAndroid
 * JD-Core Version:    0.6.0
 */