package com.softspb.shell.weather.service;

import android.database.ContentObserver;
import android.util.Log;
import android.util.SparseArray;
import java.util.Iterator;
import java.util.List;

class WeatherDataCache$1
  implements Runnable
{
  public void run()
  {
    while (true)
    {
      int j;
      try
      {
        int i = WeatherDataCache.access$000(this.this$0).size();
        j = 0;
        if (j < i)
        {
          Iterator localIterator = ((List)WeatherDataCache.access$100(this.this$0).valueAt(j)).iterator();
          if (!localIterator.hasNext())
            break label100;
          ((ContentObserver)localIterator.next()).onChange(0);
          continue;
        }
      }
      catch (Throwable localThrowable)
      {
        String str = "Unexpected error: " + localThrowable;
        int k = Log.e("Weather", str, localThrowable);
      }
      return;
      label100: j += 1;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.weather.service.WeatherDataCache.1
 * JD-Core Version:    0.6.0
 */