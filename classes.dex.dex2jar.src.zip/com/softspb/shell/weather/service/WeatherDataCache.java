package com.softspb.shell.weather.service;

import android.app.Application;
import android.os.Handler;
import com.softspb.util.DateChangedObserver;
import com.softspb.util.DateChangedObserver.DateChangedListener;
import com.spb.cities.service.CurrentLocationClient;

public class WeatherDataCache extends com.softspb.weather.core.WeatherDataCache
  implements DateChangedObserver.DateChangedListener
{
  public WeatherDataCache(Application paramApplication, CurrentLocationClient paramCurrentLocationClient)
  {
    super(paramApplication, paramCurrentLocationClient);
  }

  protected String createCurrentLocationCityName(String paramString)
  {
    return paramString;
  }

  public void onDateChanged()
  {
    Handler localHandler1 = this.mHandler;
    WeatherDataCache.1 local1 = new WeatherDataCache.1(this);
    boolean bool1 = localHandler1.post(local1);
    Handler localHandler2 = this.mHandler;
    Runnable localRunnable1 = this.considerUpdateRunnable;
    localHandler2.removeCallbacks(localRunnable1);
    Handler localHandler3 = this.mHandler;
    Runnable localRunnable2 = this.considerUpdateRunnable;
    boolean bool2 = localHandler3.post(localRunnable2);
  }

  /** @deprecated */
  public void start()
  {
    monitorenter;
    try
    {
      super.start();
      DateChangedObserver.getInstance().registerListener(this);
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  /** @deprecated */
  public void stop()
  {
    monitorenter;
    try
    {
      DateChangedObserver.getInstance().unregisterListener(this);
      super.stop();
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.weather.service.WeatherDataCache
 * JD-Core Version:    0.6.0
 */