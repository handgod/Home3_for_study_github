package com.softspb.shell;

import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import com.softspb.util.log.Logger;

class Home$4
  implements View.OnKeyListener
{
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent)
  {
    Home.access$100().e("will be dispacthed");
    return false;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.Home.4
 * JD-Core Version:    0.6.0
 */