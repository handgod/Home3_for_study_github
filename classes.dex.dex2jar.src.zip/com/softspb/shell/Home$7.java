package com.softspb.shell;

import java.util.Set;

class Home$7
  implements Runnable
{
  public void run()
  {
    Set localSet = Home.access$300(this.this$0);
    Home.PauseResumeListener localPauseResumeListener = this.val$listener;
    boolean bool = localSet.add(localPauseResumeListener);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.Home.7
 * JD-Core Version:    0.6.0
 */