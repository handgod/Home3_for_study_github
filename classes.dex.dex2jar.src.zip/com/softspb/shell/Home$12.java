package com.softspb.shell;

import android.content.Intent;
import com.softspb.shell.view.FilterPickDialogBuilder.DialogResult;

class Home$12
  implements FilterPickDialogBuilder.DialogResult
{
  public void onResult(Intent paramIntent)
  {
    Home localHome = this.this$0;
    int i = Home.RequestCode.REQUEST_INSTALL_SHORTCUT;
    localHome.startActivityForResult(paramIntent, i);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.Home.12
 * JD-Core Version:    0.6.0
 */