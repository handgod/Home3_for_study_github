package com.softspb.shell.widget;

import android.appwidget.AppWidgetHostView;
import android.content.Context;
import android.graphics.Rect;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;
import android.widget.RemoteViews;
import com.softspb.shell.Home;
import com.softspb.shell.Home.MovementController;
import com.softspb.shell.view.WidgetController2;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import com.spb.shell3d.R.layout;

public class ShellWidgetHostView extends AppWidgetHostView
{
  private static final Logger logger = Loggers.getLogger(ShellWidgetHostView.class.getName());
  private boolean hasPerformedLongPress;
  private int lastDownX;
  private int lastDownY;
  private int lastX;
  private int lastY;
  private Object lock;
  private Home.MovementController movementController;
  private CheckForLongPress pendingCheckForLongPress;
  private int touchSlop;

  static
  {
    logger.enableThreadLog();
  }

  public ShellWidgetHostView(Context paramContext)
  {
    super(paramContext);
    Object localObject = new Object();
    this.lock = localObject;
  }

  public ShellWidgetHostView(Context paramContext, int paramInt1, int paramInt2)
  {
    super(paramContext, paramInt1, paramInt2);
    Object localObject = new Object();
    this.lock = localObject;
  }

  private void postCheckForLongClick()
  {
    this.hasPerformedLongPress = 0;
    this.movementController.setDelayed();
    if (this.pendingCheckForLongPress == null)
    {
      CheckForLongPress localCheckForLongPress1 = new CheckForLongPress(null);
      this.pendingCheckForLongPress = localCheckForLongPress1;
    }
    this.pendingCheckForLongPress.rememberWindowAttachCount();
    CheckForLongPress localCheckForLongPress2 = this.pendingCheckForLongPress;
    long l = ViewConfiguration.getLongPressTimeout();
    boolean bool = postDelayed(localCheckForLongPress2, l);
  }

  private void removeLongPressCallback()
  {
    this.hasPerformedLongPress = 0;
    if (this.pendingCheckForLongPress != null)
    {
      CheckForLongPress localCheckForLongPress = this.pendingCheckForLongPress;
      boolean bool = removeCallbacks(localCheckForLongPress);
    }
  }

  private void tryToFreeLock(MotionEvent paramMotionEvent)
  {
    if ((paramMotionEvent.getAction() == 1) || (paramMotionEvent.getAction() == 3))
    {
      Home.MovementController localMovementController = this.movementController;
      Object localObject = this.lock;
      localMovementController.free(localObject);
      this.hasPerformedLongPress = 0;
    }
  }

  public void cancelLongPress()
  {
    super.cancelLongPress();
    this.hasPerformedLongPress = 0;
    if (this.pendingCheckForLongPress != null)
    {
      CheckForLongPress localCheckForLongPress = this.pendingCheckForLongPress;
      boolean bool = removeCallbacks(localCheckForLongPress);
    }
  }

  protected View getErrorView()
  {
    LayoutInflater localLayoutInflater = (LayoutInflater)getContext().getSystemService("layout_inflater");
    int i = R.layout.appwidget_error;
    return localLayoutInflater.inflate(i, this, 0);
  }

  public ViewParent invalidateChildInParent(int[] paramArrayOfInt, Rect paramRect)
  {
    Logger localLogger = logger;
    String str = "ShellAppWidgetHost invalidateChildInParent " + paramRect + " " + paramArrayOfInt;
    localLogger.i(str);
    return super.invalidateChildInParent(paramArrayOfInt, paramRect);
  }

  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent)
  {
    int i = 1;
    int j = (int)paramMotionEvent.getRawX();
    this.lastX = j;
    int k = (int)paramMotionEvent.getRawY();
    this.lastY = k;
    if (this.hasPerformedLongPress)
    {
      tryToFreeLock(paramMotionEvent);
      if (paramMotionEvent.getAction() == 1)
      {
        int m = paramMotionEvent.getAction();
        int n = (int)paramMotionEvent.getRawX();
        int i1 = (int)paramMotionEvent.getRawY();
        Home.sendMouseEvent(m, n, i1);
      }
      return i;
    }
    switch (paramMotionEvent.getAction())
    {
    default:
    case 0:
    case 2:
    case 1:
    case 3:
    }
    while (true)
    {
      i = 0;
      break;
      int i2 = this.lastX;
      this.lastDownX = i2;
      int i3 = this.lastY;
      this.lastDownY = i3;
      postCheckForLongClick();
      continue;
      int i4 = this.lastDownX;
      int i5 = this.lastX;
      int i6 = Math.abs(i4 - i5);
      int i7 = this.touchSlop;
      int i8;
      if (i6 > i7)
      {
        i8 = 1;
        label186: int i9 = this.lastDownY;
        int i10 = this.lastY;
        int i11 = Math.abs(i9 - i10);
        int i12 = this.touchSlop;
        if (i11 <= i12)
          break label247;
      }
      label247: for (int i13 = 1; (i8 != 0) || (i13 != 0); i13 = 0)
      {
        removeLongPressCallback();
        break;
        i8 = 0;
        break label186;
      }
      removeLongPressCallback();
    }
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    int i = (int)paramMotionEvent.getRawX();
    this.lastX = i;
    int j = (int)paramMotionEvent.getRawY();
    this.lastY = j;
    if (this.hasPerformedLongPress)
    {
      tryToFreeLock(paramMotionEvent);
      if (paramMotionEvent.getAction() != 3)
      {
        int k = paramMotionEvent.getAction();
        int m = (int)paramMotionEvent.getRawX();
        int n = (int)paramMotionEvent.getRawY();
        Home.sendMouseEvent(k, m, n);
      }
    }
    boolean bool;
    for (int i1 = 1; ; bool = super.onTouchEvent(paramMotionEvent))
      return i1;
  }

  public void setMovementController(Home.MovementController paramMovementController)
  {
    this.movementController = paramMovementController;
    int i = ViewConfiguration.getTouchSlop();
    this.touchSlop = i;
  }

  public void updateAppWidget(RemoteViews paramRemoteViews)
  {
    super.updateAppWidget(paramRemoteViews);
    WidgetController2 localWidgetController2 = (WidgetController2)getParent();
    if (localWidgetController2 != null)
      localWidgetController2.updateChild(this);
  }

  class CheckForLongPress
    implements Runnable
  {
    private int originalWindowAttachCount;

    private CheckForLongPress()
    {
    }

    public void rememberWindowAttachCount()
    {
      int i = ShellWidgetHostView.this.getWindowAttachCount();
      this.originalWindowAttachCount = i;
    }

    public void run()
    {
      if (ShellWidgetHostView.this.movementController.getDelayed())
      {
        Home.MovementController localMovementController1 = ShellWidgetHostView.this.movementController;
        Object localObject1 = ShellWidgetHostView.this.lock;
        if (!localMovementController1.isProcessedByOther(localObject1))
          break label38;
      }
      while (true)
      {
        return;
        label38: if ((ShellWidgetHostView.this.getParent() != null) && (ShellWidgetHostView.this.hasWindowFocus()))
        {
          int i = this.originalWindowAttachCount;
          int j = ShellWidgetHostView.this.getWindowAttachCount();
          if ((i != j) || (ShellWidgetHostView.this.hasPerformedLongPress))
            continue;
          boolean bool = ShellWidgetHostView.access$302(ShellWidgetHostView.this, 1);
          Home.MovementController localMovementController2 = ShellWidgetHostView.this.movementController;
          Object localObject2 = ShellWidgetHostView.this.lock;
          localMovementController2.process(localObject2);
          int k = ShellWidgetHostView.this.lastX;
          int m = ShellWidgetHostView.this.lastY;
          Home.sendMouseEvent(0, k, m);
          continue;
        }
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.widget.ShellWidgetHostView
 * JD-Core Version:    0.6.0
 */