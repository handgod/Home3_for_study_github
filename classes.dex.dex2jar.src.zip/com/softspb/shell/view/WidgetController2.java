package com.softspb.shell.view;

import android.appwidget.AppWidgetHostView;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import com.softspb.shell.Home;
import com.softspb.shell.Home.MovementController;
import com.softspb.shell.data.BaseWidgetInfo;
import com.softspb.shell.opengl.NativeCalls;
import com.softspb.shell.util.ConcurrentUtil;
import com.softspb.shell.widget.ShellAppWidgetHost;
import com.softspb.util.CollectionFactory;
import com.softspb.util.Conditions;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class WidgetController2 extends ViewGroup
{
  private static final long AWAIT_TIME = 500L;
  private static final int INVISIBLE_UP = 55536;
  public static final int TYPE_PANEL = 2;
  public static final int TYPE_WIDGET = 1;
  private static Logger logger;
  public static MixIdStrategy mixIdStrategy = new WidgetController2.1();
  private List<String> changesTrack;
  private Lock childLock;
  private Bitmap gEmptyBitmap;
  private Bitmap gOffscreen;
  private Canvas gOffscreenCanvas;
  private Handler handler;
  Home home;
  private SparseArray<View> ids2widgets;
  private Set<Integer> justAdded;
  private float lastMotionX;
  private float lastMotionY;
  Runnable layoutAction;
  private View mainView;
  private Home.MovementController movementController;
  private Map<Point, Bitmap> offscreens;
  private boolean stopped = 0;
  private Object touchLock;
  private int touchSlop;
  public Runnable updateScreenshots;
  private Set<Integer> updatedWidgets;
  private boolean wasShown;
  ShellAppWidgetHost widgetHost;

  static
  {
    logger = Loggers.getLogger(WidgetController2.class.getName());
  }

  public WidgetController2(Context paramContext)
  {
    this(paramContext, null);
  }

  public WidgetController2(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public WidgetController2(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    LinkedList localLinkedList = CollectionFactory.newLinkedList();
    this.changesTrack = localLinkedList;
    this.touchLock = "widgetController";
    HashSet localHashSet1 = CollectionFactory.newHashSet();
    this.justAdded = localHashSet1;
    this.wasShown = 0;
    WidgetController2.2 local2 = new WidgetController2.2(this);
    this.layoutAction = local2;
    HashSet localHashSet2 = CollectionFactory.newHashSet();
    this.updatedWidgets = localHashSet2;
    HashMap localHashMap = CollectionFactory.newHashMap();
    this.offscreens = localHashMap;
    WidgetController2.4 local4 = new WidgetController2.4(this);
    this.updateScreenshots = local4;
    ReentrantLock localReentrantLock = new ReentrantLock();
    this.childLock = localReentrantLock;
    SparseArray localSparseArray = CollectionFactory.newSparseArray();
    this.ids2widgets = localSparseArray;
    initOffscreen();
    Handler localHandler = new Handler();
    this.handler = localHandler;
  }

  private void childLayout(View paramView)
  {
    int i = 1;
    LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
    Logger localLogger1 = logger;
    StringBuilder localStringBuilder = new StringBuilder().append("Layouting child with lp:");
    String str1 = localLayoutParams.toString();
    String str2 = str1;
    localLogger1.i(str2);
    int k = localLayoutParams.x;
    int m = localLayoutParams.y;
    int n = localLayoutParams.width;
    int i1 = localLayoutParams.height;
    Logger localLogger2 = logger;
    Object[] arrayOfObject = new Object[5];
    Integer localInteger1 = Integer.valueOf(k);
    arrayOfObject[0] = localInteger1;
    Integer localInteger2 = Integer.valueOf(m);
    arrayOfObject[i] = localInteger2;
    Integer localInteger3 = Integer.valueOf(k + n);
    arrayOfObject[2] = localInteger3;
    Integer localInteger4 = Integer.valueOf(m + i1);
    arrayOfObject[3] = localInteger4;
    if (paramView.getVisibility() == 0);
    while (true)
    {
      Boolean localBoolean = Boolean.valueOf(i);
      arrayOfObject[4] = localBoolean;
      String str3 = String.format("layout{cL=%d,cT=%d,cR=%d,cB=%d,isVisible=%b}", arrayOfObject);
      localLogger2.d(str3);
      int i2 = k + n;
      int i3 = m + i1;
      paramView.layout(k, m, i2, i3);
      return;
      int j = 0;
    }
  }

  private void doMeasure(View paramView, LayoutParams paramLayoutParams)
  {
    int i = View.MeasureSpec.makeMeasureSpec(paramLayoutParams.width, 1073741824);
    int j = View.MeasureSpec.makeMeasureSpec(paramLayoutParams.height, 1073741824);
    paramView.measure(i, j);
  }

  private void initOffscreen()
  {
    Bitmap.Config localConfig1 = Bitmap.Config.ARGB_8888;
    Bitmap localBitmap1 = Bitmap.createBitmap(1, 1, localConfig1);
    this.gEmptyBitmap = localBitmap1;
    Bitmap.Config localConfig2 = Bitmap.Config.ARGB_8888;
    Bitmap localBitmap2 = Bitmap.createBitmap(1, 1, localConfig2);
    this.gOffscreen = localBitmap2;
    Bitmap localBitmap3 = this.gOffscreen;
    Canvas localCanvas = new Canvas(localBitmap3);
    this.gOffscreenCanvas = localCanvas;
  }

  private void postUpdateScreenshots()
  {
    Handler localHandler1 = this.handler;
    Runnable localRunnable1 = this.updateScreenshots;
    localHandler1.removeCallbacks(localRunnable1);
    Handler localHandler2 = this.handler;
    Runnable localRunnable2 = this.updateScreenshots;
    boolean bool = localHandler2.post(localRunnable2);
  }

  private void updateWidget(int paramInt)
  {
    switch (mixIdStrategy.getType(paramInt))
    {
    default:
    case 2:
    case 1:
    }
    while (true)
    {
      return;
      NativeCalls.UpdatePanel(mixIdStrategy.specIdByGeneral(paramInt));
      continue;
      NativeCalls.UpdateWidget(mixIdStrategy.specIdByGeneral(paramInt));
    }
  }

  public void addWidget(View paramView, LayoutParams paramLayoutParams)
  {
    Object localObject = Conditions.checkNotNull(paramView);
    Conditions.checkArgument(((LayoutParams)Conditions.checkNotNull(paramLayoutParams)).isInitialised(), "");
    SparseArray localSparseArray1 = this.ids2widgets;
    int i = paramLayoutParams.id;
    if (localSparseArray1.get(i) == null);
    int k;
    for (int j = 1; ; k = 0)
    {
      Conditions.checkArgument(j, "View with the same id already exists");
      paramView.setDrawingCacheEnabled(0);
      SparseArray localSparseArray2 = this.ids2widgets;
      int m = paramLayoutParams.getId();
      localSparseArray2.append(m, paramView);
      addView(paramView, paramLayoutParams);
      Set localSet = this.justAdded;
      Integer localInteger = Integer.valueOf(paramLayoutParams.id);
      boolean bool = localSet.add(localInteger);
      return;
    }
  }

  public boolean changeWidgetSize(int paramInt1, int paramInt2, int paramInt3)
  {
    int i = 0;
    if (this.ids2widgets.get(paramInt1) != null);
    int k;
    for (int j = 1; ; k = 0)
    {
      String str = "View with id = " + paramInt1 + "doesn't exist";
      Conditions.checkArgument(j, str);
      LayoutParams localLayoutParams = (LayoutParams)((View)this.ids2widgets.get(paramInt1)).getLayoutParams();
      if ((localLayoutParams.width != paramInt2) || (localLayoutParams.height != paramInt3))
      {
        this.wasShown = 1;
        localLayoutParams.width = paramInt2;
        localLayoutParams.height = paramInt3;
        i = 1;
      }
      return i;
    }
  }

  public LayoutParams createLayoutParams(View paramView, int paramInt1, int paramInt2, int paramInt3)
  {
    LayoutParams localLayoutParams = new LayoutParams(paramInt2, paramInt3);
    doMeasure(paramView, localLayoutParams);
    return localLayoutParams;
  }

  protected boolean drawChild(Canvas paramCanvas, View paramView, long paramLong)
  {
    if (!updateScreenshot(paramView, 1));
    Canvas localCanvas;
    for (boolean bool = super.drawChild(paramCanvas, paramView, paramLong); ; bool = super.drawChild(localCanvas, paramView, paramLong))
    {
      return bool;
      localCanvas = this.gOffscreenCanvas;
    }
  }

  public void getLock()
  {
    this.childLock.lock();
  }

  public Bitmap getWidgetScreenShot(int paramInt)
  {
    View localView = (View)this.ids2widgets.get(paramInt);
    LayoutParams localLayoutParams;
    if (localView != null)
    {
      int i = 1;
      Conditions.checkArgument(i);
      localLayoutParams = (LayoutParams)localView.getLayoutParams();
      if (localLayoutParams.bitmap != null)
        break label53;
    }
    label53: Bitmap localBitmap2;
    for (Bitmap localBitmap1 = this.gEmptyBitmap; ; localBitmap2 = localLayoutParams.bitmap)
    {
      return localBitmap1;
      int j = 0;
      break;
    }
  }

  public void hideWidgets()
  {
    logger.i("!!!!!!!!hideWidgets");
    int i = 0;
    while (true)
    {
      int j = this.ids2widgets.size();
      if (i >= j)
        break;
      LayoutParams localLayoutParams = (LayoutParams)((View)this.ids2widgets.valueAt(i)).getLayoutParams();
      int k = (i + 1) * -1000;
      int m = LayoutParams.access$102(localLayoutParams, k);
      int n = LayoutParams.access$202(localLayoutParams, 55536);
      Logger localLogger = logger;
      String str = "hideWidget " + localLayoutParams;
      localLogger.i(str);
      i += 1;
    }
    Runnable localRunnable = this.layoutAction;
    boolean bool = post(localRunnable);
  }

  public ViewParent invalidateChildInParent(int[] paramArrayOfInt, Rect paramRect)
  {
    Logger localLogger1 = logger;
    StringBuilder localStringBuilder1 = new StringBuilder().append("invalidateChildInParent ");
    String str1 = paramRect.toShortString();
    String str2 = str1;
    localLogger1.i(str2);
    int i = paramArrayOfInt[0];
    int j = paramRect.left;
    int k = i + j;
    int m = paramArrayOfInt[1];
    int n = paramRect.top;
    int i1 = m + n;
    int i2 = paramArrayOfInt[0];
    int i3 = paramRect.right;
    int i4 = i2 + i3;
    int i5 = paramArrayOfInt[1];
    int i6 = paramRect.bottom;
    int i7 = i5 + i6;
    Rect localRect1 = new Rect(k, i1, i4, i7);
    int i8 = 0;
    while (true)
    {
      int i9 = this.ids2widgets.size();
      if (i8 >= i9)
        break;
      View localView = (View)this.ids2widgets.valueAt(i8);
      int i10 = localView.getLeft();
      int i11 = localView.getTop();
      int i12 = localView.getRight();
      int i13 = localView.getBottom();
      Rect localRect2 = new Rect(i10, i11, i12, i13);
      Logger localLogger2 = logger;
      StringBuilder localStringBuilder2 = new StringBuilder().append("intersect with ");
      String str3 = paramRect.toShortString();
      String str4 = str3;
      localLogger2.i(str4);
      if (Rect.intersects(localRect2, localRect1))
        updateChild(localView);
      i8 += 1;
    }
    return super.invalidateChildInParent(paramArrayOfInt, paramRect);
  }

  public LayoutParams makeLayoutParams(View paramView, AppWidgetProviderInfo paramAppWidgetProviderInfo, int paramInt)
  {
    Object localObject1 = Conditions.checkNotNull(paramView);
    Object localObject2 = Conditions.checkNotNull(paramAppWidgetProviderInfo);
    int i = paramAppWidgetProviderInfo.minWidth;
    int j = paramAppWidgetProviderInfo.minHeight;
    return createLayoutParams(paramView, i, j, paramInt);
  }

  public int onIdle()
  {
    return 0;
  }

  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent)
  {
    int i = 0;
    if (this.movementController == null)
      logger.e("movementController isn't initialized");
    while (true)
    {
      return i;
      Home.MovementController localMovementController = this.movementController;
      Object localObject = this.touchLock;
      if (!localMovementController.isProcessedByOther(localObject))
        break;
      this.lastMotionX = 3.4028235E+38F;
    }
    int j = paramMotionEvent.getAction();
    float f1 = paramMotionEvent.getX();
    float f2 = paramMotionEvent.getY();
    int k = 0;
    switch (j)
    {
    default:
    case 0:
    case 2:
    case 1:
    }
    while (true)
    {
      Logger localLogger = logger;
      String str = "returning :" + k;
      localLogger.i(str);
      i = k;
      break;
      this.lastMotionX = f1;
      this.lastMotionY = f2;
      continue;
      float f3 = this.lastMotionX;
      int n = (int)Math.abs(f1 - f3);
      int i1 = this.touchSlop;
      if (n > i1);
      for (int m = 1; ; m = 0)
        break;
      m = 0;
    }
  }

  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.mainView == null)
    {
      logger.e("trying to layout before GLview were set");
      return;
    }
    View localView1 = this.mainView;
    int i = paramInt3 - paramInt1;
    int j = paramInt4 - paramInt2;
    localView1.layout(0, 0, i, j);
    int k = 0;
    while (true)
    {
      int m = this.ids2widgets.size();
      if (k >= m)
        break;
      View localView2 = (View)this.ids2widgets.valueAt(k);
      childLayout(localView2);
      k += 1;
    }
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    super.onMeasure(paramInt1, paramInt2);
    int i = 0;
    while (true)
    {
      int j = this.ids2widgets.size();
      if (i >= j)
        break;
      View localView = (View)this.ids2widgets.valueAt(i);
      LayoutParams localLayoutParams = (LayoutParams)localView.getLayoutParams();
      doMeasure(localView, localLayoutParams);
      i += 1;
    }
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    if (this.lastMotionX != 3.4028235E+38F)
    {
      int i = (int)this.lastMotionX;
      int j = (int)this.lastMotionY;
      Home.sendMouseEvent(0, i, j);
      Home.MovementController localMovementController1 = this.movementController;
      Object localObject1 = this.touchLock;
      localMovementController1.process(localObject1);
      this.lastMotionX = 3.4028235E+38F;
    }
    Home.MovementController localMovementController2 = this.movementController;
    Object localObject2 = this.touchLock;
    View localView = this.mainView;
    boolean bool = localMovementController2.processTouch(localObject2, paramMotionEvent, localView);
    return true;
  }

  public void recreateWidgets()
  {
    logger.i("qqqq recreateWidgets ");
    Context localContext = getContext();
    Intent localIntent = new Intent("sec.android.intent.action.HOME_RESUME");
    localContext.sendBroadcast(localIntent);
    AppWidgetManager localAppWidgetManager = AppWidgetManager.getInstance(getContext());
    int i = 0;
    int j = this.ids2widgets.size();
    if (i < j)
    {
      View localView = (View)this.ids2widgets.valueAt(i);
      LayoutParams localLayoutParams = (LayoutParams)localView.getLayoutParams();
      MixIdStrategy localMixIdStrategy = mixIdStrategy;
      int k = localLayoutParams.getId();
      if (localMixIdStrategy.getType(k) == 2);
      while (true)
      {
        i += 1;
        break;
        int m = localLayoutParams.appWidgetId;
        AppWidgetProviderInfo localAppWidgetProviderInfo = localAppWidgetManager.getAppWidgetInfo(m);
        if (localAppWidgetProviderInfo == null)
          continue;
        removeView(localView);
        ShellAppWidgetHost localShellAppWidgetHost = this.widgetHost;
        Home localHome = this.home;
        int n = localLayoutParams.appWidgetId;
        AppWidgetHostView localAppWidgetHostView = localShellAppWidgetHost.createView(localHome, n, localAppWidgetProviderInfo);
        doMeasure(localAppWidgetHostView, localLayoutParams);
        addView(localAppWidgetHostView, localLayoutParams);
        this.ids2widgets.setValueAt(i, localAppWidgetHostView);
      }
    }
    logger.i("qqqq <<recreateWidgets ");
  }

  public void releaseLock()
  {
    this.childLock.unlock();
  }

  public LayoutParams removeWidget(int paramInt)
  {
    return (LayoutParams)ConcurrentUtil.runSynchronouslyInUiThread(new WidgetController2.3(this, paramInt), 500L);
  }

  public List<LayoutParams> removeWidgets(String paramString)
  {
    Object localObject = Conditions.checkNotNull(paramString);
    LinkedList localLinkedList = CollectionFactory.newLinkedList();
    AppWidgetManager localAppWidgetManager = AppWidgetManager.getInstance(getContext());
    int i = 0;
    while (true)
    {
      int j = this.ids2widgets.size();
      if (i >= j)
        break;
      View localView = (View)this.ids2widgets.valueAt(i);
      LayoutParams localLayoutParams1 = (LayoutParams)localView.getLayoutParams();
      int k = localLayoutParams1.appWidgetId;
      AppWidgetProviderInfo localAppWidgetProviderInfo = localAppWidgetManager.getAppWidgetInfo(k);
      if (localAppWidgetProviderInfo != null)
      {
        String str1 = localAppWidgetProviderInfo.provider.getPackageName();
        if (!paramString.equals(str1));
      }
      else
      {
        boolean bool1 = localLinkedList.add(localLayoutParams1);
        Integer localInteger = Integer.valueOf(localLayoutParams1.id);
        boolean bool2 = this.updatedWidgets.remove(localInteger);
        removeView(localView);
      }
      i += 1;
    }
    if (!localLinkedList.isEmpty())
    {
      Iterator localIterator = localLinkedList.iterator();
      while (localIterator.hasNext())
      {
        LayoutParams localLayoutParams2 = (LayoutParams)localIterator.next();
        SparseArray localSparseArray = this.ids2widgets;
        int m = localLayoutParams2.id;
        localSparseArray.remove(m);
      }
      requestLayout();
    }
    Logger localLogger = logger;
    StringBuilder localStringBuilder = new StringBuilder().append("removed appWidget ");
    int n = localLinkedList.size();
    String str2 = n;
    localLogger.i(str2);
    return localLinkedList;
  }

  public void restoreWidget(View paramView, BaseWidgetInfo paramBaseWidgetInfo)
  {
    Logger localLogger = logger;
    StringBuilder localStringBuilder1 = new StringBuilder().append("restoreWidget ");
    int i = paramBaseWidgetInfo.getAppWidgetId();
    StringBuilder localStringBuilder2 = localStringBuilder1.append(i).append(", w=");
    int j = paramBaseWidgetInfo.getMinWidth();
    StringBuilder localStringBuilder3 = localStringBuilder2.append(j).append(", h=");
    int k = paramBaseWidgetInfo.getMinHeight();
    String str = k;
    localLogger.i(str);
    Object localObject1 = Conditions.checkNotNull(paramView);
    Object localObject2 = Conditions.checkNotNull(paramBaseWidgetInfo);
    int m = paramBaseWidgetInfo.getMinWidth();
    int n = paramBaseWidgetInfo.getMinHeight();
    int i1 = paramBaseWidgetInfo.getAppWidgetId();
    LayoutParams localLayoutParams = createLayoutParams(paramView, m, n, i1);
    int i2 = paramBaseWidgetInfo.getId();
    localLayoutParams.setId(i2);
    addWidget(paramView, localLayoutParams);
    this.justAdded.clear();
  }

  public void setMainView(View paramView, Home.MovementController paramMovementController)
  {
    int i = ViewConfiguration.getTouchSlop();
    this.touchSlop = i;
    View localView = (View)Conditions.checkNotNull(paramView);
    this.mainView = localView;
    Home.MovementController localMovementController = (Home.MovementController)Conditions.checkNotNull(paramMovementController);
    this.movementController = localMovementController;
  }

  public void setWidgetHost(ShellAppWidgetHost paramShellAppWidgetHost, Home paramHome)
  {
    this.widgetHost = paramShellAppWidgetHost;
    this.home = paramHome;
  }

  public boolean showWidget(int paramInt1, int paramInt2, int paramInt3)
  {
    int i = 0;
    if (this.ids2widgets.get(paramInt1) != null);
    int k;
    for (int j = 1; ; k = 0)
    {
      String str1 = "View with id = " + paramInt1 + "doesn't exist";
      Conditions.checkArgument(j, str1);
      LayoutParams localLayoutParams = (LayoutParams)((View)this.ids2widgets.get(paramInt1)).getLayoutParams();
      Logger localLogger = logger;
      StringBuilder localStringBuilder1 = new StringBuilder().append("showWidget (");
      int m = localLayoutParams.x;
      StringBuilder localStringBuilder2 = localStringBuilder1.append(m).append(", ");
      int n = localLayoutParams.y;
      StringBuilder localStringBuilder3 = localStringBuilder2.append(n).append(") -> (").append(paramInt2).append(", ").append(paramInt3).append("), [");
      int i1 = localLayoutParams.width;
      StringBuilder localStringBuilder4 = localStringBuilder3.append(i1).append(", ");
      int i2 = localLayoutParams.height;
      String str2 = i2 + "]";
      localLogger.i(str2);
      if ((localLayoutParams.x != paramInt2) || (localLayoutParams.y != paramInt3))
      {
        this.wasShown = 1;
        int i3 = LayoutParams.access$102(localLayoutParams, paramInt2);
        int i4 = LayoutParams.access$202(localLayoutParams, paramInt3);
        i = 1;
      }
      return i;
    }
  }

  public void start()
  {
    this.stopped = 0;
  }

  public void stop()
  {
    this.stopped = 1;
  }

  public void updateChild(View paramView)
  {
    LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
    if (localLayoutParams == null);
    while (true)
    {
      return;
      if (localLayoutParams.x < 0)
        ViewUtils.clearAnimation(paramView);
      Set localSet = this.updatedWidgets;
      Integer localInteger = Integer.valueOf(localLayoutParams.getId());
      boolean bool = localSet.add(localInteger);
      Logger localLogger = logger;
      StringBuilder localStringBuilder = new StringBuilder().append("updateChild");
      int i = localLayoutParams.getId();
      String str = i;
      localLogger.i(str);
      if (this.stopped)
        continue;
      postUpdateScreenshots();
    }
  }

  public boolean updateScreenshot(View paramView, boolean paramBoolean)
  {
    int i = 1;
    logger.i("updateScreenshot");
    int j = paramView.getWidth();
    int k = paramView.getHeight();
    Point localPoint1 = new Point(j, k);
    ViewGroup.LayoutParams localLayoutParams = paramView.getLayoutParams();
    if ((!(localLayoutParams instanceof LayoutParams)) || (localPoint1.x <= 0) || (localPoint1.y <= 0))
      i = 0;
    while (true)
    {
      return i;
      LayoutParams localLayoutParams1 = (LayoutParams)localLayoutParams;
      Set localSet = this.updatedWidgets;
      Integer localInteger = Integer.valueOf(localLayoutParams1.getId());
      if (!localSet.remove(localInteger))
        continue;
      Logger localLogger1 = logger;
      StringBuilder localStringBuilder1 = new StringBuilder().append("Draw child Bitmap: ");
      int m = localLayoutParams1.getId();
      StringBuilder localStringBuilder2 = localStringBuilder1.append(m).append(" (");
      int n = localPoint1.x;
      StringBuilder localStringBuilder3 = localStringBuilder2.append(n).append(",");
      int i1 = localPoint1.y;
      String str1 = i1 + ")";
      localLogger1.i(str1);
      Bitmap localBitmap1 = (Bitmap)this.offscreens.get(localPoint1);
      if (localBitmap1 == null)
      {
        logger.i("Bitmap.createBitmap");
        int i2 = localPoint1.x;
        int i3 = localPoint1.y;
        Bitmap.Config localConfig = Bitmap.Config.ARGB_8888;
        localBitmap1 = Bitmap.createBitmap(i2, i3, localConfig);
      }
      Bitmap localBitmap2;
      while (true)
      {
        Canvas localCanvas = new Canvas(localBitmap1);
        paramView.draw(localCanvas);
        getLock();
        localBitmap2 = localLayoutParams1.bitmap;
        Bitmap localBitmap3 = LayoutParams.access$402(localLayoutParams1, localBitmap1);
        releaseLock();
        if (paramBoolean)
        {
          int i4 = localLayoutParams1.getId();
          updateWidget(i4);
        }
        if (localBitmap2 != null)
          break label349;
        Object localObject1 = this.offscreens.remove(localPoint1);
        break;
        localBitmap1.eraseColor(0);
      }
      label349: int i5 = localBitmap2.getWidth();
      int i6 = localBitmap2.getHeight();
      Point localPoint2 = new Point(i5, i6);
      if (localPoint1.equals(localPoint2))
      {
        Object localObject2 = this.offscreens.put(localPoint1, localBitmap2);
        continue;
      }
      Object localObject3 = this.offscreens.remove(localPoint1);
      localBitmap2.recycle();
      Logger localLogger2 = logger;
      String str2 = "<<Change size " + localPoint1 + " " + localPoint2;
      localLogger2.i(str2);
    }
  }

  public void waitForShowWidgets()
  {
    logger.i("!!!!!!!!waitForShowWidgets");
    if (!this.wasShown)
      logger.i("!!!!!!!! NOSHOW");
    while (true)
    {
      return;
      this.wasShown = 0;
      Runnable localRunnable = this.layoutAction;
      boolean bool = post(localRunnable);
    }
  }

  public class LayoutParams extends ViewGroup.LayoutParams
  {
    private final int appWidgetId;
    private Bitmap bitmap;
    private int id = 0;
    private boolean initialised = 0;
    private int x;
    private int y;

    public LayoutParams(int paramInt1, int arg3)
    {
      super(paramInt1);
      int i;
      this.appWidgetId = i;
    }

    public int getAppWidgetId()
    {
      return this.appWidgetId;
    }

    public int getId()
    {
      return this.id;
    }

    public boolean isInitialised()
    {
      return this.initialised;
    }

    public void setId(int paramInt)
    {
      this.initialised = 1;
      this.id = paramInt;
      int i = (paramInt + 1) * -1000;
      this.x = i;
    }

    public String toString()
    {
      StringBuilder localStringBuilder1 = new StringBuilder().append("LayoutParams [id=");
      int i = this.id;
      StringBuilder localStringBuilder2 = localStringBuilder1.append(i).append(", height=");
      int j = this.height;
      StringBuilder localStringBuilder3 = localStringBuilder2.append(j).append(", width=");
      int k = this.width;
      return k + "]";
    }
  }

  public abstract interface MixIdStrategy
  {
    public abstract int generalIdBySpecId(int paramInt1, int paramInt2);

    public abstract int getType(int paramInt);

    public abstract int specIdByGeneral(int paramInt);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.view.WidgetController2
 * JD-Core Version:    0.6.0
 */