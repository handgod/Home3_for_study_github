package com.softspb.shell.view;

final class WidgetController2$1
  implements WidgetController2.MixIdStrategy
{
  private static final int MAX_WIDGETS = 1000000;

  public int generalIdBySpecId(int paramInt1, int paramInt2)
  {
    switch (paramInt2)
    {
    default:
      String str = "We dont have type = " + paramInt2;
      throw new IllegalArgumentException(str);
    case 1:
      if (paramInt1 < 1000000)
        break;
      throw new IllegalArgumentException("Widget should have id less than 1000000");
    case 2:
      paramInt1 += 1000000;
    }
    return paramInt1;
  }

  public int getType(int paramInt)
  {
    if (paramInt >= 1000000);
    for (int i = 2; ; i = 1)
      return i;
  }

  public int specIdByGeneral(int paramInt)
  {
    switch (getType(paramInt))
    {
    default:
      throw new IllegalStateException();
    case 2:
      paramInt -= 1000000;
    case 1:
    }
    return paramInt;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.view.WidgetController2.1
 * JD-Core Version:    0.6.0
 */