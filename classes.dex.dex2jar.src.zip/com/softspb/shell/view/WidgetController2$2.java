package com.softspb.shell.view;

import com.softspb.util.log.Logger;

class WidgetController2$2
  implements Runnable
{
  public void run()
  {
    WidgetController2.access$300().i("!!!!!!!! layoutAction requestLayout()");
    this.this$0.requestLayout();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.view.WidgetController2.2
 * JD-Core Version:    0.6.0
 */