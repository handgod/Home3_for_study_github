package com.softspb.shell.view;

import android.content.Context;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.spb.shell3d.R.layout;

public class AddDialogListAdapter extends ArrayAdapter<Pair<String, Integer>>
{
  private Context context;

  public AddDialogListAdapter(Context paramContext)
  {
    super(paramContext, i);
    this.context = paramContext;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    LayoutInflater localLayoutInflater = (LayoutInflater)this.context.getSystemService("layout_inflater");
    int i = R.layout.add_dialog_list_item;
    View localView = localLayoutInflater.inflate(i, paramViewGroup, 0);
    TextView localTextView = (TextView)localView.findViewById(16908308);
    ImageView localImageView = (ImageView)localView.findViewById(16908294);
    Pair localPair = (Pair)getItem(paramInt);
    CharSequence localCharSequence = (CharSequence)localPair.first;
    localTextView.setText(localCharSequence);
    int j = ((Integer)localPair.second).intValue();
    localImageView.setImageResource(j);
    return localView;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.view.AddDialogListAdapter
 * JD-Core Version:    0.6.0
 */