package com.softspb.shell.view;

import android.view.View;
import android.view.ViewGroup;
import com.softspb.util.Conditions;

public class ViewUtils
{
  public static void clearAnimation(View paramView)
  {
    ((View)Conditions.checkNotNull(paramView)).clearAnimation();
    if ((paramView instanceof ViewGroup))
    {
      ViewGroup localViewGroup = (ViewGroup)paramView;
      int i = 0;
      while (true)
      {
        int j = localViewGroup.getChildCount();
        if (i >= j)
          break;
        clearAnimation(localViewGroup.getChildAt(i));
        i += 1;
      }
    }
  }

  public static boolean hasAnimation(View paramView)
  {
    int i;
    if (((View)Conditions.checkNotNull(paramView)).getAnimation() != null)
      i = 1;
    while (true)
    {
      return i;
      if ((paramView instanceof ViewGroup))
      {
        ViewGroup localViewGroup = (ViewGroup)paramView;
        int j = 0;
        while (true)
        {
          int k = localViewGroup.getChildCount();
          if (j >= k)
            break label66;
          if (hasAnimation(localViewGroup.getChildAt(j)))
          {
            i = 1;
            break;
          }
          j += 1;
        }
      }
      label66: i = 0;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.view.ViewUtils
 * JD-Core Version:    0.6.0
 */