package com.softspb.shell.view;

import android.util.SparseArray;
import android.view.View;
import com.softspb.util.log.Logger;
import java.util.Set;

class WidgetController2$4
  implements Runnable
{
  public void run()
  {
    Logger localLogger = WidgetController2.access$300();
    StringBuilder localStringBuilder = new StringBuilder().append("updateScreenshot ");
    int i = WidgetController2.access$700(this.this$0).size();
    String str = i;
    localLogger.i(str);
    if (WidgetController2.access$700(this.this$0).isEmpty())
    {
      WidgetController2.access$300().i("updatedWidgets.isEmpty()");
      return;
    }
    int j = 0;
    while (true)
    {
      int k = WidgetController2.access$600(this.this$0).size();
      if (j >= k)
        break;
      View localView = (View)WidgetController2.access$600(this.this$0).valueAt(j);
      boolean bool = this.this$0.updateScreenshot(localView, 1);
      j += 1;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.view.WidgetController2.4
 * JD-Core Version:    0.6.0
 */