package com.softspb.shell.view;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ResolveInfo.DisplayNameComparator;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.spb.shell3d.R.id;
import com.spb.shell3d.R.layout;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class FilterPickDialogBuilder
{
  private PickAdapter adapter;
  private final Context context;
  private DialogResult dialogResult;
  private IFilter filter;
  private final Intent intent;
  private CharSequence title;

  public FilterPickDialogBuilder(Context paramContext, Intent paramIntent)
  {
    this.context = paramContext;
    this.intent = paramIntent;
  }

  private List<FilterPickDialogBuilder.PickAdapter.Item> getIntentItems(Context paramContext, Intent paramIntent, IFilter paramIFilter)
  {
    ArrayList localArrayList = new ArrayList();
    PackageManager localPackageManager = paramContext.getPackageManager();
    List localList = localPackageManager.queryIntentActivities(paramIntent, 0);
    ResolveInfo.DisplayNameComparator localDisplayNameComparator = new ResolveInfo.DisplayNameComparator(localPackageManager);
    Collections.sort(localList, localDisplayNameComparator);
    if (localList == null);
    Object localObject1;
    int i;
    label148: Object localObject2;
    while (true)
    {
      return localArrayList;
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        ResolveInfo localResolveInfo1 = (ResolveInfo)localIterator.next();
        if ((paramIFilter == null) || (paramIFilter.filter(localResolveInfo1)))
          continue;
        localIterator.remove();
      }
      localObject1 = null;
      if (localList.size() <= 0)
        break;
      ResolveInfo localResolveInfo2 = (ResolveInfo)localList.get(0);
      localItem = new FilterPickDialogBuilder.PickAdapter.Item(localPackageManager, localResolveInfo2);
      i = 0;
      int j = localList.size();
      if (i >= j)
        continue;
      localObject2 = localObject1;
      localObject1 = localItem;
      int k = i + 1;
      int m = localList.size();
      if (k != m)
        break label313;
    }
    label287: label313: ResolveInfo localResolveInfo3;
    for (FilterPickDialogBuilder.PickAdapter.Item localItem = null; ; localItem = new FilterPickDialogBuilder.PickAdapter.Item(localPackageManager, localResolveInfo3))
    {
      if (localObject2 != null)
      {
        CharSequence localCharSequence1 = localObject1.label;
        CharSequence localCharSequence2 = localObject2.label;
        if (localCharSequence1.equals(localCharSequence2));
      }
      else
      {
        if (localItem == null)
          break label287;
        CharSequence localCharSequence3 = localObject1.label;
        CharSequence localCharSequence4 = localItem.label;
        if (!localCharSequence3.equals(localCharSequence4))
          break label287;
      }
      CharSequence localCharSequence5 = ((ResolveInfo)localList.get(i)).activityInfo.applicationInfo.loadLabel(localPackageManager);
      localObject1.setExtendedInfo(localCharSequence5);
      boolean bool = localArrayList.add(localObject1);
      i += 1;
      break label148;
      localItem = null;
      break;
      int n = i + 1;
      localResolveInfo3 = (ResolveInfo)localList.get(n);
    }
  }

  public AlertDialog create()
  {
    Context localContext1 = this.context;
    AlertDialog.Builder localBuilder1 = new AlertDialog.Builder(localContext1);
    Context localContext2 = this.context;
    Intent localIntent1 = this.intent;
    IFilter localIFilter = this.filter;
    List localList = getIntentItems(localContext2, localIntent1, localIFilter);
    Context localContext3 = this.context;
    PickAdapter localPickAdapter1 = new PickAdapter(localContext3);
    this.adapter = localPickAdapter1;
    PickAdapter localPickAdapter2 = this.adapter;
    DialogResult localDialogResult = this.dialogResult;
    PickAdapter localPickAdapter3 = this.adapter;
    Intent localIntent2 = this.intent;
    ClickListener localClickListener = new ClickListener(localPickAdapter3, localIntent2);
    AlertDialog.Builder localBuilder2 = localBuilder1.setAdapter(localPickAdapter2, localClickListener);
    CharSequence localCharSequence = this.title;
    AlertDialog.Builder localBuilder3 = localBuilder1.setTitle(localCharSequence);
    return localBuilder1.create();
  }

  public FilterPickDialogBuilder setDialogResult(DialogResult paramDialogResult)
  {
    this.dialogResult = paramDialogResult;
    return this;
  }

  public FilterPickDialogBuilder setFilter(IFilter paramIFilter)
  {
    this.filter = paramIFilter;
    return this;
  }

  public FilterPickDialogBuilder setTitle(int paramInt)
  {
    String str = this.context.getResources().getString(paramInt);
    this.title = str;
    return this;
  }

  public FilterPickDialogBuilder setTitle(CharSequence paramCharSequence)
  {
    this.title = paramCharSequence;
    return this;
  }

  class PickAdapter extends BaseAdapter
  {
    LayoutInflater inflater;

    PickAdapter(Context arg2)
    {
      Object localObject;
      LayoutInflater localLayoutInflater = (LayoutInflater)localObject.getSystemService("layout_inflater");
      this.inflater = localLayoutInflater;
    }

    public int getCount()
    {
      return FilterPickDialogBuilder.this.size();
    }

    public Object getItem(int paramInt)
    {
      return FilterPickDialogBuilder.this.get(paramInt);
    }

    public long getItemId(int paramInt)
    {
      return paramInt;
    }

    public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
    {
      if (paramView == null)
      {
        LayoutInflater localLayoutInflater = this.inflater;
        int i = R.layout.shortcut_dialog_pick_item;
        paramView = localLayoutInflater.inflate(i, paramViewGroup, 0);
      }
      Item localItem = (Item)getItem(paramInt);
      TextView localTextView1 = (TextView)paramView.findViewById(16908308);
      TextView localTextView2 = (TextView)paramView.findViewById(16908309);
      if (localItem.extendedInfo != null)
      {
        CharSequence localCharSequence1 = localItem.extendedInfo;
        localTextView2.setText(localCharSequence1);
        localTextView2.setVisibility(0);
      }
      while (true)
      {
        int j = R.id.icon;
        ImageView localImageView = (ImageView)paramView.findViewById(j);
        Drawable localDrawable = localItem.icon;
        localImageView.setImageDrawable(localDrawable);
        CharSequence localCharSequence2 = localItem.label;
        localTextView1.setText(localCharSequence2);
        return paramView;
        localTextView2.setVisibility(8);
      }
    }

    class Item
    {
      String className;
      CharSequence extendedInfo;
      Drawable icon;
      CharSequence label;
      String packageName;

      Item(ResolveInfo arg2)
      {
        Object localObject;
        CharSequence localCharSequence = localObject.loadLabel(this$1);
        this.label = localCharSequence;
        if ((this.label == null) && (localObject.activityInfo != null))
        {
          String str1 = localObject.activityInfo.name;
          this.label = str1;
        }
        Drawable localDrawable = localObject.loadIcon(this$1);
        this.icon = localDrawable;
        if (localObject.activityInfo != null)
        {
          String str2 = localObject.activityInfo.applicationInfo.packageName;
          this.packageName = str2;
          String str3 = localObject.activityInfo.name;
          this.className = str3;
        }
      }

      Intent getIntent(Intent paramIntent)
      {
        Intent localIntent1 = new Intent(paramIntent);
        if ((this.packageName != null) && (this.className != null))
        {
          String str1 = this.packageName;
          String str2 = this.className;
          Intent localIntent2 = localIntent1.setClassName(str1, str2);
        }
        while (true)
        {
          return localIntent1;
          Intent localIntent3 = localIntent1.setAction("android.intent.action.CREATE_SHORTCUT");
          CharSequence localCharSequence = this.label;
          Intent localIntent4 = localIntent1.putExtra("android.intent.extra.shortcut.NAME", localCharSequence);
        }
      }

      void setExtendedInfo(CharSequence paramCharSequence)
      {
        this.extendedInfo = paramCharSequence;
      }
    }
  }

  class ClickListener
    implements DialogInterface.OnClickListener
  {
    final Adapter adapter;
    final Intent intent;

    public ClickListener(Adapter paramIntent, Intent arg3)
    {
      this.adapter = paramIntent;
      Object localObject;
      this.intent = localObject;
    }

    public void onClick(DialogInterface paramDialogInterface, int paramInt)
    {
      FilterPickDialogBuilder.PickAdapter.Item localItem = (FilterPickDialogBuilder.PickAdapter.Item)this.adapter.getItem(paramInt);
      paramDialogInterface.dismiss();
      if (FilterPickDialogBuilder.this != null)
      {
        FilterPickDialogBuilder.DialogResult localDialogResult = FilterPickDialogBuilder.this;
        Intent localIntent1 = this.intent;
        Intent localIntent2 = localItem.getIntent(localIntent1);
        localDialogResult.onResult(localIntent2);
      }
    }
  }

  public abstract interface DialogResult
  {
    public abstract void onResult(Intent paramIntent);
  }

  public abstract interface IFilter
  {
    public abstract boolean filter(ResolveInfo paramResolveInfo);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.view.FilterPickDialogBuilder
 * JD-Core Version:    0.6.0
 */