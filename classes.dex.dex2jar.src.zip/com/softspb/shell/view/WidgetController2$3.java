package com.softspb.shell.view;

import android.util.SparseArray;
import android.view.View;
import java.util.Set;
import java.util.concurrent.Callable;

class WidgetController2$3
  implements Callable<WidgetController2.LayoutParams>
{
  public WidgetController2.LayoutParams call()
    throws Exception
  {
    SparseArray localSparseArray1 = WidgetController2.access$600(this.this$0);
    int i = this.val$id;
    View localView = (View)localSparseArray1.get(i);
    WidgetController2.LayoutParams localLayoutParams;
    if (localView == null)
      localLayoutParams = null;
    while (true)
    {
      return localLayoutParams;
      SparseArray localSparseArray2 = WidgetController2.access$600(this.this$0);
      int j = this.val$id;
      localSparseArray2.delete(j);
      Set localSet = WidgetController2.access$700(this.this$0);
      Integer localInteger = Integer.valueOf(this.val$id);
      boolean bool = localSet.remove(localInteger);
      localLayoutParams = (WidgetController2.LayoutParams)localView.getLayoutParams();
      this.this$0.requestLayout();
      this.this$0.removeView(localView);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.view.WidgetController2.3
 * JD-Core Version:    0.6.0
 */