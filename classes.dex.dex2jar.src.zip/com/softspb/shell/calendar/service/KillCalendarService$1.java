package com.softspb.shell.calendar.service;

import android.content.Context;
import android.os.Process;

class KillCalendarService$1 extends CalendarClient
{
  private int pid;

  protected void onAppointmentLoaded(Appointment paramAppointment)
  {
  }

  protected void onCalendarChanged()
  {
  }

  protected void onConnected()
  {
    logd("onConnected");
    requestServicePid();
  }

  protected void onDisconnected()
  {
    logd("onDisconnected");
  }

  protected void onFinishedReloadingAppointments(int paramInt)
  {
  }

  protected void onPidResponse(int paramInt)
  {
    logd("onPidResponse: pid=" + paramInt);
    this.pid = paramInt;
    disconnect();
    if (paramInt != 0)
    {
      logd("onPidResponse: killing pid=" + paramInt);
      Process.killProcess(paramInt);
    }
    this.this$0.stopSelf();
  }

  protected void onStartedReloadingAppointments(int paramInt)
  {
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.calendar.service.KillCalendarService.1
 * JD-Core Version:    0.6.0
 */