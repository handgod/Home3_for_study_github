package com.softspb.shell.calendar.service;

import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Process;
import android.os.RemoteException;
import android.provider.CalendarContract.Calendars;
import android.provider.CalendarContract.Events;
import android.provider.CalendarContract.Instances;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.util.ArrayList;
import java.util.Date;

public class CalendarService extends Service
{
  public static final String[] CALENDARS_PROJECTION = ;
  public static final String[] CANELDAR_PROJECTION = ;
  private static final String ENABLED_CALENDARS_QUERY = ;
  static final String EXTRA_APPOINTMENT = "appointment";
  static final String EXTRA_LOAD_APPOINTMENTS_PARAMS = "load-appts-params";
  public static final int INDEX_ALL_DAY = 5;
  public static final int INDEX_CALENDAR_ID = 12;
  public static final int INDEX_DESC = 2;
  public static final int INDEX_END = 1;
  public static final int INDEX_END_DAY = 9;
  public static final int INDEX_END_MINUTE = 11;
  public static final int INDEX_ID = 7;
  public static final int INDEX_LOCATION = 4;
  public static final int INDEX_RRULE = 6;
  public static final int INDEX_START = 0;
  public static final int INDEX_START_DAY = 8;
  public static final int INDEX_START_MINUTE = 10;
  public static final int INDEX_TITLE = 3;
  static final int MSG_GET_PID = 99;
  static final int MSG_LOAD_APPOINTMENTS = 3;
  static final int MSG_ON_APPOINTMENT_LOADED = 4;
  static final int MSG_ON_CALENDAR_CHANGED = 5;
  static final int MSG_ON_FINISHED_RELOADING_APPOINTMENTS = 7;
  static final int MSG_ON_STARTED_RELOADING_APPOINTMENTS = 6;
  static final int MSG_REGISTER_CLIENT = 1;
  static final int MSG_RESPONSE_PID = 8;
  static final int MSG_UNREGISTER_CLIENT = 2;
  private static final Logger logger;
  private Uri CALENDAR_CALENDARS_URI;
  private Uri CALENDAR_CONTENT_URI;
  private Uri CALENDAR_OBSERVE_URI;
  ClassLoader classLoader;
  ArrayList<Messenger> clients;
  private ContentObserver contentObserver;
  final Messenger messenger;

  static
  {
    if (Build.VERSION.SDK_INT >= 14)
    {
      String[] arrayOfString1 = new String[13];
      arrayOfString1[0] = "begin";
      arrayOfString1[1] = "end";
      arrayOfString1[2] = "description";
      arrayOfString1[3] = "title";
      arrayOfString1[4] = "eventLocation";
      arrayOfString1[5] = "allDay";
      arrayOfString1[6] = "rrule";
      arrayOfString1[7] = "event_id";
      arrayOfString1[8] = "startDay";
      arrayOfString1[9] = "endDay";
      arrayOfString1[10] = "startMinute";
      arrayOfString1[11] = "endMinute";
      arrayOfString1[12] = "calendar_id";
      CANELDAR_PROJECTION = arrayOfString1;
      ENABLED_CALENDARS_QUERY = "visible=1";
    }
    while (true)
    {
      String[] arrayOfString2 = new String[1];
      arrayOfString2[0] = "_id";
      CALENDARS_PROJECTION = arrayOfString2;
      logger = Loggers.getLogger(CalendarService.class);
      return;
      String[] arrayOfString3 = new String[13];
      arrayOfString3[0] = "begin";
      arrayOfString3[1] = "end";
      arrayOfString3[2] = "description";
      arrayOfString3[3] = "title";
      arrayOfString3[4] = "eventLocation";
      arrayOfString3[5] = "allDay";
      arrayOfString3[6] = "rrule";
      arrayOfString3[7] = "event_id";
      arrayOfString3[8] = "startDay";
      arrayOfString3[9] = "endDay";
      arrayOfString3[10] = "startMinute";
      arrayOfString3[11] = "endMinute";
      arrayOfString3[12] = "calendar_id";
      CANELDAR_PROJECTION = arrayOfString3;
      ENABLED_CALENDARS_QUERY = "selected=1";
    }
  }

  public CalendarService()
  {
    ArrayList localArrayList = new ArrayList();
    this.clients = localArrayList;
    IncomingHandler localIncomingHandler = new IncomingHandler();
    Messenger localMessenger = new Messenger(localIncomingHandler);
    this.messenger = localMessenger;
    Handler localHandler = new Handler();
    CalendarService.1 local1 = new CalendarService.1(this, localHandler);
    this.contentObserver = local1;
  }

  public static String convertTime(long paramLong)
  {
    StringBuilder localStringBuilder = new StringBuilder().append(paramLong).append("(");
    Date localDate = new Date(paramLong);
    return localDate + ")";
  }

  // ERROR //
  private java.util.List<java.lang.Long> getEnabledCalendarIds()
  {
    // Byte code:
    //   0: invokestatic 204	java/util/Collections:emptyList	()Ljava/util/List;
    //   3: astore_1
    //   4: aload_0
    //   5: invokevirtual 208	com/softspb/shell/calendar/service/CalendarService:getContentResolver	()Landroid/content/ContentResolver;
    //   8: astore_2
    //   9: aload_0
    //   10: getfield 210	com/softspb/shell/calendar/service/CalendarService:CALENDAR_CALENDARS_URI	Landroid/net/Uri;
    //   13: astore_3
    //   14: getstatic 118	com/softspb/shell/calendar/service/CalendarService:CALENDARS_PROJECTION	[Ljava/lang/String;
    //   17: astore 4
    //   19: getstatic 114	com/softspb/shell/calendar/service/CalendarService:ENABLED_CALENDARS_QUERY	Ljava/lang/String;
    //   22: astore 5
    //   24: aload_2
    //   25: aload_3
    //   26: aload 4
    //   28: aload 5
    //   30: aconst_null
    //   31: aconst_null
    //   32: invokevirtual 216	android/content/ContentResolver:query	(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   35: astore 6
    //   37: aload 6
    //   39: ifnull +92 -> 131
    //   42: aload 6
    //   44: invokeinterface 222 1 0
    //   49: istore 7
    //   51: new 133	java/util/ArrayList
    //   54: dup
    //   55: iload 7
    //   57: invokespecial 225	java/util/ArrayList:<init>	(I)V
    //   60: astore 8
    //   62: aload 6
    //   64: invokeinterface 229 1 0
    //   69: ifeq +59 -> 128
    //   72: aload 6
    //   74: iconst_0
    //   75: invokeinterface 233 2 0
    //   80: invokestatic 239	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   83: astore 9
    //   85: aload 8
    //   87: aload 9
    //   89: invokeinterface 245 2 0
    //   94: istore 10
    //   96: goto -34 -> 62
    //   99: astore 11
    //   101: aload 8
    //   103: astore_1
    //   104: getstatic 126	com/softspb/shell/calendar/service/CalendarService:logger	Lcom/softspb/util/log/Logger;
    //   107: ldc 247
    //   109: aload 11
    //   111: invokevirtual 253	com/softspb/util/log/Logger:e	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   114: aload 6
    //   116: ifnull +10 -> 126
    //   119: aload 6
    //   121: invokeinterface 256 1 0
    //   126: aload_1
    //   127: areturn
    //   128: aload 8
    //   130: astore_1
    //   131: aload 6
    //   133: ifnull -7 -> 126
    //   136: aload 6
    //   138: invokeinterface 256 1 0
    //   143: goto -17 -> 126
    //   146: astore 12
    //   148: aload 6
    //   150: ifnull +10 -> 160
    //   153: aload 6
    //   155: invokeinterface 256 1 0
    //   160: aload 12
    //   162: athrow
    //   163: astore 12
    //   165: aload 8
    //   167: astore 13
    //   169: goto -21 -> 148
    //   172: astore 11
    //   174: goto -70 -> 104
    //
    // Exception table:
    //   from	to	target	type
    //   62	96	99	java/lang/Throwable
    //   4	62	146	finally
    //   104	114	146	finally
    //   62	96	163	finally
    //   4	62	172	java/lang/Throwable
  }

  // ERROR //
  private void loadAppointments(int paramInt, long paramLong1, long paramLong2)
  {
    // Byte code:
    //   0: ldc_w 260
    //   3: ldc_w 261
    //   6: invokestatic 267	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   9: istore 6
    //   11: new 171	java/lang/StringBuilder
    //   14: dup
    //   15: invokespecial 172	java/lang/StringBuilder:<init>	()V
    //   18: ldc_w 269
    //   21: invokevirtual 181	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: astore 7
    //   26: lload_2
    //   27: invokestatic 271	com/softspb/shell/calendar/service/CalendarService:convertTime	(J)Ljava/lang/String;
    //   30: astore 8
    //   32: aload 7
    //   34: aload 8
    //   36: invokevirtual 181	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   39: ldc_w 273
    //   42: invokevirtual 181	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   45: astore 9
    //   47: lload 4
    //   49: invokestatic 271	com/softspb/shell/calendar/service/CalendarService:convertTime	(J)Ljava/lang/String;
    //   52: astore 10
    //   54: aload 9
    //   56: aload 10
    //   58: invokevirtual 181	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   61: invokevirtual 195	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   64: invokestatic 161	com/softspb/shell/calendar/service/CalendarService:logd	(Ljava/lang/String;)V
    //   67: aload_0
    //   68: invokespecial 275	com/softspb/shell/calendar/service/CalendarService:getEnabledCalendarIds	()Ljava/util/List;
    //   71: astore 11
    //   73: aload_0
    //   74: getfield 277	com/softspb/shell/calendar/service/CalendarService:CALENDAR_CONTENT_URI	Landroid/net/Uri;
    //   77: astore 12
    //   79: iconst_2
    //   80: anewarray 279	java/lang/Object
    //   83: astore 13
    //   85: lload_2
    //   86: invokestatic 239	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   89: astore 14
    //   91: aload 13
    //   93: iconst_0
    //   94: aload 14
    //   96: aastore
    //   97: lload 4
    //   99: invokestatic 239	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   102: astore 15
    //   104: aload 13
    //   106: iconst_1
    //   107: aload 15
    //   109: aastore
    //   110: ldc_w 281
    //   113: aload 13
    //   115: invokestatic 285	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   118: astore 16
    //   120: aload 12
    //   122: aload 16
    //   124: invokestatic 291	android/net/Uri:withAppendedPath	(Landroid/net/Uri;Ljava/lang/String;)Landroid/net/Uri;
    //   127: astore 17
    //   129: new 171	java/lang/StringBuilder
    //   132: dup
    //   133: invokespecial 172	java/lang/StringBuilder:<init>	()V
    //   136: ldc_w 293
    //   139: invokevirtual 181	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   142: aload 17
    //   144: invokevirtual 189	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   147: ldc_w 295
    //   150: invokevirtual 181	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   153: invokevirtual 195	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   156: astore 18
    //   158: ldc_w 260
    //   161: aload 18
    //   163: invokestatic 267	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   166: istore 19
    //   168: aload_0
    //   169: astore 20
    //   171: iload_1
    //   172: istore 21
    //   174: aload 20
    //   176: bipush 6
    //   178: iload 21
    //   180: ldc_w 297
    //   183: invokevirtual 301	com/softspb/shell/calendar/service/CalendarService:notifyClients	(IILjava/lang/String;)V
    //   186: aload_0
    //   187: invokevirtual 208	com/softspb/shell/calendar/service/CalendarService:getContentResolver	()Landroid/content/ContentResolver;
    //   190: astore 22
    //   192: getstatic 110	com/softspb/shell/calendar/service/CalendarService:CANELDAR_PROJECTION	[Ljava/lang/String;
    //   195: astore 23
    //   197: aload 22
    //   199: aload 17
    //   201: aload 23
    //   203: aconst_null
    //   204: aconst_null
    //   205: aconst_null
    //   206: invokevirtual 216	android/content/ContentResolver:query	(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   209: astore 24
    //   211: aload 24
    //   213: ifnull +440 -> 653
    //   216: new 171	java/lang/StringBuilder
    //   219: dup
    //   220: invokespecial 172	java/lang/StringBuilder:<init>	()V
    //   223: ldc_w 303
    //   226: invokevirtual 181	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   229: astore 25
    //   231: aload 24
    //   233: invokeinterface 222 1 0
    //   238: istore 26
    //   240: aload 25
    //   242: iload 26
    //   244: invokevirtual 306	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   247: invokevirtual 195	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   250: invokestatic 161	com/softspb/shell/calendar/service/CalendarService:logd	(Ljava/lang/String;)V
    //   253: aload 24
    //   255: invokeinterface 229 1 0
    //   260: ifeq +410 -> 670
    //   263: aload 24
    //   265: bipush 12
    //   267: invokeinterface 233 2 0
    //   272: invokestatic 239	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   275: astore 27
    //   277: aload 11
    //   279: aload 27
    //   281: invokeinterface 309 2 0
    //   286: ifeq -33 -> 253
    //   289: aload 24
    //   291: iconst_0
    //   292: invokeinterface 233 2 0
    //   297: lstore 28
    //   299: aload 24
    //   301: iconst_1
    //   302: invokeinterface 233 2 0
    //   307: lstore 30
    //   309: aload 24
    //   311: iconst_2
    //   312: invokeinterface 313 2 0
    //   317: astore 32
    //   319: aload 24
    //   321: iconst_3
    //   322: invokeinterface 313 2 0
    //   327: astore 33
    //   329: aload 24
    //   331: iconst_4
    //   332: invokeinterface 313 2 0
    //   337: astore 34
    //   339: aload 24
    //   341: iconst_5
    //   342: invokeinterface 317 2 0
    //   347: iconst_1
    //   348: if_icmpne +291 -> 639
    //   351: ldc 30
    //   353: istore 35
    //   355: aload 24
    //   357: bipush 6
    //   359: invokeinterface 313 2 0
    //   364: invokestatic 323	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   367: ifne +279 -> 646
    //   370: ldc 30
    //   372: istore 36
    //   374: aload 24
    //   376: bipush 7
    //   378: invokeinterface 233 2 0
    //   383: lstore 37
    //   385: aload 24
    //   387: bipush 8
    //   389: invokeinterface 317 2 0
    //   394: istore 39
    //   396: aload 24
    //   398: bipush 10
    //   400: invokeinterface 317 2 0
    //   405: istore 40
    //   407: new 325	android/text/format/Time
    //   410: dup
    //   411: invokespecial 326	android/text/format/Time:<init>	()V
    //   414: astore 41
    //   416: aload 41
    //   418: astore 42
    //   420: iload 39
    //   422: istore 43
    //   424: aload 42
    //   426: iload 43
    //   428: invokevirtual 329	android/text/format/Time:setJulianDay	(I)J
    //   431: lstore 44
    //   433: iload 40
    //   435: bipush 60
    //   437: imul
    //   438: istore 46
    //   440: aload 41
    //   442: iload 46
    //   444: putfield 332	android/text/format/Time:second	I
    //   447: aload 24
    //   449: bipush 9
    //   451: invokeinterface 317 2 0
    //   456: istore 47
    //   458: aload 24
    //   460: bipush 11
    //   462: invokeinterface 317 2 0
    //   467: istore 48
    //   469: new 325	android/text/format/Time
    //   472: dup
    //   473: invokespecial 326	android/text/format/Time:<init>	()V
    //   476: astore 49
    //   478: aload 49
    //   480: astore 50
    //   482: iload 47
    //   484: istore 51
    //   486: aload 50
    //   488: iload 51
    //   490: invokevirtual 329	android/text/format/Time:setJulianDay	(I)J
    //   493: lstore 52
    //   495: iload 48
    //   497: bipush 60
    //   499: imul
    //   500: istore 54
    //   502: aload 49
    //   504: iload 54
    //   506: putfield 332	android/text/format/Time:second	I
    //   509: getstatic 80	android/os/Build$VERSION:SDK_INT	I
    //   512: bipush 9
    //   514: if_icmplt +21 -> 535
    //   517: aload 41
    //   519: ldc 30
    //   521: invokevirtual 336	android/text/format/Time:toMillis	(Z)J
    //   524: lstore 28
    //   526: aload 49
    //   528: ldc 30
    //   530: invokevirtual 336	android/text/format/Time:toMillis	(Z)J
    //   533: lstore 30
    //   535: aload 41
    //   537: ldc 30
    //   539: invokevirtual 336	android/text/format/Time:toMillis	(Z)J
    //   542: lstore 55
    //   544: aload 49
    //   546: ldc 30
    //   548: invokevirtual 336	android/text/format/Time:toMillis	(Z)J
    //   551: lstore 57
    //   553: aload_0
    //   554: astore 59
    //   556: iload_1
    //   557: istore 60
    //   559: aload 59
    //   561: iload 60
    //   563: aload 33
    //   565: aload 34
    //   567: lload 55
    //   569: lload 57
    //   571: lload 28
    //   573: lload 30
    //   575: iload 35
    //   577: iload 36
    //   579: iconst_0
    //   580: lload 37
    //   582: invokevirtual 340	com/softspb/shell/calendar/service/CalendarService:notifyOnAppointmentLoaded	(ILjava/lang/String;Ljava/lang/String;JJJJZZIJ)V
    //   585: goto -332 -> 253
    //   588: astore 61
    //   590: aload 61
    //   592: astore 62
    //   594: ldc_w 342
    //   597: aload 62
    //   599: invokestatic 345	com/softspb/shell/calendar/service/CalendarService:loge	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   602: aload 24
    //   604: ifnull +10 -> 614
    //   607: aload 24
    //   609: invokeinterface 256 1 0
    //   614: aload_0
    //   615: astore 63
    //   617: iload_1
    //   618: istore 64
    //   620: aload 63
    //   622: bipush 7
    //   624: iload 64
    //   626: ldc_w 347
    //   629: invokevirtual 301	com/softspb/shell/calendar/service/CalendarService:notifyClients	(IILjava/lang/String;)V
    //   632: ldc_w 349
    //   635: invokestatic 161	com/softspb/shell/calendar/service/CalendarService:logd	(Ljava/lang/String;)V
    //   638: return
    //   639: ldc 42
    //   641: istore 35
    //   643: goto -288 -> 355
    //   646: ldc 42
    //   648: istore 36
    //   650: goto -276 -> 374
    //   653: ldc_w 260
    //   656: ldc_w 351
    //   659: invokestatic 267	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   662: istore 65
    //   664: ldc_w 353
    //   667: invokestatic 356	com/softspb/shell/calendar/service/CalendarService:logw	(Ljava/lang/String;)V
    //   670: aload 24
    //   672: ifnull +10 -> 682
    //   675: aload 24
    //   677: invokeinterface 256 1 0
    //   682: aload_0
    //   683: astore 66
    //   685: iload_1
    //   686: istore 67
    //   688: aload 66
    //   690: bipush 7
    //   692: iload 67
    //   694: ldc_w 347
    //   697: invokevirtual 301	com/softspb/shell/calendar/service/CalendarService:notifyClients	(IILjava/lang/String;)V
    //   700: ldc_w 349
    //   703: invokestatic 161	com/softspb/shell/calendar/service/CalendarService:logd	(Ljava/lang/String;)V
    //   706: goto -68 -> 638
    //   709: astore 68
    //   711: aload 24
    //   713: ifnull +10 -> 723
    //   716: aload 24
    //   718: invokeinterface 256 1 0
    //   723: aload_0
    //   724: astore 69
    //   726: iload_1
    //   727: istore 70
    //   729: aload 69
    //   731: bipush 7
    //   733: iload 70
    //   735: ldc_w 347
    //   738: invokevirtual 301	com/softspb/shell/calendar/service/CalendarService:notifyClients	(IILjava/lang/String;)V
    //   741: ldc_w 349
    //   744: invokestatic 161	com/softspb/shell/calendar/service/CalendarService:logd	(Ljava/lang/String;)V
    //   747: aload 68
    //   749: athrow
    //   750: astore 71
    //   752: goto -70 -> 682
    //   755: astore 72
    //   757: goto -143 -> 614
    //   760: astore 73
    //   762: goto -39 -> 723
    //
    // Exception table:
    //   from	to	target	type
    //   168	585	588	java/lang/Throwable
    //   653	670	588	java/lang/Throwable
    //   168	585	709	finally
    //   590	602	709	finally
    //   653	670	709	finally
    //   675	682	750	java/lang/Exception
    //   607	614	755	java/lang/Exception
    //   716	723	760	java/lang/Exception
  }

  private static void logd(String paramString)
  {
    Logger localLogger = logger;
    String str = "ApptList " + paramString;
    localLogger.d(str);
  }

  private static void loge(String paramString, Throwable paramThrowable)
  {
    Logger localLogger = logger;
    String str = "ApptList " + paramString;
    localLogger.e(str, paramThrowable);
  }

  private static void logw(String paramString)
  {
    Logger localLogger = logger;
    String str = "ApptList " + paramString;
    localLogger.w(str);
  }

  void notifyClients(int paramInt1, int paramInt2, String paramString)
  {
    logd("notifyClients >>> " + paramString + " token=" + paramInt2);
    int i = this.clients.size() + -1;
    while (true)
      if (i >= 0)
        try
        {
          Messenger localMessenger = (Messenger)this.clients.get(i);
          Message localMessage = Message.obtain(null, paramInt1, paramInt2, 0);
          localMessenger.send(localMessage);
          i += -1;
        }
        catch (RemoteException localRemoteException)
        {
          while (true)
            Object localObject = this.clients.remove(i);
        }
    logd("notifyClients <<< " + paramString);
  }

  void notifyClients(int paramInt, String paramString)
  {
    logd("notifyClients >>> " + paramString);
    int i = this.clients.size() + -1;
    while (true)
      if (i >= 0)
        try
        {
          Messenger localMessenger = (Messenger)this.clients.get(i);
          Message localMessage = Message.obtain(null, paramInt);
          localMessenger.send(localMessage);
          i += -1;
        }
        catch (RemoteException localRemoteException)
        {
          while (true)
            Object localObject = this.clients.remove(i);
        }
    logd("notifyClients <<< " + paramString);
  }

  void notifyOnAppointmentLoaded(int paramInt1, String paramString1, String paramString2, long paramLong1, long paramLong2, long paramLong3, long paramLong4, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, long paramLong5)
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("notifyOnAppointmentLoaded >>> id=");
    long l1 = paramLong5;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(l1).append(" subject=\"");
    String str1 = paramString1;
    logd(str1 + "\"");
    int i = paramInt1;
    String str2 = paramString1;
    String str3 = paramString2;
    long l2 = paramLong1;
    long l3 = paramLong2;
    long l4 = paramLong3;
    long l5 = paramLong4;
    long l6 = paramBoolean1;
    boolean bool = paramBoolean2;
    long l7 = paramInt2;
    long l8 = paramLong5;
    Appointment localAppointment = new Appointment(i, str2, str3, l2, l3, l4, l5, l6, bool, l7, l8);
    int j = this.clients.size() + -1;
    while (true)
      if (j >= 0)
      {
        Handler localHandler = null;
        int k = 4;
        try
        {
          Message localMessage1 = Message.obtain(localHandler, k);
          Bundle localBundle1 = new Bundle();
          localBundle1.putParcelable("appointment", localAppointment);
          Message localMessage2 = localMessage1;
          Bundle localBundle2 = localBundle1;
          localMessage2.setData(localBundle2);
          ArrayList localArrayList1 = this.clients;
          int m = j;
          Messenger localMessenger = (Messenger)localArrayList1.get(m);
          Message localMessage3 = localMessage1;
          localMessenger.send(localMessage3);
          j += -1;
        }
        catch (RemoteException localRemoteException)
        {
          while (true)
          {
            ArrayList localArrayList2 = this.clients;
            int n = j;
            Object localObject = localArrayList2.remove(n);
          }
        }
      }
    logd("notifyOnAppointmentLoaded <<<");
  }

  public IBinder onBind(Intent paramIntent)
  {
    return this.messenger.getBinder();
  }

  public void onCreate()
  {
    logd("onCreate >>>");
    super.onCreate();
    int i;
    if (Build.VERSION.SDK_INT > 7)
      i = 1;
    while (true)
    {
      int j;
      label30: String str1;
      if (Build.VERSION.SDK_INT >= 14)
      {
        j = 1;
        if (i == 0)
          break label246;
        str1 = "com.android.calendar";
        label38: logd("onCreate: authority=" + str1);
        if (j != 0)
          break label264;
        Uri localUri1 = Uri.parse("content://" + str1 + "/instances/when");
        this.CALENDAR_CONTENT_URI = localUri1;
        Uri localUri2 = Uri.parse("content://" + str1 + "/events");
        this.CALENDAR_OBSERVE_URI = localUri2;
        Uri localUri3 = Uri.parse("content://" + str1 + "/calendars");
        this.CALENDAR_CALENDARS_URI = localUri3;
      }
      try
      {
        while (true)
        {
          String str2 = getPackageName();
          ClassLoader localClassLoader = createPackageContext(str2, 3).getClassLoader();
          this.classLoader = localClassLoader;
          ContentResolver localContentResolver = getContentResolver();
          Uri localUri4 = this.CALENDAR_OBSERVE_URI;
          ContentObserver localContentObserver = this.contentObserver;
          localContentResolver.registerContentObserver(localUri4, 1, localContentObserver);
          logd("onCreate <<<");
          return;
          i = 0;
          break;
          j = 0;
          break label30;
          label246: if (j != 0)
          {
            str1 = "com.android.calendar";
            break label38;
          }
          str1 = "calendar";
          break label38;
          label264: Uri localUri5 = CalendarContract.Instances.CONTENT_URI;
          this.CALENDAR_CONTENT_URI = localUri5;
          Uri localUri6 = CalendarContract.Events.CONTENT_URI;
          this.CALENDAR_OBSERVE_URI = localUri6;
          Uri localUri7 = CalendarContract.Calendars.CONTENT_URI;
          this.CALENDAR_CALENDARS_URI = localUri7;
        }
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        while (true)
          loge("Failed to initialize class loader: " + localNameNotFoundException, localNameNotFoundException);
      }
    }
  }

  public void onDestroy()
  {
    logd("onDestroy >>>");
    super.onDestroy();
    ContentResolver localContentResolver = getContentResolver();
    ContentObserver localContentObserver = this.contentObserver;
    localContentResolver.unregisterContentObserver(localContentObserver);
    logd("onDestroy >>>");
  }

  class IncomingHandler extends Handler
  {
    IncomingHandler()
    {
    }

    public void handleMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default:
        super.handleMessage(paramMessage);
      case 1:
      case 2:
      case 3:
      case 99:
      }
      while (true)
      {
        return;
        CalendarService.access$000("handleMessage: REGISTER_CLIENT");
        ArrayList localArrayList1 = CalendarService.this.clients;
        Messenger localMessenger1 = paramMessage.replyTo;
        boolean bool1 = localArrayList1.add(localMessenger1);
        continue;
        CalendarService.access$000("handleMessage: UNREGISTER_CLIENT");
        ArrayList localArrayList2 = CalendarService.this.clients;
        Messenger localMessenger2 = paramMessage.replyTo;
        boolean bool2 = localArrayList2.remove(localMessenger2);
        continue;
        CalendarService.access$000("handleMessage: LOAD_APPOINTMENTS");
        Bundle localBundle = paramMessage.getData();
        ClassLoader localClassLoader = CalendarService.this.classLoader;
        localBundle.setClassLoader(localClassLoader);
        LoadAppointmentsParams localLoadAppointmentsParams = (LoadAppointmentsParams)localBundle.getParcelable("load-appts-params");
        CalendarService localCalendarService = CalendarService.this;
        int i = localLoadAppointmentsParams.token;
        long l1 = localLoadAppointmentsParams.searchStartDate;
        long l2 = localLoadAppointmentsParams.searchEndDate;
        localCalendarService.loadAppointments(i, l1, l2);
        continue;
        CalendarService.access$000("handleMessage: GET_PID");
        Messenger localMessenger3 = paramMessage.replyTo;
        int j = Process.myPid();
        Message localMessage = Message.obtain(null, 8, j, 0);
        try
        {
          localMessenger3.send(localMessage);
        }
        catch (RemoteException localRemoteException)
        {
        }
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.calendar.service.CalendarService
 * JD-Core Version:    0.6.0
 */