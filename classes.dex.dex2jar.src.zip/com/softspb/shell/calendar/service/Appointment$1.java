package com.softspb.shell.calendar.service;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class Appointment$1
  implements Parcelable.Creator<Appointment>
{
  public Appointment createFromParcel(Parcel paramParcel)
  {
    return new Appointment(paramParcel);
  }

  public Appointment[] newArray(int paramInt)
  {
    return new Appointment[paramInt];
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.calendar.service.Appointment.1
 * JD-Core Version:    0.6.0
 */