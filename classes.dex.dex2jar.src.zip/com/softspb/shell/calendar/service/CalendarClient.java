package com.softspb.shell.calendar.service;

import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;

public abstract class CalendarClient
{
  static final Logger logger = Loggers.getLogger(CalendarClient.class);
  ClassLoader classLoader;
  private ServiceConnection connection;
  final Context context;
  boolean isBound;
  final Messenger messenger;
  Messenger service = null;

  protected CalendarClient(Context paramContext)
  {
    IncomingHandler localIncomingHandler = new IncomingHandler();
    Messenger localMessenger = new Messenger(localIncomingHandler);
    this.messenger = localMessenger;
    CalendarClient.1 local1 = new CalendarClient.1(this);
    this.connection = local1;
    logd("Ctor");
    this.context = paramContext;
    try
    {
      String str1 = paramContext.getPackageName();
      ClassLoader localClassLoader = paramContext.createPackageContext(str1, 3).getClassLoader();
      this.classLoader = localClassLoader;
      return;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      while (true)
      {
        Logger localLogger = logger;
        String str2 = "Failed to initialize class loader: " + localNameNotFoundException;
        localLogger.e(str2, localNameNotFoundException);
      }
    }
  }

  protected static void logd(String paramString)
  {
    Logger localLogger = logger;
    String str = "ApptList " + paramString;
    localLogger.d(str);
  }

  public void connect()
  {
    logd("connect >>>");
    Context localContext1 = this.context;
    Context localContext2 = this.context;
    Intent localIntent = new Intent(localContext2, CalendarService.class);
    ServiceConnection localServiceConnection = this.connection;
    boolean bool = localContext1.bindService(localIntent, localServiceConnection, 1);
    this.isBound = 1;
    logd("connect <<< attached service connection");
  }

  public void disconnect()
  {
    logd("disconnect >>>");
    Handler localHandler;
    int i;
    if (this.isBound)
      if (this.service != null)
      {
        localHandler = null;
        i = 2;
      }
    try
    {
      Message localMessage = Message.obtain(localHandler, i);
      Messenger localMessenger = this.messenger;
      localMessage.replyTo = localMessenger;
      this.service.send(localMessage);
      logd("disconnect: sent UNREGISTER");
      label54: Context localContext = this.context;
      ServiceConnection localServiceConnection = this.connection;
      localContext.unbindService(localServiceConnection);
      logd("disconnect <<< service connection detached");
      this.isBound = 0;
      while (true)
      {
        return;
        logd("disconnect: service is null");
        break;
        logd("disconnect <<< not bound");
      }
    }
    catch (RemoteException localRemoteException)
    {
      break label54;
    }
  }

  public boolean isConnected()
  {
    return this.isBound;
  }

  public void loadAppointments(int paramInt, long paramLong1, long paramLong2)
  {
    logd("loadAppointments >>> searchStartDate=" + paramLong1 + " searchEndDate=" + paramLong2);
    if (this.service != null)
    {
      Handler localHandler = null;
      int i = 3;
      try
      {
        Message localMessage = Message.obtain(localHandler, i);
        int j = paramInt;
        long l1 = paramLong1;
        long l2 = paramLong2;
        LoadAppointmentsParams localLoadAppointmentsParams = new LoadAppointmentsParams(j, l1, l2);
        Bundle localBundle = new Bundle();
        localBundle.putParcelable("load-appts-params", localLoadAppointmentsParams);
        localMessage.setData(localBundle);
        this.service.send(localMessage);
        logd("loadAppointments <<< sent request");
        return;
      }
      catch (RemoteException localRemoteException)
      {
        while (true)
          logd("loadAppointments <<< remote exception");
      }
    }
    logd("loadAppointments <<< service is null");
    throw new IllegalStateException("Not connected to Calendar Service");
  }

  protected abstract void onAppointmentLoaded(Appointment paramAppointment);

  protected abstract void onCalendarChanged();

  protected abstract void onConnected();

  protected abstract void onDisconnected();

  protected abstract void onFinishedReloadingAppointments(int paramInt);

  protected abstract void onPidResponse(int paramInt);

  protected abstract void onStartedReloadingAppointments(int paramInt);

  public void requestServicePid()
  {
    logd("requestServicePid >>>");
    if (this.service != null)
    {
      Message localMessage = Message.obtain(null, 99);
      Messenger localMessenger = this.messenger;
      localMessage.replyTo = localMessenger;
      try
      {
        this.service.send(localMessage);
        logd("requestServicePid <<< request sent");
        return;
      }
      catch (RemoteException localRemoteException)
      {
        while (true)
          logd("requestServicePid <<< remote exception");
      }
    }
    logd("requestServicePid <<< not connected");
    throw new IllegalStateException("Not connected to Calendar Service");
  }

  class IncomingHandler extends Handler
  {
    IncomingHandler()
    {
    }

    public void handleMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default:
        super.handleMessage(paramMessage);
      case 5:
      case 4:
      case 6:
      case 7:
      case 8:
      }
      while (true)
      {
        return;
        CalendarClient.logd("handleMessage: ON_CALENDAR_CHANGED");
        CalendarClient.this.onCalendarChanged();
        continue;
        CalendarClient.logd("handleMessage: ON_APPOINTMENT_LOADED");
        Bundle localBundle = paramMessage.getData();
        ClassLoader localClassLoader = CalendarClient.this.classLoader;
        localBundle.setClassLoader(localClassLoader);
        Appointment localAppointment = (Appointment)localBundle.getParcelable("appointment");
        CalendarClient.this.onAppointmentLoaded(localAppointment);
        continue;
        CalendarClient.logd("handleMessage: ON_STARTED_RELOADING_APPOINTMENTS");
        CalendarClient localCalendarClient1 = CalendarClient.this;
        int i = paramMessage.arg1;
        localCalendarClient1.onStartedReloadingAppointments(i);
        continue;
        CalendarClient.logd("handleMessage: ON_FINISHED_RELOADING_APPOINTMENTS");
        CalendarClient localCalendarClient2 = CalendarClient.this;
        int j = paramMessage.arg1;
        localCalendarClient2.onFinishedReloadingAppointments(j);
        continue;
        CalendarClient.logd("handleMessage: RESPONSE_PID");
        CalendarClient localCalendarClient3 = CalendarClient.this;
        int k = paramMessage.arg1;
        localCalendarClient3.onPidResponse(k);
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.calendar.service.CalendarClient
 * JD-Core Version:    0.6.0
 */