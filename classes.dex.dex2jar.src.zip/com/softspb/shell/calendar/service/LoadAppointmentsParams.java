package com.softspb.shell.calendar.service;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class LoadAppointmentsParams
  implements Parcelable
{
  public static final Parcelable.Creator<LoadAppointmentsParams> CREATOR = new LoadAppointmentsParams.1();
  public final long searchEndDate;
  public final long searchStartDate;
  public final int token;

  public LoadAppointmentsParams(int paramInt, long paramLong1, long paramLong2)
  {
    this.token = paramInt;
    this.searchStartDate = paramLong1;
    this.searchEndDate = paramLong2;
  }

  LoadAppointmentsParams(Parcel paramParcel)
  {
    int i = paramParcel.readInt();
    this.token = i;
    long l1 = paramParcel.readLong();
    this.searchStartDate = l1;
    long l2 = paramParcel.readLong();
    this.searchEndDate = l2;
  }

  public int describeContents()
  {
    return 0;
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    int i = this.token;
    paramParcel.writeInt(i);
    long l1 = this.searchStartDate;
    paramParcel.writeLong(l1);
    long l2 = this.searchEndDate;
    paramParcel.writeLong(l2);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.calendar.service.LoadAppointmentsParams
 * JD-Core Version:    0.6.0
 */