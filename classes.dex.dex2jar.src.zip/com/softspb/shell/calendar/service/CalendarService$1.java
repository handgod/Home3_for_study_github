package com.softspb.shell.calendar.service;

import android.database.ContentObserver;
import android.os.Handler;

class CalendarService$1 extends ContentObserver
{
  public void onChange(boolean paramBoolean)
  {
    CalendarService.access$000("onReceive >>>");
    this.this$0.notifyClients(5, "ON_CALENDAR_CHANGED");
    CalendarService.access$000("onReceive <<<");
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.calendar.service.CalendarService.1
 * JD-Core Version:    0.6.0
 */