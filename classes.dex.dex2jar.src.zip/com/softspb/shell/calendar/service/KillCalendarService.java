package com.softspb.shell.calendar.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

public class KillCalendarService extends Service
{
  private static final String TAG = "KillCalendarService";

  private static void logd(String paramString)
  {
    int i = Log.d("KillCalendarService", paramString);
  }

  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }

  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    logd("start killing Calendar Service");
    new KillCalendarService.1(this, this).connect();
    return 2;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.calendar.service.KillCalendarService
 * JD-Core Version:    0.6.0
 */