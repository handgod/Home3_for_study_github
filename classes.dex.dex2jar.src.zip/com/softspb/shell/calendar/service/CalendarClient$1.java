package com.softspb.shell.calendar.service;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;

class CalendarClient$1
  implements ServiceConnection
{
  public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
  {
    CalendarClient.logd("onServiceConnected: " + paramComponentName);
    CalendarClient localCalendarClient = this.this$0;
    Messenger localMessenger1 = new Messenger(paramIBinder);
    localCalendarClient.service = localMessenger1;
    try
    {
      Message localMessage = Message.obtain(null, 1);
      Messenger localMessenger2 = this.this$0.messenger;
      localMessage.replyTo = localMessenger2;
      this.this$0.service.send(localMessage);
      CalendarClient.logd("onServiceConnected <<< sent REGISTER");
      this.this$0.onConnected();
      return;
    }
    catch (RemoteException localRemoteException)
    {
      while (true)
        CalendarClient.logd("onServiceConnected <<< remote exception while sending REGISTER");
    }
  }

  public void onServiceDisconnected(ComponentName paramComponentName)
  {
    CalendarClient.logd("onServiceDisconnected: " + paramComponentName);
    this.this$0.service = null;
    this.this$0.onDisconnected();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.calendar.service.CalendarClient.1
 * JD-Core Version:    0.6.0
 */