package com.softspb.shell.calendar.service;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class Appointment
  implements Parcelable
{
  public static final Parcelable.Creator<Appointment> CREATOR = new Appointment.1();
  public final long end;
  public final long id;
  public final boolean isAllDay;
  public final boolean isRecurring;
  public final String location;
  public final long originalEnd;
  public final long originalStart;
  public final long start;
  public final int status;
  public final String subject;
  public final int token;

  public Appointment(int paramInt1, String paramString1, String paramString2, long paramLong1, long paramLong2, long paramLong3, long paramLong4, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, long paramLong5)
  {
    this.token = paramInt1;
    this.subject = paramString1;
    this.location = paramString2;
    this.start = paramLong1;
    this.end = paramLong2;
    this.originalStart = paramLong3;
    this.originalEnd = paramLong4;
    this.isAllDay = paramBoolean1;
    this.isRecurring = paramBoolean2;
    this.status = paramInt2;
    this.id = paramLong5;
  }

  Appointment(Parcel paramParcel)
  {
    int j = paramParcel.readInt();
    this.token = j;
    String str1 = paramParcel.readString();
    this.subject = str1;
    String str2 = paramParcel.readString();
    this.location = str2;
    long l1 = paramParcel.readLong();
    this.start = l1;
    long l2 = paramParcel.readLong();
    this.end = l2;
    long l3 = paramParcel.readLong();
    this.originalStart = l3;
    long l4 = paramParcel.readLong();
    this.originalEnd = l4;
    int k;
    if (paramParcel.readInt() != 0)
    {
      k = 1;
      this.isAllDay = k;
      if (paramParcel.readInt() == 0)
        break label150;
    }
    while (true)
    {
      this.isRecurring = i;
      int m = paramParcel.readInt();
      this.status = m;
      long l5 = paramParcel.readLong();
      this.id = l5;
      return;
      k = 0;
      break;
      label150: i = 0;
    }
  }

  public int describeContents()
  {
    return 0;
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    int i = 1;
    int j = this.token;
    paramParcel.writeInt(j);
    String str1 = this.subject;
    paramParcel.writeString(str1);
    String str2 = this.location;
    paramParcel.writeString(str2);
    long l1 = this.start;
    paramParcel.writeLong(l1);
    long l2 = this.end;
    paramParcel.writeLong(l2);
    long l3 = this.originalStart;
    paramParcel.writeLong(l3);
    long l4 = this.originalEnd;
    paramParcel.writeLong(l4);
    int k;
    if (this.isAllDay)
    {
      k = 1;
      paramParcel.writeInt(k);
      if (!this.isRecurring)
        break label145;
    }
    while (true)
    {
      paramParcel.writeInt(i);
      int m = this.status;
      paramParcel.writeInt(m);
      long l5 = this.id;
      paramParcel.writeLong(l5);
      return;
      k = 0;
      break;
      label145: i = 0;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.calendar.service.Appointment
 * JD-Core Version:    0.6.0
 */