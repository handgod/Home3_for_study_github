package com.softspb.shell.calendar.service;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class LoadAppointmentsParams$1
  implements Parcelable.Creator<LoadAppointmentsParams>
{
  public LoadAppointmentsParams createFromParcel(Parcel paramParcel)
  {
    return new LoadAppointmentsParams(paramParcel);
  }

  public LoadAppointmentsParams[] newArray(int paramInt)
  {
    return new LoadAppointmentsParams[paramInt];
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.calendar.service.LoadAppointmentsParams.1
 * JD-Core Version:    0.6.0
 */