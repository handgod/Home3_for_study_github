package com.softspb.shell;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import com.spb.cities.provider.CitiesContract.Cities;

class Home$9 extends Thread
{
  public void run()
  {
    try
    {
      ContentResolver localContentResolver = this.this$0.getContentResolver();
      Uri localUri = CitiesContract.Cities.getContentUri(this.this$0.getApplicationContext());
      Cursor localCursor1 = localContentResolver.query(localUri, null, "city_id=0", null, null);
      Cursor localCursor2 = localCursor1;
      if (localCursor2 != null)
        localCursor2.close();
      return;
    }
    finally
    {
      if (0 != 0)
        null.close();
    }
    throw localObject;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.Home.9
 * JD-Core Version:    0.6.0
 */