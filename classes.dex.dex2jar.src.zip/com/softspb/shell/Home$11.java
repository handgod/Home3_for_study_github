package com.softspb.shell;

import android.view.View;
import com.softspb.shell.data.BaseWidgetInfo;
import com.softspb.shell.view.WidgetController2;

class Home$11
  implements Runnable
{
  public void run()
  {
    WidgetController2 localWidgetController2 = Home.access$500(this.this$0);
    View localView = this.val$v;
    BaseWidgetInfo localBaseWidgetInfo = this.val$baseInfo;
    localWidgetController2.restoreWidget(localView, localBaseWidgetInfo);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.Home.11
 * JD-Core Version:    0.6.0
 */