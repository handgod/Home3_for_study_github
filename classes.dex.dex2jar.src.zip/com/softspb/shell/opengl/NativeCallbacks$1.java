package com.softspb.shell.opengl;

import com.softspb.shell.Home;

class NativeCallbacks$1
  implements Runnable
{
  public void run()
  {
    try
    {
      NativeCallbacks.access$000(this.this$0).showLoadingDialog();
      return;
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.opengl.NativeCallbacks.1
 * JD-Core Version:    0.6.0
 */