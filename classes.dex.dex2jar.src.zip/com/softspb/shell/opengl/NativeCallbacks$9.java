package com.softspb.shell.opengl;

import android.widget.Toast;
import com.softspb.shell.Home;

class NativeCallbacks$9
  implements Runnable
{
  public void run()
  {
    Home localHome = NativeCallbacks.access$000(this.this$0);
    Object[] arrayOfObject = new Object[1];
    String str1 = this.val$formatName;
    arrayOfObject[0] = str1;
    String str2 = String.format("Shell will be restarted with %s screen format", arrayOfObject);
    Toast.makeText(localHome, str2, 1).show();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.opengl.NativeCallbacks.9
 * JD-Core Version:    0.6.0
 */