package com.softspb.shell.opengl;

import com.softspb.shell.Home;
import com.softspb.util.log.Logger;

class NativeCallbacks$5
  implements Runnable
{
  public void run()
  {
    NativeCallbacks.access$100().d("Finish!!!");
    NativeCallbacks.access$000(this.this$0).finish();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.opengl.NativeCallbacks.5
 * JD-Core Version:    0.6.0
 */