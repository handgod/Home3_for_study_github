package com.softspb.shell.opengl;

import com.softspb.shell.Home;

class NativeCallbacks$10
  implements Runnable
{
  public void run()
  {
    NativeCallbacks.access$000(this.this$0).restartShell();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.opengl.NativeCallbacks.10
 * JD-Core Version:    0.6.0
 */