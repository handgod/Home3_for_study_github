package com.softspb.shell.opengl;

import com.softspb.shell.Home;

class NativeCallbacks$3
  implements Runnable
{
  public void run()
  {
    NativeCallbacks.access$000(this.this$0).closeOptionsMenu();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.opengl.NativeCallbacks.3
 * JD-Core Version:    0.6.0
 */