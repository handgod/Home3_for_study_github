package com.softspb.shell.opengl;

public class MoveCtx
{
  public boolean bFirst;
  boolean bMove;
  public boolean bStop;
  public boolean bUp;
  public long dt;
  private long mTime;
  public int ptFromX;
  public int ptFromY;
  public int ptStartX;
  public int ptStartY;
  public int ptToX;
  public int ptToY;
  public int vx;
  public int vy;

  public void down(int paramInt1, int paramInt2)
  {
    this.bMove = 1;
    this.ptStartX = paramInt1;
    this.ptStartY = paramInt2;
    this.ptFromX = paramInt1;
    this.ptFromY = paramInt2;
    this.ptToX = paramInt1;
    this.ptToY = paramInt2;
    this.bFirst = 1;
    this.bStop = 0;
    this.bUp = 0;
    this.vx = 0;
    this.vy = 0;
    long l = System.currentTimeMillis();
    this.mTime = l;
  }

  public void move(int paramInt1, int paramInt2)
  {
    if (!this.bMove)
    {
      int i = this.ptToX;
      this.ptFromX = i;
      int j = this.ptToY;
      this.ptFromY = j;
      this.bMove = 1;
    }
    this.ptToX = paramInt1;
    this.ptToY = paramInt2;
  }

  void speedRecalc()
  {
    long l1 = System.currentTimeMillis();
    long l2 = this.mTime;
    long l3 = l1 - l2;
    this.dt = l3;
    if (this.dt < 5L)
      this.dt = 5L;
    int i1;
    if (this.dt > 200L)
    {
      int i = this.ptToX;
      int j = this.ptFromX;
      long l4 = (i - j) * 1000;
      long l5 = this.dt;
      int k = (int)(l4 / l5);
      this.vx = k;
      int m = this.ptToY;
      int n = this.ptFromY;
      long l6 = (m - n) * 1000;
      long l7 = this.dt;
      i1 = (int)(l6 / l7);
    }
    int i7;
    for (this.vy = i1; ; this.vy = i7)
    {
      this.mTime = l1;
      return;
      long l8 = this.vx;
      long l9 = this.dt;
      long l10 = 200L - l9;
      long l11 = l8 * l10;
      int i2 = this.ptToX;
      int i3 = this.ptFromX;
      long l12 = (i2 - i3) * 1000;
      int i4 = (int)((l11 + l12) / 200L);
      this.vx = i4;
      long l13 = this.vy;
      long l14 = this.dt;
      long l15 = 200L - l14;
      long l16 = l13 * l15;
      int i5 = this.ptToY;
      int i6 = this.ptFromY;
      long l17 = (i5 - i6) * 1000;
      i7 = (int)((l16 + l17) / 200L);
    }
  }

  public void up(int paramInt1, int paramInt2)
  {
    if (!this.bMove)
    {
      int i = this.ptToX;
      this.ptFromX = i;
      int j = this.ptToY;
      this.ptFromY = j;
      this.bMove = 1;
    }
    this.ptToX = paramInt1;
    this.ptToY = paramInt2;
    this.bUp = 1;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.opengl.MoveCtx
 * JD-Core Version:    0.6.0
 */