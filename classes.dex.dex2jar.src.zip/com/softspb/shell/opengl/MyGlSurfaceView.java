package com.softspb.shell.opengl;

import android.content.Context;
import android.content.res.Resources;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import java.io.PrintStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class MyGlSurfaceView extends SurfaceView
  implements SurfaceHolder.Callback
{
  private static String LOG_TAG = "From java";
  volatile boolean awaitingSurfaceChange;
  Handler handler;
  private boolean mEnabled = 0;
  private SurfaceHolder mSurfaceHolder;

  public MyGlSurfaceView(Context paramContext)
  {
    this(paramContext, null);
  }

  public MyGlSurfaceView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    nContextCreate();
    init();
  }

  private void init()
  {
    SurfaceHolder localSurfaceHolder = getHolder();
    localSurfaceHolder.addCallback(this);
    localSurfaceHolder.setFormat(4);
    Handler localHandler = new Handler();
    this.handler = localHandler;
  }

  public void destroy()
  {
    nContextDestroy();
  }

  public void enableS3D(boolean paramBoolean)
  {
    this.mEnabled = paramBoolean;
    StringBuilder localStringBuilder = new StringBuilder().append("Device model: ");
    String str1 = Build.DEVICE;
    String str2 = str1;
    int i = Log.i("enableS3D", str2);
    if (Build.DEVICE.equals("p920"));
    while (true)
    {
      return;
      int j = Log.i("enableS3D", "Trying HTC S3D");
      int k = 1;
      Surface localSurface = getHolder().getSurface();
      try
      {
        Class localClass1 = Class.forName("com.htc.view.DisplaySetting");
        Class[] arrayOfClass = new Class[2];
        arrayOfClass[0] = Surface.class;
        Class localClass2 = Integer.TYPE;
        arrayOfClass[1] = localClass2;
        Method localMethod = localClass1.getMethod("setStereoscopic3DFormat", arrayOfClass);
        int m = localClass1.getField("STEREOSCOPIC_3D_FORMAT_SIDE_BY_SIDE").getInt(null);
        int n = localClass1.getField("STEREOSCOPIC_3D_FORMAT_OFF").getInt(null);
        Object localObject = null;
        Object[] arrayOfObject = new Object[2];
        arrayOfObject[0] = localSurface;
        int i1 = 1;
        if (paramBoolean);
        while (true)
        {
          Integer localInteger = Integer.valueOf(m);
          arrayOfObject[i1] = localInteger;
          int i2 = ((Boolean)localMethod.invoke(localObject, arrayOfObject)).booleanValue();
          k = i2;
          String str3 = "HTC return value:" + k;
          int i3 = Log.i("enableS3D", str3);
          if (k != 0)
            break;
          int i4 = Log.i("enableS3D", "S3D format not supported");
          break;
          m = n;
        }
      }
      catch (Throwable localThrowable)
      {
        while (true)
        {
          String str4 = "HTC S3D setStereoscopic3DFormat failed: " + localThrowable;
          int i5 = Log.i("enableS3D", str4);
        }
      }
    }
  }

  public boolean isEnableS3D()
  {
    return this.mEnabled;
  }

  native void nContextCreate();

  native void nContextDestroy();

  native void nContextPause();

  native void nContextResume();

  native void nContextSetPriority(int paramInt);

  native void nContextSetSurface(int paramInt1, int paramInt2, Surface paramSurface, int paramInt3, int paramInt4, int paramInt5);

  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
  }

  public void onPause()
  {
    nContextPause();
  }

  public void onResume()
  {
    nContextResume();
    if (this.mEnabled)
    {
      boolean bool = this.mEnabled;
      enableS3D(bool);
    }
  }

  public void queueEvent(Runnable paramRunnable)
  {
  }

  public void surfaceChanged(SurfaceHolder paramSurfaceHolder, int paramInt1, int paramInt2, int paramInt3)
  {
    DisplayMetrics localDisplayMetrics = getResources().getDisplayMetrics();
    if (Build.VERSION.SDK_INT != 13)
      if (Build.VERSION.SDK_INT > 13)
      {
        float f1 = localDisplayMetrics.widthPixels;
        float f2 = localDisplayMetrics.density;
        float f3 = 600.0F * f2;
        if (f1 >= f3);
      }
      else
      {
        if (localDisplayMetrics.heightPixels == paramInt3)
          break label227;
      }
    if (getResources().getDisplayMetrics().widthPixels == paramInt2)
    {
      PrintStream localPrintStream = System.out;
      StringBuilder localStringBuilder1 = new StringBuilder().append("surfaceChanged (").append(paramInt2).append(" ").append(paramInt3).append(") (");
      int i = localDisplayMetrics.widthPixels;
      StringBuilder localStringBuilder2 = localStringBuilder1.append(i).append(" ");
      int j = localDisplayMetrics.heightPixels;
      String str = j + ")";
      localPrintStream.println(str);
      Surface localSurface = paramSurfaceHolder.getSurface();
      int k = localDisplayMetrics.widthPixels;
      int m = localDisplayMetrics.heightPixels;
      MyGlSurfaceView localMyGlSurfaceView = this;
      int n = paramInt2;
      int i1 = paramInt3;
      int i2 = paramInt1;
      localMyGlSurfaceView.nContextSetSurface(n, i1, localSurface, i2, k, m);
      this.awaitingSurfaceChange = 0;
    }
    while (true)
    {
      label227: return;
      this.awaitingSurfaceChange = 1;
      Handler localHandler = this.handler;
      SurfaceChangedCallback localSurfaceChangedCallback = new SurfaceChangedCallback(paramInt2, paramInt3, paramInt1);
      boolean bool = localHandler.postDelayed(localSurfaceChangedCallback, 100L);
    }
  }

  public void surfaceCreated(SurfaceHolder paramSurfaceHolder)
  {
    this.mSurfaceHolder = paramSurfaceHolder;
  }

  public void surfaceDestroyed(SurfaceHolder paramSurfaceHolder)
  {
    MyGlSurfaceView localMyGlSurfaceView = this;
    int i = 0;
    int j = 0;
    int k = 0;
    int m = 0;
    localMyGlSurfaceView.nContextSetSurface(0, i, null, j, k, m);
  }

  class SurfaceChangedCallback
    implements Runnable
  {
    int format;
    int h;
    SurfaceHolder holder;
    int w;

    public SurfaceChangedCallback(int paramInt1, int paramInt2, int arg4)
    {
      this.w = paramInt1;
      this.h = paramInt2;
      int i;
      this.format = i;
    }

    public void run()
    {
      if (MyGlSurfaceView.this.awaitingSurfaceChange)
      {
        SurfaceHolder localSurfaceHolder = MyGlSurfaceView.this.getHolder();
        this.holder = localSurfaceHolder;
        DisplayMetrics localDisplayMetrics = MyGlSurfaceView.this.getResources().getDisplayMetrics();
        int i = MyGlSurfaceView.this.getResources().getDisplayMetrics().widthPixels;
        int j = this.w;
        if (i != j)
          break label243;
        PrintStream localPrintStream = System.out;
        StringBuilder localStringBuilder1 = new StringBuilder().append("surfaceChanged (");
        int k = this.w;
        StringBuilder localStringBuilder2 = localStringBuilder1.append(k).append(" ");
        int m = this.h;
        StringBuilder localStringBuilder3 = localStringBuilder2.append(m).append(") (");
        int n = localDisplayMetrics.widthPixels;
        StringBuilder localStringBuilder4 = localStringBuilder3.append(n).append(" ");
        int i1 = localDisplayMetrics.heightPixels;
        String str = i1 + ")";
        localPrintStream.println(str);
        MyGlSurfaceView localMyGlSurfaceView = MyGlSurfaceView.this;
        int i2 = this.w;
        int i3 = this.h;
        Surface localSurface = this.holder.getSurface();
        int i4 = this.format;
        int i5 = localDisplayMetrics.widthPixels;
        int i6 = localDisplayMetrics.heightPixels;
        localMyGlSurfaceView.nContextSetSurface(i2, i3, localSurface, i4, i5, i6);
        MyGlSurfaceView.this.awaitingSurfaceChange = 0;
      }
      while (true)
      {
        return;
        label243: boolean bool = MyGlSurfaceView.this.handler.postDelayed(this, 100L);
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.opengl.MyGlSurfaceView
 * JD-Core Version:    0.6.0
 */