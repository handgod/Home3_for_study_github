package com.softspb.shell.opengl;

import com.softspb.shell.Home;
import com.softspb.shell.util.MenuController;

class NativeCallbacks$2
  implements Runnable
{
  public void run()
  {
    MenuController localMenuController = NativeCallbacks.access$000(this.this$0).getMenuController();
    int i = this.val$anchorX;
    int j = this.val$anchorY;
    localMenuController.openMenuFromNative(i, j);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.opengl.NativeCallbacks.2
 * JD-Core Version:    0.6.0
 */