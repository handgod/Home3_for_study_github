package com.softspb.shell.opengl;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.webkit.WebSettings;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.webkit.WebView;
import com.softspb.shell.Home;
import com.spb.shell3d.R.string;

class NativeCallbacks$7
  implements Runnable
{
  public void run()
  {
    Home localHome1 = NativeCallbacks.access$000(this.this$0);
    WebView localWebView = new WebView(localHome1);
    localWebView.loadUrl("file:///android_asset/files/licenses/copyright.txt");
    localWebView.getSettings().setDefaultTextEncodingName("UTF-8");
    localWebView.getSettings().setUseWideViewPort(1);
    WebSettings localWebSettings = localWebView.getSettings();
    WebSettings.LayoutAlgorithm localLayoutAlgorithm = WebSettings.LayoutAlgorithm.NORMAL;
    localWebSettings.setLayoutAlgorithm(localLayoutAlgorithm);
    Home localHome2 = NativeCallbacks.access$000(this.this$0);
    AlertDialog.Builder localBuilder = new AlertDialog.Builder(localHome2).setPositiveButton(17039370, null).setView(localWebView).setIcon(17301659);
    int i = R.string.legal_notices_title;
    localBuilder.setTitle(i).create().show();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.opengl.NativeCallbacks.7
 * JD-Core Version:    0.6.0
 */