package com.softspb.shell.opengl;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import com.softspb.shell.Home;

class NativeCallbacks$4
  implements Runnable
{
  public void run()
  {
    Home localHome = NativeCallbacks.access$000(this.this$0);
    AlertDialog.Builder localBuilder1 = new AlertDialog.Builder(localHome);
    String str1 = this.val$message;
    AlertDialog.Builder localBuilder2 = localBuilder1.setMessage(str1);
    String str2 = this.val$title;
    localBuilder2.setTitle(str2).setPositiveButton(17039370, null).create().show();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.opengl.NativeCallbacks.4
 * JD-Core Version:    0.6.0
 */