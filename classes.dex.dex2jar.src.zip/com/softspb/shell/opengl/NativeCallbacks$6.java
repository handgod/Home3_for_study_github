package com.softspb.shell.opengl;

import com.softspb.shell.adapters.wallpaper.WallpaperAdapter;

class NativeCallbacks$6
  implements Runnable
{
  public void run()
  {
    NativeCallbacks.access$200(this.this$0).openSetWallPaperDialog();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.opengl.NativeCallbacks.6
 * JD-Core Version:    0.6.0
 */