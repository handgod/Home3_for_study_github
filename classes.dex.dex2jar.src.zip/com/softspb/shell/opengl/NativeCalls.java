package com.softspb.shell.opengl;

public class NativeCalls
{
  public static native void AddWidget(int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, String paramString1, String paramString2, int paramInt5);

  public static native void DeleteWidget(int paramInt1, int paramInt2);

  public static native void InitWidget(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString1, String paramString2, int paramInt5);

  public static native void UpdatePanel(int paramInt);

  public static native void UpdateWidget(int paramInt);

  public static native void handleSearchRequest();

  public static native void nativeDone(NativeCallbacks paramNativeCallbacks);

  public static native void nativeInit(NativeCallbacks paramNativeCallbacks);

  public static native void notifyContactsUpdate(int paramInt1, int paramInt2, int paramInt3);

  public static native void onHomePressed();
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.opengl.NativeCalls
 * JD-Core Version:    0.6.0
 */