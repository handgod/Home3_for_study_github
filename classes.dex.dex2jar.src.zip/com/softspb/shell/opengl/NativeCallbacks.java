package com.softspb.shell.opengl;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ApplicationInfo;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Debug;
import android.os.Environment;
import android.os.IBinder;
import android.os.Process;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import com.softspb.shell.Home;
import com.softspb.shell.ShellApplication;
import com.softspb.shell.adapters.AdaptersHolder;
import com.softspb.shell.adapters.AppAdapter;
import com.softspb.shell.adapters.AppAdapterAndroid;
import com.softspb.shell.adapters.ApptListAdapter;
import com.softspb.shell.adapters.ApptListAdapterAndroid;
import com.softspb.shell.adapters.BatteryAdapter;
import com.softspb.shell.adapters.BatteryAdapterAndroid;
import com.softspb.shell.adapters.BookmarksAdapter;
import com.softspb.shell.adapters.BookmarksAdapterAndroid;
import com.softspb.shell.adapters.CallLogAdapter;
import com.softspb.shell.adapters.CallLogAdapterAndroid;
import com.softspb.shell.adapters.CitiesAdapter;
import com.softspb.shell.adapters.CitiesAdapterAndroid;
import com.softspb.shell.adapters.ContactsAdapter;
import com.softspb.shell.adapters.ContactsAdapterAndroid;
import com.softspb.shell.adapters.DialogBoxAdapter;
import com.softspb.shell.adapters.DialogBoxAdapterAndroid;
import com.softspb.shell.adapters.GSensorAdapter;
import com.softspb.shell.adapters.GSensorAdapterAndroid;
import com.softspb.shell.adapters.ImageAdapter;
import com.softspb.shell.adapters.ImageAdapterAndroid;
import com.softspb.shell.adapters.MediaLibAdapter;
import com.softspb.shell.adapters.MediaLibAdapterAndroid;
import com.softspb.shell.adapters.MessagingAdapter;
import com.softspb.shell.adapters.MessagingAdapterAndroid;
import com.softspb.shell.adapters.NetworkAdapter;
import com.softspb.shell.adapters.NetworkAdapterAndroid;
import com.softspb.shell.adapters.OperatorAdapter;
import com.softspb.shell.adapters.OperatorAdapterAndroid;
import com.softspb.shell.adapters.ProgramListAdapter;
import com.softspb.shell.adapters.ShortcutAdapter;
import com.softspb.shell.adapters.ShortcutAdapterAndroid;
import com.softspb.shell.adapters.SoundProfileAdapter;
import com.softspb.shell.adapters.SoundProfileAdapterAndroid;
import com.softspb.shell.adapters.TimeAdapter;
import com.softspb.shell.adapters.TimeAdapterAndroid;
import com.softspb.shell.adapters.WeatherAdapter;
import com.softspb.shell.adapters.WeatherAdapterAndroid;
import com.softspb.shell.adapters.WirelessAdapter;
import com.softspb.shell.adapters.WirelessAdapterAndroid;
import com.softspb.shell.adapters.YandexAdapterAndroid;
import com.softspb.shell.adapters.YandexSearchAdapter;
import com.softspb.shell.adapters.alarms.AlarmsAdapter;
import com.softspb.shell.adapters.alarms.AlarmsAdapterAndroid;
import com.softspb.shell.adapters.alarms.AlarmsAdapterAndroid2;
import com.softspb.shell.adapters.backlight.BacklightAdapter;
import com.softspb.shell.adapters.backlight.BacklightAdapterAndroidApi7;
import com.softspb.shell.adapters.backlight.BacklightAdapterAndroidApi8;
import com.softspb.shell.adapters.dialog.NewDialogAdapter;
import com.softspb.shell.adapters.dialog.NewDialogAdapterAndroid;
import com.softspb.shell.adapters.dialog.ShellDatePickerDialog;
import com.softspb.shell.adapters.dialog.ShellDialog;
import com.softspb.shell.adapters.imageviewer.ImageViewerAdapter;
import com.softspb.shell.adapters.imageviewer.ImageViewerAdapterAndroid;
import com.softspb.shell.adapters.program.adapter.ProgramListAdapterAndroid2;
import com.softspb.shell.adapters.simplemedia.SimpleMediaAdapter;
import com.softspb.shell.adapters.simplemedia.SimpleMediaAdapterAndroid;
import com.softspb.shell.adapters.wallpaper.WallpaperAdapter;
import com.softspb.shell.adapters.wallpaper.WallpaperAdapterAndroid;
import com.softspb.shell.calendar.service.KillCalendarService;
import com.softspb.shell.util.DebugUtil;
import com.softspb.shell.view.WidgetController2;
import com.softspb.util.CollectionFactory;
import com.softspb.util.IOHelper;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import com.spb.contacts.KillContactsService;
import com.spb.shell3d.R.drawable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class NativeCallbacks extends NativeCalls
{
  public static final int ANDROID_FROM = 0;
  public static final int ANDROID_TO = 1440;
  private static final long FIRST_DELAY = 900000L;
  private static final String INDEX_XML_FILENAME = "index.xml";
  private static final String KEY_SCREEN_FORMAT = "_key_screen_format";
  public static final int MAJOR_ID = 1;
  private static final ExecutorService NATIVE_EXECUTOR = ;
  private static final int NO_ICON = 255;
  public static final int PRODUCT_ID = 174;
  private static final long REPEAT_DELAY = 3600000L;
  private static final int SCREEN_COUNT = 3;
  private static final int SCREEN_SIZE = 480;
  private static final Logger logger;
  private AdaptersHolder adaptersHolder;
  private AppAdapter appAdapter;
  private ShellApplication application;
  private final ApptListAdapter apptAdapter;
  private BacklightAdapter backlightAdapter;
  private BatteryAdapter batteryAdapter;
  private CitiesAdapter citiesAdapter;
  private ContactsAdapter contactsAdapter;
  private Home context;
  private Set<int[]> delayedWidgets;
  private DialogBoxAdapter dialogBoxAdapter;
  private GSensorAdapter gSensorAdapter;
  private ImageAdapter imageAdapter;
  private ImageViewerAdapter imageViwerAdapter;
  private boolean isLoadStarted;
  final List<NativeMenuItem> menuItems;
  private MessagingAdapter messagingAdapter;
  private NetworkAdapter networkAdapter;
  private NewDialogAdapter newDialogAdapter;
  private OperatorAdapter operatorAdapter;
  private ProgramListAdapter programListAdapter;
  private ShortcutAdapter shortcutAdapter;
  private SimpleMediaAdapter simpleMediaAdapter;
  private SoundProfileAdapter soundProfileAdapter;
  private TimeAdapter timeAdapter;
  private Vibrator vibrator;
  private View view;
  private WallpaperAdapter wallpaperAdapter;
  private WeatherAdapter weatherAdapter;
  private WidgetController2 widgetController;
  private WallpaperManager wm;
  private YandexAdapterAndroid yandexSearchAdapter;

  static
  {
    TimeUnit localTimeUnit = TimeUnit.SECONDS;
    LinkedBlockingQueue localLinkedBlockingQueue = new LinkedBlockingQueue();
    int i = 1;
    NATIVE_EXECUTOR = new ThreadPoolExecutor(1, i, 1L, localTimeUnit, localLinkedBlockingQueue);
    logger = Loggers.getLogger(NativeCallbacks.class.getName());
  }

  public NativeCallbacks(Home paramHome, WidgetController2 paramWidgetController2, View paramView)
  {
    ArrayList localArrayList = new ArrayList();
    this.menuItems = localArrayList;
    HashSet localHashSet = CollectionFactory.newHashSet();
    this.delayedWidgets = localHashSet;
    this.context = paramHome;
    ShellApplication localShellApplication = (ShellApplication)paramHome.getApplication();
    this.application = localShellApplication;
    this.view = paramView;
    WallpaperManager localWallpaperManager = WallpaperManager.getInstance(paramHome);
    this.wm = localWallpaperManager;
    AdaptersHolder localAdaptersHolder1 = new AdaptersHolder();
    this.adaptersHolder = localAdaptersHolder1;
    AdaptersHolder localAdaptersHolder2 = this.adaptersHolder;
    ProgramListAdapterAndroid2 localProgramListAdapterAndroid2 = new ProgramListAdapterAndroid2(localAdaptersHolder2);
    this.programListAdapter = localProgramListAdapterAndroid2;
    AdaptersHolder localAdaptersHolder3 = this.adaptersHolder;
    ApptListAdapterAndroid localApptListAdapterAndroid = new ApptListAdapterAndroid(localAdaptersHolder3);
    this.apptAdapter = localApptListAdapterAndroid;
    AdaptersHolder localAdaptersHolder4 = this.adaptersHolder;
    MessagingAdapterAndroid localMessagingAdapterAndroid = new MessagingAdapterAndroid(localAdaptersHolder4);
    this.messagingAdapter = localMessagingAdapterAndroid;
    AdaptersHolder localAdaptersHolder5 = this.adaptersHolder;
    ImageAdapterAndroid localImageAdapterAndroid = new ImageAdapterAndroid(localAdaptersHolder5);
    this.imageAdapter = localImageAdapterAndroid;
    AdaptersHolder localAdaptersHolder6 = this.adaptersHolder;
    GSensorAdapterAndroid localGSensorAdapterAndroid = new GSensorAdapterAndroid(localAdaptersHolder6);
    this.gSensorAdapter = localGSensorAdapterAndroid;
    AdaptersHolder localAdaptersHolder7 = this.adaptersHolder;
    ContactsAdapterAndroid localContactsAdapterAndroid = new ContactsAdapterAndroid(localAdaptersHolder7);
    this.contactsAdapter = localContactsAdapterAndroid;
    AdaptersHolder localAdaptersHolder8 = this.adaptersHolder;
    WeatherAdapterAndroid localWeatherAdapterAndroid = new WeatherAdapterAndroid(localAdaptersHolder8);
    this.weatherAdapter = localWeatherAdapterAndroid;
    AdaptersHolder localAdaptersHolder9 = this.adaptersHolder;
    ImageViewerAdapterAndroid localImageViewerAdapterAndroid = new ImageViewerAdapterAndroid(localAdaptersHolder9);
    this.imageViwerAdapter = localImageViewerAdapterAndroid;
    BacklightAdapterAndroidApi8 localBacklightAdapterAndroidApi8;
    if (Build.VERSION.SDK_INT > 8)
    {
      AdaptersHolder localAdaptersHolder10 = this.adaptersHolder;
      localBacklightAdapterAndroidApi8 = new BacklightAdapterAndroidApi8(localAdaptersHolder10);
    }
    BacklightAdapterAndroidApi7 localBacklightAdapterAndroidApi7;
    for (this.backlightAdapter = localBacklightAdapterAndroidApi8; ; this.backlightAdapter = localBacklightAdapterAndroidApi7)
    {
      AdaptersHolder localAdaptersHolder11 = this.adaptersHolder;
      SoundProfileAdapterAndroid localSoundProfileAdapterAndroid = new SoundProfileAdapterAndroid(localAdaptersHolder11);
      this.soundProfileAdapter = localSoundProfileAdapterAndroid;
      AdaptersHolder localAdaptersHolder12 = this.adaptersHolder;
      BatteryAdapterAndroid localBatteryAdapterAndroid = new BatteryAdapterAndroid(localAdaptersHolder12);
      this.batteryAdapter = localBatteryAdapterAndroid;
      AdaptersHolder localAdaptersHolder13 = this.adaptersHolder;
      TimeAdapterAndroid localTimeAdapterAndroid = new TimeAdapterAndroid(localAdaptersHolder13);
      this.timeAdapter = localTimeAdapterAndroid;
      AdaptersHolder localAdaptersHolder14 = this.adaptersHolder;
      AppAdapterAndroid localAppAdapterAndroid = new AppAdapterAndroid(localAdaptersHolder14);
      this.appAdapter = localAppAdapterAndroid;
      this.appAdapter.create(paramHome, this);
      AdaptersHolder localAdaptersHolder15 = this.adaptersHolder;
      OperatorAdapterAndroid localOperatorAdapterAndroid = new OperatorAdapterAndroid(localAdaptersHolder15);
      this.operatorAdapter = localOperatorAdapterAndroid;
      AdaptersHolder localAdaptersHolder16 = this.adaptersHolder;
      DialogBoxAdapterAndroid localDialogBoxAdapterAndroid = new DialogBoxAdapterAndroid(localAdaptersHolder16);
      this.dialogBoxAdapter = localDialogBoxAdapterAndroid;
      AdaptersHolder localAdaptersHolder17 = this.adaptersHolder;
      NewDialogAdapterAndroid localNewDialogAdapterAndroid = new NewDialogAdapterAndroid(localAdaptersHolder17);
      this.newDialogAdapter = localNewDialogAdapterAndroid;
      AdaptersHolder localAdaptersHolder18 = this.adaptersHolder;
      CitiesAdapterAndroid localCitiesAdapterAndroid = new CitiesAdapterAndroid(localAdaptersHolder18);
      this.citiesAdapter = localCitiesAdapterAndroid;
      AdaptersHolder localAdaptersHolder19 = this.adaptersHolder;
      SimpleMediaAdapterAndroid localSimpleMediaAdapterAndroid = new SimpleMediaAdapterAndroid(localAdaptersHolder19);
      this.simpleMediaAdapter = localSimpleMediaAdapterAndroid;
      AdaptersHolder localAdaptersHolder20 = this.adaptersHolder;
      ShortcutAdapterAndroid localShortcutAdapterAndroid = new ShortcutAdapterAndroid(localAdaptersHolder20);
      this.shortcutAdapter = localShortcutAdapterAndroid;
      AdaptersHolder localAdaptersHolder21 = this.adaptersHolder;
      NetworkAdapterAndroid localNetworkAdapterAndroid = new NetworkAdapterAndroid(localAdaptersHolder21);
      this.networkAdapter = localNetworkAdapterAndroid;
      AdaptersHolder localAdaptersHolder22 = this.adaptersHolder;
      WallpaperAdapterAndroid localWallpaperAdapterAndroid = new WallpaperAdapterAndroid(localAdaptersHolder22);
      this.wallpaperAdapter = localWallpaperAdapterAndroid;
      AdaptersHolder localAdaptersHolder23 = this.adaptersHolder;
      YandexAdapterAndroid localYandexAdapterAndroid = new YandexAdapterAndroid(localAdaptersHolder23);
      this.yandexSearchAdapter = localYandexAdapterAndroid;
      this.wallpaperAdapter.create(paramHome, this);
      this.messagingAdapter.create(paramHome, this);
      this.contactsAdapter.create(paramHome, this);
      this.contactsAdapter.start();
      this.networkAdapter.create(paramHome, this);
      this.shortcutAdapter.create(paramHome, this);
      this.weatherAdapter.create(paramHome, this);
      this.apptAdapter.create(paramHome, this);
      this.imageAdapter.create(paramHome, this);
      this.imageViwerAdapter.create(paramHome, this);
      this.citiesAdapter.create(paramHome, this);
      this.backlightAdapter.create(paramHome, this);
      this.backlightAdapter.start();
      this.dialogBoxAdapter.create(paramHome, this);
      this.dialogBoxAdapter.start();
      this.newDialogAdapter.create(paramHome, this);
      this.timeAdapter.create(paramHome, this);
      this.yandexSearchAdapter.create(paramHome, this);
      this.widgetController = paramWidgetController2;
      Vibrator localVibrator = (Vibrator)paramHome.getSystemService("vibrator");
      this.vibrator = localVibrator;
      return;
      AdaptersHolder localAdaptersHolder24 = this.adaptersHolder;
      localBacklightAdapterAndroidApi7 = new BacklightAdapterAndroidApi7(localAdaptersHolder24);
    }
  }

  private InputStream getAssetStream(String paramString)
  {
    Logger localLogger1 = logger;
    String str1 = ">>>NativeCallbacks.getAssetStream: '" + paramString + "'";
    localLogger1.d(str1);
    Object localObject;
    if (paramString != null)
    {
      paramString = paramString.toLowerCase();
      localObject = null;
    }
    try
    {
      InputStream localInputStream = this.context.getAssets().open(paramString);
      localObject = localInputStream;
      Logger localLogger2 = logger;
      String str2 = "<<<NativeCallbacks.getAssetStream: '" + paramString + "'";
      localLogger2.d(str2);
      while (true)
      {
        return localObject;
        localObject = null;
      }
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      while (true)
      {
        if (paramString.endsWith("index.xml"))
          continue;
        Logger localLogger3 = logger;
        String str3 = "file '" + paramString + "' does not exist: ";
        localLogger3.d(str3, localFileNotFoundException);
      }
    }
    catch (IOException localIOException)
    {
      while (true)
      {
        Logger localLogger4 = logger;
        String str4 = "file '" + paramString + "' could not be opened: ";
        localLogger4.d(str4, localIOException);
      }
    }
  }

  private int getIconByString(String paramString)
  {
    int i = -1;
    if (TextUtils.isEmpty(paramString));
    while (true)
    {
      return i;
      if (paramString.equals("Add"))
      {
        i = R.drawable.ic_menu_add;
        continue;
      }
      if (paramString.equals("AddFolder"))
      {
        i = R.drawable.ic_menu_add_folders;
        continue;
      }
      if (paramString.equals("RenamePanel"))
      {
        i = R.drawable.ic_menu_edit;
        continue;
      }
      if (paramString.equals("DebugTools"))
      {
        i = R.drawable.ic_menu_manage;
        continue;
      }
      if (paramString.equals("About"))
      {
        i = R.drawable.ic_menu_info_details;
        continue;
      }
      if (paramString.equals("Exit"))
      {
        i = R.drawable.ic_menu_close_clear_cancel;
        continue;
      }
      if (paramString.equals("WeatherChangeCity"))
      {
        i = R.drawable.ic_menu_change;
        continue;
      }
      if (paramString.equals("SettingsWnd"))
      {
        i = R.drawable.ic_menu_preferences;
        continue;
      }
      if (paramString.equals("Update"))
      {
        i = R.drawable.ic_menu_refresh;
        continue;
      }
      if (paramString.equals("ManagePanels"))
      {
        i = R.drawable.ic_shell_edit_panels;
        continue;
      }
      if (paramString.equals("Wallpaper"))
      {
        i = R.drawable.ic_menu_gallery;
        continue;
      }
      if (paramString.equals("Uninstall"))
      {
        i = R.drawable.ic_menu_clear_playlist;
        continue;
      }
      if (paramString.equals("FreeLayout"))
      {
        i = R.drawable.ic_menu_sort_by_size;
        continue;
      }
      if (!paramString.equals("ShellSettings"))
        continue;
      i = R.drawable.ic_shell_settings;
    }
  }

  public static String getMemoryInfo()
  {
    logger.d("getMemoryInfo() ");
    StringBuffer localStringBuffer1 = new StringBuffer();
    long l1 = Debug.getNativeHeapSize();
    String str1 = "nhs = " + l1;
    StringBuffer localStringBuffer2 = localStringBuffer1.append(str1);
    long l2 = Debug.getNativeHeapAllocatedSize();
    String str2 = "nas = " + l2;
    StringBuffer localStringBuffer3 = localStringBuffer1.append(str2);
    long l3 = Debug.getNativeHeapFreeSize();
    String str3 = "nfs = " + l3;
    StringBuffer localStringBuffer4 = localStringBuffer1.append(str3);
    return localStringBuffer1.toString();
  }

  public static long pack(long paramLong1, long paramLong2)
  {
    return paramLong1 << 32 | paramLong2;
  }

  public static void postToNative(Runnable paramRunnable)
  {
    NATIVE_EXECUTOR.execute(paramRunnable);
  }

  public static void printMemory()
  {
    logger.d("printMemory() ");
  }

  public void AddSMSListener(int paramInt)
  {
    this.messagingAdapter.addListener(paramInt);
  }

  public Bitmap CreateImage(String paramString)
  {
    Logger localLogger = logger;
    String str = "Bitmap CreateImage " + paramString;
    localLogger.d(str);
    BookmarksAdapter localBookmarksAdapter = BookmarksAdapter.instance();
    if ((paramString.startsWith("bookmark-image")) && (localBookmarksAdapter != null));
    for (Bitmap localBitmap = localBookmarksAdapter.getImage(paramString); ; localBitmap = this.imageAdapter.getByPath(paramString))
      return localBitmap;
  }

  public Bitmap CreateImage(ByteBuffer paramByteBuffer)
  {
    return this.imageAdapter.getByBuffer(paramByteBuffer);
  }

  public Bitmap CreateImage(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2)
  {
    return this.imageAdapter.getByBuffer(paramByteBuffer, paramInt1, paramInt2);
  }

  public void DeinitWeatherAdapter()
  {
    try
    {
      getWeatherAdapter().stop();
      return;
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
  }

  void EnableGSensor(boolean paramBoolean)
  {
    this.gSensorAdapter.EnableGSensor(paramBoolean);
  }

  public String GetAMPM(long paramLong)
  {
    return this.timeAdapter.getAMPMString(paramLong);
  }

  public int GetAndroidVersion()
  {
    return this.appAdapter.GetAndroidVersion();
  }

  public void GetContact(int paramInt)
  {
    getContactsAdapter().reloadContact(paramInt);
  }

  public int GetContactByPhone(String paramString)
  {
    return getContactsAdapter().getContactByPhone(paramString);
  }

  public Bitmap GetContactPic(String paramString)
  {
    Object localObject = null;
    try
    {
      Bitmap localBitmap = getContactsAdapter().getContactPic(0, paramString);
      localObject = localBitmap;
      return localObject;
    }
    catch (Exception localException)
    {
      while (true)
      {
        Logger localLogger = logger;
        String str = "GetContactPic failed:" + localException;
        localLogger.e(str);
      }
    }
  }

  public int GetCount()
  {
    logger.d("GetCount()");
    return this.messagingAdapter.getCount();
  }

  public String GetDeviceId()
  {
    return this.appAdapter.getDeviceId();
  }

  public String GetDeviceModel()
  {
    return this.appAdapter.getDeviceModel();
  }

  public String GetKey()
  {
    return this.appAdapter.getKey();
  }

  public int GetLastMessageByContact(int paramInt)
  {
    return this.messagingAdapter.getLastMessage(paramInt);
  }

  public void GetMessage(int paramInt, long paramLong)
  {
    Logger localLogger = logger;
    Object[] arrayOfObject = new Object[1];
    Integer localInteger = Integer.valueOf(paramInt);
    arrayOfObject[0] = localInteger;
    String str = String.format("%08x", arrayOfObject);
    localLogger.d(str);
    this.messagingAdapter.getMessageById(paramInt, paramLong);
  }

  int GetPanelCount()
  {
    return 1;
  }

  public String GetStorageCard()
  {
    return Environment.getExternalStorageDirectory().getAbsolutePath();
  }

  public int GetUnreadCount()
  {
    logger.d("GetUnreadCount()");
    return this.messagingAdapter.getUnreadCount();
  }

  public void GetVersionInfo(int paramInt)
  {
    this.appAdapter.getVersionInfo(paramInt);
  }

  public void GetWidgets(int paramInt)
  {
    try
    {
      logger.d("GetWidgets!!");
      this.context.setWidgetToken(paramInt);
      this.context.restoreWidgetsInNative();
      return;
    }
    catch (Throwable localThrowable)
    {
      while (true)
        localThrowable.printStackTrace();
    }
  }

  public void HideWidgets()
  {
    this.widgetController.hideWidgets();
  }

  public void InitWeatherAdapter(int paramInt)
  {
    getWeatherAdapter().start(paramInt);
  }

  public void LoadCityInfo(int paramInt)
  {
    this.citiesAdapter.loadCityInfo(paramInt);
  }

  public void MakeCall(String paramString, boolean paramBoolean)
  {
    getContactsAdapter().call(paramString, paramBoolean);
  }

  ShellDatePickerDialog NewDatePickerDialog(int paramInt)
  {
    return this.newDialogAdapter.newShellDatePickerDialog(paramInt);
  }

  ShellDialog NewShellDialog(int paramInt)
  {
    return this.newDialogAdapter.newShellDialog(paramInt);
  }

  public void OnInboxFolderCreated(String paramString, int paramInt)
  {
    this.messagingAdapter.onInboxFolderCreated(paramString, paramInt);
  }

  public void OpenContactCard(int paramInt, String paramString)
  {
    getContactsAdapter().openContactCard(paramInt, paramString);
  }

  public void OpenSelectCity(int paramInt)
  {
    getWeatherAdapter().openCitySelect(paramInt);
  }

  public void PostRestart()
  {
    this.context.restartShell();
  }

  public void ReadApptList(int paramInt, long paramLong1, long paramLong2)
  {
    ApptListAdapter localApptListAdapter = this.apptAdapter;
    int i = paramInt;
    long l1 = paramLong1;
    long l2 = paramLong2;
    localApptListAdapter.getApptList(i, l1, l2);
  }

  public long[] ReadMessages(int paramInt)
  {
    logger.d("ReadMessages()");
    return this.messagingAdapter.getMessageList(paramInt);
  }

  public void ReloadBirthdays(int paramInt)
  {
    getContactsAdapter().reloadBirthdays(paramInt);
  }

  public void ReloadContacts(int paramInt)
  {
    getContactsAdapter().reloadContacts(paramInt);
  }

  public void RemoveSMSListener(int paramInt)
  {
    this.messagingAdapter.removeListener(paramInt);
  }

  public boolean SaveCompressed(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, int paramInt3, String paramString)
  {
    ImageAdapter localImageAdapter = this.imageAdapter;
    ByteBuffer localByteBuffer = paramByteBuffer;
    int i = paramInt1;
    int j = paramInt2;
    int k = paramInt3;
    String str = paramString;
    return localImageAdapter.SaveCompressed(localByteBuffer, i, j, k, str);
  }

  public long SelectCityForCTA()
  {
    return this.citiesAdapter.openCitySelect();
  }

  public void SendEmail(String paramString1, String paramString2)
  {
    Logger localLogger = logger;
    String str = "SendEmail: displayName=" + paramString1 + " email=" + paramString2;
    localLogger.d(str);
    Uri localUri = Uri.fromParts("mailto", paramString2, null);
    Intent localIntent = new Intent("android.intent.action.SENDTO", localUri);
    this.context.startActivity(localIntent);
  }

  public void SendSMS(String paramString1, String paramString2)
  {
    Logger localLogger = logger;
    String str = "SendSMS: displayName=" + paramString1 + " phoneNumber=" + paramString2;
    localLogger.d(str);
    Uri localUri = Uri.fromParts("smsto", paramString2, null);
    Intent localIntent = new Intent("android.intent.action.SENDTO", localUri);
    this.context.startActivity(localIntent);
  }

  public void SetWeatherUpdateRate(int paramInt)
  {
    getWeatherAdapter().setUpdateRate(paramInt);
  }

  public void SetWeatherUseOnlyWifi(boolean paramBoolean)
  {
    getWeatherAdapter().setUseOnlyWifi(paramBoolean);
  }

  public boolean ShowWidget(int paramInt1, int paramInt2, int paramInt3)
  {
    int i = 0;
    try
    {
      if (this.isLoadStarted)
      {
        Set localSet = this.delayedWidgets;
        int[] arrayOfInt = new int[3];
        arrayOfInt[0] = paramInt1;
        arrayOfInt[1] = paramInt2;
        arrayOfInt[2] = paramInt3;
        boolean bool1 = localSet.add(arrayOfInt);
      }
      while (true)
      {
        return i;
        Logger localLogger = logger;
        String str = "ShowWidget " + paramInt1;
        localLogger.d(str);
        boolean bool2 = this.widgetController.showWidget(paramInt1, paramInt2, paramInt3);
        i = bool2;
      }
    }
    catch (Throwable localThrowable)
    {
      while (true)
        localThrowable.printStackTrace();
    }
  }

  public int SoundProfileGetRingMode()
  {
    return this.soundProfileAdapter.getRingMode();
  }

  public int SoundProfileGetRingVolume()
  {
    return this.soundProfileAdapter.getRingVolume();
  }

  public void SoundProfileNotifyChange()
  {
    this.soundProfileAdapter.notifyChange();
  }

  public void SoundProfileOpenSettings()
  {
    this.soundProfileAdapter.openSettings();
  }

  public void SoundProfileSetRingMode(int paramInt)
  {
    this.soundProfileAdapter.setRingMode(paramInt);
  }

  /** @deprecated */
  public void Start()
  {
    monitorenter;
    try
    {
      logger.d("Start");
      logger.d("Init");
      onShow();
      nativeInit(this);
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void StartCitiesAdapter(int paramInt)
  {
    this.citiesAdapter.start(paramInt);
  }

  public void StartListeningCurrentLocationForCTA()
  {
    this.citiesAdapter.startListeningCurrentLocation();
  }

  public void StartMessagingAdapter(int paramInt)
  {
    this.messagingAdapter.start(paramInt);
  }

  void StartNewDialogAdapter(int paramInt)
  {
    this.newDialogAdapter.start(paramInt);
  }

  public void StartTimeAdapter(int paramInt)
  {
    this.timeAdapter.start(paramInt);
  }

  public void Stop()
  {
    logger.d("Stop");
    onHide();
    monitorenter;
    try
    {
      nativeDone(this);
      monitorexit;
      AdaptersHolder localAdaptersHolder = this.adaptersHolder;
      Home localHome = this.context;
      localAdaptersHolder.closeHeldAdapters(localHome);
      logger.d("<<Stop");
      return;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public void StopCitiesAdapter()
  {
    this.citiesAdapter.stop();
  }

  public void StopListeningCurrentLocationForCTA()
  {
    this.citiesAdapter.stopListeningCurrentLocation();
  }

  public void UpdateCurrentLocation()
  {
    this.citiesAdapter.updateCurrentLocation();
  }

  public void WaitForShowWidgets()
  {
    if (this.isLoadStarted);
    while (true)
    {
      return;
      this.widgetController.waitForShowWidgets();
    }
  }

  public void addMenuItem(int paramInt, String paramString1, String paramString2)
  {
    Logger localLogger = logger;
    String str = "addMenuItem, id=" + paramInt + ", title=" + paramString1 + ", icon=" + paramString2;
    localLogger.d(str);
    synchronized (this.menuItems)
    {
      List localList2 = this.menuItems;
      NativeMenuItem localNativeMenuItem = new NativeMenuItem(paramString1, paramString2);
      boolean bool = localList2.add(localNativeMenuItem);
      return;
    }
  }

  public boolean addToFavorites(int paramInt)
  {
    return getContactsAdapter().addToFavorites(paramInt);
  }

  public void askEvents()
  {
    if (this.gSensorAdapter.isPresent())
      this.gSensorAdapter.askEvents();
  }

  public boolean canChangeInterfaceMode()
  {
    return this.appAdapter.canChangeInterfaceMode();
  }

  public boolean changeWidgetSize(int paramInt1, int paramInt2, int paramInt3)
  {
    try
    {
      boolean bool1 = this.widgetController.changeWidgetSize(paramInt1, paramInt2, paramInt3);
      bool2 = bool1;
      return bool2;
    }
    catch (Throwable localThrowable)
    {
      while (true)
      {
        localThrowable.printStackTrace();
        boolean bool2 = false;
      }
    }
  }

  public void checkWallpaperChange()
  {
    this.wallpaperAdapter.checkWallpaperChange();
  }

  public AlarmsAdapter createAlarmsAdapter(int paramInt)
  {
    Home localHome1;
    if (Build.VERSION.SDK_INT >= 8)
      localHome1 = this.context;
    Home localHome2;
    for (Object localObject = new AlarmsAdapterAndroid2(paramInt, localHome1); ; localObject = new AlarmsAdapterAndroid(paramInt, localHome2))
    {
      return localObject;
      localHome2 = this.context;
    }
  }

  public BookmarksAdapter createBookmarksAdapter(int paramInt)
  {
    Home localHome = this.context;
    return new BookmarksAdapterAndroid(paramInt, localHome);
  }

  public CallLogAdapter createCallLogAdapter(int paramInt)
  {
    Home localHome = this.context;
    return new CallLogAdapterAndroid(paramInt, localHome, this);
  }

  public MediaLibAdapter createMediaLibAdapter(int paramInt)
  {
    Home localHome = this.context;
    return new MediaLibAdapterAndroid(paramInt, localHome);
  }

  public WirelessAdapter createWirelessAdapter(int paramInt)
  {
    Home localHome = this.context;
    return new WirelessAdapterAndroid(paramInt, localHome);
  }

  public boolean deinitSimpleMediaAdapter()
  {
    logger.d("NativeCallbacks.deinitSimpleMediaAdapter");
    this.simpleMediaAdapter.stop();
    return true;
  }

  public void disposeContactsAdapter()
  {
    getContactsAdapter().disposeContactsAdapter();
  }

  public void doCloseLoadingDialog()
  {
    this.widgetController.hideWidgets();
    Iterator localIterator = this.delayedWidgets.iterator();
    while (localIterator.hasNext())
    {
      int[] arrayOfInt = (int[])localIterator.next();
      WidgetController2 localWidgetController2 = this.widgetController;
      int i = arrayOfInt[0];
      int j = arrayOfInt[1];
      int k = arrayOfInt[2];
      boolean bool = localWidgetController2.showWidget(i, j, k);
    }
    this.delayedWidgets.clear();
    this.widgetController.waitForShowWidgets();
    try
    {
      this.context.closeLoadingDialog();
      return;
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
  }

  public void doShowLoadingDialog()
  {
    Home localHome = this.context;
    NativeCallbacks.1 local1 = new NativeCallbacks.1(this);
    localHome.runOnUiThread(local1);
  }

  public void emptyMenu()
  {
    synchronized (this.menuItems)
    {
      this.menuItems.clear();
      return;
    }
  }

  public void enableHTCStereo3D(boolean paramBoolean)
  {
    this.appAdapter.enableHTCStereo3D(paramBoolean);
  }

  public void exit()
  {
    logger.d(">>Exit");
    if (!DebugUtil.isMonkey())
    {
      Home localHome = this.context;
      NativeCallbacks.5 local5 = new NativeCallbacks.5(this);
      localHome.runOnUiThread(local5);
    }
    while (true)
    {
      logger.d("<<Exit");
      return;
      logger.d("NativeCallbacks.exit ignored - user is a monkey");
    }
  }

  public boolean fillMenu(Menu paramMenu)
  {
    for (int i = 0; ; i = 1)
    {
      synchronized (this.menuItems)
      {
        if (this.menuItems.size() == 0)
          return i;
        Iterator localIterator = this.menuItems.iterator();
        while (localIterator.hasNext())
        {
          NativeMenuItem localNativeMenuItem = (NativeMenuItem)localIterator.next();
          int j = localNativeMenuItem.id;
          String str1 = localNativeMenuItem.str;
          MenuItem localMenuItem1 = paramMenu.add(0, j, 0, str1);
          String str2 = localNativeMenuItem.icon;
          int k = getIconByString(str2);
          if (k == -1)
            continue;
          MenuItem localMenuItem2 = localMenuItem1.setIcon(k);
        }
      }
      monitorexit;
    }
  }

  public void findByTag(String paramString)
  {
    Logger localLogger = logger;
    String str = "NativeCallbacks.findByTag: tag=" + paramString;
    localLogger.d(str);
    this.programListAdapter.findByTag(paramString);
  }

  public void forceUpdateWeather(int paramInt)
  {
    getWeatherAdapter().forceUpdate(paramInt);
  }

  public String formatDateTime(long paramLong, int paramInt)
  {
    try
    {
      String str1 = this.timeAdapter.format(paramLong, paramInt);
      str2 = str1;
      return str2;
    }
    catch (Exception localException)
    {
      while (true)
      {
        localException.printStackTrace();
        String str2 = "Fail";
      }
    }
  }

  public byte[] getAsset(String paramString)
  {
    Logger localLogger1 = logger;
    String str1 = "getAsset, path:'" + paramString + "'";
    localLogger1.d(str1);
    byte[] arrayOfByte = null;
    try
    {
      localInputStream = getAssetStream(paramString);
      if (localInputStream != null)
      {
        Logger localLogger2 = logger;
        String str2 = "Reading asset: '" + paramString + "'";
        localLogger2.d(str2);
        arrayOfByte = new byte[localInputStream.available()];
        int i = localInputStream.read(arrayOfByte);
      }
      while (true)
      {
        return arrayOfByte;
        Logger localLogger3 = logger;
        String str3 = "Asset not found: " + paramString;
        localLogger3.d(str3);
      }
    }
    catch (IOException localIOException)
    {
      while (true)
      {
        logger.e("Error occured while getting asset: ", localIOException);
        IOHelper.closeSilent(localInputStream);
      }
    }
    finally
    {
      InputStream localInputStream;
      IOHelper.closeSilent(localInputStream);
    }
    throw localObject;
  }

  public int getAssetSize(String paramString)
  {
    int i = 0;
    try
    {
      localInputStream = getAssetStream(paramString);
      if (localInputStream != null)
      {
        int j = localInputStream.available();
        i = j;
      }
      return i;
    }
    catch (IOException localIOException)
    {
      while (true)
      {
        Logger localLogger = logger;
        String str = "cannot get '" + paramString + "' asset size:";
        localLogger.d(str, localIOException);
        IOHelper.closeSilent(localInputStream);
      }
    }
    finally
    {
      InputStream localInputStream;
      IOHelper.closeSilent(localInputStream);
    }
    throw localObject;
  }

  public int getBacklightLevel()
  {
    logger.d("NativeCallbacks.getBacklightLevel");
    return this.backlightAdapter.getLevel();
  }

  public int getBacklightMaxLevelsCount()
  {
    logger.d("NativeCallbacks.getBacklightMaxLevelsCount");
    return this.backlightAdapter.getMaxLevelsCount();
  }

  public Bitmap getBitmapFromResourceDrawable(String paramString)
  {
    return this.imageAdapter.getByPath(paramString);
  }

  public String getCacheDir()
  {
    return this.context.getCacheDir().getPath();
  }

  public CitiesAdapter getCitiesAdapter()
  {
    return this.citiesAdapter;
  }

  public ContactsAdapter getContactsAdapter()
  {
    return this.contactsAdapter;
  }

  public String getCountryISOCode()
  {
    String str1 = Locale.getDefault().getCountry();
    Logger localLogger = logger;
    String str2 = "getCountryISOCode: lang=" + str1;
    localLogger.d(str2);
    return str1;
  }

  public long getCurrentTimeUTC()
  {
    long l1 = System.currentTimeMillis();
    long l2 = TimeZone.getDefault().getOffset(l1);
    return l1 - l2;
  }

  public String getDataDir()
  {
    return this.context.getApplicationInfo().dataDir;
  }

  public DialogBoxAdapter getDialogBoxAdapter()
  {
    return this.dialogBoxAdapter;
  }

  public int getFirstDayOfWeek()
  {
    return this.timeAdapter.getFirstDayOfWeek();
  }

  public void getFolderIds(int paramInt)
  {
    Logger localLogger = logger;
    String str = "NativeCallbacks.getFolderIds: " + paramInt;
    localLogger.d(str);
    this.imageViwerAdapter.getFolderIds(paramInt);
  }

  public Bitmap getImage(String paramString)
  {
    Logger localLogger = logger;
    String str = "NativeCallbacks.getImage: imageUri=" + paramString;
    localLogger.d(str);
    BookmarksAdapter localBookmarksAdapter = BookmarksAdapter.instance();
    Bitmap localBitmap;
    if (paramString.startsWith("content://"))
      localBitmap = this.imageAdapter.getByPath(paramString);
    while (true)
    {
      return localBitmap;
      if ((paramString.startsWith("bookmark-image")) && (localBookmarksAdapter != null))
      {
        localBitmap = localBookmarksAdapter.getImage(paramString);
        continue;
      }
      localBitmap = this.imageViwerAdapter.getImage(paramString);
    }
  }

  public ImageAdapter getImageAdapter()
  {
    return this.imageAdapter;
  }

  public void getImageList(int paramInt, String paramString)
  {
    Logger localLogger = logger;
    String str = "NativeCallbacks.getImageList: " + paramInt + ", " + paramString;
    localLogger.d(str);
    this.imageViwerAdapter.getImageList(paramInt, paramString);
  }

  public String getLanguageISOCode()
  {
    String str1 = Locale.getDefault().getLanguage();
    Logger localLogger = logger;
    String str2 = "getLanguageISOCode: lang=" + str1;
    localLogger.d(str2);
    return str1;
  }

  void getLock()
  {
    this.widgetController.getLock();
  }

  public NewDialogAdapter getNewDialogAdapter()
  {
    return this.newDialogAdapter;
  }

  public ProgramListAdapter getProgramListAdapter()
  {
    logger.d("ProgramListAdapter getProgramListAdapter()");
    return this.programListAdapter;
  }

  public boolean getScreenMode()
  {
    return PreferenceManager.getDefaultSharedPreferences(this.context).getBoolean("_key_screen_format", 0);
  }

  public ShortcutAdapter getShortcutAdapter()
  {
    return this.shortcutAdapter;
  }

  public SimpleMediaAdapter getSimpleMediaAdapter()
  {
    return this.simpleMediaAdapter;
  }

  public String getSourceDir()
  {
    return this.context.getApplicationInfo().sourceDir;
  }

  public int getSystemDpi()
  {
    DisplayMetrics localDisplayMetrics = new DisplayMetrics();
    this.context.getWindowManager().getDefaultDisplay().getMetrics(localDisplayMetrics);
    return (int)(localDisplayMetrics.density * 160.0F);
  }

  public boolean getUseLiveWallpaperPreference()
  {
    return isLiveWallpaper();
  }

  public Bitmap getWallpaper()
  {
    return this.wallpaperAdapter.getWallpaper();
  }

  public String getWallpaperSkin()
  {
    return this.wallpaperAdapter.getWallpaperSkin();
  }

  public WeatherAdapter getWeatherAdapter()
  {
    return this.weatherAdapter;
  }

  public Bitmap getWidgetIcon(int paramInt)
  {
    Uri localUri = this.context.getIconUri(paramInt);
    Object localObject;
    if (localUri == null)
    {
      Resources localResources1 = this.context.getResources();
      int i = R.drawable.icon;
      localObject = BitmapFactory.decodeResource(localResources1, i);
    }
    while (true)
    {
      return localObject;
      try
      {
        ImageAdapter localImageAdapter = this.imageAdapter;
        String str = localUri.toString();
        Bitmap localBitmap = localImageAdapter.getByPath(str);
        localObject = localBitmap;
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
        Resources localResources2 = this.context.getResources();
        int j = R.drawable.icon;
        localObject = BitmapFactory.decodeResource(localResources2, j);
      }
    }
  }

  public String getWidgetName(int paramInt)
  {
    return this.context.getWidgetName(paramInt);
  }

  public Bitmap getWidgetScreenshot(int paramInt)
  {
    Object localObject = null;
    try
    {
      Bitmap localBitmap = this.widgetController.getWidgetScreenShot(paramInt);
      localObject = localBitmap;
      label13: return localObject;
    }
    catch (Throwable localThrowable)
    {
      break label13;
    }
  }

  public YandexSearchAdapter getYandexSearchAdapter()
  {
    return this.yandexSearchAdapter;
  }

  public boolean hasKeyboard()
  {
    return this.appAdapter.hasKeyboard();
  }

  public boolean hasMenuKey()
  {
    int i = 0;
    DisplayMetrics localDisplayMetrics = this.context.getResources().getDisplayMetrics();
    float f1 = localDisplayMetrics.widthPixels;
    float f2 = localDisplayMetrics.density;
    float f3 = 600.0F * f2;
    int j;
    if (f1 >= f3)
    {
      j = 1;
      if ((j == 0) || (Build.VERSION.SDK_INT < 14))
        break label64;
    }
    while (true)
    {
      return i;
      j = 0;
      break;
      label64: if ((Build.VERSION.SDK_INT >= 11) && (Build.VERSION.SDK_INT < 14))
        continue;
      i = 1;
    }
  }

  public boolean hasTelephony()
  {
    return this.appAdapter.hasTelephony();
  }

  public void hideMenu()
  {
    Home localHome = this.context;
    NativeCallbacks.3 local3 = new NativeCallbacks.3(this);
    localHome.runOnUiThread(local3);
  }

  public void init()
  {
    logger.d(">>>NativeCallbacks.init");
    logger.d("NativeCallbacks.init1");
    ProgramListAdapter localProgramListAdapter = this.programListAdapter;
    Home localHome1 = this.context;
    localProgramListAdapter.create(localHome1, this);
    this.programListAdapter.start();
    logger.d("NativeCallbacks.init2");
    logger.d("NativeCallbacks.init3");
    logger.d("NativeCallbacks.init4");
    logger.d("NativeCallbacks.init5");
    SoundProfileAdapter localSoundProfileAdapter = this.soundProfileAdapter;
    Home localHome2 = this.context;
    localSoundProfileAdapter.create(localHome2, this);
    logger.d("NativeCallbacks.init6");
    SimpleMediaAdapter localSimpleMediaAdapter = this.simpleMediaAdapter;
    Home localHome3 = this.context;
    localSimpleMediaAdapter.create(localHome3, this);
    logger.d("NativeCallbacks.init7");
    logger.d("NativeCallbacks.init8");
    BatteryAdapter localBatteryAdapter = this.batteryAdapter;
    Home localHome4 = this.context;
    localBatteryAdapter.create(localHome4, this);
    OperatorAdapter localOperatorAdapter = this.operatorAdapter;
    Home localHome5 = this.context;
    localOperatorAdapter.create(localHome5, this);
    logger.d("<<<NativeCallbacks.init");
  }

  public void initContactsAdapter(int paramInt)
  {
    getContactsAdapter().initContactsAdapter(paramInt);
  }

  public boolean initSimpleMediaAdapter(int paramInt)
  {
    logger.d(">>>NativeCallbacks.initSimpleMediaAdapter");
    this.simpleMediaAdapter.start(paramInt);
    logger.d("<<<NativeCallbacks.initSimpleMediaAdapter");
    return true;
  }

  public boolean isBacklightAutoSupported()
  {
    logger.d("NativeCallbacks.isBacklightAutoBupported");
    return this.backlightAdapter.isAutolevelSupported();
  }

  public boolean isBacklightSupported()
  {
    logger.d("NativeCallbacks.isBacklightBupported");
    return this.backlightAdapter.isSupported();
  }

  public boolean isLiveWallpaper()
  {
    return this.wallpaperAdapter.isLiveWallpaper();
  }

  public boolean isLoadStarted()
  {
    return this.isLoadStarted;
  }

  public boolean isMenuEmpty()
  {
    synchronized (this.menuItems)
    {
      boolean bool = this.menuItems.isEmpty();
      return bool;
    }
  }

  public boolean isMipmapEnabled()
  {
    return this.appAdapter.isMipmapEnabled();
  }

  public boolean isVoiceSearchAvailable()
  {
    return this.yandexSearchAdapter.isVoiceSearchAvailable();
  }

  public boolean isYandexCountry()
  {
    return this.yandexSearchAdapter.isYandexCountry();
  }

  public void kill()
  {
    Process.killProcess(Process.myPid());
  }

  public void killCalendar()
  {
    logger.d("ApptListAdapter.killCalendar");
    Home localHome = this.context;
    Intent localIntent = new Intent(localHome, KillCalendarService.class);
    ComponentName localComponentName = this.context.startService(localIntent);
  }

  public void killContacts()
  {
    Home localHome = this.context;
    Intent localIntent = new Intent(localHome, KillContactsService.class);
    ComponentName localComponentName = this.context.startService(localIntent);
  }

  public boolean launch(String paramString)
  {
    Logger localLogger = logger;
    String str = "NativeCallbacks.launch: tag=" + paramString;
    localLogger.d(str);
    return this.programListAdapter.launch(paramString);
  }

  public boolean launch(String paramString1, String paramString2)
  {
    Logger localLogger = logger;
    String str = "NativeCallbacks.launch: packageName=" + paramString1 + " activityClassName=" + paramString2;
    localLogger.d(str);
    return this.programListAdapter.launch(paramString1, paramString2);
  }

  public void launchShortcut(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    ShortcutAdapter localShortcutAdapter = this.shortcutAdapter;
    int i = paramInt1;
    int j = paramInt2;
    int k = paramInt3;
    int m = paramInt4;
    int n = paramInt5;
    localShortcutAdapter.launch(i, j, k, m, n);
  }

  public void listShortcuts(int paramInt)
  {
    this.shortcutAdapter.start(paramInt);
  }

  public void loadCityName(int paramInt)
  {
    getWeatherAdapter().loadCityName(paramInt);
  }

  public void loadConditions(int paramInt)
  {
    getWeatherAdapter().loadConditions(paramInt);
  }

  public void loadForecast(int paramInt)
  {
    getWeatherAdapter().loadForecast(paramInt);
  }

  public void loadUpdateTime(int paramInt)
  {
    getWeatherAdapter().loadUpdateStatus(paramInt);
  }

  public void moveBackground(float paramFloat)
  {
    WallpaperManager localWallpaperManager = this.wm;
    IBinder localIBinder = this.view.getWindowToken();
    localWallpaperManager.setWallpaperOffsets(localIBinder, paramFloat, 0.0F);
  }

  public void notifyListener(int paramInt)
  {
  }

  public void onHide()
  {
    this.gSensorAdapter.stop();
  }

  public void onHomeLoadStarted()
  {
    this.isLoadStarted = 1;
  }

  public void onHomeLoaded()
  {
    Logger localLogger = logger;
    StringBuilder localStringBuilder = new StringBuilder().append("onHomeLoaded() ");
    boolean bool = this.isLoadStarted;
    String str = bool;
    localLogger.d(str);
    try
    {
      this.isLoadStarted = 0;
      ShellApplication localShellApplication = this.application;
      Home localHome = this.context;
      localShellApplication.startLicensingProcess(localHome);
      return;
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
  }

  public int onIdle()
  {
    int i = this.widgetController.onIdle();
    Logger localLogger = logger;
    String str = "widgetS onIdle = " + i;
    localLogger.d(str);
    return i;
  }

  public void onPositionChanged(int paramInt)
  {
  }

  public void onShow()
  {
    try
    {
      GSensorAdapter localGSensorAdapter = this.gSensorAdapter;
      Home localHome = this.context;
      localGSensorAdapter.create(localHome, this);
      this.gSensorAdapter.start();
      return;
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
  }

  public void onUnhandledTouch(int paramInt1, int paramInt2)
  {
    Home localHome = this.context;
    NativeCallbacks.8 local8 = new NativeCallbacks.8(this, paramInt1, paramInt2);
    localHome.runOnUiThread(local8);
  }

  public void onWeatherProviderDeleted(int paramInt)
  {
    getWeatherAdapter().onWeatherProviderDeleted(paramInt);
  }

  public void openAppt(long paramLong1, long paramLong2, long paramLong3)
  {
    ApptListAdapter localApptListAdapter = this.apptAdapter;
    long l1 = paramLong1;
    long l2 = paramLong2;
    long l3 = paramLong3;
    localApptListAdapter.openAppt(l1, l2, l3);
  }

  public void openBrowser(String paramString)
  {
    this.networkAdapter.openBrowser(paramString);
  }

  public void openCalendar(long paramLong)
  {
    logger.d("NativeCallbacks.openCalendar");
    this.apptAdapter.openCalendar(paramLong);
  }

  public boolean openCreateApptDialog(long paramLong)
  {
    logger.d("NativeCallbacks.openCreateApptDialog");
    return this.apptAdapter.openCreateApptDialog(paramLong);
  }

  public void openImage(String paramString)
  {
    Logger localLogger = logger;
    String str = "NativeCallbacks.openImage: " + paramString;
    localLogger.d(str);
    this.imageViwerAdapter.openImage(paramString);
  }

  public void openMessageThread(long paramLong)
  {
    this.messagingAdapter.openMessageThread(paramLong);
  }

  public void openSetWallpaperDialog()
  {
    Home localHome = this.context;
    NativeCallbacks.6 local6 = new NativeCallbacks.6(this);
    localHome.runOnUiThread(local6);
  }

  public void openSmsMmsActivity()
  {
    this.messagingAdapter.openSmsMmsActivity();
  }

  public int prepareNewWidget(String paramString)
  {
    try
    {
      StringTokenizer localStringTokenizer = new StringTokenizer(paramString, "/");
      String str1 = localStringTokenizer.nextToken();
      String str2 = localStringTokenizer.nextToken();
      int i = this.context.launcherWidgetInit(str1, str2);
      j = i;
      return j;
    }
    catch (Throwable localThrowable)
    {
      while (true)
        int j = -1;
    }
  }

  void releaseLock()
  {
    this.widgetController.releaseLock();
  }

  public void reloadWallpaper()
  {
    this.wallpaperAdapter.reloadWallpaper();
  }

  public boolean removeFromFavorites(int paramInt)
  {
    return getContactsAdapter().removeFromFavorites(paramInt);
  }

  public void removeShortcut(int paramInt)
  {
    this.shortcutAdapter.remove(paramInt);
  }

  public void selectCity(int paramInt1, int paramInt2)
  {
    Logger localLogger = logger;
    StringBuilder localStringBuilder = new StringBuilder().append("selectCity: weatherProviderToken=0x");
    String str1 = Integer.toHexString(paramInt1);
    String str2 = str1 + " cityId=" + paramInt2;
    localLogger.d(str2);
    getWeatherAdapter().selectCity(paramInt1, paramInt2);
  }

  public void setBacklightLevel(int paramInt)
  {
    Logger localLogger = logger;
    String str = "NativeCallbacks.setBacklightLevel, level=" + paramInt;
    localLogger.d(str);
    this.backlightAdapter.setLevel(paramInt);
  }

  public void setGlRenderer(String paramString)
  {
  }

  public void setOrientation(int paramInt)
  {
    this.appAdapter.setOrientation(paramInt);
  }

  public void setUseLiveWallpaperPreference(boolean paramBoolean)
  {
    WallpaperAdapter.setUseLiveWallpapers(this.context, paramBoolean);
    if (WallpaperAdapter.isLiveWallpaper(this.context))
      this.context.restartShell();
  }

  public void setWallpaperFromFile(String paramString)
  {
    try
    {
      this.wallpaperAdapter.setWallpaperFromFile(paramString);
      return;
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
  }

  public void showAddToFavoritesDialog()
  {
    getContactsAdapter().showAddToFavoritesDialog();
  }

  public boolean showContactPicker(int paramInt)
  {
    getContactsAdapter().showPickContactDialog(paramInt);
    return true;
  }

  public void showLegalNoticeDialog()
  {
    Home localHome = this.context;
    NativeCallbacks.7 local7 = new NativeCallbacks.7(this);
    localHome.runOnUiThread(local7);
  }

  public void showMenu(int paramInt1, int paramInt2)
  {
    PrintStream localPrintStream = System.out;
    String str = "showMenu " + paramInt1 + " " + paramInt2;
    localPrintStream.println(str);
    Home localHome = this.context;
    NativeCallbacks.2 local2 = new NativeCallbacks.2(this, paramInt1, paramInt2);
    localHome.runOnUiThread(local2);
  }

  public void showMessage(String paramString1, String paramString2)
  {
    Home localHome = this.context;
    NativeCallbacks.4 local4 = new NativeCallbacks.4(this, paramString2, paramString1);
    localHome.runOnUiThread(local4);
  }

  void showPopupMessage(String paramString)
  {
    this.newDialogAdapter.showPopupMessage(paramString);
  }

  public void startSystemSearch()
  {
    this.context.startSearch(null, 0, null, 1);
  }

  public void startVoiceSearch()
  {
    this.yandexSearchAdapter.startVoiceSearch();
  }

  public void startYandexSearch(int paramInt)
  {
    this.yandexSearchAdapter.startSearch(paramInt);
  }

  public void switchScreen()
  {
    int i = 0;
    SharedPreferences localSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.context);
    int j;
    if (!localSharedPreferences.getBoolean("_key_screen_format", i))
      j = 1;
    if (j != 0);
    for (String str = "8888"; ; str = "default")
    {
      Home localHome = this.context;
      NativeCallbacks.9 local9 = new NativeCallbacks.9(this, str);
      localHome.runOnUiThread(local9);
      boolean bool1 = localSharedPreferences.edit().putBoolean("_key_screen_format", j).commit();
      WidgetController2 localWidgetController2 = this.widgetController;
      NativeCallbacks.10 local10 = new NativeCallbacks.10(this);
      boolean bool2 = localWidgetController2.postDelayed(local10, 5000L);
      return;
    }
  }

  public void uninstall(String paramString)
  {
    Logger localLogger = logger;
    String str = "uninstall package: " + paramString;
    localLogger.i(str);
    this.programListAdapter.uninstall(paramString);
  }

  public boolean uninstallProgram(String paramString)
  {
    Logger localLogger = logger;
    String str = "NativeCallbacks.uninstallProgram: packageName=" + paramString;
    localLogger.d(str);
    this.programListAdapter.uninstall(paramString);
    return true;
  }

  public void vibrate(long paramLong)
  {
    this.vibrator.vibrate(paramLong);
    Logger localLogger = logger;
    String str = "OOps, I vibrated for " + paramLong + " ms.";
    localLogger.d(str);
  }

  public void vibrateKeyPress()
  {
    boolean bool = this.view.performHapticFeedback(1);
  }

  public void vibrateLongPress()
  {
    boolean bool = this.view.performHapticFeedback(0);
  }

  public void widgetAdd(int paramInt)
  {
    this.context.showAddDialog(paramInt);
  }

  public void widgetDelete(int paramInt)
  {
    Logger localLogger = logger;
    String str = "widgetDelete" + paramInt;
    localLogger.d(str);
    this.context.widgetDelete(paramInt);
  }

  public boolean widgetDrop(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    return false;
  }

  class NativeMenuItem
  {
    String icon;
    int id;
    String str;

    NativeMenuItem(String paramString1, String arg3)
    {
      this.id = this$1;
      this.str = paramString1;
      Object localObject;
      this.icon = localObject;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.opengl.NativeCallbacks
 * JD-Core Version:    0.6.0
 */