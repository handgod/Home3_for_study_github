package com.softspb.shell;

import android.content.Intent;
import com.softspb.util.log.Logger;

class Home$10
  implements Runnable
{
  public void run()
  {
    try
    {
      Home localHome = this.this$0;
      Intent localIntent1 = this.val$request;
      int i = this.val$requestCode;
      localHome.startActivityForResult(localIntent1, i);
      return;
    }
    catch (Exception localException)
    {
      while (true)
      {
        Logger localLogger = Home.access$100();
        StringBuilder localStringBuilder = new StringBuilder().append("Starting request (");
        Intent localIntent2 = this.val$request;
        String str = localIntent2 + ") failed: " + localException;
        localLogger.e(str, localException);
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.Home.10
 * JD-Core Version:    0.6.0
 */