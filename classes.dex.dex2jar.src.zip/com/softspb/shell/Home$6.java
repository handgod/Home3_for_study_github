package com.softspb.shell;

import android.content.Context;
import ru.yandex.startup.StartupUUIDClient;

class Home$6 extends StartupUUIDClient
{
  protected void onStartupCompleted()
  {
    stop();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.Home.6
 * JD-Core Version:    0.6.0
 */