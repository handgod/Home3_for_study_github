package com.softspb.shell;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;

class Home$16
  implements DialogInterface.OnClickListener
{
  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    Home localHome = this.this$0;
    Intent localIntent = new Intent("android.settings.MANAGE_APPLICATIONS_SETTINGS");
    localHome.startActivity(localIntent);
    this.this$0.finish();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.Home.16
 * JD-Core Version:    0.6.0
 */