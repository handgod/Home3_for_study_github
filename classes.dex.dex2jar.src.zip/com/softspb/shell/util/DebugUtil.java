package com.softspb.shell.util;

import android.app.ActivityManager;

public class DebugUtil
{
  public static boolean isMonkey()
  {
    int i = 0;
    try
    {
      boolean bool = ActivityManager.isUserAMonkey();
      i = bool;
      label8: return i;
    }
    catch (Throwable localThrowable)
    {
      break label8;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.util.DebugUtil
 * JD-Core Version:    0.6.0
 */