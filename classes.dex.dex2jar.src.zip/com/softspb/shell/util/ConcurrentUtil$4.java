package com.softspb.shell.util;

import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;

final class ConcurrentUtil$4
  implements Runnable
{
  public void run()
  {
    try
    {
      ConcurrentUtil.ResultHolder localResultHolder = this.val$holder;
      Object localObject1 = this.val$task.call();
      localResultHolder.set(localObject1);
      return;
    }
    catch (Exception localException)
    {
      while (true)
      {
        localException.printStackTrace();
        this.val$latch.countDown();
      }
    }
    finally
    {
      this.val$latch.countDown();
    }
    throw localObject2;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.util.ConcurrentUtil.4
 * JD-Core Version:    0.6.0
 */