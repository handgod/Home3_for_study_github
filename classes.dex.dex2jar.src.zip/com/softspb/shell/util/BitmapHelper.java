package com.softspb.shell.util;

import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.os.Environment;
import com.softspb.util.Conditions;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.io.File;

public class BitmapHelper
{
  private static Logger logger = Loggers.getLogger(BitmapHelper.class.getName());

  public static Bitmap rotate(Bitmap paramBitmap, float paramFloat)
  {
    Object localObject = Conditions.checkNotNull(paramBitmap);
    if (!paramBitmap.isRecycled());
    int j;
    for (int i = 1; ; j = 0)
    {
      Conditions.checkArgument(i, "Can't rotate recycled bitmap");
      Matrix localMatrix = new Matrix();
      localMatrix.reset();
      boolean bool = localMatrix.postRotate(paramFloat);
      int k = paramBitmap.getWidth();
      int m = paramBitmap.getHeight();
      Bitmap localBitmap = paramBitmap;
      int n = 0;
      return Bitmap.createBitmap(localBitmap, 0, n, k, m, localMatrix, 1);
    }
  }

  public static void writeBitmap(Bitmap paramBitmap)
  {
    if (!Environment.getExternalStorageState().equals("mounted"));
    while (true)
    {
      return;
      Object[] arrayOfObject = new Object[2];
      String str1 = Long.toString(System.currentTimeMillis());
      arrayOfObject[0] = str1;
      arrayOfObject[1] = "png";
      String str2 = String.format("%s.%s", arrayOfObject);
      File localFile = Environment.getExternalStorageDirectory();
      writeBitmap(paramBitmap, str2, localFile);
    }
  }

  // ERROR //
  public static void writeBitmap(Bitmap paramBitmap, String paramString, File paramFile)
  {
    // Byte code:
    //   0: aload_2
    //   1: invokevirtual 120	java/io/File:exists	()Z
    //   4: ifne +4 -> 8
    //   7: return
    //   8: new 117	java/io/File
    //   11: dup
    //   12: aload_2
    //   13: aload_1
    //   14: invokespecial 123	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   17: astore_3
    //   18: aconst_null
    //   19: astore 4
    //   21: new 125	java/io/FileOutputStream
    //   24: dup
    //   25: aload_3
    //   26: invokespecial 128	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   29: astore 5
    //   31: getstatic 134	android/graphics/Bitmap$CompressFormat:PNG	Landroid/graphics/Bitmap$CompressFormat;
    //   34: astore 6
    //   36: aload_0
    //   37: aload 6
    //   39: bipush 90
    //   41: aload 5
    //   43: invokevirtual 138	android/graphics/Bitmap:compress	(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z
    //   46: istore 7
    //   48: getstatic 23	com/softspb/shell/util/BitmapHelper:logger	Lcom/softspb/util/log/Logger;
    //   51: astore 8
    //   53: new 140	java/lang/StringBuilder
    //   56: dup
    //   57: invokespecial 141	java/lang/StringBuilder:<init>	()V
    //   60: ldc 143
    //   62: invokevirtual 147	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   65: iload 7
    //   67: invokevirtual 150	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
    //   70: ldc 152
    //   72: invokevirtual 147	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   75: aload_1
    //   76: invokevirtual 147	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   79: invokevirtual 154	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   82: astore 9
    //   84: aload 8
    //   86: aload 9
    //   88: invokevirtual 160	com/softspb/util/log/Logger:i	(Ljava/lang/String;)V
    //   91: aload 5
    //   93: ifnull +88 -> 181
    //   96: aload 5
    //   98: invokestatic 166	com/softspb/util/IOHelper:closeSilent	(Ljava/io/Closeable;)V
    //   101: aload 5
    //   103: astore 10
    //   105: goto -98 -> 7
    //   108: astore 11
    //   110: getstatic 23	com/softspb/shell/util/BitmapHelper:logger	Lcom/softspb/util/log/Logger;
    //   113: ldc 168
    //   115: aload 11
    //   117: invokevirtual 172	com/softspb/util/log/Logger:e	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   120: aload 4
    //   122: ifnull -115 -> 7
    //   125: aload 4
    //   127: invokestatic 166	com/softspb/util/IOHelper:closeSilent	(Ljava/io/Closeable;)V
    //   130: goto -123 -> 7
    //   133: astore 12
    //   135: getstatic 23	com/softspb/shell/util/BitmapHelper:logger	Lcom/softspb/util/log/Logger;
    //   138: ldc 174
    //   140: aload 12
    //   142: invokevirtual 172	com/softspb/util/log/Logger:e	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   145: goto -138 -> 7
    //   148: astore 13
    //   150: aload 4
    //   152: ifnull +8 -> 160
    //   155: aload 4
    //   157: invokestatic 166	com/softspb/util/IOHelper:closeSilent	(Ljava/io/Closeable;)V
    //   160: aload 13
    //   162: athrow
    //   163: astore 13
    //   165: aload 5
    //   167: astore 4
    //   169: goto -19 -> 150
    //   172: astore 11
    //   174: aload 5
    //   176: astore 4
    //   178: goto -68 -> 110
    //   181: aload 5
    //   183: astore 14
    //   185: goto -178 -> 7
    //
    // Exception table:
    //   from	to	target	type
    //   21	31	108	java/io/IOException
    //   8	18	133	java/lang/SecurityException
    //   96	101	133	java/lang/SecurityException
    //   125	130	133	java/lang/SecurityException
    //   155	163	133	java/lang/SecurityException
    //   21	31	148	finally
    //   110	120	148	finally
    //   31	91	163	finally
    //   31	91	172	java/io/IOException
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.util.BitmapHelper
 * JD-Core Version:    0.6.0
 */