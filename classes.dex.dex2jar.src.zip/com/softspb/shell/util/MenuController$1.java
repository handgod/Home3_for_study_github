package com.softspb.shell.util;

import android.view.MenuItem;
import android.widget.PopupMenu.OnMenuItemClickListener;

class MenuController$1
  implements PopupMenu.OnMenuItemClickListener
{
  public boolean onMenuItemClick(MenuItem paramMenuItem)
  {
    this.this$0.currentMenu = null;
    return this.this$0.onOptionsItemSelected(paramMenuItem);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.util.MenuController.1
 * JD-Core Version:    0.6.0
 */