package com.softspb.shell.util;

import com.softspb.util.log.Logger;
import java.util.concurrent.CountDownLatch;

final class ConcurrentUtil$1
  implements Runnable
{
  public void run()
  {
    ConcurrentUtil.access$000().i("->latch.countDown");
    try
    {
      this.val$latch.countDown();
      ConcurrentUtil.access$000().i("<-latch.countDown");
      return;
    }
    catch (Exception localException)
    {
      while (true)
      {
        ConcurrentUtil.access$000().e("!!!! screenLatch error");
        localException.printStackTrace();
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.util.ConcurrentUtil.1
 * JD-Core Version:    0.6.0
 */