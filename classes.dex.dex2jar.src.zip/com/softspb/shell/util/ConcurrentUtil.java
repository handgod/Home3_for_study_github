package com.softspb.shell.util;

import android.os.Handler;
import android.os.Looper;
import com.softspb.util.Conditions;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class ConcurrentUtil
{
  private static Logger logger = Loggers.getLogger(ConcurrentUtil.class.getName());

  public static void completeAction(Runnable paramRunnable, long paramLong)
  {
    Object localObject = Conditions.checkNotNull(paramRunnable);
    CountDownLatch localCountDownLatch = new CountDownLatch(1);
    Handler localHandler = getHandler();
    ConcurrentUtil.2 local2 = new ConcurrentUtil.2(paramRunnable, localCountDownLatch);
    boolean bool1 = localHandler.post(local2);
    try
    {
      TimeUnit localTimeUnit = TimeUnit.MILLISECONDS;
      boolean bool2 = localCountDownLatch.await(paramLong, localTimeUnit);
      return;
    }
    catch (InterruptedException localInterruptedException)
    {
      while (true)
        localInterruptedException.printStackTrace();
    }
  }

  private static Handler getHandler()
  {
    Looper localLooper = Looper.getMainLooper();
    return new Handler(localLooper);
  }

  private static void latchDownInUIThread(CountDownLatch paramCountDownLatch)
  {
    Handler localHandler = getHandler();
    ConcurrentUtil.1 local1 = new ConcurrentUtil.1(paramCountDownLatch);
    boolean bool = localHandler.post(local1);
  }

  public static <T> T runSynchronouslyInUiThread(Callable<T> paramCallable, long paramLong)
  {
    Object localObject = Conditions.checkNotNull(paramCallable);
    ResultHolder localResultHolder = new ResultHolder();
    CountDownLatch localCountDownLatch = new CountDownLatch(1);
    Handler localHandler = getHandler();
    ConcurrentUtil.4 local4 = new ConcurrentUtil.4(localResultHolder, paramCallable, localCountDownLatch);
    boolean bool1 = localHandler.post(local4);
    try
    {
      TimeUnit localTimeUnit = TimeUnit.MILLISECONDS;
      boolean bool2 = localCountDownLatch.await(paramLong, localTimeUnit);
      return localResultHolder.get();
    }
    catch (InterruptedException localInterruptedException)
    {
      while (true)
        localInterruptedException.printStackTrace();
    }
  }

  public static void runSynchronouslyInUiThread(Runnable paramRunnable, long paramLong)
  {
    Object localObject = Conditions.checkNotNull(paramRunnable);
    CountDownLatch localCountDownLatch = new CountDownLatch(1);
    Handler localHandler = getHandler();
    ConcurrentUtil.3 local3 = new ConcurrentUtil.3(paramRunnable, localCountDownLatch);
    boolean bool1 = localHandler.post(local3);
    try
    {
      TimeUnit localTimeUnit = TimeUnit.MILLISECONDS;
      boolean bool2 = localCountDownLatch.await(paramLong, localTimeUnit);
      return;
    }
    catch (InterruptedException localInterruptedException)
    {
      while (true)
        localInterruptedException.printStackTrace();
    }
  }

  class ResultHolder<T>
  {
    T result = null;

    T get()
    {
      return this.result;
    }

    void set(T paramT)
    {
      this.result = paramT;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.util.ConcurrentUtil
 * JD-Core Version:    0.6.0
 */