package com.softspb.shell.util;

import android.graphics.Point;
import android.os.Build.VERSION;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.PopupMenu.OnMenuItemClickListener;
import com.softspb.shell.Home;
import com.softspb.shell.opengl.MyGlSurfaceView;
import com.softspb.shell.opengl.NativeCallbacks;

public class MenuController
{
  PopupMenu currentMenu;
  private Home home;
  PopupMenu.OnMenuItemClickListener menuItemClickListener;
  boolean menuReady = 0;
  private NativeCallbacks nc;

  public MenuController(Home paramHome)
  {
    this.home = paramHome;
    if (Build.VERSION.SDK_INT >= 11)
    {
      MenuController.1 local1 = new MenuController.1(this);
      this.menuItemClickListener = local1;
    }
  }

  public static native void onMenuClosed();

  public static native void onMenuItemSelected(int paramInt);

  private void openPopupMenu(int paramInt1, int paramInt2)
  {
    View localView = this.home.getMenuAnchorView();
    MyGlSurfaceView localMyGlSurfaceView = this.home.getSurfaceView();
    Point localPoint;
    PopupMenu localPopupMenu;
    if ((paramInt1 != -1) && (paramInt2 != -1))
    {
      int i = localMyGlSurfaceView.getLeft() + paramInt1;
      int j = localMyGlSurfaceView.getTop() + paramInt2;
      localPoint = new Point(i, j);
      int k = localPoint.x;
      int m = localPoint.y;
      int n = localPoint.x;
      int i1 = localPoint.y;
      localView.layout(k, m, n, i1);
      Home localHome = this.home;
      localPopupMenu = new PopupMenu(localHome, localView);
      Menu localMenu1 = localPopupMenu.getMenu();
      if (prepareOptionsMenu(localMenu1))
        break label165;
    }
    while (true)
    {
      return;
      int i2 = localMyGlSurfaceView.getRight();
      int i3 = localMyGlSurfaceView.getBottom();
      localPoint = new Point(i2, i3);
      break;
      label165: Menu localMenu2 = localPopupMenu.getMenu();
      if (!onMenuOpened(0, localMenu2))
        continue;
      this.currentMenu = localPopupMenu;
      PopupMenu.OnMenuItemClickListener localOnMenuItemClickListener = this.menuItemClickListener;
      localPopupMenu.setOnMenuItemClickListener(localOnMenuItemClickListener);
      localPopupMenu.show();
    }
  }

  public static native boolean requestMenu();

  public void onCreate()
  {
    NativeCallbacks localNativeCallbacks = this.home.getNativeCallbacks();
    this.nc = localNativeCallbacks;
  }

  public void onDestroy()
  {
  }

  public boolean onMenuOpened(int paramInt, Menu paramMenu)
  {
    int i = 0;
    if (paramInt == 0)
      if (!this.menuReady)
        boolean bool2 = requestMenu();
    while (true)
    {
      return i;
      this.menuReady = 0;
      if (this.nc.isMenuEmpty())
        continue;
      i = 1;
      continue;
      boolean bool1 = onMenuOpened(paramInt, paramMenu);
    }
  }

  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    onMenuItemSelected(paramMenuItem.getItemId());
    return true;
  }

  public void onOptionsMenuClosed(Menu paramMenu)
  {
    onMenuClosed();
  }

  public void onRelayout()
  {
    if (this.currentMenu != null)
      this.currentMenu.dismiss();
  }

  public void openCompatibleMenu(int paramInt1, int paramInt2)
  {
    if (Build.VERSION.SDK_INT < 11)
      this.home.openClassicOptionsMenu();
    while (true)
    {
      return;
      openPopupMenu(paramInt1, paramInt2);
    }
  }

  public void openMenuFromNative(int paramInt1, int paramInt2)
  {
    this.menuReady = 1;
    openCompatibleMenu(paramInt1, paramInt2);
  }

  public boolean prepareOptionsMenu(Menu paramMenu)
  {
    paramMenu.clear();
    boolean bool = this.nc.fillMenu(paramMenu);
    if (paramMenu.size() == 0)
      MenuItem localMenuItem = paramMenu.add(0, 0, 0, "Menu unintialized");
    return true;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.util.MenuController
 * JD-Core Version:    0.6.0
 */