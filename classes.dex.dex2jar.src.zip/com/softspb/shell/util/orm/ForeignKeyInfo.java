package com.softspb.shell.util.orm;

import com.softspb.shell.util.orm.ann.ForeignKey;

public class ForeignKeyInfo
{
  private final String fieldName;
  private final String foreignFieldName;
  private final String foreignTableName;

  public ForeignKeyInfo(String paramString1, String paramString2, String paramString3)
  {
    this.fieldName = paramString1;
    this.foreignTableName = paramString2;
    this.foreignFieldName = paramString3;
  }

  public static ForeignKeyInfo create(ForeignKey paramForeignKey, String paramString)
  {
    String str1 = paramForeignKey.tableName();
    String str2 = paramForeignKey.fieldName();
    return new ForeignKeyInfo(paramString, str1, str2);
  }

  public String getFieldName()
  {
    return this.fieldName;
  }

  public String getForeignFieldName()
  {
    return this.foreignFieldName;
  }

  public String getForeignTableName()
  {
    return this.foreignTableName;
  }

  public String toSQLString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    StringBuilder localStringBuilder2 = localStringBuilder1.append("FOREIGN KEY (");
    String str1 = this.fieldName;
    StringBuilder localStringBuilder3 = localStringBuilder2.append(str1).append(")").append(") REFERENCES ");
    String str2 = this.foreignTableName;
    StringBuilder localStringBuilder4 = localStringBuilder3.append(str2);
    StringBuilder localStringBuilder5 = localStringBuilder1.append("(");
    String str3 = this.foreignFieldName;
    return str3 + ")";
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.util.orm.ForeignKeyInfo
 * JD-Core Version:    0.6.0
 */