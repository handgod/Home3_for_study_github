package com.softspb.shell.util.orm;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class DataColumn
{
  private final DataAdapter<?> dataAdapter;
  private final Method getter;
  private final boolean isPrimaryKey;
  private final String name;
  private final Method setter;

  public DataColumn(Method paramMethod1, Method paramMethod2, String paramString, DataAdapter<?> paramDataAdapter)
  {
  }

  public DataColumn(Method paramMethod1, Method paramMethod2, String paramString, DataAdapter<?> paramDataAdapter, boolean paramBoolean)
  {
    this.setter = paramMethod1;
    this.getter = paramMethod2;
    this.name = paramString;
    this.dataAdapter = paramDataAdapter;
    this.isPrimaryKey = paramBoolean;
  }

  public String getName()
  {
    return this.name;
  }

  public String getTypeName()
  {
    return this.dataAdapter.getTypeName();
  }

  public <T> T getValue(Object paramObject, Class<T> paramClass)
    throws IllegalAccessException, InvocationTargetException
  {
    Method localMethod = this.getter;
    Object[] arrayOfObject = new Object[0];
    Object localObject = localMethod.invoke(paramObject, arrayOfObject);
    return paramClass.cast(localObject);
  }

  public boolean isPrimaryKey()
  {
    return this.isPrimaryKey;
  }

  public void setValue(Object paramObject, DataProvider paramDataProvider)
    throws InvocationTargetException, IllegalAccessException
  {
    Method localMethod = this.setter;
    Object[] arrayOfObject = new Object[1];
    DataAdapter localDataAdapter = this.dataAdapter;
    String str = this.name;
    Object localObject1 = localDataAdapter.get(paramDataProvider, str);
    arrayOfObject[0] = localObject1;
    Object localObject2 = localMethod.invoke(paramObject, arrayOfObject);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.util.orm.DataColumn
 * JD-Core Version:    0.6.0
 */