package com.softspb.shell.util.orm.ann;

import java.lang.annotation.Annotation;

public @interface ForeignKey
{
  public abstract String fieldName();

  public abstract String tableName();
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.util.orm.ann.ForeignKey
 * JD-Core Version:    0.6.0
 */