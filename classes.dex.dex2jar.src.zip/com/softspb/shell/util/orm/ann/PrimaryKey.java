package com.softspb.shell.util.orm.ann;

import dalvik.annotation.AnnotationDefault;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@AnnotationDefault(@PrimaryKey(autoincrement=true))
@Retention(RetentionPolicy.RUNTIME)
@Target({java.lang.annotation.ElementType.METHOD})
public @interface PrimaryKey
{
  public abstract boolean autoincrement();
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.util.orm.ann.PrimaryKey
 * JD-Core Version:    0.6.0
 */