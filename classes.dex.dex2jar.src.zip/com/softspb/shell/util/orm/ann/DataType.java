package com.softspb.shell.util.orm.ann;

public abstract interface DataType
{
  public static final String BLOB = "BLOB";
  public static final String DOUBLE = "DOUBLE";
  public static final String FLOAT = "FLOAT";
  public static final String INTEGER = "INTEGER";
  public static final String LONG = "LONG";
  public static final String SHORT = "SHORT";
  public static final String TEXT = "TEXT";
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.util.orm.ann.DataType
 * JD-Core Version:    0.6.0
 */