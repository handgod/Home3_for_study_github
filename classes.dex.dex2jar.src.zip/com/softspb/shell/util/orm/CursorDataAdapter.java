package com.softspb.shell.util.orm;

import android.database.Cursor;

public class CursorDataAdapter
  implements DataProvider
{
  private final Cursor cursor;

  public CursorDataAdapter(Cursor paramCursor)
  {
    this.cursor = paramCursor;
  }

  public void close()
  {
    this.cursor.close();
  }

  public byte[] getBlob(String paramString)
  {
    Cursor localCursor = this.cursor;
    int i = this.cursor.getColumnIndexOrThrow(paramString);
    return localCursor.getBlob(i);
  }

  public double getDouble(String paramString)
  {
    int i = this.cursor.getColumnIndexOrThrow(paramString);
    return this.cursor.getDouble(i);
  }

  public float getFloat(String paramString)
  {
    int i = this.cursor.getColumnIndexOrThrow(paramString);
    return this.cursor.getFloat(i);
  }

  public int getInt(String paramString)
  {
    int i = this.cursor.getColumnIndexOrThrow(paramString);
    return this.cursor.getInt(i);
  }

  public long getLong(String paramString)
  {
    int i = this.cursor.getColumnIndexOrThrow(paramString);
    return this.cursor.getLong(i);
  }

  public short getShort(String paramString)
  {
    int i = this.cursor.getColumnIndexOrThrow(paramString);
    return this.cursor.getShort(i);
  }

  public String getText(String paramString)
  {
    int i = this.cursor.getColumnIndexOrThrow(paramString);
    return this.cursor.getString(i);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.util.orm.CursorDataAdapter
 * JD-Core Version:    0.6.0
 */