package com.softspb.shell.util.orm;

import java.util.HashMap;

public abstract class DataAdapter<V>
{
  private static final HashMap<String, DataAdapter<?>> ADAPTER_MAP;
  public static final DataAdapter<byte[]> BLOB;
  public static final DataAdapter<Double> DOUBLE;
  public static final DataAdapter<Float> FLOAT;
  public static final DataAdapter<Integer> INT = new IntAdapter();
  public static final DataAdapter<Long> LONG;
  public static final DataAdapter<Short> SHORT;
  public static final DataAdapter<String> TEXT;

  static
  {
    BLOB = new BlobAdapter();
    DOUBLE = new DoubleAdapter();
    FLOAT = new FloatAdapter();
    LONG = new LongAdapter();
    SHORT = new ShortAdapter();
    TEXT = new TextAdapter();
    ADAPTER_MAP = new HashMap();
    synchronized (ADAPTER_MAP)
    {
      HashMap localHashMap2 = ADAPTER_MAP;
      DataAdapter localDataAdapter1 = INT;
      Object localObject1 = localHashMap2.put("INTEGER", localDataAdapter1);
      HashMap localHashMap3 = ADAPTER_MAP;
      DataAdapter localDataAdapter2 = BLOB;
      Object localObject2 = localHashMap3.put("BLOB", localDataAdapter2);
      HashMap localHashMap4 = ADAPTER_MAP;
      DataAdapter localDataAdapter3 = DOUBLE;
      Object localObject3 = localHashMap4.put("DOUBLE", localDataAdapter3);
      HashMap localHashMap5 = ADAPTER_MAP;
      DataAdapter localDataAdapter4 = FLOAT;
      Object localObject4 = localHashMap5.put("FLOAT", localDataAdapter4);
      HashMap localHashMap6 = ADAPTER_MAP;
      DataAdapter localDataAdapter5 = LONG;
      Object localObject5 = localHashMap6.put("LONG", localDataAdapter5);
      HashMap localHashMap7 = ADAPTER_MAP;
      DataAdapter localDataAdapter6 = SHORT;
      Object localObject6 = localHashMap7.put("SHORT", localDataAdapter6);
      HashMap localHashMap8 = ADAPTER_MAP;
      DataAdapter localDataAdapter7 = TEXT;
      Object localObject7 = localHashMap8.put("TEXT", localDataAdapter7);
      return;
    }
  }

  public static <T> DataAdapter<T> forType(String paramString)
  {
    return (DataAdapter)ADAPTER_MAP.get(paramString);
  }

  public abstract V get(DataProvider paramDataProvider, String paramString);

  public abstract String getTypeName();

  final class TextAdapter extends DataAdapter<String>
  {
    private TextAdapter()
    {
      super();
    }

    public String get(DataProvider paramDataProvider, String paramString)
    {
      return paramDataProvider.getText(paramString);
    }

    public String getTypeName()
    {
      return "TEXT";
    }
  }

  final class ShortAdapter extends DataAdapter<Short>
  {
    private ShortAdapter()
    {
      super();
    }

    public Short get(DataProvider paramDataProvider, String paramString)
    {
      return Short.valueOf(paramDataProvider.getShort(paramString));
    }

    public String getTypeName()
    {
      return "SHORT";
    }
  }

  final class LongAdapter extends DataAdapter<Long>
  {
    private LongAdapter()
    {
      super();
    }

    public Long get(DataProvider paramDataProvider, String paramString)
    {
      return Long.valueOf(paramDataProvider.getLong(paramString));
    }

    public String getTypeName()
    {
      return "LONG";
    }
  }

  final class FloatAdapter extends DataAdapter<Float>
  {
    private FloatAdapter()
    {
      super();
    }

    public Float get(DataProvider paramDataProvider, String paramString)
    {
      return Float.valueOf(paramDataProvider.getFloat(paramString));
    }

    public String getTypeName()
    {
      return "FLOAT";
    }
  }

  final class DoubleAdapter extends DataAdapter<Double>
  {
    private DoubleAdapter()
    {
      super();
    }

    public Double get(DataProvider paramDataProvider, String paramString)
    {
      return Double.valueOf(paramDataProvider.getDouble(paramString));
    }

    public String getTypeName()
    {
      return "DOUBLE";
    }
  }

  final class BlobAdapter extends DataAdapter<byte[]>
  {
    private BlobAdapter()
    {
      super();
    }

    public byte[] get(DataProvider paramDataProvider, String paramString)
    {
      return paramDataProvider.getBlob(paramString);
    }

    public String getTypeName()
    {
      return "BLOB";
    }
  }

  final class IntAdapter extends DataAdapter<Integer>
  {
    private IntAdapter()
    {
      super();
    }

    public Integer get(DataProvider paramDataProvider, String paramString)
    {
      return Integer.valueOf(paramDataProvider.getInt(paramString));
    }

    public String getTypeName()
    {
      return "INTEGER";
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.util.orm.DataAdapter
 * JD-Core Version:    0.6.0
 */