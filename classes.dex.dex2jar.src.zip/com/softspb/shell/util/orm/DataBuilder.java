package com.softspb.shell.util.orm;

import android.content.ContentValues;
import com.softspb.shell.util.orm.ann.DataSetter;
import com.softspb.shell.util.orm.ann.ForeignKey;
import com.softspb.shell.util.orm.ann.PrimaryKey;
import com.softspb.util.CollectionFactory;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.concurrent.ConcurrentHashMap;

public class DataBuilder<T>
{
  private static final ConcurrentHashMap<Class<?>, DataBuilder<?>> BUILDERS_CACHE = new ConcurrentHashMap();
  private final Class<T> clazz;
  private final LinkedList<ForeignKeyInfo> fkInfo;
  private final LinkedList<ValueSetter> valueSetters;

  private DataBuilder(Class<T> paramClass)
  {
    this.clazz = paramClass;
    LinkedList localLinkedList1 = new LinkedList();
    this.valueSetters = localLinkedList1;
    LinkedList localLinkedList2 = new LinkedList();
    this.fkInfo = localLinkedList2;
  }

  private static <K> void checkClass(Class<K> paramClass)
  {
    if (paramClass.isInterface())
    {
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str1 = paramClass.getName();
      String str2 = str1 + " is an interface.";
      throw new IllegalArgumentException(str2);
    }
    if (paramClass.isAnnotation())
    {
      StringBuilder localStringBuilder2 = new StringBuilder();
      String str3 = paramClass.getName();
      String str4 = str3 + " is an annotation";
      throw new IllegalArgumentException(str4);
    }
  }

  public static <K> DataBuilder<K> createBuilder(Class<K> paramClass)
  {
    checkClass(paramClass);
    if (BUILDERS_CACHE.containsKey(paramClass));
    DataBuilder localDataBuilder;
    for (Object localObject1 = (DataBuilder)BUILDERS_CACHE.get(paramClass); ; localObject1 = localDataBuilder)
    {
      return localObject1;
      localDataBuilder = new DataBuilder(paramClass);
      Method[] arrayOfMethod = paramClass.getMethods();
      int i = arrayOfMethod.length;
      int j = 0;
      if (j < i)
      {
        Method localMethod = arrayOfMethod[j];
        DataSetter localDataSetter;
        if (localMethod.isAnnotationPresent(DataSetter.class))
        {
          localDataSetter = (DataSetter)localMethod.getAnnotation(DataSetter.class);
          if (localMethod.isAnnotationPresent(PrimaryKey.class))
            break label208;
          LinkedList localLinkedList1 = localDataBuilder.valueSetters;
          String str1 = localDataSetter.columnName();
          DataAdapter localDataAdapter1 = DataAdapter.forType(localDataSetter.type());
          ValueSetter localValueSetter1 = new ValueSetter(localMethod, str1, localDataAdapter1);
          boolean bool1 = localLinkedList1.add(localValueSetter1);
        }
        while (true)
        {
          if (localMethod.isAnnotationPresent(ForeignKey.class))
          {
            ForeignKey localForeignKey = (ForeignKey)localMethod.getAnnotation(ForeignKey.class);
            LinkedList localLinkedList2 = localDataBuilder.fkInfo;
            String str2 = localDataSetter.columnName();
            ForeignKeyInfo localForeignKeyInfo = ForeignKeyInfo.create(localForeignKey, str2);
            boolean bool2 = localLinkedList2.add(localForeignKeyInfo);
          }
          j += 1;
          break;
          label208: LinkedList localLinkedList3 = localDataBuilder.valueSetters;
          String str3 = localDataSetter.columnName();
          DataAdapter localDataAdapter2 = DataAdapter.forType(localDataSetter.type());
          PrimaryKey localPrimaryKey = (PrimaryKey)localMethod.getAnnotation(PrimaryKey.class);
          PrimaryKeyInfo localPrimaryKeyInfo = new PrimaryKeyInfo(localPrimaryKey);
          ValueSetter localValueSetter2 = new ValueSetter(localMethod, str3, localDataAdapter2, localPrimaryKeyInfo);
          boolean bool3 = localLinkedList3.add(localValueSetter2);
        }
      }
      Object localObject2 = BUILDERS_CACHE.put(paramClass, localDataBuilder);
    }
  }

  public ArrayList<String> checkForMissedValues(ContentValues paramContentValues)
  {
    ArrayList localArrayList = CollectionFactory.newArrayList();
    int i = 0;
    while (true)
    {
      int j = this.valueSetters.size();
      if (i >= j)
        break;
      ValueSetter localValueSetter = (ValueSetter)this.valueSetters.get(i);
      if (localValueSetter.getPrimaryKeyInfo() == null)
      {
        String str1 = localValueSetter.getName();
        if (!paramContentValues.containsKey(str1))
        {
          String str2 = localValueSetter.getName();
          boolean bool = localArrayList.add(str2);
        }
      }
      i += 1;
    }
    return localArrayList;
  }

  public HashMap<String, String> createProjectionMap()
  {
    HashMap localHashMap = CollectionFactory.newHashMap();
    Iterator localIterator = this.valueSetters.iterator();
    while (localIterator.hasNext())
    {
      ValueSetter localValueSetter = (ValueSetter)localIterator.next();
      String str1 = localValueSetter.getName();
      String str2 = localValueSetter.getName();
      Object localObject = localHashMap.put(str1, str2);
    }
    return localHashMap;
  }

  public String createTableSQL(String paramString)
  {
    StringBuilder localStringBuilder1 = new StringBuilder("CREATE TABLE ").append(paramString).append(" (");
    ListIterator localListIterator1 = this.valueSetters.listIterator();
    while (localListIterator1.hasNext())
    {
      if (localListIterator1.hasPrevious())
        StringBuilder localStringBuilder2 = localStringBuilder1.append(",");
      ValueSetter localValueSetter = (ValueSetter)localListIterator1.next();
      String str1 = localValueSetter.getName();
      StringBuilder localStringBuilder3 = localStringBuilder1.append(str1).append(" ");
      String str2 = localValueSetter.getTypeName();
      StringBuilder localStringBuilder4 = localStringBuilder3.append(str2);
      if (localValueSetter.getPrimaryKeyInfo() == null)
        continue;
      StringBuilder localStringBuilder5 = localStringBuilder1.append(" ");
      String str3 = localValueSetter.getPrimaryKeyInfo().toSQLString();
      StringBuilder localStringBuilder6 = localStringBuilder5.append(str3);
    }
    ListIterator localListIterator2 = this.fkInfo.listIterator();
    while (localListIterator2.hasNext())
    {
      ForeignKeyInfo localForeignKeyInfo = (ForeignKeyInfo)localListIterator2.next();
      StringBuilder localStringBuilder7 = localStringBuilder1.append(",");
      String str4 = localForeignKeyInfo.toSQLString();
      StringBuilder localStringBuilder8 = localStringBuilder7.append(str4);
    }
    StringBuilder localStringBuilder9 = localStringBuilder1.append(");");
    return localStringBuilder1.toString();
  }

  public T newInstance(DataProvider paramDataProvider)
    throws InstantiationException, IllegalAccessException, InvocationTargetException
  {
    Object localObject = this.clazz.newInstance();
    Iterator localIterator = this.valueSetters.iterator();
    while (localIterator.hasNext())
      ((ValueSetter)localIterator.next()).apply(localObject, paramDataProvider);
    return localObject;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.util.orm.DataBuilder
 * JD-Core Version:    0.6.0
 */