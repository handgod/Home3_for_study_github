package com.softspb.shell.util.orm;

import com.softspb.shell.util.orm.ann.PrimaryKey;

public class PrimaryKeyInfo
{
  private final boolean isAutoIncrement;

  public PrimaryKeyInfo(PrimaryKey paramPrimaryKey)
  {
    this(bool);
  }

  public PrimaryKeyInfo(boolean paramBoolean)
  {
    this.isAutoIncrement = paramBoolean;
  }

  public boolean isAutoIncrement()
  {
    return this.isAutoIncrement;
  }

  public String toSQLString()
  {
    StringBuilder localStringBuilder = new StringBuilder().append("PRIMARY KEY");
    if (this.isAutoIncrement);
    for (String str = " AUTOINCREMENT"; ; str = "")
      return str;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.util.orm.PrimaryKeyInfo
 * JD-Core Version:    0.6.0
 */