package com.softspb.shell.util.orm;

public abstract interface DataProvider
{
  public abstract byte[] getBlob(String paramString);

  public abstract double getDouble(String paramString);

  public abstract float getFloat(String paramString);

  public abstract int getInt(String paramString);

  public abstract long getLong(String paramString);

  public abstract short getShort(String paramString);

  public abstract String getText(String paramString);
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.util.orm.DataProvider
 * JD-Core Version:    0.6.0
 */