package com.softspb.shell.util.orm;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class ValueSetter
{
  private final DataAdapter<?> dataAdapter;
  private final Method method;
  private final String name;
  private final PrimaryKeyInfo primaryKeyInfo;

  public ValueSetter(Method paramMethod, String paramString, DataAdapter<?> paramDataAdapter)
  {
    this(paramMethod, paramString, paramDataAdapter, null);
  }

  public ValueSetter(Method paramMethod, String paramString, DataAdapter<?> paramDataAdapter, PrimaryKeyInfo paramPrimaryKeyInfo)
  {
    this.method = paramMethod;
    this.name = paramString;
    this.dataAdapter = paramDataAdapter;
    this.primaryKeyInfo = paramPrimaryKeyInfo;
  }

  public void apply(Object paramObject, DataProvider paramDataProvider)
    throws InvocationTargetException, IllegalAccessException
  {
    Method localMethod = this.method;
    Object[] arrayOfObject = new Object[1];
    DataAdapter localDataAdapter = this.dataAdapter;
    String str = this.name;
    Object localObject1 = localDataAdapter.get(paramDataProvider, str);
    arrayOfObject[0] = localObject1;
    Object localObject2 = localMethod.invoke(paramObject, arrayOfObject);
  }

  public String getName()
  {
    return this.name;
  }

  public PrimaryKeyInfo getPrimaryKeyInfo()
  {
    return this.primaryKeyInfo;
  }

  public String getTypeName()
  {
    return this.dataAdapter.getTypeName();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.util.orm.ValueSetter
 * JD-Core Version:    0.6.0
 */