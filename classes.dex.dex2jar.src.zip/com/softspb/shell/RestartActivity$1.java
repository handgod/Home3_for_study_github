package com.softspb.shell;

import android.content.Intent;
import android.os.Process;

class RestartActivity$1
  implements Runnable
{
  public void run()
  {
    try
    {
      Thread.sleep(5000L);
      Process.killProcess(this.val$shellPid);
      l = 1000L;
    }
    catch (InterruptedException localInterruptedException2)
    {
      try
      {
        long l;
        Thread.sleep(l);
      }
      catch (InterruptedException localInterruptedException2)
      {
        try
        {
          while (true)
          {
            this.this$0.dismissDialog(0);
            this.this$0.finish();
            RestartActivity localRestartActivity1 = this.this$0;
            RestartActivity localRestartActivity2 = this.this$0;
            Intent localIntent = new Intent(localRestartActivity2, Home.class);
            localRestartActivity1.startActivity(localIntent);
            return;
            localInterruptedException1.printStackTrace();
            continue;
            localInterruptedException2.printStackTrace();
          }
        }
        catch (Exception localException)
        {
          while (true)
            localException.printStackTrace();
        }
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.RestartActivity.1
 * JD-Core Version:    0.6.0
 */