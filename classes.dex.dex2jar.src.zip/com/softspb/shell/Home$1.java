package com.softspb.shell;

import com.softspb.shell.opengl.MyGlSurfaceView;

class Home$1
  implements Runnable
{
  public void run()
  {
    MyGlSurfaceView localMyGlSurfaceView = Home.access$000(this.this$0);
    boolean bool = this.val$Enable;
    localMyGlSurfaceView.enableS3D(bool);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.Home.1
 * JD-Core Version:    0.6.0
 */