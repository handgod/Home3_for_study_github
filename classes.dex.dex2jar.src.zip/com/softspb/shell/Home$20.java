package com.softspb.shell;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.io.PrintStream;

class Home$20 extends BroadcastReceiver
{
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    System.out.println("Home.onReceive");
    ShellApplication localShellApplication = (ShellApplication)this.this$0.getApplication();
    Home localHome = this.this$0;
    localShellApplication.onLicenseCheckFailed(localHome, paramIntent);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.Home.20
 * JD-Core Version:    0.6.0
 */