package com.softspb.shell;

import android.content.Intent;
import com.softspb.shell.view.FilterPickDialogBuilder.DialogResult;

class Home$18
  implements FilterPickDialogBuilder.DialogResult
{
  public void onResult(Intent paramIntent)
  {
    this.this$0.finish();
    this.this$0.startActivity(paramIntent);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.Home.18
 * JD-Core Version:    0.6.0
 */