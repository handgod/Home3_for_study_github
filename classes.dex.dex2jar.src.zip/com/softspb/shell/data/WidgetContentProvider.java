package com.softspb.shell.data;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.text.TextUtils;
import com.softspb.shell.util.orm.DataBuilder;
import com.softspb.util.CollectionFactory;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

public class WidgetContentProvider extends ContentProvider
{
  private static Map<String, String> BASE_WIDGETS_PROJECTION = ;
  private static final HashMap<Integer, String> CODE2TYPE = ;
  private static final int MATCH_BASE_WIDGETS_DIR = 3;
  private static final int MATCH_BASE_WIDGETS_ITEM = 4;
  private static final int MATCH_SHORTCUTS_DIR = 5;
  private static final int MATCH_SHORTCUTS_ITEM = 6;
  private static Map<String, String> SHORTCUTS_PROJECTION;
  private final DataBuilder<BaseWidgetInfo> baseWidgetInfoBuilder;
  private Uri baseWidgetsContentUri;
  private DBHelper dbHelper;
  private Logger logger;
  private final DataBuilder<ShortcutInfo> shortcutInfoBuilder;
  private Uri shortcutsContentUri;
  private final UriMatcher uriMatcher;

  static
  {
    HashMap localHashMap1 = CODE2TYPE;
    Integer localInteger1 = Integer.valueOf(3);
    Object localObject1 = localHashMap1.put(localInteger1, "vnd.android.cursor.dir/vnd.softspb.basewidget");
    HashMap localHashMap2 = CODE2TYPE;
    Integer localInteger2 = Integer.valueOf(4);
    Object localObject2 = localHashMap2.put(localInteger2, "vnd.android.cursor.item/vnd.softspb.basewidget");
    HashMap localHashMap3 = CODE2TYPE;
    Integer localInteger3 = Integer.valueOf(5);
    String str1 = WidgetsContract.ShortcutInfoContract.CONTENT_TYPE;
    Object localObject3 = localHashMap3.put(localInteger3, str1);
    HashMap localHashMap4 = CODE2TYPE;
    Integer localInteger4 = Integer.valueOf(6);
    String str2 = WidgetsContract.ShortcutInfoContract.CONTENT_ITEM_TYPE;
    Object localObject4 = localHashMap4.put(localInteger4, str2);
  }

  public WidgetContentProvider()
  {
    DataBuilder localDataBuilder1 = DataBuilder.createBuilder(BaseWidgetInfo.class);
    this.baseWidgetInfoBuilder = localDataBuilder1;
    DataBuilder localDataBuilder2 = DataBuilder.createBuilder(ShortcutInfo.class);
    this.shortcutInfoBuilder = localDataBuilder2;
    UriMatcher localUriMatcher = new UriMatcher(-1);
    this.uriMatcher = localUriMatcher;
    Logger localLogger = Loggers.getLogger(WidgetContentProvider.class.getName());
    this.logger = localLogger;
  }

  private String createExceptionMessage(ArrayList<String> paramArrayList)
  {
    ListIterator localListIterator = paramArrayList.listIterator();
    StringBuilder localStringBuilder1 = new StringBuilder("Missed Fields:");
    while (localListIterator.hasNext())
    {
      if (localListIterator.hasPrevious())
        StringBuilder localStringBuilder2 = localStringBuilder1.append(",");
      String str = (String)localListIterator.next();
      StringBuilder localStringBuilder3 = localStringBuilder1.append(str);
    }
    return localStringBuilder1.toString();
  }

  private static String createWhereStatement(String paramString, int paramInt)
  {
    StringBuilder localStringBuilder = new StringBuilder().append("_id=").append(paramInt);
    if (!TextUtils.isEmpty(paramString));
    for (String str = " AND (" + paramString + 41; ; str = "")
      return str;
  }

  private static int getId(Uri paramUri)
  {
    String str = (String)paramUri.getPathSegments().get(1);
    return new Integer(str).intValue();
  }

  private void initProjection()
  {
    if (BASE_WIDGETS_PROJECTION == null)
      BASE_WIDGETS_PROJECTION = this.baseWidgetInfoBuilder.createProjectionMap();
    if (SHORTCUTS_PROJECTION == null)
      SHORTCUTS_PROJECTION = this.shortcutInfoBuilder.createProjectionMap();
  }

  private void initUriMatcher(String paramString)
  {
    this.uriMatcher.addURI(paramString, "basewidgets", 3);
    this.uriMatcher.addURI(paramString, "basewidgets/#", 4);
    this.uriMatcher.addURI(paramString, "shortcuts", 5);
    this.uriMatcher.addURI(paramString, "shortcuts/#", 6);
  }

  private void validateValues(ContentValues paramContentValues, DataBuilder<?> paramDataBuilder)
  {
    ArrayList localArrayList = paramDataBuilder.checkForMissedValues(paramContentValues);
    if (!localArrayList.isEmpty())
    {
      String str = createExceptionMessage(localArrayList).toString();
      throw new IllegalStateException(str);
    }
  }

  public void attachInfo(Context paramContext, ProviderInfo paramProviderInfo)
  {
    super.attachInfo(paramContext, paramProviderInfo);
    String str1 = WidgetsContract.getAuthority(paramContext);
    if (!paramProviderInfo.authority.equals(str1))
    {
      StringBuilder localStringBuilder1 = new StringBuilder().append("Unexpected authority: ");
      String str2 = paramProviderInfo.authority;
      String str3 = str2 + ", must be: " + str1;
      throw new RuntimeException(str3);
    }
    String str4 = getClass().getName();
    StringBuilder localStringBuilder2 = new StringBuilder();
    String str5 = paramContext.getPackageName();
    String str6 = str5 + ".widgets.provider.WidgetsProvider";
    if (!str4.equals(str6))
    {
      String str7 = "Unexpected class name: " + str4 + ", must be: " + str6;
      throw new RuntimeException(str7);
    }
    initUriMatcher(str1);
    Uri localUri1 = WidgetsContract.ShortcutInfoContract.getContentUri(paramContext);
    this.shortcutsContentUri = localUri1;
    Uri localUri2 = WidgetsContract.BaseWidgetInfoContract.getContentUri(paramContext);
    this.baseWidgetsContentUri = localUri2;
  }

  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString)
  {
    int i = this.uriMatcher.match(paramUri);
    SQLiteDatabase localSQLiteDatabase = this.dbHelper.getWritableDatabase();
    int j;
    int k;
    switch (i)
    {
    default:
      try
      {
        String str1 = "Unknown URI:" + paramUri;
        throw new IllegalArgumentException(str1);
      }
      finally
      {
        localSQLiteDatabase.close();
      }
    case 3:
      j = localSQLiteDatabase.delete("BaseWidget", paramString, paramArrayOfString);
      k = j;
    case 4:
    case 5:
    case 6:
    }
    while (true)
    {
      localSQLiteDatabase.close();
      return k;
      String str2 = (String)paramUri.getPathSegments().get(1);
      int m = new Integer(str2).intValue();
      String str3 = createWhereStatement(paramString, m);
      k = localSQLiteDatabase.delete("BaseWidget", str3, paramArrayOfString);
      continue;
      k = localSQLiteDatabase.delete("Shortcut", paramString, paramArrayOfString);
      continue;
      int n = getId(paramUri);
      String str4 = createWhereStatement(paramString, n);
      j = localSQLiteDatabase.delete("Shortcut", str4, paramArrayOfString);
      k = j;
    }
  }

  public String getType(Uri paramUri)
  {
    int i = this.uriMatcher.match(paramUri);
    if (i != -1)
    {
      HashMap localHashMap = CODE2TYPE;
      Integer localInteger = Integer.valueOf(i);
      return (String)localHashMap.get(localInteger);
    }
    String str = "Unknown URI " + paramUri;
    throw new IllegalArgumentException(str);
  }

  public Uri insert(Uri paramUri, ContentValues paramContentValues)
  {
    String str2;
    Uri localUri1;
    DataBuilder localDataBuilder;
    switch (this.uriMatcher.match(paramUri))
    {
    case 4:
    default:
      String str1 = "Unknown URI:" + paramUri;
      throw new IllegalArgumentException(str1);
    case 3:
      str2 = "BaseWidget";
      localUri1 = this.baseWidgetsContentUri;
      localDataBuilder = this.baseWidgetInfoBuilder;
    case 5:
    }
    String str3;
    while (true)
    {
      validateValues(paramContentValues, localDataBuilder);
      try
      {
        long l = this.dbHelper.getWritableDatabase().insert(str2, null, paramContentValues);
        if (l > 0L)
        {
          Uri localUri2 = ContentUris.withAppendedId(localUri1, l);
          getContext().getContentResolver().notifyChange(localUri2, null);
          return localUri2;
          str2 = "Shortcut";
          localUri1 = this.shortcutsContentUri;
          localDataBuilder = this.shortcutInfoBuilder;
        }
      }
      catch (Exception str3)
      {
        localException.printStackTrace();
        str3 = "Failed to insert row into " + paramUri;
      }
    }
    throw new SQLException(str3);
  }

  public boolean onCreate()
  {
    Context localContext = getContext();
    DBHelper localDBHelper = new DBHelper(localContext);
    this.dbHelper = localDBHelper;
    initProjection();
    return true;
  }

  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    SQLiteQueryBuilder localSQLiteQueryBuilder = new SQLiteQueryBuilder();
    switch (this.uriMatcher.match(paramUri))
    {
    default:
      String str1 = "unknown uri:" + paramUri;
      throw new IllegalArgumentException(str1);
    case 4:
      StringBuilder localStringBuilder1 = new StringBuilder().append("_id=");
      String str2 = (String)paramUri.getPathSegments().get(1);
      String str3 = str2;
      localSQLiteQueryBuilder.appendWhere(str3);
    case 3:
      localSQLiteQueryBuilder.setTables("BaseWidget");
      Map localMap1 = BASE_WIDGETS_PROJECTION;
      localSQLiteQueryBuilder.setProjectionMap(localMap1);
    case 6:
    case 5:
    }
    while (true)
    {
      SQLiteDatabase localSQLiteDatabase = this.dbHelper.getReadableDatabase();
      String[] arrayOfString1 = paramArrayOfString1;
      String str4 = paramString1;
      String[] arrayOfString2 = paramArrayOfString2;
      String str5 = null;
      String str6 = paramString2;
      Cursor localCursor = localSQLiteQueryBuilder.query(localSQLiteDatabase, arrayOfString1, str4, arrayOfString2, null, str5, str6);
      ContentResolver localContentResolver = getContext().getContentResolver();
      localCursor.setNotificationUri(localContentResolver, paramUri);
      return localCursor;
      StringBuilder localStringBuilder2 = new StringBuilder().append("_id=");
      String str7 = (String)paramUri.getPathSegments().get(1);
      String str8 = str7;
      localSQLiteQueryBuilder.appendWhere(str8);
      localSQLiteQueryBuilder.setTables("Shortcut");
      Map localMap2 = SHORTCUTS_PROJECTION;
      localSQLiteQueryBuilder.setProjectionMap(localMap2);
    }
  }

  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString)
  {
    switch (this.uriMatcher.match(paramUri))
    {
    default:
    case 4:
    }
    while (true)
    {
      int i = 0;
      while (true)
      {
        return i;
        try
        {
          SQLiteDatabase localSQLiteDatabase = this.dbHelper.getWritableDatabase();
          StringBuilder localStringBuilder = new StringBuilder().append("_id=");
          String str1 = paramUri.getLastPathSegment();
          String str2 = str1;
          int j = localSQLiteDatabase.update("BaseWidget", paramContentValues, str2, null);
          i = j;
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
        }
      }
    }
  }

  class DBHelper extends SQLiteOpenHelper
  {
    private static final String DB_NAME = "shell.db";
    private static final int DB_VERSION = 33;

    public DBHelper(Context arg2)
    {
      super("shell.db", null, 33);
    }

    public void onCreate(SQLiteDatabase paramSQLiteDatabase)
    {
      WidgetContentProvider.this.logger.d("DBHelper.onCreate");
      String str1 = WidgetContentProvider.this.baseWidgetInfoBuilder.createTableSQL("BaseWidget");
      paramSQLiteDatabase.execSQL(str1);
      String str2 = WidgetContentProvider.this.shortcutInfoBuilder.createTableSQL("Shortcut");
      paramSQLiteDatabase.execSQL(str2);
    }

    public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2)
    {
      Logger localLogger = WidgetContentProvider.this.logger;
      String str = "DBHelper.onUpgrade: " + paramInt1 + "->" + paramInt2;
      localLogger.d(str);
      paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS widget_info");
      paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS Shortcut");
      paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS BaseWidget");
      onCreate(paramSQLiteDatabase);
    }
  }

  abstract interface Tables
  {
    public static final String BASE_WIDGETS = "BaseWidget";
    public static final String SHORTCUTS = "Shortcut";
    public static final String WIDGET_INFO = "widget_info";
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.data.WidgetContentProvider
 * JD-Core Version:    0.6.0
 */