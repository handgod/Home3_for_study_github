package com.softspb.shell.data;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.Intent.ShortcutIconResource;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.BaseColumns;
import android.util.Log;
import com.softspb.shell.util.orm.ann.DataSetter;
import com.softspb.shell.util.orm.ann.PrimaryKey;
import com.spb.shell3d.R.drawable;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;

public class ShortcutInfo
  implements BaseColumns, WidgetsContract.ShortcutInfoColumns, Persistable
{
  public static final int ICON_TYPE_BITMAP = 2;
  public static final int ICON_TYPE_RESOURCE = 1;
  public static final int SHORTCUT_TYPE = 1;
  private int baseWidgetId;
  private Bitmap icon;
  private Intent.ShortcutIconResource iconResource;
  private int iconType;
  private int id;
  private Intent intent;
  private String title;

  public ShortcutInfo()
  {
    Intent.ShortcutIconResource localShortcutIconResource = new Intent.ShortcutIconResource();
    this.iconResource = localShortcutIconResource;
    this.id = -1;
  }

  public ShortcutInfo(String paramString, Intent paramIntent)
  {
    Intent.ShortcutIconResource localShortcutIconResource = new Intent.ShortcutIconResource();
    this.iconResource = localShortcutIconResource;
    this.id = -1;
    this.title = paramString;
    this.intent = paramIntent;
  }

  static byte[] flattenBitmap(Bitmap paramBitmap)
  {
    Object localObject = null;
    if (paramBitmap == null);
    while (true)
    {
      return localObject;
      int i = paramBitmap.getWidth();
      int j = paramBitmap.getHeight();
      int k = i * j * 4;
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream(k);
      try
      {
        Bitmap.CompressFormat localCompressFormat = Bitmap.CompressFormat.PNG;
        boolean bool = paramBitmap.compress(localCompressFormat, 100, localByteArrayOutputStream);
        localByteArrayOutputStream.flush();
        localByteArrayOutputStream.close();
        byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
        localObject = arrayOfByte;
      }
      catch (IOException localIOException)
      {
        int m = Log.e("Launcher", "Could not write icon");
      }
    }
  }

  public Bitmap getIcon()
  {
    return this.icon;
  }

  public Intent.ShortcutIconResource getIconResource()
  {
    return this.iconResource;
  }

  public int getIconType()
  {
    return this.iconType;
  }

  public int getId()
  {
    return this.id;
  }

  public Uri getImageUri(Context paramContext)
  {
    switch (this.iconType)
    {
    default:
    case 2:
    case 1:
    }
    while (true)
    {
      Object[] arrayOfObject1 = new Object[3];
      arrayOfObject1[0] = "android.resource";
      String str1 = paramContext.getPackageName();
      arrayOfObject1[1] = str1;
      Integer localInteger1 = Integer.valueOf(R.drawable.dummy_icon);
      arrayOfObject1[2] = localInteger1;
      Object localObject = Uri.parse(String.format("%s://%s/%d", arrayOfObject1));
      while (true)
      {
        return localObject;
        localObject = getUri(paramContext);
        continue;
        try
        {
          PackageManager localPackageManager = paramContext.getPackageManager();
          String str2 = this.iconResource.packageName;
          Resources localResources = localPackageManager.getResourcesForApplication(str2);
          String str3 = this.iconResource.resourceName;
          int i = localResources.getIdentifier(str3, null, null);
          Object[] arrayOfObject2 = new Object[3];
          arrayOfObject2[0] = "android.resource";
          String str4 = this.iconResource.packageName;
          arrayOfObject2[1] = str4;
          Integer localInteger2 = Integer.valueOf(i);
          arrayOfObject2[2] = localInteger2;
          Uri localUri = Uri.parse(String.format("%s://%s/%d", arrayOfObject2));
          localObject = localUri;
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
        }
      }
    }
  }

  public Intent getIntent()
  {
    return this.intent;
  }

  public String getTitle()
  {
    return this.title;
  }

  public Uri getUri(Context paramContext)
  {
    if (this.id == -1);
    Uri localUri2;
    long l;
    for (Uri localUri1 = WidgetsContract.ShortcutInfoContract.getContentUri(paramContext); ; localUri1 = ContentUris.withAppendedId(localUri2, l))
    {
      return localUri1;
      localUri2 = WidgetsContract.ShortcutInfoContract.getContentUri(paramContext);
      l = this.id;
    }
  }

  public void setIcon(Bitmap paramBitmap)
  {
    this.iconType = 2;
    this.icon = paramBitmap;
  }

  @DataSetter(columnName="icon", type="BLOB")
  public void setIcon(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null);
    while (true)
    {
      return;
      int i = paramArrayOfByte.length;
      Bitmap localBitmap = BitmapFactory.decodeByteArray(paramArrayOfByte, 0, i);
      this.icon = localBitmap;
    }
  }

  public void setIconResource(Intent.ShortcutIconResource paramShortcutIconResource)
  {
    this.iconType = 1;
    this.iconResource = paramShortcutIconResource;
  }

  @DataSetter(columnName="icon_type", type="INTEGER")
  public void setIconType(int paramInt)
  {
    this.iconType = paramInt;
  }

  @DataSetter(columnName="_id", type="INTEGER")
  @PrimaryKey
  public void setId(int paramInt)
  {
    this.id = paramInt;
  }

  @DataSetter(columnName="intent_descr", type="TEXT")
  public void setIntent(String paramString)
  {
    try
    {
      Intent localIntent = Intent.parseUri(paramString, 0);
      this.intent = localIntent;
      return;
    }
    catch (URISyntaxException localURISyntaxException)
    {
      while (true)
        int i = Log.e("Shortcut Info", "broken uri");
    }
  }

  @DataSetter(columnName="package_name", type="TEXT")
  public void setPackageName(String paramString)
  {
    if (paramString == null);
    while (true)
    {
      return;
      this.iconResource.packageName = paramString;
    }
  }

  @DataSetter(columnName="resource_name", type="TEXT")
  public void setResourceName(String paramString)
  {
    if (paramString == null);
    while (true)
    {
      return;
      this.iconResource.resourceName = paramString;
    }
  }

  @DataSetter(columnName="title", type="TEXT")
  public void setTitle(String paramString)
  {
    this.title = paramString;
  }

  public ContentValues toContentValues()
  {
    String str1 = null;
    ContentValues localContentValues = new ContentValues();
    String str2 = this.title;
    localContentValues.put("title", str2);
    String str3 = this.intent.toUri(0);
    localContentValues.put("intent_descr", str3);
    Integer localInteger = Integer.valueOf(this.iconType);
    localContentValues.put("icon_type", localInteger);
    String str4;
    if (this.iconResource == null)
    {
      str4 = null;
      localContentValues.put("resource_name", str4);
      str4 = "package_name";
      if (this.iconResource != null)
        break label124;
    }
    while (true)
    {
      localContentValues.put(str4, str1);
      byte[] arrayOfByte = flattenBitmap(this.icon);
      localContentValues.put("icon", arrayOfByte);
      return localContentValues;
      str4 = this.iconResource.resourceName;
      break;
      label124: str1 = this.iconResource.packageName;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.data.ShortcutInfo
 * JD-Core Version:    0.6.0
 */