package com.softspb.shell;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class Home$14
  implements DialogInterface.OnClickListener
{
  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    this.this$0.showDialog(13);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.Home.14
 * JD-Core Version:    0.6.0
 */