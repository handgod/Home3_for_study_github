package com.softspb.shell.browser.service;

class HTCThumbObserver$ThumbFileObserver$1
  implements Runnable
{
  public void run()
  {
    HTCThumbObserver localHTCThumbObserver = this.this$1.this$0;
    String str = this.val$url;
    localHTCThumbObserver.onThumbChanged(str);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.browser.service.HTCThumbObserver.ThumbFileObserver.1
 * JD-Core Version:    0.6.0
 */