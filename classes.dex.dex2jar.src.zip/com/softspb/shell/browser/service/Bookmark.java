package com.softspb.shell.browser.service;

import android.database.Cursor;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;

public class Bookmark
  implements Parcelable
{
  public static final Parcelable.Creator<Bookmark> CREATOR = ;
  private static final int PRIME = 99990001;
  long date;
  int favIconLength = -1;
  final int id;
  int sumValue = 0;
  String title;
  String url;
  byte xorValue = 0;

  Bookmark(int paramInt, Cursor paramCursor)
  {
    this.id = paramInt;
    boolean bool = update(paramCursor);
  }

  private Bookmark(Parcel paramParcel)
  {
    int i = paramParcel.readInt();
    this.id = i;
    String str1 = paramParcel.readString();
    this.title = str1;
    String str2 = paramParcel.readString();
    this.url = str2;
    long l = paramParcel.readLong();
    this.date = l;
  }

  private void formatFields(StringBuilder paramStringBuilder)
  {
    StringBuilder localStringBuilder1 = paramStringBuilder.append(" title=");
    String str1 = this.title;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1).append(" url=");
    String str2 = this.url;
    StringBuilder localStringBuilder3 = localStringBuilder2.append(str2).append(" date=");
    long l = this.date;
    StringBuilder localStringBuilder4 = localStringBuilder3.append(l);
  }

  private static int getSumValue(byte[] paramArrayOfByte)
  {
    int i;
    if (paramArrayOfByte == null)
      i = 0;
    while (true)
    {
      return i;
      i = 0;
      byte[] arrayOfByte = paramArrayOfByte;
      int j = arrayOfByte.length;
      int k = 0;
      while (k < j)
      {
        int m = arrayOfByte[k];
        i = (i + m) % 99990001;
        k += 1;
      }
    }
  }

  private static byte getXorValue(byte[] paramArrayOfByte)
  {
    int i;
    if (paramArrayOfByte == null)
      i = 0;
    while (true)
    {
      return i;
      i = 0;
      byte[] arrayOfByte = paramArrayOfByte;
      int j = arrayOfByte.length;
      int k = 0;
      while (k < j)
      {
        int m = arrayOfByte[k];
        i = (byte)(i ^ m);
        k += 1;
      }
    }
  }

  public int describeContents()
  {
    return 0;
  }

  public long getDate()
  {
    return this.date;
  }

  public int getId()
  {
    return this.id;
  }

  public String getTitle()
  {
    return this.title;
  }

  public String getUrl()
  {
    return this.url;
  }

  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str = getClass().getSimpleName();
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str).append("[id=");
    int i = this.id;
    StringBuilder localStringBuilder3 = localStringBuilder2.append(i);
    formatFields(localStringBuilder3);
    return "]";
  }

  boolean update(Cursor paramCursor)
  {
    int i = 0;
    long l = paramCursor.getLong(3);
    String str1 = paramCursor.getString(5);
    String str2 = paramCursor.getString(1);
    byte[] arrayOfByte = paramCursor.getBlob(6);
    if (arrayOfByte == null);
    for (int j = -1; ; j = arrayOfByte.length)
    {
      byte b = getXorValue(arrayOfByte);
      int k = getSumValue(arrayOfByte);
      if (!TextUtils.equals(this.title, str1))
      {
        this.title = str1;
        i = 1;
      }
      if (!TextUtils.equals(this.url, str2))
      {
        this.url = str2;
        i = 1;
      }
      if (this.date != l)
      {
        this.date = l;
        i = 1;
      }
      if ((this.favIconLength != j) || (this.sumValue != k) || (this.xorValue != b))
      {
        this.favIconLength = j;
        this.sumValue = k;
        this.xorValue = b;
        i = 1;
      }
      return i;
    }
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    int i = this.id;
    paramParcel.writeInt(i);
    String str1 = this.title;
    paramParcel.writeString(str1);
    String str2 = this.url;
    paramParcel.writeString(str2);
    long l = this.date;
    paramParcel.writeLong(l);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.browser.service.Bookmark
 * JD-Core Version:    0.6.0
 */