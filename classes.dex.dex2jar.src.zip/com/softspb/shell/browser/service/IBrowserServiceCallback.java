package com.softspb.shell.browser.service;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract interface IBrowserServiceCallback extends IInterface
{
  public abstract void onBookmarkDeleted(int paramInt)
    throws RemoteException;

  public abstract void onBookmarkUpdated(int paramInt, String paramString1, String paramString2)
    throws RemoteException;

  public abstract class Stub extends Binder
    implements IBrowserServiceCallback
  {
    private static final String DESCRIPTOR = "com.softspb.shell.browser.service.IBrowserServiceCallback";
    static final int TRANSACTION_onBookmarkDeleted = 2;
    static final int TRANSACTION_onBookmarkUpdated = 1;

    public Stub()
    {
      attachInterface(this, "com.softspb.shell.browser.service.IBrowserServiceCallback");
    }

    public static IBrowserServiceCallback asInterface(IBinder paramIBinder)
    {
      Object localObject;
      if (paramIBinder == null)
        localObject = null;
      while (true)
      {
        return localObject;
        localObject = paramIBinder.queryLocalInterface("com.softspb.shell.browser.service.IBrowserServiceCallback");
        if ((localObject != null) && ((localObject instanceof IBrowserServiceCallback)))
        {
          localObject = (IBrowserServiceCallback)localObject;
          continue;
        }
        localObject = new Proxy();
      }
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      boolean bool = true;
      switch (paramInt1)
      {
      default:
        bool = super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
      case 1:
      case 2:
      }
      while (true)
      {
        return bool;
        paramParcel2.writeString("com.softspb.shell.browser.service.IBrowserServiceCallback");
        continue;
        paramParcel1.enforceInterface("com.softspb.shell.browser.service.IBrowserServiceCallback");
        int i = paramParcel1.readInt();
        String str1 = paramParcel1.readString();
        String str2 = paramParcel1.readString();
        onBookmarkUpdated(i, str1, str2);
        continue;
        paramParcel1.enforceInterface("com.softspb.shell.browser.service.IBrowserServiceCallback");
        int j = paramParcel1.readInt();
        onBookmarkDeleted(j);
      }
    }

    class Proxy
      implements IBrowserServiceCallback
    {
      Proxy()
      {
      }

      public IBinder asBinder()
      {
        return IBrowserServiceCallback.Stub.this;
      }

      public String getInterfaceDescriptor()
      {
        return "com.softspb.shell.browser.service.IBrowserServiceCallback";
      }

      public void onBookmarkDeleted(int paramInt)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.softspb.shell.browser.service.IBrowserServiceCallback");
          localParcel.writeInt(paramInt);
          boolean bool = IBrowserServiceCallback.Stub.this.transact(2, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
        throw localObject;
      }

      public void onBookmarkUpdated(int paramInt, String paramString1, String paramString2)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.softspb.shell.browser.service.IBrowserServiceCallback");
          localParcel.writeInt(paramInt);
          localParcel.writeString(paramString1);
          localParcel.writeString(paramString2);
          boolean bool = IBrowserServiceCallback.Stub.this.transact(1, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
        throw localObject;
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.browser.service.IBrowserServiceCallback
 * JD-Core Version:    0.6.0
 */