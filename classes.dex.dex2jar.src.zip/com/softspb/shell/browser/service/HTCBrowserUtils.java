package com.softspb.shell.browser.service;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.ComponentName;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.io.File;
import java.util.Iterator;
import java.util.List;

public abstract class HTCBrowserUtils
{
  private static final String HTC_SENSE_ALBUM_WIDGET_PROVIDER = "com.htc.album.PhotoAppWidgetProvider";
  private static final String HTC_SENSE_MUSIC_WIDGET_PROVIDER = "com.htc.music.MediaAppWidgetProvider";
  public static final String MANUFACTURER_HTC = "HTC";
  public static final String THUMB_FOLDER_HTC = "/sdcard/.bookmark_thumb1";
  private static Logger logger = Loggers.getLogger(HTCBrowserUtils.class.getName());

  public static boolean detectHTCBrowser(Context paramContext)
  {
    int i = 0;
    String str1 = Build.MANUFACTURER;
    if (!"HTC".equals(str1))
      logger.d("Not an HTC device");
    while (true)
    {
      return i;
      AppWidgetManager localAppWidgetManager = AppWidgetManager.getInstance(paramContext);
      Iterator localIterator = localAppWidgetManager.getInstalledProviders().iterator();
      AppWidgetProviderInfo localAppWidgetProviderInfo;
      while (true)
        if (localIterator.hasNext())
        {
          localAppWidgetProviderInfo = (AppWidgetProviderInfo)localIterator.next();
          if (!localAppWidgetProviderInfo.provider.getClassName().equals("com.htc.album.PhotoAppWidgetProvider"))
            continue;
          Logger localLogger1 = logger;
          StringBuilder localStringBuilder1 = new StringBuilder().append("Detected HTC Sense widget provider: ");
          ComponentName localComponentName1 = localAppWidgetProviderInfo.provider;
          String str2 = localComponentName1;
          localLogger1.d(str2);
          logger.d("Detected HTC Browser");
          i = 1;
          break;
        }
      localIterator = localAppWidgetManager.getInstalledProviders().iterator();
      while (true)
        if (localIterator.hasNext())
        {
          localAppWidgetProviderInfo = (AppWidgetProviderInfo)localIterator.next();
          if (!localAppWidgetProviderInfo.provider.getClassName().equals("com.htc.music.MediaAppWidgetProvider"))
            continue;
          Logger localLogger2 = logger;
          StringBuilder localStringBuilder2 = new StringBuilder().append("Detected HTC Sense widget provider: ");
          ComponentName localComponentName2 = localAppWidgetProviderInfo.provider;
          String str3 = localComponentName2;
          localLogger2.d(str3);
          logger.d("Detected HTC Browser");
          i = 1;
          break;
        }
      logger.d("NOT an HTC Browser");
    }
  }

  public static String getHTCThumbnailFilename(String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder().append("m");
    String str = Integer.toHexString(paramString.hashCode());
    return str + ".jpg";
  }

  public static Bitmap tryLoadHTCThumbnail(int paramInt, Cursor paramCursor)
  {
    Object localObject = null;
    logger.d("Trying to load thumbnail from HTC...");
    File localFile = new File("/sdcard/.bookmark_thumb1");
    int i = paramCursor.getColumnIndex("url");
    String str1 = paramCursor.getString(i);
    if (str1 == null)
    {
      Logger localLogger1 = logger;
      String str2 = "Bookmark has no URL: id=" + paramInt;
      localLogger1.w(str2);
    }
    while (true)
    {
      return localObject;
      try
      {
        if (!localFile.isDirectory())
          logger.w("HTC thumbnails directory not found.");
      }
      catch (SecurityException localSecurityException)
      {
        Logger localLogger2 = logger;
        String str3 = "Can't read HTC bookmarks directory: " + localSecurityException;
        localLogger2.w(str3, localSecurityException);
        continue;
        String str4 = getHTCThumbnailFilename(str1);
        String str5 = new File(localFile, str4).getPath();
        Logger localLogger3 = logger;
        String str6 = "Loading HTC thumbnail from file: " + str5;
        localLogger3.d(str6);
        Bitmap localBitmap = BitmapFactory.decodeFile(str5);
        localObject = localBitmap;
      }
      catch (Exception localException)
      {
        Logger localLogger4 = logger;
        String str7 = "Error occurred while loading HTC bookmark thumbnail: " + localException;
        localLogger4.w(str7, localException);
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.browser.service.HTCBrowserUtils
 * JD-Core Version:    0.6.0
 */