package com.softspb.shell.browser.service;

import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import com.softspb.util.log.Logger;

class BrowserService$1 extends IBrowserService.Stub
{
  public BrowserConfiguration getBrowserConfiguration()
    throws RemoteException
  {
    return BrowserService.access$300(this.this$0);
  }

  public void loadBookmarks()
    throws RemoteException
  {
    BrowserService.access$000(this.this$0);
  }

  public Bitmap loadIcon(int paramInt)
    throws RemoteException
  {
    ContentResolver localContentResolver = this.this$0.contentResolver;
    Logger localLogger = BrowserService.access$100();
    return BrowserUtils.loadIcon(localContentResolver, paramInt, localLogger);
  }

  public Bitmap loadThumbnail(int paramInt)
    throws RemoteException
  {
    ContentResolver localContentResolver = this.this$0.contentResolver;
    boolean bool = BrowserService.access$200(this.this$0);
    Logger localLogger = BrowserService.access$100();
    return BrowserUtils.loadThumbnail(localContentResolver, paramInt, bool, localLogger);
  }

  public void registerCallback(IBrowserServiceCallback paramIBrowserServiceCallback)
    throws RemoteException
  {
    Logger localLogger = BrowserService.access$100();
    String str = "registerCallback: " + paramIBrowserServiceCallback;
    localLogger.d(str);
    if (paramIBrowserServiceCallback != null)
      boolean bool = BrowserService.access$400(this.this$0).register(paramIBrowserServiceCallback);
  }

  public void unregisterCallback(IBrowserServiceCallback paramIBrowserServiceCallback)
    throws RemoteException
  {
    Logger localLogger = BrowserService.access$100();
    String str = "unregisterCallback: " + paramIBrowserServiceCallback;
    localLogger.d(str);
    if (paramIBrowserServiceCallback != null)
      boolean bool = BrowserService.access$400(this.this$0).unregister(paramIBrowserServiceCallback);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.browser.service.BrowserService.1
 * JD-Core Version:    0.6.0
 */