package com.softspb.shell.browser.service;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class BrowserConfiguration$1
  implements Parcelable.Creator<BrowserConfiguration>
{
  public BrowserConfiguration createFromParcel(Parcel paramParcel)
  {
    return new BrowserConfiguration(paramParcel, null);
  }

  public BrowserConfiguration[] newArray(int paramInt)
  {
    return new BrowserConfiguration[paramInt];
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.browser.service.BrowserConfiguration.1
 * JD-Core Version:    0.6.0
 */