package com.softspb.shell.browser.service;

import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.os.RemoteException;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;

public abstract class BrowserClient
{
  static final Logger logger = Loggers.getLogger(BrowserClient.class);
  BrowserConfiguration browserConfiguration;
  private ServiceConnection connection;
  final Context context;
  boolean isBound;
  boolean isHtcBrowser = 0;
  boolean isReady;
  IBrowserService service;
  IBrowserServiceCallback serviceCallback;

  protected BrowserClient(Context paramContext)
  {
    BrowserClient.1 local1 = new BrowserClient.1(this);
    this.serviceCallback = local1;
    BrowserClient.2 local2 = new BrowserClient.2(this);
    this.connection = local2;
    logd("Ctor");
    this.context = paramContext;
  }

  protected static void logd(String paramString)
  {
    logger.d(paramString);
  }

  public void connect()
  {
    logd("connect >>>");
    Context localContext1 = this.context;
    Context localContext2 = this.context;
    Intent localIntent = new Intent(localContext2, BrowserService.class);
    ServiceConnection localServiceConnection = this.connection;
    boolean bool = localContext1.bindService(localIntent, localServiceConnection, 1);
    this.isBound = 1;
    logd("connect <<< attached service connection");
  }

  public void disconnect()
  {
    logd("disconnect >>>");
    if ((!this.isBound) || (this.service != null));
    try
    {
      IBrowserService localIBrowserService = this.service;
      IBrowserServiceCallback localIBrowserServiceCallback = this.serviceCallback;
      localIBrowserService.unregisterCallback(localIBrowserServiceCallback);
      label36: Context localContext = this.context;
      ServiceConnection localServiceConnection = this.connection;
      localContext.unbindService(localServiceConnection);
      logd("disconnect <<< service connection detached");
      this.isBound = 0;
      this.isReady = 0;
      while (true)
      {
        return;
        logd("disconnect: service is null");
        break;
        logd("disconnect <<< not bound");
      }
    }
    catch (RemoteException localRemoteException)
    {
      break label36;
    }
  }

  public boolean isConnected()
  {
    return this.isBound;
  }

  public boolean isReady()
  {
    return this.isReady;
  }

  public Bitmap loadIcon(int paramInt)
  {
    Object localObject = null;
    if (this.isReady);
    try
    {
      Bitmap localBitmap = this.service.loadIcon(paramInt);
      localObject = localBitmap;
      label22: return localObject;
    }
    catch (RemoteException localRemoteException)
    {
      break label22;
    }
  }

  public Bitmap loadThumbnail(int paramInt)
  {
    Object localObject = null;
    if (this.isReady);
    try
    {
      Bitmap localBitmap = this.service.loadThumbnail(paramInt);
      localObject = localBitmap;
      label22: return localObject;
    }
    catch (RemoteException localRemoteException)
    {
      break label22;
    }
  }

  protected abstract void onBookmarkDeleted(int paramInt);

  protected abstract void onBookmarkUpdated(int paramInt, String paramString1, String paramString2);

  protected abstract void onConnected();

  protected abstract void onDisconnected();

  public void postLoadBookmarks()
  {
    StringBuilder localStringBuilder = new StringBuilder().append("postReloadBookmarks >>> isReady=");
    boolean bool = this.isReady;
    logd(bool);
    if (this.isReady);
    try
    {
      this.service.loadBookmarks();
      label45: logd("postReloadBookmarks <<<");
      return;
    }
    catch (RemoteException localRemoteException)
    {
      break label45;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.browser.service.BrowserClient
 * JD-Core Version:    0.6.0
 */