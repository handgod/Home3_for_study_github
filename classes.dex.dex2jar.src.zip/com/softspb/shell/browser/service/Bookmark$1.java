package com.softspb.shell.browser.service;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class Bookmark$1
  implements Parcelable.Creator<Bookmark>
{
  public Bookmark createFromParcel(Parcel paramParcel)
  {
    return new Bookmark(paramParcel, null);
  }

  public Bookmark[] newArray(int paramInt)
  {
    return new Bookmark[paramInt];
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.browser.service.Bookmark.1
 * JD-Core Version:    0.6.0
 */