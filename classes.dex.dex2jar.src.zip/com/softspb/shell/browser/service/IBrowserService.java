package com.softspb.shell.browser.service;

import android.graphics.Bitmap;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;

public abstract interface IBrowserService extends IInterface
{
  public abstract BrowserConfiguration getBrowserConfiguration()
    throws RemoteException;

  public abstract void loadBookmarks()
    throws RemoteException;

  public abstract Bitmap loadIcon(int paramInt)
    throws RemoteException;

  public abstract Bitmap loadThumbnail(int paramInt)
    throws RemoteException;

  public abstract void registerCallback(IBrowserServiceCallback paramIBrowserServiceCallback)
    throws RemoteException;

  public abstract void unregisterCallback(IBrowserServiceCallback paramIBrowserServiceCallback)
    throws RemoteException;

  public abstract class Stub extends Binder
    implements IBrowserService
  {
    private static final String DESCRIPTOR = "com.softspb.shell.browser.service.IBrowserService";
    static final int TRANSACTION_getBrowserConfiguration = 4;
    static final int TRANSACTION_loadBookmarks = 1;
    static final int TRANSACTION_loadIcon = 2;
    static final int TRANSACTION_loadThumbnail = 3;
    static final int TRANSACTION_registerCallback = 5;
    static final int TRANSACTION_unregisterCallback = 6;

    public Stub()
    {
      attachInterface(this, "com.softspb.shell.browser.service.IBrowserService");
    }

    public static IBrowserService asInterface(IBinder paramIBinder)
    {
      Object localObject;
      if (paramIBinder == null)
        localObject = null;
      while (true)
      {
        return localObject;
        localObject = paramIBinder.queryLocalInterface("com.softspb.shell.browser.service.IBrowserService");
        if ((localObject != null) && ((localObject instanceof IBrowserService)))
        {
          localObject = (IBrowserService)localObject;
          continue;
        }
        localObject = new Proxy();
      }
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      boolean bool = true;
      switch (paramInt1)
      {
      default:
        bool = super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      }
      while (true)
      {
        return bool;
        paramParcel2.writeString("com.softspb.shell.browser.service.IBrowserService");
        continue;
        paramParcel1.enforceInterface("com.softspb.shell.browser.service.IBrowserService");
        loadBookmarks();
        continue;
        paramParcel1.enforceInterface("com.softspb.shell.browser.service.IBrowserService");
        int i = paramParcel1.readInt();
        Object localObject = loadIcon(i);
        paramParcel2.writeNoException();
        if (localObject != null)
        {
          paramParcel2.writeInt(1);
          ((Bitmap)localObject).writeToParcel(paramParcel2, 1);
          continue;
        }
        paramParcel2.writeInt(0);
        continue;
        paramParcel1.enforceInterface("com.softspb.shell.browser.service.IBrowserService");
        int j = paramParcel1.readInt();
        localObject = loadThumbnail(j);
        paramParcel2.writeNoException();
        if (localObject != null)
        {
          paramParcel2.writeInt(1);
          ((Bitmap)localObject).writeToParcel(paramParcel2, 1);
          continue;
        }
        paramParcel2.writeInt(0);
        continue;
        paramParcel1.enforceInterface("com.softspb.shell.browser.service.IBrowserService");
        localObject = getBrowserConfiguration();
        paramParcel2.writeNoException();
        if (localObject != null)
        {
          paramParcel2.writeInt(1);
          ((BrowserConfiguration)localObject).writeToParcel(paramParcel2, 1);
          continue;
        }
        paramParcel2.writeInt(0);
        continue;
        paramParcel1.enforceInterface("com.softspb.shell.browser.service.IBrowserService");
        IBrowserServiceCallback localIBrowserServiceCallback1 = IBrowserServiceCallback.Stub.asInterface(paramParcel1.readStrongBinder());
        registerCallback(localIBrowserServiceCallback1);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.softspb.shell.browser.service.IBrowserService");
        IBrowserServiceCallback localIBrowserServiceCallback2 = IBrowserServiceCallback.Stub.asInterface(paramParcel1.readStrongBinder());
        unregisterCallback(localIBrowserServiceCallback2);
        paramParcel2.writeNoException();
      }
    }

    class Proxy
      implements IBrowserService
    {
      Proxy()
      {
      }

      public IBinder asBinder()
      {
        return IBrowserService.Stub.this;
      }

      public BrowserConfiguration getBrowserConfiguration()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.softspb.shell.browser.service.IBrowserService");
          boolean bool = IBrowserService.Stub.this.transact(4, localParcel1, localParcel2, 0);
          localParcel2.readException();
          if (localParcel2.readInt() != 0)
          {
            localBrowserConfiguration = (BrowserConfiguration)BrowserConfiguration.CREATOR.createFromParcel(localParcel2);
            return localBrowserConfiguration;
          }
          BrowserConfiguration localBrowserConfiguration = null;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public String getInterfaceDescriptor()
      {
        return "com.softspb.shell.browser.service.IBrowserService";
      }

      public void loadBookmarks()
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.softspb.shell.browser.service.IBrowserService");
          boolean bool = IBrowserService.Stub.this.transact(1, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
        throw localObject;
      }

      public Bitmap loadIcon(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.softspb.shell.browser.service.IBrowserService");
          localParcel1.writeInt(paramInt);
          boolean bool = IBrowserService.Stub.this.transact(2, localParcel1, localParcel2, 0);
          localParcel2.readException();
          if (localParcel2.readInt() != 0)
          {
            localBitmap = (Bitmap)Bitmap.CREATOR.createFromParcel(localParcel2);
            return localBitmap;
          }
          Bitmap localBitmap = null;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public Bitmap loadThumbnail(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.softspb.shell.browser.service.IBrowserService");
          localParcel1.writeInt(paramInt);
          boolean bool = IBrowserService.Stub.this.transact(3, localParcel1, localParcel2, 0);
          localParcel2.readException();
          if (localParcel2.readInt() != 0)
          {
            localBitmap = (Bitmap)Bitmap.CREATOR.createFromParcel(localParcel2);
            return localBitmap;
          }
          Bitmap localBitmap = null;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public void registerCallback(IBrowserServiceCallback paramIBrowserServiceCallback)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.softspb.shell.browser.service.IBrowserService");
          if (paramIBrowserServiceCallback != null)
          {
            localIBinder = paramIBrowserServiceCallback.asBinder();
            localParcel1.writeStrongBinder(localIBinder);
            boolean bool = IBrowserService.Stub.this.transact(5, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
          IBinder localIBinder = null;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public void unregisterCallback(IBrowserServiceCallback paramIBrowserServiceCallback)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.softspb.shell.browser.service.IBrowserService");
          if (paramIBrowserServiceCallback != null)
          {
            localIBinder = paramIBrowserServiceCallback.asBinder();
            localParcel1.writeStrongBinder(localIBinder);
            boolean bool = IBrowserService.Stub.this.transact(6, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
          IBinder localIBinder = null;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.browser.service.IBrowserService
 * JD-Core Version:    0.6.0
 */