package com.softspb.shell.browser.service;

import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Messenger;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.provider.Browser;
import android.util.SparseArray;
import android.util.SparseIntArray;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.util.ArrayList;
import java.util.HashMap;

public class BrowserService extends Service
{
  static final String BOOKMARKS_SELECTION = ;
  public static final int BOOKMARK_IMAGE_TYPE_ICON = 1;
  public static final int BOOKMARK_INAGE_TYPE_THUMBNAIL = 2;
  private static final int MAX_BITMAP_LENGTH = 99000;
  private static final Logger logger = Loggers.getLogger(BrowserService.class);
  final SparseArray<Bookmark> bookmarks;
  private BrowserConfiguration browserConfiguration;
  private final IBrowserService.Stub browserServiceBinder;
  private final RemoteCallbackList<IBrowserServiceCallback> callbackList;
  final ArrayList<Messenger> clients;
  private ContentObserver contentObserver;
  ContentResolver contentResolver;
  private HTCThumbObserver htcThumbObserver;
  private boolean isHtcBrowser;
  private HashMap<String, Bookmark> url2bookmark;

  public BrowserService()
  {
    ArrayList localArrayList = new ArrayList();
    this.clients = localArrayList;
    SparseArray localSparseArray = new SparseArray();
    this.bookmarks = localSparseArray;
    RemoteCallbackList localRemoteCallbackList = new RemoteCallbackList();
    this.callbackList = localRemoteCallbackList;
    BrowserService.1 local1 = new BrowserService.1(this);
    this.browserServiceBinder = local1;
    Handler localHandler = new Handler();
    BrowserService.2 local2 = new BrowserService.2(this, localHandler);
    this.contentObserver = local2;
  }

  private void deleteBookmark(int paramInt)
  {
    Bookmark localBookmark = (Bookmark)this.bookmarks.get(paramInt);
    this.bookmarks.delete(paramInt);
    if ((this.isHtcBrowser) && (localBookmark != null))
    {
      HashMap localHashMap = this.url2bookmark;
      String str = localBookmark.url;
      Object localObject = localHashMap.remove(str);
    }
    notifyBookmarkDeleted(paramInt);
  }

  private void loadBookmarks()
  {
    logger.d("loadBookmarks >>>");
    SparseArray localSparseArray = this.bookmarks;
    SparseIntArray localSparseIntArray = new SparseIntArray();
    int i = localSparseArray.size();
    int j = 0;
    while (j < i)
    {
      int k = localSparseArray.keyAt(j);
      localSparseIntArray.put(k, 1);
      j += 1;
    }
    int m = 0;
    try
    {
      ContentResolver localContentResolver = this.contentResolver;
      Uri localUri = Browser.BOOKMARKS_URI;
      String[] arrayOfString = Browser.HISTORY_PROJECTION;
      String str1 = BOOKMARKS_SELECTION;
      localCursor = localContentResolver.query(localUri, arrayOfString, str1, null, null);
      if ((localCursor != null) && (localCursor.moveToFirst()))
        while (true)
        {
          if (localCursor.isAfterLast())
            break label358;
          int n = (int)localCursor.getLong(0);
          localSparseIntArray.delete(n);
          localBookmark = (Bookmark)localSparseArray.get(n);
          if (localBookmark != null)
            break;
          i1 = 1;
          localBookmark = new Bookmark(n, localCursor);
          localSparseArray.put(n, localBookmark);
          if ((this.isHtcBrowser) && (localBookmark.url != null))
          {
            HashMap localHashMap = this.url2bookmark;
            String str2 = localBookmark.url;
            Object localObject1 = localHashMap.put(str2, localBookmark);
            HTCThumbObserver localHTCThumbObserver = this.htcThumbObserver;
            String str3 = localBookmark.url;
            localHTCThumbObserver.addURL(str3);
          }
          m += 1;
          logd("loadBookmarks: " + localBookmark);
          if (i1 != 0)
            updateBookmark(localBookmark);
          boolean bool = localCursor.moveToNext();
        }
    }
    finally
    {
      while (true)
      {
        Cursor localCursor;
        Bookmark localBookmark;
        int i1;
        if (localCursor != null);
        try
        {
          localCursor.close();
          label306: logd("loadBookmarks: loaded " + m + " bookmarks");
          logd("loadBookmarks <<<");
          throw localObject2;
          int i2 = localBookmark.update(localCursor);
          i1 = i2;
          continue;
          label358: if (localCursor != null);
          try
          {
            localCursor.close();
            label370: logd("loadBookmarks: loaded " + m + " bookmarks");
            logd("loadBookmarks <<<");
            i = localSparseIntArray.size();
            j = 0;
            while (j < i)
            {
              int i3 = localSparseIntArray.keyAt(j);
              deleteBookmark(i3);
              j += 1;
            }
          }
          catch (Exception localException1)
          {
            break label370;
          }
        }
        catch (Exception localException2)
        {
          break label306;
        }
      }
    }
  }

  private static void logd(String paramString)
  {
    logger.d(paramString);
  }

  private static void loge(String paramString, Throwable paramThrowable)
  {
    logger.e(paramString, paramThrowable);
  }

  private static void logw(String paramString)
  {
    logger.w(paramString);
  }

  private void updateBookmark(Bookmark paramBookmark)
  {
    notifyBookmarkUpdated(paramBookmark);
  }

  void notifyBookmarkDeleted(int paramInt)
  {
    int i = this.callbackList.beginBroadcast();
    int j = 0;
    while (true)
    {
      if (j < i);
      try
      {
        ((IBrowserServiceCallback)this.callbackList.getBroadcastItem(j)).onBookmarkDeleted(paramInt);
        label32: j += 1;
        continue;
        this.callbackList.finishBroadcast();
        return;
      }
      catch (RemoteException localRemoteException)
      {
        break label32;
      }
    }
  }

  void notifyBookmarkUpdated(Bookmark paramBookmark)
  {
    int i = this.callbackList.beginBroadcast();
    int j = 0;
    while (true)
    {
      if (j < i);
      try
      {
        IBrowserServiceCallback localIBrowserServiceCallback = (IBrowserServiceCallback)this.callbackList.getBroadcastItem(j);
        int k = paramBookmark.id;
        String str1 = paramBookmark.title;
        String str2 = paramBookmark.url;
        localIBrowserServiceCallback.onBookmarkUpdated(k, str1, str2);
        label59: j += 1;
        continue;
        this.callbackList.finishBroadcast();
        return;
      }
      catch (RemoteException localRemoteException)
      {
        break label59;
      }
    }
  }

  public IBinder onBind(Intent paramIntent)
  {
    return this.browserServiceBinder;
  }

  public void onCreate()
  {
    logd("onCreate >>>");
    super.onCreate();
    ContentResolver localContentResolver1 = getContentResolver();
    this.contentResolver = localContentResolver1;
    ContentResolver localContentResolver2 = this.contentResolver;
    Uri localUri = Browser.BOOKMARKS_URI;
    ContentObserver localContentObserver = this.contentObserver;
    localContentResolver2.registerContentObserver(localUri, 1, localContentObserver);
    boolean bool1 = HTCBrowserUtils.detectHTCBrowser(this);
    this.isHtcBrowser = bool1;
    boolean bool2 = this.isHtcBrowser;
    BrowserConfiguration localBrowserConfiguration = new BrowserConfiguration(bool2);
    this.browserConfiguration = localBrowserConfiguration;
    if (this.isHtcBrowser)
    {
      Looper localLooper = Looper.myLooper();
      HTCThumbObserver localHTCThumbObserver = new HTCThumbObserver(localLooper);
      this.htcThumbObserver = localHTCThumbObserver;
      this.htcThumbObserver.start();
      HashMap localHashMap = new HashMap();
      this.url2bookmark = localHashMap;
    }
    logd("onCreate <<<");
  }

  public void onDestroy()
  {
    logd("onDestroy >>>");
    super.onDestroy();
    ContentResolver localContentResolver = this.contentResolver;
    ContentObserver localContentObserver = this.contentObserver;
    localContentResolver.unregisterContentObserver(localContentObserver);
    if (this.isHtcBrowser)
      this.htcThumbObserver.stop();
    logd("onDestroy <<<");
  }

  class HTCThumbObserver extends HTCThumbObserver
  {
    HTCThumbObserver(Looper arg2)
    {
      super();
    }

    void onThumbChanged(String paramString)
    {
      Logger localLogger = logger;
      String str = "onThumbChanged: url=" + paramString;
      localLogger.d(str);
      Bookmark localBookmark = (Bookmark)BrowserService.this.url2bookmark.get(paramString);
      if (localBookmark != null)
        BrowserService.this.notifyBookmarkUpdated(localBookmark);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.browser.service.BrowserService
 * JD-Core Version:    0.6.0
 */