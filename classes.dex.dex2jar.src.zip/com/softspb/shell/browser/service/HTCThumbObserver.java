package com.softspb.shell.browser.service;

import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.os.FileObserver;
import android.os.Handler;
import android.os.Looper;
import com.softspb.shell.SDCardReceiver;
import com.softspb.shell.SDCardReceiver.SDCardListener;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.io.File;
import java.util.HashMap;

abstract class HTCThumbObserver
  implements SDCardReceiver.SDCardListener
{
  static final String THUMB_FOLDER_HTC;
  static final String externalStoragePath = Environment.getExternalStorageDirectory().getPath();
  static final Logger logger;
  private final HashMap<String, String> filename2Url;
  private final ThumbHandler handler;
  private FileObserver thumbFolderObserver;

  static
  {
    StringBuilder localStringBuilder = new StringBuilder();
    String str = externalStoragePath;
    THUMB_FOLDER_HTC = str + "/" + ".bookmark_thumb1";
    logger = Loggers.getLogger(HTCThumbObserver.class.getName());
  }

  HTCThumbObserver(Looper paramLooper)
  {
    HashMap localHashMap = new HashMap();
    this.filename2Url = localHashMap;
    ThumbHandler localThumbHandler = new ThumbHandler(paramLooper);
    this.handler = localThumbHandler;
    ThumbFileObserver localThumbFileObserver = new ThumbFileObserver();
    this.thumbFolderObserver = localThumbFileObserver;
  }

  static String getEventDescription(int paramInt)
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    if ((paramInt & 0x1) != 0)
    {
      if (localStringBuilder1.length() > 0)
        StringBuilder localStringBuilder2 = localStringBuilder1.append(124);
      StringBuilder localStringBuilder3 = localStringBuilder1.append("ACCESS");
    }
    if ((paramInt & 0x4) != 0)
    {
      if (localStringBuilder1.length() > 0)
        StringBuilder localStringBuilder4 = localStringBuilder1.append(124);
      StringBuilder localStringBuilder5 = localStringBuilder1.append("ATTRIB");
    }
    if ((paramInt & 0x10) != 0)
    {
      if (localStringBuilder1.length() > 0)
        StringBuilder localStringBuilder6 = localStringBuilder1.append(124);
      StringBuilder localStringBuilder7 = localStringBuilder1.append("CLOSE_NOWRITE");
    }
    if ((paramInt & 0x8) != 0)
    {
      if (localStringBuilder1.length() > 0)
        StringBuilder localStringBuilder8 = localStringBuilder1.append(124);
      StringBuilder localStringBuilder9 = localStringBuilder1.append("CLOSE_WRITE");
    }
    if ((paramInt & 0x100) != 0)
    {
      if (localStringBuilder1.length() > 0)
        StringBuilder localStringBuilder10 = localStringBuilder1.append(124);
      StringBuilder localStringBuilder11 = localStringBuilder1.append("CREATE");
    }
    if ((paramInt & 0x200) != 0)
    {
      if (localStringBuilder1.length() > 0)
        StringBuilder localStringBuilder12 = localStringBuilder1.append(124);
      StringBuilder localStringBuilder13 = localStringBuilder1.append("DELETE");
    }
    if ((paramInt & 0x400) != 0)
    {
      if (localStringBuilder1.length() > 0)
        StringBuilder localStringBuilder14 = localStringBuilder1.append(124);
      StringBuilder localStringBuilder15 = localStringBuilder1.append("DELETE_SELF");
    }
    if ((paramInt & 0x2) != 0)
    {
      if (localStringBuilder1.length() > 0)
        StringBuilder localStringBuilder16 = localStringBuilder1.append(124);
      StringBuilder localStringBuilder17 = localStringBuilder1.append("MODIFY");
    }
    if ((paramInt & 0x800) != 0)
    {
      if (localStringBuilder1.length() > 0)
        StringBuilder localStringBuilder18 = localStringBuilder1.append(124);
      StringBuilder localStringBuilder19 = localStringBuilder1.append("MOVE_SELF");
    }
    if ((paramInt & 0x40) != 0)
    {
      if (localStringBuilder1.length() > 0)
        StringBuilder localStringBuilder20 = localStringBuilder1.append(124);
      StringBuilder localStringBuilder21 = localStringBuilder1.append("MOVED_FROM");
    }
    if ((paramInt & 0x80) != 0)
    {
      if (localStringBuilder1.length() > 0)
        StringBuilder localStringBuilder22 = localStringBuilder1.append(124);
      StringBuilder localStringBuilder23 = localStringBuilder1.append("MOVED_TO");
    }
    if ((paramInt & 0x20) != 0)
    {
      if (localStringBuilder1.length() > 0)
        StringBuilder localStringBuilder24 = localStringBuilder1.append(124);
      StringBuilder localStringBuilder25 = localStringBuilder1.append("OPEN");
    }
    return localStringBuilder1.toString();
  }

  void addURL(String paramString)
  {
    String str = HTCBrowserUtils.getHTCThumbnailFilename(paramString);
    Object localObject = this.filename2Url.put(str, paramString);
  }

  public void onReceive(Intent paramIntent)
  {
    String str1 = paramIntent.getAction();
    Uri localUri = paramIntent.getData();
    if (localUri != null)
    {
      String str2 = localUri.getScheme();
      if ("file".equals(str2))
      {
        String str3 = externalStoragePath;
        String str4 = localUri.getPath();
        if (str3.equals(str4))
        {
          if (!"android.intent.action.MEDIA_MOUNTED".equals(str1))
            break label68;
          this.thumbFolderObserver.startWatching();
        }
      }
    }
    while (true)
    {
      return;
      label68: if ("android.intent.action.MEDIA_UNMOUNTED".equals(str1))
      {
        this.thumbFolderObserver.stopWatching();
        continue;
      }
    }
  }

  abstract void onThumbChanged(String paramString);

  void removeUrl(String paramString)
  {
    String str = HTCBrowserUtils.getHTCThumbnailFilename(paramString);
    Object localObject = this.filename2Url.remove(str);
  }

  void start()
  {
    this.thumbFolderObserver.startWatching();
    SDCardReceiver.registerListener(this);
  }

  void stop()
  {
    this.thumbFolderObserver.stopWatching();
    this.handler.removeCallbacksAndMessages(null);
    SDCardReceiver.unregisterListener(this);
  }

  class ThumbFileObserver extends FileObserver
  {
    ThumbFileObserver()
    {
      super(520);
    }

    public void onEvent(int paramInt, String paramString)
    {
      Logger localLogger = HTCThumbObserver.logger;
      StringBuilder localStringBuilder = new StringBuilder().append("File system event: event=");
      String str1 = HTCThumbObserver.getEventDescription(paramInt);
      String str2 = str1 + " path=" + paramString;
      localLogger.d(str2);
      if ((paramInt & 0x208) != 0)
      {
        String str3 = (String)HTCThumbObserver.this.filename2Url.get(paramString);
        if (str3 != null)
        {
          HTCThumbObserver.ThumbHandler localThumbHandler = HTCThumbObserver.this.handler;
          HTCThumbObserver.ThumbFileObserver.1 local1 = new HTCThumbObserver.ThumbFileObserver.1(this, str3);
          boolean bool = localThumbHandler.post(local1);
        }
      }
    }
  }

  class ThumbHandler extends Handler
  {
    ThumbHandler(Looper arg2)
    {
      super();
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.browser.service.HTCThumbObserver
 * JD-Core Version:    0.6.0
 */