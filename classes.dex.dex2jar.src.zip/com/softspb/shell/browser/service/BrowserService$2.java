package com.softspb.shell.browser.service;

import android.database.ContentObserver;
import android.os.Handler;

class BrowserService$2 extends ContentObserver
{
  public void onChange(boolean paramBoolean)
  {
    BrowserService.access$500("onReceive >>>");
    BrowserService.access$000(this.this$0);
    BrowserService.access$500("onReceive <<<");
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.browser.service.BrowserService.2
 * JD-Core Version:    0.6.0
 */