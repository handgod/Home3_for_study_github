package com.softspb.shell.browser.service;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;

class BrowserClient$2
  implements ServiceConnection
{
  public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
  {
    BrowserClient.logd("onServiceConnected: " + paramComponentName);
    BrowserClient localBrowserClient1 = this.this$0;
    IBrowserService localIBrowserService1 = IBrowserService.Stub.asInterface(paramIBinder);
    localBrowserClient1.service = localIBrowserService1;
    try
    {
      IBrowserService localIBrowserService2 = this.this$0.service;
      IBrowserServiceCallback localIBrowserServiceCallback = this.this$0.serviceCallback;
      localIBrowserService2.registerCallback(localIBrowserServiceCallback);
      BrowserClient localBrowserClient2 = this.this$0;
      BrowserConfiguration localBrowserConfiguration = this.this$0.service.getBrowserConfiguration();
      localBrowserClient2.browserConfiguration = localBrowserConfiguration;
      BrowserClient localBrowserClient3 = this.this$0;
      boolean bool1 = this.this$0.browserConfiguration.isHtcBrowser;
      localBrowserClient3.isHtcBrowser = bool1;
      this.this$0.isReady = 1;
      StringBuilder localStringBuilder = new StringBuilder().append("onServiceConnected: connected to service, isHtcBrowser=");
      boolean bool2 = this.this$0.isHtcBrowser;
      BrowserClient.logd(bool2);
      this.this$0.onConnected();
      return;
    }
    catch (RemoteException localRemoteException)
    {
      while (true)
        BrowserClient.logd("onServiceConnected <<< remote exception while sending REGISTER");
    }
  }

  public void onServiceDisconnected(ComponentName paramComponentName)
  {
    BrowserClient.logd("onServiceDisconnected: " + paramComponentName);
    this.this$0.service = null;
    this.this$0.onDisconnected();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.browser.service.BrowserClient.2
 * JD-Core Version:    0.6.0
 */