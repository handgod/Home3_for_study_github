package com.softspb.shell.browser.service;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class BrowserConfiguration
  implements Parcelable
{
  public static final Parcelable.Creator<BrowserConfiguration> CREATOR = new BrowserConfiguration.1();
  public final boolean isHtcBrowser;

  private BrowserConfiguration(Parcel paramParcel)
  {
    if (paramParcel.readInt() != 0);
    for (int i = 1; ; i = 0)
    {
      this.isHtcBrowser = i;
      return;
    }
  }

  BrowserConfiguration(boolean paramBoolean)
  {
    this.isHtcBrowser = paramBoolean;
  }

  public int describeContents()
  {
    return 0;
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    if (this.isHtcBrowser);
    for (int i = 1; ; i = 0)
    {
      paramParcel.writeInt(i);
      return;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.browser.service.BrowserConfiguration
 * JD-Core Version:    0.6.0
 */