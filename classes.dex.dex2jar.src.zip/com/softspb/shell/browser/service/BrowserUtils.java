package com.softspb.shell.browser.service;

public class BrowserUtils
{
  static final int BOOKMARK_ICON_INDEX;
  static final String[] BOOKMARK_ICON_PROJECTION;

  static
  {
    String[] arrayOfString = new String[1];
    arrayOfString[0] = "favicon";
    BOOKMARK_ICON_PROJECTION = arrayOfString;
  }

  // ERROR //
  public static android.graphics.Bitmap loadIcon(android.content.ContentResolver paramContentResolver, int paramInt, com.softspb.util.log.Logger paramLogger)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: new 26	java/lang/StringBuilder
    //   5: dup
    //   6: invokespecial 27	java/lang/StringBuilder:<init>	()V
    //   9: ldc 29
    //   11: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   14: iload_1
    //   15: invokevirtual 36	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   18: invokevirtual 40	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   21: astore 4
    //   23: aload_2
    //   24: aload 4
    //   26: invokevirtual 46	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   29: getstatic 52	android/provider/Browser:BOOKMARKS_URI	Landroid/net/Uri;
    //   32: astore 5
    //   34: iload_1
    //   35: i2l
    //   36: lstore 6
    //   38: aload 5
    //   40: lload 6
    //   42: invokestatic 58	android/content/ContentUris:withAppendedId	(Landroid/net/Uri;J)Landroid/net/Uri;
    //   45: astore 8
    //   47: getstatic 17	com/softspb/shell/browser/service/BrowserUtils:BOOKMARK_ICON_PROJECTION	[Ljava/lang/String;
    //   50: astore 9
    //   52: aload_0
    //   53: aload 8
    //   55: aload 9
    //   57: ldc 60
    //   59: aconst_null
    //   60: aconst_null
    //   61: invokevirtual 66	android/content/ContentResolver:query	(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   64: astore 10
    //   66: aload 10
    //   68: ifnull +104 -> 172
    //   71: aload 10
    //   73: invokeinterface 72 1 0
    //   78: ifeq +94 -> 172
    //   81: aload 10
    //   83: iconst_0
    //   84: invokeinterface 76 2 0
    //   89: astore 11
    //   91: aconst_null
    //   92: astore_3
    //   93: aload 11
    //   95: ifnull +63 -> 158
    //   98: new 26	java/lang/StringBuilder
    //   101: dup
    //   102: invokespecial 27	java/lang/StringBuilder:<init>	()V
    //   105: ldc 78
    //   107: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   110: astore 12
    //   112: aload 11
    //   114: arraylength
    //   115: istore 13
    //   117: aload 12
    //   119: iload 13
    //   121: invokevirtual 36	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   124: ldc 80
    //   126: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   129: invokevirtual 40	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   132: astore 14
    //   134: aload_2
    //   135: aload 14
    //   137: invokevirtual 46	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   140: aload 11
    //   142: arraylength
    //   143: istore 15
    //   145: aload 11
    //   147: iconst_0
    //   148: iload 15
    //   150: invokestatic 86	android/graphics/BitmapFactory:decodeByteArray	([BII)Landroid/graphics/Bitmap;
    //   153: astore 16
    //   155: aload 16
    //   157: astore_3
    //   158: aload 10
    //   160: ifnull +10 -> 170
    //   163: aload 10
    //   165: invokeinterface 89 1 0
    //   170: aload_3
    //   171: areturn
    //   172: aload 10
    //   174: ifnull -4 -> 170
    //   177: aload 10
    //   179: invokeinterface 89 1 0
    //   184: goto -14 -> 170
    //   187: astore 17
    //   189: goto -19 -> 170
    //   192: astore 18
    //   194: aload 10
    //   196: ifnull +10 -> 206
    //   199: aload 10
    //   201: invokeinterface 89 1 0
    //   206: aload 18
    //   208: athrow
    //   209: astore 19
    //   211: goto -41 -> 170
    //   214: astore 20
    //   216: goto -10 -> 206
    //
    // Exception table:
    //   from	to	target	type
    //   177	184	187	java/lang/Exception
    //   29	155	192	finally
    //   163	170	209	java/lang/Exception
    //   199	206	214	java/lang/Exception
  }

  // ERROR //
  public static android.graphics.Bitmap loadThumbnail(android.content.ContentResolver paramContentResolver, int paramInt, boolean paramBoolean, com.softspb.util.log.Logger paramLogger)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 4
    //   3: new 26	java/lang/StringBuilder
    //   6: dup
    //   7: invokespecial 27	java/lang/StringBuilder:<init>	()V
    //   10: ldc 93
    //   12: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   15: iload_1
    //   16: invokevirtual 36	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   19: invokevirtual 40	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   22: astore 5
    //   24: aload_3
    //   25: aload 5
    //   27: invokevirtual 46	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   30: getstatic 52	android/provider/Browser:BOOKMARKS_URI	Landroid/net/Uri;
    //   33: astore 6
    //   35: iload_1
    //   36: i2l
    //   37: lstore 7
    //   39: aload 6
    //   41: lload 7
    //   43: invokestatic 58	android/content/ContentUris:withAppendedId	(Landroid/net/Uri;J)Landroid/net/Uri;
    //   46: astore 9
    //   48: aload_0
    //   49: aload 9
    //   51: aconst_null
    //   52: ldc 60
    //   54: aconst_null
    //   55: aconst_null
    //   56: invokevirtual 66	android/content/ContentResolver:query	(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   59: astore 10
    //   61: aload 10
    //   63: ifnull +187 -> 250
    //   66: aload 10
    //   68: invokeinterface 72 1 0
    //   73: ifeq +177 -> 250
    //   76: aconst_null
    //   77: astore 4
    //   79: aconst_null
    //   80: astore 11
    //   82: aload 10
    //   84: ldc 95
    //   86: invokeinterface 99 2 0
    //   91: istore 12
    //   93: iload 12
    //   95: bipush 255
    //   97: if_icmpeq +63 -> 160
    //   100: aload 10
    //   102: iload 12
    //   104: invokeinterface 76 2 0
    //   109: astore 11
    //   111: aload 11
    //   113: ifnonnull +73 -> 186
    //   116: aload_3
    //   117: ldc 101
    //   119: invokevirtual 104	com/softspb/util/log/Logger:w	(Ljava/lang/String;)V
    //   122: iload_2
    //   123: ifeq +11 -> 134
    //   126: iload_1
    //   127: aload 10
    //   129: invokestatic 110	com/softspb/shell/browser/service/HTCBrowserUtils:tryLoadHTCThumbnail	(ILandroid/database/Cursor;)Landroid/graphics/Bitmap;
    //   132: astore 4
    //   134: aload 4
    //   136: ifnonnull +9 -> 145
    //   139: aload_3
    //   140: ldc 112
    //   142: invokevirtual 104	com/softspb/util/log/Logger:w	(Ljava/lang/String;)V
    //   145: aload 10
    //   147: ifnull +10 -> 157
    //   150: aload 10
    //   152: invokeinterface 89 1 0
    //   157: aload 4
    //   159: areturn
    //   160: aload_3
    //   161: ldc 114
    //   163: invokevirtual 104	com/softspb/util/log/Logger:w	(Ljava/lang/String;)V
    //   166: goto -55 -> 111
    //   169: astore 13
    //   171: aload 10
    //   173: ifnull +10 -> 183
    //   176: aload 10
    //   178: invokeinterface 89 1 0
    //   183: aload 13
    //   185: athrow
    //   186: new 26	java/lang/StringBuilder
    //   189: dup
    //   190: invokespecial 27	java/lang/StringBuilder:<init>	()V
    //   193: ldc 116
    //   195: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   198: astore 14
    //   200: aload 11
    //   202: arraylength
    //   203: istore 15
    //   205: aload 14
    //   207: iload 15
    //   209: invokevirtual 36	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   212: ldc 118
    //   214: invokevirtual 33	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   217: invokevirtual 40	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   220: astore 16
    //   222: aload_3
    //   223: aload 16
    //   225: invokevirtual 46	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   228: aload 11
    //   230: arraylength
    //   231: istore 17
    //   233: aload 11
    //   235: iconst_0
    //   236: iload 17
    //   238: invokestatic 86	android/graphics/BitmapFactory:decodeByteArray	([BII)Landroid/graphics/Bitmap;
    //   241: astore 18
    //   243: aload 18
    //   245: astore 4
    //   247: goto -113 -> 134
    //   250: aload 10
    //   252: ifnull -95 -> 157
    //   255: aload 10
    //   257: invokeinterface 89 1 0
    //   262: goto -105 -> 157
    //   265: astore 19
    //   267: goto -110 -> 157
    //   270: astore 20
    //   272: goto -115 -> 157
    //   275: astore 21
    //   277: goto -94 -> 183
    //
    // Exception table:
    //   from	to	target	type
    //   30	145	169	finally
    //   160	166	169	finally
    //   186	243	169	finally
    //   255	262	265	java/lang/Exception
    //   150	157	270	java/lang/Exception
    //   176	183	275	java/lang/Exception
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.browser.service.BrowserUtils
 * JD-Core Version:    0.6.0
 */