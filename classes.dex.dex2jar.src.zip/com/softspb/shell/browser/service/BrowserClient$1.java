package com.softspb.shell.browser.service;

import android.os.RemoteException;

class BrowserClient$1 extends IBrowserServiceCallback.Stub
{
  public void onBookmarkDeleted(int paramInt)
    throws RemoteException
  {
    this.this$0.onBookmarkDeleted(paramInt);
  }

  public void onBookmarkUpdated(int paramInt, String paramString1, String paramString2)
    throws RemoteException
  {
    this.this$0.onBookmarkUpdated(paramInt, paramString1, paramString2);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.browser.service.BrowserClient.1
 * JD-Core Version:    0.6.0
 */