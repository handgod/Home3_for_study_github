package com.softspb.shell;

import android.content.pm.ActivityInfo;
import android.content.pm.ResolveInfo;
import com.softspb.shell.view.FilterPickDialogBuilder.IFilter;

class Home$17
  implements FilterPickDialogBuilder.IFilter
{
  public boolean filter(ResolveInfo paramResolveInfo)
  {
    String str1 = paramResolveInfo.activityInfo.packageName;
    String str2 = this.this$0.getPackageName();
    if (!str1.equalsIgnoreCase(str2));
    for (int i = 1; ; i = 0)
      return i;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.shell.Home.17
 * JD-Core Version:    0.6.0
 */