package com.softspb.util;

import android.util.Log;
import java.io.Closeable;
import java.io.IOException;

public class IOHelper
{
  private static final String LOG_TAG = "IOHelper";

  public static void closeSilent(Closeable paramCloseable)
  {
    if (paramCloseable != null);
    try
    {
      paramCloseable.close();
      return;
    }
    catch (IOException localIOException)
    {
      while (true)
        int i = Log.e("IOHelper", "error while trying to close stream", localIOException);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.IOHelper
 * JD-Core Version:    0.6.0
 */