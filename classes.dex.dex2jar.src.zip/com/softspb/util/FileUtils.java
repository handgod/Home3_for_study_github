package com.softspb.util;

import android.util.Log;

public final class FileUtils
{
  // ERROR //
  public static void copyAssetToFile(android.content.Context paramContext, String paramString, java.io.File paramFile)
    throws java.io.IOException
  {
    // Byte code:
    //   0: new 15	java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial 16	java/lang/StringBuilder:<init>	()V
    //   7: ldc 18
    //   9: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   12: astore_3
    //   13: aload_1
    //   14: astore 4
    //   16: aload_3
    //   17: aload 4
    //   19: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   22: ldc 24
    //   24: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   27: astore 5
    //   29: aload_2
    //   30: astore 6
    //   32: aload 5
    //   34: aload 6
    //   36: invokevirtual 27	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   39: invokevirtual 31	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   42: invokestatic 35	com/softspb/util/FileUtils:logd	(Ljava/lang/String;)V
    //   45: aconst_null
    //   46: astore 7
    //   48: iconst_0
    //   49: istore 8
    //   51: aload_0
    //   52: invokevirtual 41	android/content/Context:getAssets	()Landroid/content/res/AssetManager;
    //   55: astore 9
    //   57: aload_1
    //   58: astore 10
    //   60: aload 9
    //   62: aload 10
    //   64: invokevirtual 47	android/content/res/AssetManager:open	(Ljava/lang/String;)Ljava/io/InputStream;
    //   67: astore 11
    //   69: new 15	java/lang/StringBuilder
    //   72: dup
    //   73: invokespecial 16	java/lang/StringBuilder:<init>	()V
    //   76: ldc 49
    //   78: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   81: astore 12
    //   83: aload_1
    //   84: astore 13
    //   86: aload 12
    //   88: aload 13
    //   90: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   93: invokevirtual 31	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   96: invokestatic 35	com/softspb/util/FileUtils:logd	(Ljava/lang/String;)V
    //   99: aload_2
    //   100: invokevirtual 55	java/io/File:getParentFile	()Ljava/io/File;
    //   103: astore 14
    //   105: new 15	java/lang/StringBuilder
    //   108: dup
    //   109: invokespecial 16	java/lang/StringBuilder:<init>	()V
    //   112: ldc 57
    //   114: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   117: astore 15
    //   119: aload 14
    //   121: ifnonnull +335 -> 456
    //   124: ldc 59
    //   126: astore 16
    //   128: aload 15
    //   130: aload 16
    //   132: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   135: invokevirtual 31	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   138: invokestatic 35	com/softspb/util/FileUtils:logd	(Ljava/lang/String;)V
    //   141: aload 14
    //   143: ifnull +327 -> 470
    //   146: aload 14
    //   148: invokevirtual 63	java/io/File:exists	()Z
    //   151: ifeq +319 -> 470
    //   154: ldc 64
    //   156: istore 17
    //   158: new 15	java/lang/StringBuilder
    //   161: dup
    //   162: invokespecial 16	java/lang/StringBuilder:<init>	()V
    //   165: ldc 66
    //   167: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   170: iload 17
    //   172: invokevirtual 69	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
    //   175: invokevirtual 31	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   178: invokestatic 35	com/softspb/util/FileUtils:logd	(Ljava/lang/String;)V
    //   181: aload 14
    //   183: ifnull +131 -> 314
    //   186: iload 17
    //   188: ifne +126 -> 314
    //   191: new 15	java/lang/StringBuilder
    //   194: dup
    //   195: invokespecial 16	java/lang/StringBuilder:<init>	()V
    //   198: ldc 71
    //   200: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   203: astore 18
    //   205: aload 14
    //   207: invokevirtual 74	java/io/File:getPath	()Ljava/lang/String;
    //   210: astore 19
    //   212: aload 18
    //   214: aload 19
    //   216: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   219: invokevirtual 31	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   222: invokestatic 35	com/softspb/util/FileUtils:logd	(Ljava/lang/String;)V
    //   225: aload 14
    //   227: invokevirtual 77	java/io/File:mkdirs	()Z
    //   230: ifne +50 -> 280
    //   233: new 15	java/lang/StringBuilder
    //   236: dup
    //   237: invokespecial 16	java/lang/StringBuilder:<init>	()V
    //   240: ldc 79
    //   242: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   245: astore 20
    //   247: aload 14
    //   249: invokevirtual 74	java/io/File:getPath	()Ljava/lang/String;
    //   252: astore 21
    //   254: aload 20
    //   256: aload 21
    //   258: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   261: ldc 81
    //   263: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   266: invokevirtual 31	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   269: astore 22
    //   271: ldc 83
    //   273: aload 22
    //   275: invokestatic 89	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   278: istore 23
    //   280: new 15	java/lang/StringBuilder
    //   283: dup
    //   284: invokespecial 16	java/lang/StringBuilder:<init>	()V
    //   287: ldc 91
    //   289: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   292: astore 24
    //   294: aload 14
    //   296: invokevirtual 74	java/io/File:getPath	()Ljava/lang/String;
    //   299: astore 25
    //   301: aload 24
    //   303: aload 25
    //   305: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   308: invokevirtual 31	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   311: invokestatic 35	com/softspb/util/FileUtils:logd	(Ljava/lang/String;)V
    //   314: aload_2
    //   315: astore 26
    //   317: new 93	java/io/FileOutputStream
    //   320: dup
    //   321: aload 26
    //   323: invokespecial 96	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   326: astore 27
    //   328: new 15	java/lang/StringBuilder
    //   331: dup
    //   332: invokespecial 16	java/lang/StringBuilder:<init>	()V
    //   335: ldc 98
    //   337: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   340: astore 28
    //   342: aload_2
    //   343: invokevirtual 74	java/io/File:getPath	()Ljava/lang/String;
    //   346: astore 29
    //   348: aload 28
    //   350: aload 29
    //   352: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   355: invokevirtual 31	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   358: invokestatic 35	com/softspb/util/FileUtils:logd	(Ljava/lang/String;)V
    //   361: sipush 1024
    //   364: newarray byte
    //   366: astore 30
    //   368: iconst_0
    //   369: istore 31
    //   371: iconst_0
    //   372: istore 32
    //   374: aload 11
    //   376: aload 30
    //   378: invokevirtual 104	java/io/InputStream:read	([B)I
    //   381: istore 33
    //   383: iload 33
    //   385: bipush 255
    //   387: if_icmpeq +90 -> 477
    //   390: aload 27
    //   392: aload 30
    //   394: iconst_0
    //   395: iload 33
    //   397: invokevirtual 110	java/io/OutputStream:write	([BII)V
    //   400: iload 31
    //   402: iload 33
    //   404: iadd
    //   405: istore 31
    //   407: iload 32
    //   409: iconst_1
    //   410: iadd
    //   411: istore 34
    //   413: iload 32
    //   415: bipush 100
    //   417: irem
    //   418: ifne +454 -> 872
    //   421: new 15	java/lang/StringBuilder
    //   424: dup
    //   425: invokespecial 16	java/lang/StringBuilder:<init>	()V
    //   428: ldc 112
    //   430: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   433: iload 31
    //   435: invokevirtual 115	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   438: ldc 117
    //   440: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   443: invokevirtual 31	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   446: invokestatic 35	com/softspb/util/FileUtils:logd	(Ljava/lang/String;)V
    //   449: iload 34
    //   451: istore 32
    //   453: goto -79 -> 374
    //   456: aload 14
    //   458: invokevirtual 74	java/io/File:getPath	()Ljava/lang/String;
    //   461: astore 35
    //   463: aload 35
    //   465: astore 16
    //   467: goto -339 -> 128
    //   470: ldc 118
    //   472: istore 17
    //   474: goto -316 -> 158
    //   477: ldc 120
    //   479: invokestatic 35	com/softspb/util/FileUtils:logd	(Ljava/lang/String;)V
    //   482: aload 11
    //   484: ifnull +13 -> 497
    //   487: aload 11
    //   489: invokevirtual 123	java/io/InputStream:close	()V
    //   492: ldc 125
    //   494: invokestatic 35	com/softspb/util/FileUtils:logd	(Ljava/lang/String;)V
    //   497: aload 27
    //   499: ifnull +13 -> 512
    //   502: aload 27
    //   504: invokevirtual 126	java/io/OutputStream:close	()V
    //   507: ldc 128
    //   509: invokestatic 35	com/softspb/util/FileUtils:logd	(Ljava/lang/String;)V
    //   512: iconst_0
    //   513: ifeq +75 -> 588
    //   516: new 15	java/lang/StringBuilder
    //   519: dup
    //   520: invokespecial 16	java/lang/StringBuilder:<init>	()V
    //   523: ldc 130
    //   525: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   528: astore 36
    //   530: aload_2
    //   531: invokevirtual 74	java/io/File:getPath	()Ljava/lang/String;
    //   534: astore 37
    //   536: aload 36
    //   538: aload 37
    //   540: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   543: invokevirtual 31	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   546: invokestatic 35	com/softspb/util/FileUtils:logd	(Ljava/lang/String;)V
    //   549: aload_2
    //   550: invokevirtual 133	java/io/File:delete	()Z
    //   553: istore 38
    //   555: new 15	java/lang/StringBuilder
    //   558: dup
    //   559: invokespecial 16	java/lang/StringBuilder:<init>	()V
    //   562: ldc 135
    //   564: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   567: astore 39
    //   569: aload_2
    //   570: invokevirtual 74	java/io/File:getPath	()Ljava/lang/String;
    //   573: astore 40
    //   575: aload 39
    //   577: aload 40
    //   579: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   582: invokevirtual 31	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   585: invokestatic 35	com/softspb/util/FileUtils:logd	(Ljava/lang/String;)V
    //   588: return
    //   589: astore 41
    //   591: new 15	java/lang/StringBuilder
    //   594: dup
    //   595: invokespecial 16	java/lang/StringBuilder:<init>	()V
    //   598: ldc 137
    //   600: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   603: aload 41
    //   605: invokevirtual 27	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   608: invokevirtual 31	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   611: aload 41
    //   613: invokestatic 141	com/softspb/util/FileUtils:loge	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   616: iconst_1
    //   617: istore 8
    //   619: aload 41
    //   621: athrow
    //   622: astore 16
    //   624: aload 11
    //   626: ifnull +13 -> 639
    //   629: aload 11
    //   631: invokevirtual 123	java/io/InputStream:close	()V
    //   634: ldc 125
    //   636: invokestatic 35	com/softspb/util/FileUtils:logd	(Ljava/lang/String;)V
    //   639: aload 7
    //   641: ifnull +13 -> 654
    //   644: aload 7
    //   646: invokevirtual 126	java/io/OutputStream:close	()V
    //   649: ldc 128
    //   651: invokestatic 35	com/softspb/util/FileUtils:logd	(Ljava/lang/String;)V
    //   654: iload 8
    //   656: ifeq +75 -> 731
    //   659: new 15	java/lang/StringBuilder
    //   662: dup
    //   663: invokespecial 16	java/lang/StringBuilder:<init>	()V
    //   666: ldc 130
    //   668: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   671: astore 42
    //   673: aload_2
    //   674: invokevirtual 74	java/io/File:getPath	()Ljava/lang/String;
    //   677: astore 43
    //   679: aload 42
    //   681: aload 43
    //   683: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   686: invokevirtual 31	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   689: invokestatic 35	com/softspb/util/FileUtils:logd	(Ljava/lang/String;)V
    //   692: aload_2
    //   693: invokevirtual 133	java/io/File:delete	()Z
    //   696: istore 44
    //   698: new 15	java/lang/StringBuilder
    //   701: dup
    //   702: invokespecial 16	java/lang/StringBuilder:<init>	()V
    //   705: ldc 135
    //   707: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   710: astore 45
    //   712: aload_2
    //   713: invokevirtual 74	java/io/File:getPath	()Ljava/lang/String;
    //   716: astore 46
    //   718: aload 45
    //   720: aload 46
    //   722: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   725: invokevirtual 31	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   728: invokestatic 35	com/softspb/util/FileUtils:logd	(Ljava/lang/String;)V
    //   731: aload 16
    //   733: athrow
    //   734: astore 47
    //   736: new 15	java/lang/StringBuilder
    //   739: dup
    //   740: invokespecial 16	java/lang/StringBuilder:<init>	()V
    //   743: ldc 143
    //   745: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   748: aload 47
    //   750: invokevirtual 27	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   753: invokevirtual 31	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   756: aload 47
    //   758: invokestatic 141	com/softspb/util/FileUtils:loge	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   761: goto -122 -> 639
    //   764: astore 48
    //   766: new 15	java/lang/StringBuilder
    //   769: dup
    //   770: invokespecial 16	java/lang/StringBuilder:<init>	()V
    //   773: ldc 145
    //   775: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   778: aload 48
    //   780: invokevirtual 27	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   783: invokevirtual 31	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   786: aload 48
    //   788: invokestatic 141	com/softspb/util/FileUtils:loge	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   791: goto -137 -> 654
    //   794: astore 49
    //   796: new 15	java/lang/StringBuilder
    //   799: dup
    //   800: invokespecial 16	java/lang/StringBuilder:<init>	()V
    //   803: ldc 143
    //   805: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   808: aload 49
    //   810: invokevirtual 27	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   813: invokevirtual 31	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   816: aload 49
    //   818: invokestatic 141	com/softspb/util/FileUtils:loge	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   821: goto -324 -> 497
    //   824: astore 50
    //   826: new 15	java/lang/StringBuilder
    //   829: dup
    //   830: invokespecial 16	java/lang/StringBuilder:<init>	()V
    //   833: ldc 145
    //   835: invokevirtual 22	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   838: aload 50
    //   840: invokevirtual 27	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   843: invokevirtual 31	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   846: aload 50
    //   848: invokestatic 141	com/softspb/util/FileUtils:loge	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   851: goto -339 -> 512
    //   854: astore 16
    //   856: aload 27
    //   858: astore 7
    //   860: goto -236 -> 624
    //   863: astore 41
    //   865: aload 27
    //   867: astore 7
    //   869: goto -278 -> 591
    //   872: iload 34
    //   874: istore 32
    //   876: goto -502 -> 374
    //
    // Exception table:
    //   from	to	target	type
    //   51	328	589	java/io/IOException
    //   456	463	589	java/io/IOException
    //   51	328	622	finally
    //   456	463	622	finally
    //   591	622	622	finally
    //   629	639	734	java/io/IOException
    //   644	654	764	java/io/IOException
    //   487	497	794	java/io/IOException
    //   502	512	824	java/io/IOException
    //   328	449	854	finally
    //   477	482	854	finally
    //   328	449	863	java/io/IOException
    //   477	482	863	java/io/IOException
  }

  static void logd(String paramString)
  {
  }

  static void loge(String paramString, Throwable paramThrowable)
  {
    int i = Log.e("FileUtils", paramString, paramThrowable);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.FileUtils
 * JD-Core Version:    0.6.0
 */