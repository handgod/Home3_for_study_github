package com.softspb.util;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

public class DelayedHandler extends Handler
{
  static final int MSG_DO_UPDATE = 10002;
  static final int MSG_INCOMING_UPDATE = 10001;
  long thresholdMs;

  public DelayedHandler(long paramLong)
  {
    this.thresholdMs = paramLong;
  }

  public DelayedHandler(Looper paramLooper, long paramLong)
  {
    super(paramLooper);
    this.thresholdMs = paramLong;
  }

  public void handleDelayed(Runnable paramRunnable)
  {
    Message localMessage = Message.obtain(this, 10001, paramRunnable);
    boolean bool = sendMessage(localMessage);
  }

  public void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default:
    case 10001:
    case 10002:
    }
    while (true)
    {
      return;
      Object localObject1 = paramMessage.obj;
      Message localMessage = Message.obtain(this, 10002, localObject1);
      long l = this.thresholdMs;
      boolean bool = sendMessageDelayed(localMessage, l);
      continue;
      Object localObject2 = paramMessage.obj;
      if (hasMessages(10002, localObject2))
        continue;
      ((Runnable)paramMessage.obj).run();
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.DelayedHandler
 * JD-Core Version:    0.6.0
 */