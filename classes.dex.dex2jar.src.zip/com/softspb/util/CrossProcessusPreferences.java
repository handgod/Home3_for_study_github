package com.softspb.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.content.pm.PackageManager.NameNotFoundException;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

public class CrossProcessusPreferences
  implements SharedPreferences
{
  private static final String CHANGED_KEYS = "changed_keys";
  protected String mAction;
  private final LinkedList<SharedPreferences.OnSharedPreferenceChangeListener> mListeners;
  protected String mPrefsName;
  protected Context targetContext;
  PrefsChangedReceiver updatePrefsReceiver;

  public CrossProcessusPreferences(Context paramContext, String paramString1, String paramString2)
  {
    PrefsChangedReceiver localPrefsChangedReceiver1 = new PrefsChangedReceiver();
    this.updatePrefsReceiver = localPrefsChangedReceiver1;
    LinkedList localLinkedList = new LinkedList();
    this.mListeners = localLinkedList;
    try
    {
      Context localContext1 = paramContext.createPackageContext(paramString1, 0);
      this.targetContext = localContext1;
      this.mPrefsName = paramString2;
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str1 = this.targetContext.getPackageName();
      StringBuilder localStringBuilder2 = localStringBuilder1.append(str1).append(".action.UPDATE_PREFS.");
      String str2 = this.mPrefsName;
      String str3 = str2;
      this.mAction = str3;
      Context localContext2 = this.targetContext;
      PrefsChangedReceiver localPrefsChangedReceiver2 = this.updatePrefsReceiver;
      String str4 = this.mAction;
      IntentFilter localIntentFilter = new IntentFilter(str4);
      Intent localIntent = localContext2.registerReceiver(localPrefsChangedReceiver2, localIntentFilter);
      return;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      while (true)
        this.targetContext = paramContext;
    }
  }

  private SharedPreferences getSharedPreferences()
  {
    Context localContext = this.targetContext;
    String str = this.mPrefsName;
    return localContext.getSharedPreferences(str, 0);
  }

  void broadcastPrefsChanged(HashSet<String> paramHashSet)
  {
    if (this.targetContext != null)
    {
      String str = this.mAction;
      Intent localIntent1 = new Intent(str);
      String[] arrayOfString1 = new String[paramHashSet.size()];
      String[] arrayOfString2 = (String[])paramHashSet.toArray(arrayOfString1);
      Intent localIntent2 = localIntent1.putExtra("changed_keys", arrayOfString2);
      this.targetContext.sendBroadcast(localIntent1);
    }
  }

  public boolean contains(String paramString)
  {
    SharedPreferences localSharedPreferences = getSharedPreferences();
    if ((localSharedPreferences != null) && (localSharedPreferences.contains(paramString)));
    for (int i = 1; ; i = 0)
      return i;
  }

  public void dispose()
  {
    Context localContext = this.targetContext;
    PrefsChangedReceiver localPrefsChangedReceiver = this.updatePrefsReceiver;
    localContext.unregisterReceiver(localPrefsChangedReceiver);
  }

  public SharedPreferences.Editor edit()
  {
    SharedPreferences.Editor localEditor = getSharedPreferences().edit();
    return new EditorNotifier(localEditor);
  }

  public Map<String, ?> getAll()
  {
    SharedPreferences localSharedPreferences = getSharedPreferences();
    if (localSharedPreferences != null);
    for (Map localMap = localSharedPreferences.getAll(); ; localMap = Collections.emptyMap())
      return localMap;
  }

  public boolean getBoolean(String paramString, boolean paramBoolean)
  {
    SharedPreferences localSharedPreferences = getSharedPreferences();
    if (localSharedPreferences != null)
      paramBoolean = localSharedPreferences.getBoolean(paramString, paramBoolean);
    return paramBoolean;
  }

  public float getFloat(String paramString, float paramFloat)
  {
    SharedPreferences localSharedPreferences = getSharedPreferences();
    if (localSharedPreferences != null)
      paramFloat = localSharedPreferences.getFloat(paramString, paramFloat);
    return paramFloat;
  }

  public int getInt(String paramString, int paramInt)
  {
    SharedPreferences localSharedPreferences = getSharedPreferences();
    if (localSharedPreferences != null)
      paramInt = localSharedPreferences.getInt(paramString, paramInt);
    return paramInt;
  }

  public long getLong(String paramString, long paramLong)
  {
    SharedPreferences localSharedPreferences = getSharedPreferences();
    if (localSharedPreferences != null);
    try
    {
      long l = localSharedPreferences.getLong(paramString, paramLong);
      paramLong = l;
      return paramLong;
    }
    catch (ClassCastException localClassCastException)
    {
      while (true)
      {
        int i = (int)paramLong;
        paramLong = localSharedPreferences.getInt(paramString, i);
      }
    }
  }

  public String getString(String paramString1, String paramString2)
  {
    SharedPreferences localSharedPreferences = getSharedPreferences();
    if (localSharedPreferences != null)
      paramString2 = localSharedPreferences.getString(paramString1, paramString2);
    return paramString2;
  }

  public Set<String> getStringSet(String paramString, Set<String> paramSet)
  {
    throw new UnsupportedOperationException();
  }

  void notifyPrefsChanged(String paramString)
  {
    Object localObject1 = getAll().get(paramString);
    synchronized (this.mListeners)
    {
      Iterator localIterator = this.mListeners.iterator();
      if (localIterator.hasNext())
        ((SharedPreferences.OnSharedPreferenceChangeListener)localIterator.next()).onSharedPreferenceChanged(this, paramString);
    }
    monitorexit;
  }

  public void registerOnSharedPreferenceChangeListener(SharedPreferences.OnSharedPreferenceChangeListener paramOnSharedPreferenceChangeListener)
  {
    SharedPreferences localSharedPreferences = getSharedPreferences();
    if (localSharedPreferences != null)
      localSharedPreferences.registerOnSharedPreferenceChangeListener(paramOnSharedPreferenceChangeListener);
    synchronized (this.mListeners)
    {
      if (!this.mListeners.contains(paramOnSharedPreferenceChangeListener))
        boolean bool = this.mListeners.add(paramOnSharedPreferenceChangeListener);
      return;
    }
  }

  public void unregisterOnSharedPreferenceChangeListener(SharedPreferences.OnSharedPreferenceChangeListener paramOnSharedPreferenceChangeListener)
  {
    SharedPreferences localSharedPreferences = getSharedPreferences();
    if (localSharedPreferences != null)
      localSharedPreferences.unregisterOnSharedPreferenceChangeListener(paramOnSharedPreferenceChangeListener);
    synchronized (this.mListeners)
    {
      boolean bool = this.mListeners.remove(paramOnSharedPreferenceChangeListener);
      return;
    }
  }

  class EditorNotifier
    implements SharedPreferences.Editor
  {
    HashSet<String> changedKeys;
    SharedPreferences.Editor mEditor;

    public EditorNotifier(SharedPreferences.Editor arg2)
    {
      HashSet localHashSet = new HashSet();
      this.changedKeys = localHashSet;
      Object localObject;
      this.mEditor = localObject;
    }

    public void apply()
    {
      throw new UnsupportedOperationException();
    }

    public SharedPreferences.Editor clear()
    {
      SharedPreferences.Editor localEditor = this.mEditor.clear();
      HashSet localHashSet = this.changedKeys;
      Set localSet = CrossProcessusPreferences.this.getAll().keySet();
      boolean bool = localHashSet.addAll(localSet);
      return this;
    }

    public boolean commit()
    {
      boolean bool = this.mEditor.commit();
      if (bool)
      {
        CrossProcessusPreferences localCrossProcessusPreferences = CrossProcessusPreferences.this;
        HashSet localHashSet = this.changedKeys;
        localCrossProcessusPreferences.broadcastPrefsChanged(localHashSet);
      }
      return bool;
    }

    public SharedPreferences.Editor putBoolean(String paramString, boolean paramBoolean)
    {
      SharedPreferences.Editor localEditor = this.mEditor.putBoolean(paramString, paramBoolean);
      boolean bool = this.changedKeys.add(paramString);
      return this;
    }

    public SharedPreferences.Editor putFloat(String paramString, float paramFloat)
    {
      SharedPreferences.Editor localEditor = this.mEditor.putFloat(paramString, paramFloat);
      boolean bool = this.changedKeys.add(paramString);
      return this;
    }

    public SharedPreferences.Editor putInt(String paramString, int paramInt)
    {
      SharedPreferences.Editor localEditor = this.mEditor.putInt(paramString, paramInt);
      boolean bool = this.changedKeys.add(paramString);
      return this;
    }

    public SharedPreferences.Editor putLong(String paramString, long paramLong)
    {
      SharedPreferences.Editor localEditor = this.mEditor.putLong(paramString, paramLong);
      boolean bool = this.changedKeys.add(paramString);
      return this;
    }

    public SharedPreferences.Editor putString(String paramString1, String paramString2)
    {
      SharedPreferences.Editor localEditor = this.mEditor.putString(paramString1, paramString2);
      boolean bool = this.changedKeys.add(paramString1);
      return this;
    }

    public SharedPreferences.Editor putStringSet(String paramString, Set<String> paramSet)
    {
      throw new UnsupportedOperationException();
    }

    public SharedPreferences.Editor remove(String paramString)
    {
      SharedPreferences.Editor localEditor = this.mEditor.remove(paramString);
      boolean bool = this.changedKeys.add(paramString);
      return this;
    }
  }

  class PrefsChangedReceiver extends BroadcastReceiver
  {
    WeakReference<CrossProcessusPreferences> ref;

    public PrefsChangedReceiver()
    {
      WeakReference localWeakReference = new WeakReference(this$1);
      this.ref = localWeakReference;
    }

    public void onReceive(Context paramContext, Intent paramIntent)
    {
      CrossProcessusPreferences localCrossProcessusPreferences = (CrossProcessusPreferences)this.ref.get();
      if (localCrossProcessusPreferences == null);
      while (true)
      {
        return;
        String[] arrayOfString1 = paramIntent.getStringArrayExtra("changed_keys");
        if (arrayOfString1 == null)
          continue;
        String[] arrayOfString2 = arrayOfString1;
        int i = arrayOfString2.length;
        int j = 0;
        while (j < i)
        {
          String str = arrayOfString2[j];
          localCrossProcessusPreferences.notifyPrefsChanged(str);
          j += 1;
        }
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.CrossProcessusPreferences
 * JD-Core Version:    0.6.0
 */