package com.softspb.util;

public class DeviceUtil
{
  private static final String DEVICE_ID = "device_id";
  private static final String EMPTY = "empty";

  // ERROR //
  public static String getDeviceId(android.content.Context paramContext)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic 26	android/preference/PreferenceManager:getDefaultSharedPreferences	(Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   4: ldc 9
    //   6: ldc 12
    //   8: invokeinterface 32 3 0
    //   13: astore_1
    //   14: aload_1
    //   15: ldc 12
    //   17: invokevirtual 38	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   20: ifeq +25 -> 45
    //   23: aload_0
    //   24: ldc 40
    //   26: invokevirtual 46	android/content/Context:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   29: checkcast 48	android/telephony/TelephonyManager
    //   32: invokevirtual 51	android/telephony/TelephonyManager:getDeviceId	()Ljava/lang/String;
    //   35: astore_2
    //   36: aload_2
    //   37: invokestatic 57	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   40: ifne +5 -> 45
    //   43: aload_2
    //   44: astore_1
    //   45: aload_1
    //   46: ldc 12
    //   48: invokevirtual 38	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   51: ifeq +22 -> 73
    //   54: aload_0
    //   55: invokevirtual 61	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   58: ldc 63
    //   60: invokestatic 68	android/provider/Settings$Secure:getString	(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;
    //   63: astore_3
    //   64: aload_3
    //   65: invokestatic 57	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   68: ifne +5 -> 73
    //   71: aload_3
    //   72: astore_1
    //   73: aload_1
    //   74: ldc 12
    //   76: invokevirtual 38	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   79: ifeq +35 -> 114
    //   82: aload_0
    //   83: ldc 70
    //   85: invokevirtual 46	android/content/Context:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   88: checkcast 72	android/net/wifi/WifiManager
    //   91: invokevirtual 76	android/net/wifi/WifiManager:getConnectionInfo	()Landroid/net/wifi/WifiInfo;
    //   94: astore 4
    //   96: aload 4
    //   98: ifnonnull +147 -> 245
    //   101: ldc 12
    //   103: astore_1
    //   104: aload_1
    //   105: invokestatic 57	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   108: ifeq +6 -> 114
    //   111: ldc 12
    //   113: astore_1
    //   114: aload_1
    //   115: ldc 12
    //   117: invokevirtual 38	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   120: ifeq +79 -> 199
    //   123: aconst_null
    //   124: astore 5
    //   126: invokestatic 82	java/lang/Runtime:getRuntime	()Ljava/lang/Runtime;
    //   129: ldc 84
    //   131: invokevirtual 88	java/lang/Runtime:exec	(Ljava/lang/String;)Ljava/lang/Process;
    //   134: astore 6
    //   136: aload 6
    //   138: invokevirtual 94	java/lang/Process:getInputStream	()Ljava/io/InputStream;
    //   141: astore 7
    //   143: new 96	java/io/InputStreamReader
    //   146: dup
    //   147: aload 7
    //   149: invokespecial 99	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;)V
    //   152: astore 8
    //   154: new 101	java/io/BufferedReader
    //   157: dup
    //   158: aload 8
    //   160: invokespecial 104	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
    //   163: astore 9
    //   165: aload 9
    //   167: invokevirtual 107	java/io/BufferedReader:readLine	()Ljava/lang/String;
    //   170: astore 10
    //   172: aload 10
    //   174: astore 11
    //   176: aload 11
    //   178: ifnull +6 -> 184
    //   181: aload 11
    //   183: astore_1
    //   184: aload 9
    //   186: invokestatic 113	com/softspb/util/IOHelper:closeSilent	(Ljava/io/Closeable;)V
    //   189: aload 6
    //   191: ifnull +8 -> 199
    //   194: aload 6
    //   196: invokevirtual 116	java/lang/Process:destroy	()V
    //   199: aload_0
    //   200: invokestatic 26	android/preference/PreferenceManager:getDefaultSharedPreferences	(Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   203: invokeinterface 120 1 0
    //   208: astore 12
    //   210: aload 12
    //   212: ldc 9
    //   214: aload_1
    //   215: invokeinterface 126 3 0
    //   220: astore 13
    //   222: aload 12
    //   224: invokeinterface 130 1 0
    //   229: istore 14
    //   231: aload_1
    //   232: ldc 12
    //   234: invokevirtual 38	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   237: ifeq +57 -> 294
    //   240: ldc 132
    //   242: astore_1
    //   243: aload_1
    //   244: areturn
    //   245: aload 4
    //   247: invokevirtual 137	android/net/wifi/WifiInfo:getMacAddress	()Ljava/lang/String;
    //   250: astore_1
    //   251: goto -147 -> 104
    //   254: astore 15
    //   256: aload 5
    //   258: invokestatic 113	com/softspb/util/IOHelper:closeSilent	(Ljava/io/Closeable;)V
    //   261: aload 6
    //   263: ifnull -64 -> 199
    //   266: aload 6
    //   268: invokevirtual 116	java/lang/Process:destroy	()V
    //   271: goto -72 -> 199
    //   274: astore 16
    //   276: aload 5
    //   278: invokestatic 113	com/softspb/util/IOHelper:closeSilent	(Ljava/io/Closeable;)V
    //   281: aload 6
    //   283: ifnull +8 -> 291
    //   286: aload 6
    //   288: invokevirtual 116	java/lang/Process:destroy	()V
    //   291: aload 16
    //   293: athrow
    //   294: aload_1
    //   295: invokevirtual 141	java/lang/String:hashCode	()I
    //   298: invokestatic 147	java/lang/Math:abs	(I)I
    //   301: invokestatic 151	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   304: astore_1
    //   305: goto -62 -> 243
    //   308: astore 16
    //   310: aload 9
    //   312: astore 5
    //   314: goto -38 -> 276
    //   317: astore 17
    //   319: aload 9
    //   321: astore 5
    //   323: goto -67 -> 256
    //
    // Exception table:
    //   from	to	target	type
    //   126	165	254	java/io/IOException
    //   126	165	274	finally
    //   165	172	308	finally
    //   165	172	317	java/io/IOException
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.DeviceUtil
 * JD-Core Version:    0.6.0
 */