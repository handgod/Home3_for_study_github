package com.softspb.util;

public abstract interface IIntListPreference
{
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.IIntListPreference
 * JD-Core Version:    0.6.0
 */