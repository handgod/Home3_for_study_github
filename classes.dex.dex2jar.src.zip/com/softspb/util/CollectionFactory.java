package com.softspb.util;

import android.util.SparseArray;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

public class CollectionFactory
{
  public static <T> ArrayList<T> newArrayList()
  {
    return new ArrayList();
  }

  public static <T> ArrayList<T> newArrayList(int paramInt)
  {
    return new ArrayList(paramInt);
  }

  public static <K, V> ConcurrentHashMap<K, V> newConcurentHashMap()
  {
    return new ConcurrentHashMap();
  }

  public static <K, V> HashMap<K, V> newHashMap()
  {
    return new HashMap();
  }

  public static <T> HashSet<T> newHashSet()
  {
    return new HashSet();
  }

  public static <T> LinkedList<T> newLinkedList()
  {
    return new LinkedList();
  }

  public static <T> LinkedList<T> newLinkedList(Collection<? extends T> paramCollection)
  {
    return new LinkedList(paramCollection);
  }

  public static <T> SparseArray<T> newSparseArray()
  {
    return new SparseArray();
  }

  public static <T> TreeSet<T> newTreeSet()
  {
    return new TreeSet();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.CollectionFactory
 * JD-Core Version:    0.6.0
 */