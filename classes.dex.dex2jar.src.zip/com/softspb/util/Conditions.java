package com.softspb.util;

public class Conditions
{
  public static void checkArgument(boolean paramBoolean)
  {
    if (!paramBoolean)
      throw new IllegalArgumentException();
  }

  public static void checkArgument(boolean paramBoolean, Object paramObject)
  {
    if (!paramBoolean)
    {
      String str = String.valueOf(paramObject);
      throw new IllegalArgumentException(str);
    }
  }

  public static void checkArgument(boolean paramBoolean, String paramString, Object[] paramArrayOfObject)
  {
    if (!paramBoolean)
    {
      String str = format(paramString, paramArrayOfObject);
      throw new IllegalArgumentException(str);
    }
  }

  public static <T> T checkNotNull(T paramT)
  {
    if (paramT == null)
      throw new NullPointerException();
    return paramT;
  }

  public static <T> T checkNotNull(T paramT, Object paramObject)
  {
    if (paramT == null)
    {
      String str = String.valueOf(paramObject);
      throw new NullPointerException(str);
    }
    return paramT;
  }

  public static <T> T checkNotNull(T paramT, String paramString, Object[] paramArrayOfObject)
  {
    if (paramT == null)
    {
      String str = format(paramString, paramArrayOfObject);
      throw new NullPointerException(str);
    }
    return paramT;
  }

  static String format(String paramString, Object[] paramArrayOfObject)
  {
    paramString = String.valueOf(paramString);
    int i = paramString.length();
    int j = paramArrayOfObject.length * 16;
    int k = i + j;
    StringBuilder localStringBuilder1 = new StringBuilder(k);
    int m = 0;
    int n = 0;
    while (true)
    {
      int i1 = paramArrayOfObject.length;
      int i2;
      if (n < i1)
      {
        i2 = paramString.indexOf("%s", m);
        if (i2 != -1);
      }
      else
      {
        String str1 = paramString.substring(m);
        StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
        int i3 = paramArrayOfObject.length;
        if (n >= i3)
          break;
        StringBuilder localStringBuilder3 = localStringBuilder1.append(" [");
        int i4 = n + 1;
        Object localObject1 = paramArrayOfObject[n];
        StringBuilder localStringBuilder4 = localStringBuilder1.append(localObject1);
        int i6;
        for (n = i4; ; n = i6)
        {
          int i5 = paramArrayOfObject.length;
          if (n >= i5)
            break;
          StringBuilder localStringBuilder5 = localStringBuilder1.append(", ");
          i6 = n + 1;
          Object localObject2 = paramArrayOfObject[n];
          StringBuilder localStringBuilder6 = localStringBuilder1.append(localObject2);
        }
      }
      String str2 = paramString.substring(m, i2);
      StringBuilder localStringBuilder7 = localStringBuilder1.append(str2);
      int i7 = n + 1;
      Object localObject3 = paramArrayOfObject[n];
      StringBuilder localStringBuilder8 = localStringBuilder1.append(localObject3);
      m = i2 + 2;
      n = i7;
      continue;
      StringBuilder localStringBuilder9 = localStringBuilder1.append(93);
    }
    return localStringBuilder1.toString();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.Conditions
 * JD-Core Version:    0.6.0
 */