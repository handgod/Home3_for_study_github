package com.softspb.util.broadcastreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import com.softspb.util.CollectionFactory;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class DecoratedBroadcastReceiver extends BroadcastReceiver
{
  private Map<String, IActionListener> listeners;

  public DecoratedBroadcastReceiver()
  {
    HashMap localHashMap = CollectionFactory.newHashMap();
    this.listeners = localHashMap;
  }

  public DecoratedBroadcastReceiver(String paramString, IActionListener paramIActionListener)
  {
    HashMap localHashMap = CollectionFactory.newHashMap();
    this.listeners = localHashMap;
    addActionListener(paramString, paramIActionListener);
  }

  public void addActionListener(String paramString, IActionListener paramIActionListener)
  {
    if (paramString == null)
      throw new IllegalArgumentException("action couldn't be null");
    if (paramIActionListener == null)
      throw new IllegalArgumentException("listener couldn't be null");
    Object localObject = this.listeners.put(paramString, paramIActionListener);
  }

  public IntentFilter getIntentFilter()
  {
    IntentFilter localIntentFilter = new IntentFilter();
    Iterator localIterator = this.listeners.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      localIntentFilter.addAction(str);
    }
    return localIntentFilter;
  }

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    Map localMap1 = this.listeners;
    String str1 = paramIntent.getAction();
    if (localMap1.containsKey(str1))
    {
      Map localMap2 = this.listeners;
      String str2 = paramIntent.getAction();
      ((IActionListener)localMap2.get(str2)).onAction(paramContext, paramIntent);
    }
  }

  public abstract interface IActionListener
  {
    public abstract void onAction(Context paramContext, Intent paramIntent);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.broadcastreceiver.DecoratedBroadcastReceiver
 * JD-Core Version:    0.6.0
 */