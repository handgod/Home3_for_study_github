package com.softspb.util;

import android.database.CharArrayBuffer;
import android.database.CrossProcessCursor;
import android.database.Cursor;
import android.database.CursorWindow;
import android.database.CursorWrapper;

public class ProjectionCursor extends CursorWrapper
  implements CrossProcessCursor
{
  int columnCount;
  CrossProcessCursor cursor;
  int[] indexMap;
  String[] projection;

  public ProjectionCursor(Cursor paramCursor, String[] paramArrayOfString)
  {
    super(paramCursor);
    CrossProcessCursor localCrossProcessCursor = (CrossProcessCursor)paramCursor;
    this.cursor = localCrossProcessCursor;
    this.projection = paramArrayOfString;
    int i = paramArrayOfString.length;
    this.columnCount = i;
    int[] arrayOfInt1 = new int[this.columnCount];
    this.indexMap = arrayOfInt1;
    int j = 0;
    while (true)
    {
      int k = this.columnCount;
      if (j >= k)
        break;
      String str1 = paramArrayOfString[j];
      int m = paramCursor.getColumnIndexOrThrow(str1);
      int[] arrayOfInt2 = this.indexMap;
      String str2 = paramArrayOfString[j];
      int n = paramCursor.getColumnIndex(str2);
      arrayOfInt2[j] = n;
      j += 1;
    }
  }

  public void copyStringToBuffer(int paramInt, CharArrayBuffer paramCharArrayBuffer)
  {
    int i = this.indexMap[paramInt];
    super.copyStringToBuffer(i, paramCharArrayBuffer);
  }

  public void fillWindow(int paramInt, CursorWindow paramCursorWindow)
  {
    this.cursor.fillWindow(paramInt, paramCursorWindow);
  }

  public byte[] getBlob(int paramInt)
  {
    int i = this.indexMap[paramInt];
    return super.getBlob(i);
  }

  public int getColumnCount()
  {
    return this.columnCount;
  }

  public int getColumnIndex(String paramString)
  {
    int i = 0;
    int j = this.columnCount;
    if (i < j)
      if (!this.projection[i].equals(paramString));
    while (true)
    {
      return i;
      i += 1;
      break;
      i = -1;
    }
  }

  public int getColumnIndexOrThrow(String paramString)
  {
    int i = getColumnIndex(paramString);
    if (i == -1)
    {
      String str = "Column " + paramString + " doesn't exist";
      throw new IllegalArgumentException(str);
    }
    return i;
  }

  public String getColumnName(int paramInt)
  {
    return this.projection[paramInt];
  }

  public String[] getColumnNames()
  {
    return this.projection;
  }

  public double getDouble(int paramInt)
  {
    int i = this.indexMap[paramInt];
    return super.getDouble(i);
  }

  public float getFloat(int paramInt)
  {
    int i = this.indexMap[paramInt];
    return super.getFloat(i);
  }

  public int getInt(int paramInt)
  {
    int i = this.indexMap[paramInt];
    return super.getInt(i);
  }

  public long getLong(int paramInt)
  {
    int i = this.indexMap[paramInt];
    return super.getLong(i);
  }

  public short getShort(int paramInt)
  {
    int i = this.indexMap[paramInt];
    return super.getShort(i);
  }

  public String getString(int paramInt)
  {
    int i = this.indexMap[paramInt];
    return super.getString(i);
  }

  public CursorWindow getWindow()
  {
    return this.cursor.getWindow();
  }

  public boolean onMove(int paramInt1, int paramInt2)
  {
    return this.cursor.onMove(paramInt1, paramInt2);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.ProjectionCursor
 * JD-Core Version:    0.6.0
 */