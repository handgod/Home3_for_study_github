package com.softspb.util;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.io.File;

public abstract class AssetSQLiteOpenHelper extends SQLiteOpenHelper
{
  private static final String TEMP_DB_NAME = "upgrade_temp_db";
  protected final String TAG;
  private String assetPath;
  private final Context context;
  private File dbFile;
  private boolean needUpgrade;
  private int newVersion;
  private int oldVersion;

  public AssetSQLiteOpenHelper(Context paramContext, String paramString, SQLiteDatabase.CursorFactory paramCursorFactory, int paramInt)
  {
    super(paramContext, str1, paramCursorFactory, paramInt);
    String str2 = getClass().getSimpleName();
    this.TAG = str2;
    this.context = paramContext;
    String str3 = new File(paramString).getName();
    File localFile = paramContext.getDatabasePath(str3);
    this.dbFile = localFile;
    this.assetPath = paramString;
  }

  /** @deprecated */
  // ERROR //
  public SQLiteDatabase getWritableDatabase()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 65
    //   5: invokevirtual 68	com/softspb/util/AssetSQLiteOpenHelper:logd	(Ljava/lang/String;)V
    //   8: aload_0
    //   9: getfield 48	com/softspb/util/AssetSQLiteOpenHelper:context	Landroid/content/Context;
    //   12: ldc 70
    //   14: invokevirtual 54	android/content/Context:getDatabasePath	(Ljava/lang/String;)Ljava/io/File;
    //   17: invokevirtual 74	java/io/File:getParentFile	()Ljava/io/File;
    //   20: astore_1
    //   21: aload_0
    //   22: getfield 58	com/softspb/util/AssetSQLiteOpenHelper:assetPath	Ljava/lang/String;
    //   25: astore_2
    //   26: new 24	java/io/File
    //   29: dup
    //   30: aload_1
    //   31: aload_2
    //   32: invokespecial 77	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   35: astore_3
    //   36: aload_0
    //   37: getfield 56	com/softspb/util/AssetSQLiteOpenHelper:dbFile	Ljava/io/File;
    //   40: astore 4
    //   42: aload_3
    //   43: aload 4
    //   45: invokevirtual 81	java/io/File:equals	(Ljava/lang/Object;)Z
    //   48: ifne +157 -> 205
    //   51: aload_3
    //   52: invokevirtual 85	java/io/File:canRead	()Z
    //   55: istore 5
    //   57: iload 5
    //   59: ifeq +146 -> 205
    //   62: aload_3
    //   63: invokevirtual 88	java/io/File:getPath	()Ljava/lang/String;
    //   66: aconst_null
    //   67: bipush 16
    //   69: invokestatic 94	android/database/sqlite/SQLiteDatabase:openDatabase	(Ljava/lang/String;Landroid/database/sqlite/SQLiteDatabase$CursorFactory;I)Landroid/database/sqlite/SQLiteDatabase;
    //   72: astore 6
    //   74: new 96	java/lang/StringBuilder
    //   77: dup
    //   78: invokespecial 99	java/lang/StringBuilder:<init>	()V
    //   81: ldc 101
    //   83: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   86: astore 7
    //   88: aload_3
    //   89: invokevirtual 88	java/io/File:getPath	()Ljava/lang/String;
    //   92: astore 8
    //   94: aload 7
    //   96: aload 8
    //   98: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   101: invokevirtual 108	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   104: astore 9
    //   106: aload_0
    //   107: aload 9
    //   109: invokevirtual 68	com/softspb/util/AssetSQLiteOpenHelper:logd	(Ljava/lang/String;)V
    //   112: new 96	java/lang/StringBuilder
    //   115: dup
    //   116: invokespecial 99	java/lang/StringBuilder:<init>	()V
    //   119: ldc 110
    //   121: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   124: astore 10
    //   126: aload 6
    //   128: invokevirtual 114	android/database/sqlite/SQLiteDatabase:getVersion	()I
    //   131: istore 11
    //   133: aload 10
    //   135: iload 11
    //   137: invokevirtual 117	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   140: invokevirtual 108	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   143: astore 12
    //   145: aload_0
    //   146: aload 12
    //   148: invokevirtual 68	com/softspb/util/AssetSQLiteOpenHelper:logd	(Ljava/lang/String;)V
    //   151: aload 6
    //   153: ifnull +8 -> 161
    //   156: aload 6
    //   158: invokevirtual 120	android/database/sqlite/SQLiteDatabase:close	()V
    //   161: new 96	java/lang/StringBuilder
    //   164: dup
    //   165: invokespecial 99	java/lang/StringBuilder:<init>	()V
    //   168: ldc 122
    //   170: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   173: astore 13
    //   175: aload_3
    //   176: invokevirtual 88	java/io/File:getPath	()Ljava/lang/String;
    //   179: astore 14
    //   181: aload 13
    //   183: aload 14
    //   185: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   188: invokevirtual 108	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   191: astore 15
    //   193: aload_0
    //   194: aload 15
    //   196: invokevirtual 68	com/softspb/util/AssetSQLiteOpenHelper:logd	(Ljava/lang/String;)V
    //   199: aload_3
    //   200: invokevirtual 125	java/io/File:delete	()Z
    //   203: istore 16
    //   205: aload_0
    //   206: getfield 56	com/softspb/util/AssetSQLiteOpenHelper:dbFile	Ljava/io/File;
    //   209: invokevirtual 85	java/io/File:canRead	()Z
    //   212: ifne +220 -> 432
    //   215: aload_0
    //   216: ldc 127
    //   218: invokevirtual 68	com/softspb/util/AssetSQLiteOpenHelper:logd	(Ljava/lang/String;)V
    //   221: aload_0
    //   222: getfield 48	com/softspb/util/AssetSQLiteOpenHelper:context	Landroid/content/Context;
    //   225: astore 17
    //   227: aload_0
    //   228: getfield 58	com/softspb/util/AssetSQLiteOpenHelper:assetPath	Ljava/lang/String;
    //   231: astore 18
    //   233: aload_0
    //   234: getfield 56	com/softspb/util/AssetSQLiteOpenHelper:dbFile	Ljava/io/File;
    //   237: astore 19
    //   239: aload 17
    //   241: aload 18
    //   243: aload 19
    //   245: invokestatic 133	com/softspb/util/FileUtils:copyAssetToFile	(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;)V
    //   248: aload_0
    //   249: ldc 135
    //   251: invokevirtual 68	com/softspb/util/AssetSQLiteOpenHelper:logd	(Ljava/lang/String;)V
    //   254: aload_0
    //   255: getfield 56	com/softspb/util/AssetSQLiteOpenHelper:dbFile	Ljava/io/File;
    //   258: invokevirtual 88	java/io/File:getPath	()Ljava/lang/String;
    //   261: aconst_null
    //   262: bipush 16
    //   264: invokestatic 94	android/database/sqlite/SQLiteDatabase:openDatabase	(Ljava/lang/String;Landroid/database/sqlite/SQLiteDatabase$CursorFactory;I)Landroid/database/sqlite/SQLiteDatabase;
    //   267: astore 20
    //   269: aload_0
    //   270: ldc 137
    //   272: invokevirtual 68	com/softspb/util/AssetSQLiteOpenHelper:logd	(Ljava/lang/String;)V
    //   275: aload 20
    //   277: ifnull +8 -> 285
    //   280: aload 20
    //   282: invokevirtual 120	android/database/sqlite/SQLiteDatabase:close	()V
    //   285: aload_0
    //   286: ldc 138
    //   288: putfield 140	com/softspb/util/AssetSQLiteOpenHelper:needUpgrade	Z
    //   291: aload_0
    //   292: invokespecial 142	android/database/sqlite/SQLiteOpenHelper:getWritableDatabase	()Landroid/database/sqlite/SQLiteDatabase;
    //   295: astore 5
    //   297: aload 5
    //   299: astore 21
    //   301: aload_0
    //   302: monitorexit
    //   303: aload 21
    //   305: areturn
    //   306: astore 22
    //   308: aload 6
    //   310: ifnull +8 -> 318
    //   313: aload 6
    //   315: invokevirtual 120	android/database/sqlite/SQLiteDatabase:close	()V
    //   318: aload 22
    //   320: athrow
    //   321: astore 23
    //   323: aload_0
    //   324: monitorexit
    //   325: aload 23
    //   327: athrow
    //   328: astore 24
    //   330: new 96	java/lang/StringBuilder
    //   333: dup
    //   334: invokespecial 99	java/lang/StringBuilder:<init>	()V
    //   337: ldc 144
    //   339: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   342: aload 24
    //   344: invokevirtual 147	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   347: invokevirtual 108	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   350: astore 25
    //   352: aload_0
    //   353: aload 25
    //   355: aload 24
    //   357: invokevirtual 151	com/softspb/util/AssetSQLiteOpenHelper:logw	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   360: goto -112 -> 248
    //   363: astore 24
    //   365: new 96	java/lang/StringBuilder
    //   368: dup
    //   369: invokespecial 99	java/lang/StringBuilder:<init>	()V
    //   372: ldc 153
    //   374: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   377: aload 24
    //   379: invokevirtual 147	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   382: invokevirtual 108	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   385: astore 26
    //   387: aload_0
    //   388: aload 26
    //   390: aload 24
    //   392: invokevirtual 151	com/softspb/util/AssetSQLiteOpenHelper:logw	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   395: aload_0
    //   396: getfield 56	com/softspb/util/AssetSQLiteOpenHelper:dbFile	Ljava/io/File;
    //   399: invokevirtual 125	java/io/File:delete	()Z
    //   402: istore 27
    //   404: aload 20
    //   406: ifnull -121 -> 285
    //   409: aload 20
    //   411: invokevirtual 120	android/database/sqlite/SQLiteDatabase:close	()V
    //   414: goto -129 -> 285
    //   417: astore 22
    //   419: aload 20
    //   421: ifnull +8 -> 429
    //   424: aload 20
    //   426: invokevirtual 120	android/database/sqlite/SQLiteDatabase:close	()V
    //   429: aload 22
    //   431: athrow
    //   432: new 96	java/lang/StringBuilder
    //   435: dup
    //   436: invokespecial 99	java/lang/StringBuilder:<init>	()V
    //   439: ldc 155
    //   441: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   444: astore 28
    //   446: aload_0
    //   447: getfield 56	com/softspb/util/AssetSQLiteOpenHelper:dbFile	Ljava/io/File;
    //   450: invokevirtual 88	java/io/File:getPath	()Ljava/lang/String;
    //   453: astore 29
    //   455: aload 28
    //   457: aload 29
    //   459: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   462: invokevirtual 108	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   465: astore 30
    //   467: aload_0
    //   468: aload 30
    //   470: invokevirtual 68	com/softspb/util/AssetSQLiteOpenHelper:logd	(Ljava/lang/String;)V
    //   473: aload_0
    //   474: getfield 56	com/softspb/util/AssetSQLiteOpenHelper:dbFile	Ljava/io/File;
    //   477: invokevirtual 88	java/io/File:getPath	()Ljava/lang/String;
    //   480: aconst_null
    //   481: bipush 16
    //   483: invokestatic 94	android/database/sqlite/SQLiteDatabase:openDatabase	(Ljava/lang/String;Landroid/database/sqlite/SQLiteDatabase$CursorFactory;I)Landroid/database/sqlite/SQLiteDatabase;
    //   486: astore 6
    //   488: new 96	java/lang/StringBuilder
    //   491: dup
    //   492: invokespecial 99	java/lang/StringBuilder:<init>	()V
    //   495: ldc 157
    //   497: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   500: astore 31
    //   502: aload 6
    //   504: invokevirtual 114	android/database/sqlite/SQLiteDatabase:getVersion	()I
    //   507: istore 32
    //   509: aload 31
    //   511: iload 32
    //   513: invokevirtual 117	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   516: invokevirtual 108	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   519: astore 33
    //   521: aload_0
    //   522: aload 33
    //   524: invokevirtual 68	com/softspb/util/AssetSQLiteOpenHelper:logd	(Ljava/lang/String;)V
    //   527: aload 6
    //   529: ifnull -244 -> 285
    //   532: aload 6
    //   534: invokevirtual 120	android/database/sqlite/SQLiteDatabase:close	()V
    //   537: goto -252 -> 285
    //   540: astore 22
    //   542: aload 6
    //   544: ifnull +8 -> 552
    //   547: aload 6
    //   549: invokevirtual 120	android/database/sqlite/SQLiteDatabase:close	()V
    //   552: aload 22
    //   554: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   62	151	306	finally
    //   2	57	321	finally
    //   156	221	321	finally
    //   221	248	321	finally
    //   248	254	321	finally
    //   280	297	321	finally
    //   313	321	321	finally
    //   330	360	321	finally
    //   409	473	321	finally
    //   532	555	321	finally
    //   221	248	328	java/io/IOException
    //   254	275	363	android/database/sqlite/SQLiteException
    //   254	275	417	finally
    //   365	404	417	finally
    //   473	527	540	finally
  }

  protected void logd(String paramString)
  {
    int i = Log.d(this.TAG, paramString);
  }

  protected void logw(String paramString, Exception paramException)
  {
    int i = Log.w(this.TAG, paramString, paramException);
  }

  public void onCreate(SQLiteDatabase paramSQLiteDatabase)
  {
  }

  // ERROR //
  public void onOpen(SQLiteDatabase paramSQLiteDatabase)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 140	com/softspb/util/AssetSQLiteOpenHelper:needUpgrade	Z
    //   4: ifeq +267 -> 271
    //   7: aload_0
    //   8: getfield 48	com/softspb/util/AssetSQLiteOpenHelper:context	Landroid/content/Context;
    //   11: astore_2
    //   12: new 96	java/lang/StringBuilder
    //   15: dup
    //   16: invokespecial 99	java/lang/StringBuilder:<init>	()V
    //   19: ldc 174
    //   21: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: astore_3
    //   25: aload_0
    //   26: getfield 58	com/softspb/util/AssetSQLiteOpenHelper:assetPath	Ljava/lang/String;
    //   29: astore 4
    //   31: new 24	java/io/File
    //   34: dup
    //   35: aload 4
    //   37: invokespecial 27	java/io/File:<init>	(Ljava/lang/String;)V
    //   40: invokevirtual 31	java/io/File:getName	()Ljava/lang/String;
    //   43: astore 5
    //   45: aload_3
    //   46: aload 5
    //   48: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   51: invokevirtual 108	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   54: astore 6
    //   56: aload_2
    //   57: aload 6
    //   59: invokevirtual 54	android/content/Context:getDatabasePath	(Ljava/lang/String;)Ljava/io/File;
    //   62: astore 7
    //   64: new 96	java/lang/StringBuilder
    //   67: dup
    //   68: invokespecial 99	java/lang/StringBuilder:<init>	()V
    //   71: ldc 176
    //   73: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   76: astore 8
    //   78: aload 7
    //   80: invokevirtual 88	java/io/File:getPath	()Ljava/lang/String;
    //   83: astore 9
    //   85: aload 8
    //   87: aload 9
    //   89: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   92: invokevirtual 108	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   95: astore 10
    //   97: aload_0
    //   98: aload 10
    //   100: invokevirtual 68	com/softspb/util/AssetSQLiteOpenHelper:logd	(Ljava/lang/String;)V
    //   103: aload_0
    //   104: getfield 48	com/softspb/util/AssetSQLiteOpenHelper:context	Landroid/content/Context;
    //   107: astore 11
    //   109: aload_0
    //   110: getfield 58	com/softspb/util/AssetSQLiteOpenHelper:assetPath	Ljava/lang/String;
    //   113: astore 12
    //   115: aload 11
    //   117: aload 12
    //   119: aload 7
    //   121: invokestatic 133	com/softspb/util/FileUtils:copyAssetToFile	(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;)V
    //   124: ldc 178
    //   126: astore 13
    //   128: new 96	java/lang/StringBuilder
    //   131: dup
    //   132: invokespecial 99	java/lang/StringBuilder:<init>	()V
    //   135: ldc 180
    //   137: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   140: aload 13
    //   142: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   145: invokevirtual 108	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   148: astore 14
    //   150: aload_0
    //   151: aload 14
    //   153: invokevirtual 68	com/softspb/util/AssetSQLiteOpenHelper:logd	(Ljava/lang/String;)V
    //   156: iconst_1
    //   157: istore 15
    //   159: iload 15
    //   161: anewarray 182	java/lang/String
    //   164: astore 16
    //   166: aload 7
    //   168: invokevirtual 88	java/io/File:getPath	()Ljava/lang/String;
    //   171: astore 17
    //   173: aload 16
    //   175: iconst_0
    //   176: aload 17
    //   178: aastore
    //   179: aload_1
    //   180: aload 13
    //   182: aload 16
    //   184: invokevirtual 186	android/database/sqlite/SQLiteDatabase:execSQL	(Ljava/lang/String;[Ljava/lang/Object;)V
    //   187: aload_0
    //   188: getfield 188	com/softspb/util/AssetSQLiteOpenHelper:oldVersion	I
    //   191: istore 18
    //   193: aload_1
    //   194: iload 18
    //   196: invokevirtual 192	android/database/sqlite/SQLiteDatabase:setVersion	(I)V
    //   199: aload_1
    //   200: invokevirtual 195	android/database/sqlite/SQLiteDatabase:beginTransaction	()V
    //   203: aload_0
    //   204: getfield 188	com/softspb/util/AssetSQLiteOpenHelper:oldVersion	I
    //   207: istore 19
    //   209: aload_0
    //   210: getfield 197	com/softspb/util/AssetSQLiteOpenHelper:newVersion	I
    //   213: istore 20
    //   215: aload_0
    //   216: aload_1
    //   217: iload 19
    //   219: iload 20
    //   221: ldc 9
    //   223: invokevirtual 201	com/softspb/util/AssetSQLiteOpenHelper:onUpgrade	(Landroid/database/sqlite/SQLiteDatabase;IILjava/lang/String;)V
    //   226: aload_1
    //   227: invokevirtual 204	android/database/sqlite/SQLiteDatabase:setTransactionSuccessful	()V
    //   230: aload_0
    //   231: getfield 197	com/softspb/util/AssetSQLiteOpenHelper:newVersion	I
    //   234: istore 21
    //   236: aload_1
    //   237: iload 21
    //   239: invokevirtual 192	android/database/sqlite/SQLiteDatabase:setVersion	(I)V
    //   242: aload_1
    //   243: invokevirtual 207	android/database/sqlite/SQLiteDatabase:endTransaction	()V
    //   246: aload_0
    //   247: ldc 209
    //   249: invokevirtual 68	com/softspb/util/AssetSQLiteOpenHelper:logd	(Ljava/lang/String;)V
    //   252: aload_1
    //   253: ldc 211
    //   255: invokevirtual 213	android/database/sqlite/SQLiteDatabase:execSQL	(Ljava/lang/String;)V
    //   258: aload_0
    //   259: ldc 215
    //   261: invokevirtual 68	com/softspb/util/AssetSQLiteOpenHelper:logd	(Ljava/lang/String;)V
    //   264: aload 7
    //   266: invokevirtual 125	java/io/File:delete	()Z
    //   269: istore 22
    //   271: return
    //   272: astore 23
    //   274: new 96	java/lang/StringBuilder
    //   277: dup
    //   278: invokespecial 99	java/lang/StringBuilder:<init>	()V
    //   281: ldc 217
    //   283: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   286: aload 23
    //   288: invokevirtual 147	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   291: invokevirtual 108	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   294: astore 24
    //   296: aload_0
    //   297: aload 24
    //   299: aload 23
    //   301: invokevirtual 151	com/softspb/util/AssetSQLiteOpenHelper:logw	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   304: goto -180 -> 124
    //   307: astore 15
    //   309: aload_1
    //   310: invokevirtual 207	android/database/sqlite/SQLiteDatabase:endTransaction	()V
    //   313: aload 15
    //   315: athrow
    //   316: astore 25
    //   318: aload_0
    //   319: ldc 219
    //   321: aload 25
    //   323: invokevirtual 151	com/softspb/util/AssetSQLiteOpenHelper:logw	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   326: aload_0
    //   327: ldc 215
    //   329: invokevirtual 68	com/softspb/util/AssetSQLiteOpenHelper:logd	(Ljava/lang/String;)V
    //   332: aload 7
    //   334: invokevirtual 125	java/io/File:delete	()Z
    //   337: istore 26
    //   339: goto -68 -> 271
    //   342: astore 27
    //   344: aload_0
    //   345: ldc 215
    //   347: invokevirtual 68	com/softspb/util/AssetSQLiteOpenHelper:logd	(Ljava/lang/String;)V
    //   350: aload 7
    //   352: invokevirtual 125	java/io/File:delete	()Z
    //   355: istore 28
    //   357: aload 27
    //   359: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   103	124	272	java/io/IOException
    //   203	242	307	finally
    //   159	203	316	java/lang/Exception
    //   242	258	316	java/lang/Exception
    //   309	316	316	java/lang/Exception
    //   159	203	342	finally
    //   242	258	342	finally
    //   309	316	342	finally
    //   318	326	342	finally
  }

  public final void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2)
  {
    String str = "onUpgrade: oldVersion=" + paramInt1 + " newVersion=" + paramInt2;
    logd(str);
    this.needUpgrade = 1;
    this.oldVersion = paramInt1;
    this.newVersion = paramInt2;
  }

  protected abstract void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2, String paramString);
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.AssetSQLiteOpenHelper
 * JD-Core Version:    0.6.0
 */