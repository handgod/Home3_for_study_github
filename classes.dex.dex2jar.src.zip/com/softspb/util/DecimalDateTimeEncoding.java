package com.softspb.util;

import android.text.format.Time;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public final class DecimalDateTimeEncoding
{
  private static ThreadLocal<GregorianCalendar> gregCalendar = new ThreadLocal();
  private static TimeZone timeZoneUT = TimeZone.getTimeZone("GMT+0");

  public static int add(int paramInt1, int paramInt2)
  {
    Date localDate = decodeDate(paramInt1);
    GregorianCalendar localGregorianCalendar = useCalendarInstance();
    localGregorianCalendar.setTime(localDate);
    localGregorianCalendar.add(5, paramInt2);
    return encodeCalendar(localGregorianCalendar);
  }

  public static int daysBetween(int paramInt1, int paramInt2)
  {
    Time localTime = fromDateUTC(paramInt1);
    long l1 = fromDateUTC(paramInt2).toMillis(1);
    long l2 = localTime.toMillis(1);
    long l3 = l1 - l2;
    if (l3 >= 0L)
      l3 += 43200000L;
    while (true)
    {
      return (int)(l3 / 86400000L);
      l3 -= 43200000L;
    }
  }

  public static Date decodeDate(int paramInt)
  {
    GregorianCalendar localGregorianCalendar = useCalendarInstance();
    localGregorianCalendar.setTimeInMillis(0L);
    int i = paramInt % 100;
    localGregorianCalendar.set(5, i);
    int j = paramInt / 100;
    int k = j % 100 + -1;
    localGregorianCalendar.set(2, k);
    int m = j / 100;
    localGregorianCalendar.set(1, m);
    return localGregorianCalendar.getTime();
  }

  public static Date decodeDate(String paramString)
  {
    String str;
    try
    {
      Date localDate = decodeDate(Integer.parseInt(paramString));
      return localDate;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      str = "Date cannot be decoded from argument: " + paramString;
    }
    throw new IllegalArgumentException(str);
  }

  public static Date decodeDateTime(int paramInt1, int paramInt2, TimeZone paramTimeZone)
  {
    GregorianCalendar localGregorianCalendar = useCalendarInstance();
    localGregorianCalendar.setTimeInMillis(0L);
    if (paramTimeZone != null)
      localGregorianCalendar.setTimeZone(paramTimeZone);
    int i = paramInt1 % 100;
    localGregorianCalendar.set(5, i);
    int j = paramInt1 / 100;
    int k = j % 100 + -1;
    localGregorianCalendar.set(2, k);
    int m = j / 100;
    localGregorianCalendar.set(1, m);
    int n = paramInt2 / 100;
    localGregorianCalendar.set(11, n);
    int i1 = paramInt2 % 100;
    localGregorianCalendar.set(12, i1);
    return localGregorianCalendar.getTime();
  }

  public static Date decodeDateTimeLocal(int paramInt1, int paramInt2)
  {
    return decodeDateTime(paramInt1, paramInt2, null);
  }

  public static Date decodeDateTimeUT(int paramInt1, int paramInt2)
  {
    TimeZone localTimeZone = timeZoneUT;
    return decodeDateTime(paramInt1, paramInt2, localTimeZone);
  }

  public static Date decodeDateUTC(int paramInt1, int paramInt2, TimeZone paramTimeZone)
  {
    int i = paramInt1 % 100;
    int j = paramInt1 / 100;
    int k = j % 100 + -1;
    int m = j / 100;
    int n = paramInt2 / 100;
    int i1 = paramInt2 % 100;
    Time localTime = new Time("UTC");
    localTime.set(0, i1, n, i, k, m);
    long l = localTime.normalize(0);
    if (paramTimeZone != null)
    {
      String str = paramTimeZone.getID();
      localTime.switchTimezone(str);
    }
    GregorianCalendar localGregorianCalendar = useCalendarInstance();
    int i2 = localTime.year;
    localGregorianCalendar.set(1, i2);
    int i3 = localTime.month;
    localGregorianCalendar.set(2, i3);
    int i4 = localTime.monthDay;
    localGregorianCalendar.set(5, i4);
    return localGregorianCalendar.getTime();
  }

  public static Date decodeTime(int paramInt)
  {
    GregorianCalendar localGregorianCalendar = useCalendarInstance();
    localGregorianCalendar.setTimeInMillis(0L);
    int i = paramInt / 100;
    localGregorianCalendar.set(11, i);
    int j = paramInt % 100;
    localGregorianCalendar.set(12, j);
    return localGregorianCalendar.getTime();
  }

  private static int encodeCalendar(Calendar paramCalendar)
  {
    int i = paramCalendar.get(1) * 10000;
    int j = (paramCalendar.get(2) + 1) * 100;
    int k = i + j;
    int m = paramCalendar.get(5);
    return k + m;
  }

  public static int encodeDate(Time paramTime)
  {
    int i = paramTime.year * 10000;
    int j = (paramTime.month + 1) * 100;
    int k = i + j;
    int m = paramTime.monthDay;
    return k + m;
  }

  public static int encodeDate(Date paramDate)
  {
    GregorianCalendar localGregorianCalendar = useCalendarInstance();
    localGregorianCalendar.setTime(paramDate);
    return encodeCalendar(localGregorianCalendar);
  }

  public static int encodeHourMin(int paramInt1, int paramInt2)
  {
    int i = paramInt1 * 60;
    paramInt2 += i;
    int j;
    int k;
    if (paramInt2 >= 0)
    {
      j = paramInt2 / 60 * 100;
      k = paramInt2 % 60;
    }
    int n;
    int i1;
    for (int m = j + k; ; m = n - i1)
    {
      return m;
      n = paramInt2 / 60 * 100;
      i1 = -paramInt2 % 60;
    }
  }

  public static int encodeTime(Time paramTime)
  {
    int i = paramTime.hour * 100;
    int j = paramTime.minute;
    return i + j;
  }

  private static int encodeTime(Calendar paramCalendar)
  {
    int i = paramCalendar.get(11) * 100;
    int j = paramCalendar.get(12);
    return i + j;
  }

  public static int encodeTime(Date paramDate)
  {
    GregorianCalendar localGregorianCalendar = useCalendarInstance();
    localGregorianCalendar.setTime(paramDate);
    int i = localGregorianCalendar.get(11) * 100;
    int j = localGregorianCalendar.get(12);
    return i + j;
  }

  public static Time fromDateUTC(int paramInt)
  {
    Time localTime = new Time("UTC");
    int i = paramInt % 100;
    localTime.monthDay = i;
    int j = paramInt / 100;
    int k = j % 100 + -1;
    localTime.month = k;
    int m = j / 100;
    localTime.year = m;
    long l = localTime.normalize(1);
    return localTime;
  }

  public static int getDayOfWeek(int paramInt)
  {
    GregorianCalendar localGregorianCalendar = useCalendarInstance();
    int i = paramInt % 100;
    int j = paramInt / 100;
    int k = j % 100 + -1;
    int m = j / 100;
    localGregorianCalendar.set(m, k, i);
    return localGregorianCalendar.get(7);
  }

  public static Time getNowAtUTCOffset(int paramInt)
  {
    Time localTime = new Time();
    localTime.setToNow();
    long l1 = localTime.toMillis(1);
    long l2 = paramInt * 60;
    long l3 = localTime.gmtoff;
    long l4 = l2 - l3;
    if (localTime.isDst != 0);
    for (int i = 3600; ; i = 0)
    {
      long l5 = i;
      long l6 = (l4 + l5) * 1000L;
      long l7 = l1 + l6;
      localTime.set(l7);
      return localTime;
    }
  }

  public static int getTimeNowEncoded()
  {
    return encodeTime(GregorianCalendar.getInstance());
  }

  public static int getTodayDateEncoded()
  {
    return encodeCalendar(GregorianCalendar.getInstance());
  }

  public static int idFromDateMillis(int paramInt)
  {
    long l = paramInt;
    return encodeDate(new Date(l));
  }

  private static GregorianCalendar useCalendarInstance()
  {
    GregorianCalendar localGregorianCalendar = (GregorianCalendar)gregCalendar.get();
    if (localGregorianCalendar == null)
    {
      localGregorianCalendar = new GregorianCalendar();
      gregCalendar.set(localGregorianCalendar);
    }
    localGregorianCalendar.clear();
    return localGregorianCalendar;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.DecimalDateTimeEncoding
 * JD-Core Version:    0.6.0
 */