package com.softspb.util.log;

public class NullPrinter extends SPBLogPrinter
{
  NullPrinter()
  {
    super(null);
  }

  void println(int paramInt, String paramString)
  {
  }

  void println(int paramInt, String paramString, long paramLong)
  {
  }

  void setTag(String paramString)
  {
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.log.NullPrinter
 * JD-Core Version:    0.6.0
 */