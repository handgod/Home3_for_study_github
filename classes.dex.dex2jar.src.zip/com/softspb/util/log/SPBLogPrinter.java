package com.softspb.util.log;

abstract class SPBLogPrinter
{
  String tag;

  SPBLogPrinter(String paramString)
  {
    this.tag = paramString;
  }

  void close()
  {
  }

  void flush()
  {
  }

  void println(int paramInt, String paramString)
  {
    long l = System.currentTimeMillis();
    println(paramInt, paramString, l);
  }

  abstract void println(int paramInt, String paramString, long paramLong);

  void setTag(String paramString)
  {
    this.tag = paramString;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.log.SPBLogPrinter
 * JD-Core Version:    0.6.0
 */