package com.softspb.util.log;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Environment;
import java.io.File;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public final class Loggers
{
  private static Context context;
  static final String externalStoragePath;
  private static ConcurrentHashMap<String, SynchronizedFileAppender> fileAppendersMap;
  static boolean globalEnabled;
  static final Logger logger;
  private static ConcurrentHashMap<String, Logger> loggersMap = new ConcurrentHashMap();
  static final LogSDCardListener sdCardListener;
  private static File spbLogsDir;

  static
  {
    fileAppendersMap = new ConcurrentHashMap();
    externalStoragePath = Environment.getExternalStorageDirectory().getPath();
    SystemLogPrinter localSystemLogPrinter = new SystemLogPrinter("Loggers");
    logger = new Logger("Loggers", 7, localSystemLogPrinter);
    logger.disable();
    sdCardListener = new LogSDCardListener();
    SDCardReceiver.registerListener(sdCardListener);
    globalEnabled = 1;
  }

  private static void addLogFilePrinter(Logger paramLogger)
  {
    String str1 = paramLogger.getName();
    int i = str1.lastIndexOf('.') + 1;
    String str2 = str1.substring(i);
    SynchronizedFileAppender localSynchronizedFileAppender = getFileAppender(str2);
    if (globalEnabled)
      localSynchronizedFileAppender.enable();
    while (true)
    {
      LogFilePrinter localLogFilePrinter = new LogFilePrinter(str2, localSynchronizedFileAppender);
      paramLogger.addLogPrinter(localLogFilePrinter);
      return;
      localSynchronizedFileAppender.disable();
    }
  }

  private static Logger createLogger(String paramString)
  {
    Logger localLogger1 = logger;
    String str1 = "createLogger >>> name=" + paramString;
    localLogger1.d(str1);
    int i = paramString.lastIndexOf('.') + 1;
    String str2 = paramString.substring(i);
    SystemLogPrinter localSystemLogPrinter = new SystemLogPrinter(str2);
    Logger localLogger2 = new Logger(paramString, 7, localSystemLogPrinter);
    if (spbLogsDir != null)
      addLogFilePrinter(localLogger2);
    if (globalEnabled)
    {
      String str3 = "createLogger: enabling logger: " + paramString;
      localLogger2.d(str3);
      localLogger2.enable();
    }
    while (true)
    {
      Logger localLogger3 = logger;
      String str4 = "createLogger <<< name=" + paramString;
      localLogger3.d(str4);
      return localLogger2;
      String str5 = "createLogger: disabling logger: " + paramString;
      localLogger2.d(str5);
      localLogger2.disable();
    }
  }

  private static void disableFileAppenders()
  {
    logger.d("disableFileAppenders >>>");
    synchronized (fileAppendersMap)
    {
      Iterator localIterator = fileAppendersMap.values().iterator();
      if (localIterator.hasNext())
      {
        SynchronizedFileAppender localSynchronizedFileAppender = (SynchronizedFileAppender)localIterator.next();
        Logger localLogger = logger;
        StringBuilder localStringBuilder = new StringBuilder().append("disableFileAppenders: disabling file appender: ");
        String str1 = localSynchronizedFileAppender.getFile().getPath();
        String str2 = str1;
        localLogger.d(str2);
        localSynchronizedFileAppender.println("Stopping printing because SD card was removed");
        localSynchronizedFileAppender.disable();
      }
    }
    monitorexit;
    logger.d("disableFileAppenders <<<");
  }

  public static void disableGlobal()
  {
    if (globalEnabled)
      globalEnabled = 0;
    disableFileAppenders();
    disableLoggers();
  }

  private static void disableLoggers()
  {
    logger.d("disableLoggers >>>");
    synchronized (loggersMap)
    {
      Iterator localIterator = loggersMap.values().iterator();
      if (localIterator.hasNext())
      {
        Logger localLogger1 = (Logger)localIterator.next();
        Logger localLogger2 = logger;
        StringBuilder localStringBuilder = new StringBuilder().append("disableLoggers: disabling logger: ");
        String str1 = localLogger1.getName();
        String str2 = str1;
        localLogger2.d(str2);
        localLogger1.disable();
      }
    }
    monitorexit;
    logger.d("disableLoggers <<<");
  }

  private static void enableFileAppenders()
  {
    logger.d("enableFileAppenders >>>");
    synchronized (fileAppendersMap)
    {
      Iterator localIterator = fileAppendersMap.values().iterator();
      if (localIterator.hasNext())
      {
        SynchronizedFileAppender localSynchronizedFileAppender = (SynchronizedFileAppender)localIterator.next();
        Logger localLogger = logger;
        StringBuilder localStringBuilder = new StringBuilder().append("enableFileAppenders: enabling file appender: ");
        String str1 = localSynchronizedFileAppender.getFile().getPath();
        String str2 = str1;
        localLogger.d(str2);
        localSynchronizedFileAppender.enable();
        localSynchronizedFileAppender.println("Re-Starting printing after SD card was mounted");
      }
    }
    monitorexit;
    logger.d("enableFileAppenders <<<");
  }

  public static void enableGlobal()
  {
    logger.d("enableGlobal >>>");
    if (!globalEnabled)
      globalEnabled = 1;
    enableFileAppenders();
    enableLoggers();
    logger.d("enableGlobal <<<");
  }

  private static void enableLoggers()
  {
    logger.d("enableLoggers >>>");
    synchronized (loggersMap)
    {
      Iterator localIterator = loggersMap.values().iterator();
      if (localIterator.hasNext())
      {
        Logger localLogger1 = (Logger)localIterator.next();
        Logger localLogger2 = logger;
        StringBuilder localStringBuilder = new StringBuilder().append("enableLoggers: enabling logger: ");
        String str1 = localLogger1.getName();
        String str2 = str1;
        localLogger2.d(str2);
        localLogger1.enable();
      }
    }
    monitorexit;
    logger.d("enableLoggers <<<");
  }

  private static File getExternalFilesDir(Context paramContext)
  {
    Class localClass = paramContext.getClass();
    try
    {
      Class[] arrayOfClass = new Class[1];
      arrayOfClass[0] = String.class;
      Method localMethod = localClass.getMethod("getExternalFilesDir", arrayOfClass);
      String[] arrayOfString = new String[1];
      arrayOfString[0] = 0;
      File localFile = (File)localMethod.invoke(paramContext, arrayOfString);
      label46: if (localFile == null)
      {
        localFile = Environment.getExternalStorageDirectory();
        if (localFile != null)
        {
          StringBuilder localStringBuilder = new StringBuilder().append("Android/data/");
          String str1 = paramContext.getPackageName();
          String str2 = str1 + "/files";
          localFile = new File(localFile, str2);
        }
      }
      return localFile;
    }
    catch (Exception localException)
    {
      break label46;
    }
  }

  // ERROR //
  private static SynchronizedFileAppender getFileAppender(String paramString)
  {
    // Byte code:
    //   0: getstatic 64	com/softspb/util/log/Loggers:logger	Lcom/softspb/util/log/Logger;
    //   3: astore_1
    //   4: new 118	java/lang/StringBuilder
    //   7: dup
    //   8: invokespecial 119	java/lang/StringBuilder:<init>	()V
    //   11: ldc 250
    //   13: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   16: aload_0
    //   17: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   20: invokevirtual 128	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   23: astore_2
    //   24: aload_1
    //   25: aload_2
    //   26: invokevirtual 131	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   29: getstatic 36	com/softspb/util/log/Loggers:fileAppendersMap	Ljava/util/concurrent/ConcurrentHashMap;
    //   32: aload_0
    //   33: invokevirtual 254	java/util/concurrent/ConcurrentHashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   36: checkcast 101	com/softspb/util/log/SynchronizedFileAppender
    //   39: astore_3
    //   40: aload_3
    //   41: ifnonnull +194 -> 235
    //   44: ldc 2
    //   46: astore 4
    //   48: aload 4
    //   50: monitorenter
    //   51: aload_3
    //   52: ifnonnull +180 -> 232
    //   55: getstatic 133	com/softspb/util/log/Loggers:spbLogsDir	Ljava/io/File;
    //   58: astore 5
    //   60: new 118	java/lang/StringBuilder
    //   63: dup
    //   64: invokespecial 119	java/lang/StringBuilder:<init>	()V
    //   67: aload_0
    //   68: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   71: ldc_w 256
    //   74: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   77: invokevirtual 128	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   80: astore 6
    //   82: new 44	java/io/File
    //   85: dup
    //   86: aload 5
    //   88: aload 6
    //   90: invokespecial 248	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   93: astore 7
    //   95: getstatic 64	com/softspb/util/log/Loggers:logger	Lcom/softspb/util/log/Logger;
    //   98: astore 8
    //   100: new 118	java/lang/StringBuilder
    //   103: dup
    //   104: invokespecial 119	java/lang/StringBuilder:<init>	()V
    //   107: ldc_w 258
    //   110: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   113: astore 9
    //   115: aload 7
    //   117: invokevirtual 48	java/io/File:getPath	()Ljava/lang/String;
    //   120: astore 10
    //   122: aload 9
    //   124: aload 10
    //   126: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   129: invokevirtual 128	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   132: astore 11
    //   134: aload 8
    //   136: aload 11
    //   138: invokevirtual 131	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   141: new 101	com/softspb/util/log/SynchronizedFileAppender
    //   144: dup
    //   145: aload 7
    //   147: aload_0
    //   148: invokespecial 259	com/softspb/util/log/SynchronizedFileAppender:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   151: astore 12
    //   153: getstatic 36	com/softspb/util/log/Loggers:fileAppendersMap	Ljava/util/concurrent/ConcurrentHashMap;
    //   156: aload_0
    //   157: aload 12
    //   159: invokevirtual 263	java/util/concurrent/ConcurrentHashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   162: astore 13
    //   164: getstatic 133	com/softspb/util/log/Loggers:spbLogsDir	Ljava/io/File;
    //   167: invokevirtual 266	java/io/File:exists	()Z
    //   170: ifne +101 -> 271
    //   173: getstatic 133	com/softspb/util/log/Loggers:spbLogsDir	Ljava/io/File;
    //   176: invokevirtual 269	java/io/File:mkdirs	()Z
    //   179: ifne +92 -> 271
    //   182: getstatic 64	com/softspb/util/log/Loggers:logger	Lcom/softspb/util/log/Logger;
    //   185: astore 14
    //   187: new 118	java/lang/StringBuilder
    //   190: dup
    //   191: invokespecial 119	java/lang/StringBuilder:<init>	()V
    //   194: ldc_w 271
    //   197: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   200: astore 15
    //   202: getstatic 133	com/softspb/util/log/Loggers:spbLogsDir	Ljava/io/File;
    //   205: invokevirtual 48	java/io/File:getPath	()Ljava/lang/String;
    //   208: astore 16
    //   210: aload 15
    //   212: aload 16
    //   214: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   217: invokevirtual 128	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   220: astore 17
    //   222: aload 14
    //   224: aload 17
    //   226: invokevirtual 274	com/softspb/util/log/Logger:e	(Ljava/lang/String;)V
    //   229: aload 12
    //   231: astore_3
    //   232: aload 4
    //   234: monitorexit
    //   235: getstatic 64	com/softspb/util/log/Loggers:logger	Lcom/softspb/util/log/Logger;
    //   238: astore 18
    //   240: new 118	java/lang/StringBuilder
    //   243: dup
    //   244: invokespecial 119	java/lang/StringBuilder:<init>	()V
    //   247: ldc_w 276
    //   250: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   253: aload_0
    //   254: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   257: invokevirtual 128	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   260: astore 19
    //   262: aload 18
    //   264: aload 19
    //   266: invokevirtual 131	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   269: aload_3
    //   270: areturn
    //   271: getstatic 64	com/softspb/util/log/Loggers:logger	Lcom/softspb/util/log/Logger;
    //   274: astore 20
    //   276: new 118	java/lang/StringBuilder
    //   279: dup
    //   280: invokespecial 119	java/lang/StringBuilder:<init>	()V
    //   283: ldc_w 278
    //   286: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   289: astore 21
    //   291: getstatic 133	com/softspb/util/log/Loggers:spbLogsDir	Ljava/io/File;
    //   294: invokevirtual 48	java/io/File:getPath	()Ljava/lang/String;
    //   297: astore 22
    //   299: aload 21
    //   301: aload 22
    //   303: invokevirtual 125	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   306: invokevirtual 128	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   309: astore 23
    //   311: aload 20
    //   313: aload 23
    //   315: invokevirtual 131	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   318: aload 12
    //   320: astore_3
    //   321: goto -89 -> 232
    //   324: astore 24
    //   326: aload 4
    //   328: monitorexit
    //   329: aload 24
    //   331: athrow
    //   332: astore 24
    //   334: aload 12
    //   336: astore 25
    //   338: goto -12 -> 326
    //
    // Exception table:
    //   from	to	target	type
    //   55	153	324	finally
    //   232	235	324	finally
    //   326	329	324	finally
    //   153	229	332	finally
    //   271	318	332	finally
  }

  public static Logger getLogger(Class<?> paramClass)
  {
    if (paramClass == null)
      throw new IllegalArgumentException();
    return getLogger(paramClass.getName());
  }

  public static Logger getLogger(String paramString)
  {
    Logger localLogger1 = logger;
    String str1 = "getLogger >>> name=" + paramString;
    localLogger1.d(str1);
    Logger localLogger2 = (Logger)loggersMap.get(paramString);
    Loggers localLoggers;
    if (localLogger2 == null)
    {
      localLoggers = Loggers.class;
      monitorenter;
      if (localLogger2 != null);
    }
    try
    {
      localLogger2 = createLogger(paramString);
      Object localObject1 = loggersMap.put(paramString, localLogger2);
      monitorexit;
      Logger localLogger3 = logger;
      String str2 = "getLogger <<< name=" + paramString;
      localLogger3.d(str2);
      return localLogger2;
    }
    finally
    {
      monitorexit;
    }
    throw localObject2;
  }

  public static String[] getRegisteredLoggerNames()
  {
    Set localSet = loggersMap.keySet();
    String[] arrayOfString = new String[localSet.size()];
    return (String[])localSet.toArray(arrayOfString);
  }

  private static void initLogsDirectory(Context paramContext)
  {
    File localFile = getExternalFilesDir(paramContext);
    int i = R.string.spb_logs_directory_pathname;
    String str1 = paramContext.getString(i);
    if (localFile != null)
      spbLogsDir = new File(localFile, str1);
    while (true)
    {
      return;
      String str2 = externalStoragePath;
      spbLogsDir = new File(str2, str1);
    }
  }

  static void onSDCardMounted()
  {
    logger.d("onSDCardMounted >>>");
    if (globalEnabled)
      enableFileAppenders();
    logger.d("onSDCardMounted <<<");
  }

  static void onSDCardUnmounted()
  {
    logger.d("onSDCardUnmounted >>>");
    disableFileAppenders();
    logger.d("onSDCardUnmounted <<<");
  }

  public static void setContext(Context paramContext)
  {
    Logger localLogger = logger;
    StringBuilder localStringBuilder = new StringBuilder().append("setContext >>> context=").append(paramContext).append(" globalEnabled=");
    boolean bool = globalEnabled;
    String str = bool;
    localLogger.d(str);
    Resources localResources = paramContext.getResources();
    int i = R.bool.logging_enabled;
    if (localResources.getBoolean(i))
      enableGlobal();
    while (true)
    {
      context = paramContext;
      initLogsDirectory(paramContext);
      startLoggingToFiles();
      if (globalEnabled)
        enableFileAppenders();
      logger.d("setContext <<<");
      return;
      disableGlobal();
    }
  }

  private static void startLoggingToFiles()
  {
    logger.d("startLoggingToFiles >>>");
    Iterator localIterator = loggersMap.entrySet().iterator();
    while (localIterator.hasNext())
      addLogFilePrinter((Logger)((Map.Entry)localIterator.next()).getValue());
    logger.d("startLoggingToFiles <<<");
  }

  public static void stop()
  {
    logger.d("Loggers.stop >>>");
    if (context != null)
    {
      synchronized (fileAppendersMap)
      {
        Iterator localIterator = fileAppendersMap.values().iterator();
        if (localIterator.hasNext())
        {
          SynchronizedFileAppender localSynchronizedFileAppender = (SynchronizedFileAppender)localIterator.next();
          Logger localLogger = logger;
          StringBuilder localStringBuilder = new StringBuilder().append("Loggers.stop: closing file appender: ");
          String str1 = localSynchronizedFileAppender.getFile().getPath();
          String str2 = str1;
          localLogger.d(str2);
          localSynchronizedFileAppender.flush();
          localSynchronizedFileAppender.close();
        }
      }
      monitorexit;
    }
    SDCardReceiver.unregisterListener(sdCardListener);
    logger.d("Loggers.stop <<<");
  }

  class LogSDCardListener
    implements SDCardReceiver.SDCardListener
  {
    public void onReceive(Intent paramIntent)
    {
      String str1 = paramIntent.getAction();
      Uri localUri = paramIntent.getData();
      if (localUri != null)
      {
        String str2 = localUri.getScheme();
        if ("file".equals(str2))
        {
          String str3 = Loggers.externalStoragePath;
          String str4 = localUri.getPath();
          if (str3.equals(str4))
          {
            if (!"android.intent.action.MEDIA_MOUNTED".equals(str1))
              break label64;
            Loggers.onSDCardMounted();
          }
        }
      }
      while (true)
      {
        return;
        label64: if ("android.intent.action.MEDIA_UNMOUNTED".equals(str1))
        {
          Loggers.onSDCardUnmounted();
          continue;
        }
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.log.Loggers
 * JD-Core Version:    0.6.0
 */