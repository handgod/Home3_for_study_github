package com.softspb.util.log;

import android.util.Log;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class Logger
{
  private volatile boolean isEnabled;
  private volatile boolean isThreadLoggingEnabled;
  private final List<SPBLogPrinter> logPrinters;
  private final String name;

  Logger(String paramString, int paramInt)
  {
    CopyOnWriteArrayList localCopyOnWriteArrayList = new CopyOnWriteArrayList();
    this.logPrinters = localCopyOnWriteArrayList;
    this.isThreadLoggingEnabled = 0;
    this.isEnabled = 0;
    this.name = paramString;
  }

  Logger(String paramString, int paramInt, SPBLogPrinter paramSPBLogPrinter)
  {
    this(paramString, paramInt);
    boolean bool = this.logPrinters.add(paramSPBLogPrinter);
  }

  private final String prepareMessage(String paramString)
  {
    Thread localThread = Thread.currentThread();
    if (this.isThreadLoggingEnabled)
    {
      StringBuilder localStringBuilder1 = new StringBuilder().append(91);
      String str = localThread.getName();
      StringBuilder localStringBuilder2 = localStringBuilder1.append(str).append(", tid=");
      long l = localThread.getId();
      paramString = l + "] - " + paramString;
    }
    return paramString;
  }

  private final String prepareMessage(String paramString, Throwable paramThrowable)
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str1 = prepareMessage(paramString);
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1).append(10);
    String str2 = Log.getStackTraceString(paramThrowable);
    return str2;
  }

  private void println(int paramInt, String paramString)
  {
    Iterator localIterator = this.logPrinters.iterator();
    while (localIterator.hasNext())
      ((SPBLogPrinter)localIterator.next()).println(paramInt, paramString);
  }

  void addLogPrinter(SPBLogPrinter paramSPBLogPrinter)
  {
    boolean bool = this.logPrinters.add(paramSPBLogPrinter);
    Logger localLogger = Loggers.logger;
    StringBuilder localStringBuilder1 = new StringBuilder().append("Logger \"");
    String str1 = this.name;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1).append("\" is starting to log here with tag=");
    String str2 = paramSPBLogPrinter.tag;
    String str3 = str2;
    localLogger.d(str3);
  }

  public void d(String paramString)
  {
    if (this.isEnabled)
    {
      String str = prepareMessage(paramString);
      println(3, str);
    }
  }

  public void d(String paramString, Throwable paramThrowable)
  {
    if (this.isEnabled)
    {
      String str = prepareMessage(paramString, paramThrowable);
      println(3, str);
    }
  }

  public void d(String paramString, Object[] paramArrayOfObject)
  {
    if (this.isEnabled)
    {
      String str1 = String.format(paramString, paramArrayOfObject);
      String str2 = prepareMessage(str1);
      println(3, str2);
    }
  }

  public void disable()
  {
    this.isEnabled = 0;
  }

  public void disableThreadLog()
  {
    this.isThreadLoggingEnabled = 0;
  }

  public void e(String paramString)
  {
    if (this.isEnabled)
    {
      String str = prepareMessage(paramString);
      println(6, str);
    }
  }

  public void e(String paramString, Throwable paramThrowable)
  {
    if (this.isEnabled)
    {
      String str = prepareMessage(paramString, paramThrowable);
      println(6, str);
    }
  }

  public void enable()
  {
    this.isEnabled = 1;
  }

  public void enableThreadLog()
  {
    this.isThreadLoggingEnabled = 1;
  }

  public String getName()
  {
    return this.name;
  }

  public void i(String paramString)
  {
    if (this.isEnabled)
    {
      String str = prepareMessage(paramString);
      println(4, str);
    }
  }

  public void i(String paramString, Throwable paramThrowable)
  {
    if (this.isEnabled)
    {
      String str = prepareMessage(paramString, paramThrowable);
      println(4, str);
    }
  }

  public void i(String paramString, Object[] paramArrayOfObject)
  {
    if (this.isEnabled)
    {
      String str1 = String.format(paramString, paramArrayOfObject);
      String str2 = prepareMessage(str1);
      println(4, str2);
    }
  }

  public void v(String paramString)
  {
    if (this.isEnabled)
    {
      String str = prepareMessage(paramString);
      println(2, str);
    }
  }

  public void v(String paramString, Throwable paramThrowable)
  {
    if (this.isEnabled)
    {
      String str = prepareMessage(paramString, paramThrowable);
      println(2, str);
    }
  }

  public void w(String paramString)
  {
    if (this.isEnabled)
    {
      String str = prepareMessage(paramString);
      println(5, str);
    }
  }

  public void w(String paramString, Throwable paramThrowable)
  {
    if (this.isEnabled)
    {
      String str = prepareMessage(paramString, paramThrowable);
      println(5, str);
    }
  }

  public void w(String paramString, Object[] paramArrayOfObject)
  {
    if (this.isEnabled)
    {
      String str1 = String.format(paramString, paramArrayOfObject);
      String str2 = prepareMessage(str1);
      println(5, str2);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.log.Logger
 * JD-Core Version:    0.6.0
 */