package com.softspb.util.log;

import android.util.Log;
import java.io.File;
import java.util.concurrent.ConcurrentLinkedQueue;

class SynchronizedFileAppender
  implements Runnable
{
  private static final long MAX_FLUSH_INTERVAL_MS = 10000L;
  private final File file;
  private boolean isClosed;
  private boolean isEnabled;
  private int lastAddedLineNumber;
  private int lineCount;
  private final ConcurrentLinkedQueue<String> logQueue;
  private final Object monitor;
  private final String name;
  int usersCount;
  private Thread workerThread;

  SynchronizedFileAppender(File paramFile, String paramString)
  {
    ConcurrentLinkedQueue localConcurrentLinkedQueue = new ConcurrentLinkedQueue();
    this.logQueue = localConcurrentLinkedQueue;
    this.isClosed = 0;
    this.isEnabled = 1;
    Object localObject = new Object();
    this.monitor = localObject;
    this.lineCount = 0;
    this.lastAddedLineNumber = -1;
    this.usersCount = 0;
    this.name = paramString;
    this.file = paramFile;
    Thread localThread = new Thread(this, paramString);
    this.workerThread = localThread;
    this.workerThread.start();
  }

  void close()
  {
    Logger localLogger = Loggers.logger;
    StringBuilder localStringBuilder = new StringBuilder().append("Closing file appender: ");
    String str1 = this.file.getPath();
    String str2 = str1;
    localLogger.d(str2);
    this.isClosed = 1;
    synchronized (this.monitor)
    {
      this.monitor.notifyAll();
      return;
    }
  }

  void disable()
  {
    Logger localLogger = Loggers.logger;
    StringBuilder localStringBuilder = new StringBuilder().append("Disabling file appender: ");
    String str1 = this.file.getPath();
    String str2 = str1;
    localLogger.d(str2);
    this.isEnabled = 0;
    synchronized (this.monitor)
    {
      this.monitor.notify();
      return;
    }
  }

  void enable()
  {
    Logger localLogger = Loggers.logger;
    StringBuilder localStringBuilder1 = new StringBuilder().append("Enabling file appender: ");
    String str1 = this.file.getPath();
    String str2 = str1;
    localLogger.d(str2);
    this.isEnabled = 1;
    StringBuilder localStringBuilder2 = new StringBuilder().append("File appender was re-enabled: ");
    int i = this.lineCount;
    int j = this.lastAddedLineNumber;
    int k = i - j + -1;
    String str3 = k + " lines were skipped";
    println(str3);
    synchronized (this.monitor)
    {
      this.monitor.notify();
      return;
    }
  }

  // ERROR //
  void flush()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 39	com/softspb/util/log/SynchronizedFileAppender:logQueue	Ljava/util/concurrent/ConcurrentLinkedQueue;
    //   4: invokevirtual 127	java/util/concurrent/ConcurrentLinkedQueue:poll	()Ljava/lang/Object;
    //   7: checkcast 129	java/lang/String
    //   10: astore_1
    //   11: aload_1
    //   12: ifnull +67 -> 79
    //   15: aconst_null
    //   16: astore_2
    //   17: aload_0
    //   18: getfield 57	com/softspb/util/log/SynchronizedFileAppender:file	Ljava/io/File;
    //   21: astore_3
    //   22: new 131	java/io/FileWriter
    //   25: dup
    //   26: aload_3
    //   27: ldc 43
    //   29: invokespecial 134	java/io/FileWriter:<init>	(Ljava/io/File;Z)V
    //   32: astore 4
    //   34: new 136	java/io/PrintWriter
    //   37: dup
    //   38: aload 4
    //   40: invokespecial 139	java/io/PrintWriter:<init>	(Ljava/io/Writer;)V
    //   43: astore 5
    //   45: aload_1
    //   46: ifnull +23 -> 69
    //   49: aload 5
    //   51: aload_1
    //   52: invokevirtual 140	java/io/PrintWriter:println	(Ljava/lang/String;)V
    //   55: aload_0
    //   56: getfield 39	com/softspb/util/log/SynchronizedFileAppender:logQueue	Ljava/util/concurrent/ConcurrentLinkedQueue;
    //   59: invokevirtual 127	java/util/concurrent/ConcurrentLinkedQueue:poll	()Ljava/lang/Object;
    //   62: checkcast 129	java/lang/String
    //   65: astore_1
    //   66: goto -21 -> 45
    //   69: aload 5
    //   71: ifnull +8 -> 79
    //   74: aload 5
    //   76: invokevirtual 142	java/io/PrintWriter:close	()V
    //   79: return
    //   80: astore 6
    //   82: getstatic 74	com/softspb/util/log/Loggers:logger	Lcom/softspb/util/log/Logger;
    //   85: astore 7
    //   87: new 76	java/lang/StringBuilder
    //   90: dup
    //   91: invokespecial 77	java/lang/StringBuilder:<init>	()V
    //   94: ldc 144
    //   96: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   99: astore 8
    //   101: aload_0
    //   102: getfield 57	com/softspb/util/log/SynchronizedFileAppender:file	Ljava/io/File;
    //   105: invokevirtual 89	java/io/File:getPath	()Ljava/lang/String;
    //   108: astore 9
    //   110: aload 8
    //   112: aload 9
    //   114: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   117: ldc 146
    //   119: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   122: aload 6
    //   124: invokevirtual 149	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   127: invokevirtual 92	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   130: astore 10
    //   132: aload 7
    //   134: aload 10
    //   136: aload 6
    //   138: invokevirtual 153	com/softspb/util/log/Logger:w	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   141: aload_0
    //   142: ldc 40
    //   144: putfield 45	com/softspb/util/log/SynchronizedFileAppender:isEnabled	Z
    //   147: aload_2
    //   148: ifnull -69 -> 79
    //   151: aload_2
    //   152: invokevirtual 142	java/io/PrintWriter:close	()V
    //   155: goto -76 -> 79
    //   158: astore 11
    //   160: aload_2
    //   161: ifnull +7 -> 168
    //   164: aload_2
    //   165: invokevirtual 142	java/io/PrintWriter:close	()V
    //   168: aload 11
    //   170: athrow
    //   171: astore 11
    //   173: aload 5
    //   175: astore_2
    //   176: goto -16 -> 160
    //   179: astore 6
    //   181: aload 5
    //   183: astore_2
    //   184: goto -102 -> 82
    //
    // Exception table:
    //   from	to	target	type
    //   17	45	80	java/io/IOException
    //   17	45	158	finally
    //   82	147	158	finally
    //   49	66	171	finally
    //   49	66	179	java/io/IOException
  }

  File getFile()
  {
    return this.file;
  }

  String getName()
  {
    return this.name;
  }

  void println(String paramString)
  {
    int i = this.lineCount + 1;
    this.lineCount = i;
    if ((!this.isClosed) && (this.isEnabled))
    {
      boolean bool = this.logQueue.add(paramString);
      int j = this.lineCount + -1;
      this.lastAddedLineNumber = j;
    }
    synchronized (this.monitor)
    {
      this.monitor.notify();
      return;
    }
  }

  public void run()
  {
    if (!this.isClosed)
    {
      if (this.isEnabled)
        flush();
      try
      {
        synchronized (this.monitor)
        {
          this.monitor.wait(10000L);
        }
      }
      catch (InterruptedException localInterruptedException)
      {
        StringBuilder localStringBuilder = new StringBuilder().append("Interrupted logging to file ");
        String str1 = this.file.getPath();
        String str2 = str1 + ": " + localInterruptedException;
        int i = Log.w("Logger", str2, localInterruptedException);
        monitorexit;
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.log.SynchronizedFileAppender
 * JD-Core Version:    0.6.0
 */