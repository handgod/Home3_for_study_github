package com.softspb.util.log;

import java.text.SimpleDateFormat;
import java.util.Date;

class LogFilePrinter extends SPBLogPrinter
{
  private static SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd HH:mm:ss.SSS");
  private boolean isClosed = 0;
  private final SynchronizedFileAppender out;

  LogFilePrinter(String paramString, SynchronizedFileAppender paramSynchronizedFileAppender)
  {
    super(paramString);
    this.out = paramSynchronizedFileAppender;
  }

  void close()
  {
    this.isClosed = 1;
  }

  void flush()
  {
    if (!this.isClosed)
      this.out.flush();
  }

  SynchronizedFileAppender getOut()
  {
    return this.out;
  }

  public void println(int paramInt, String paramString, long paramLong)
  {
    if (this.isClosed)
      return;
    StringBuilder localStringBuilder1 = new StringBuilder();
    SimpleDateFormat localSimpleDateFormat = dateFormat;
    Date localDate = new Date(paramLong);
    String str1 = localSimpleDateFormat.format(localDate);
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
    switch (paramInt)
    {
    default:
      StringBuilder localStringBuilder3 = localStringBuilder1.append(": ANY/");
    case 5:
    case 2:
    case 3:
    case 4:
    case 6:
    }
    while (true)
    {
      String str2 = this.tag;
      StringBuilder localStringBuilder4 = localStringBuilder1.append(str2).append(": ").append(paramString);
      SynchronizedFileAppender localSynchronizedFileAppender = this.out;
      String str3 = localStringBuilder1.toString();
      localSynchronizedFileAppender.println(str3);
      break;
      StringBuilder localStringBuilder5 = localStringBuilder1.append(": WARN/");
      continue;
      StringBuilder localStringBuilder6 = localStringBuilder1.append(": VERBOSE/");
      continue;
      StringBuilder localStringBuilder7 = localStringBuilder1.append(": DEBUG/");
      continue;
      StringBuilder localStringBuilder8 = localStringBuilder1.append(": INFO/");
      continue;
      StringBuilder localStringBuilder9 = localStringBuilder1.append(": ERROR/");
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.log.LogFilePrinter
 * JD-Core Version:    0.6.0
 */