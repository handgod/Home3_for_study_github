package com.softspb.util.log;

class MultiLogPrinter extends SPBLogPrinter
{
  SPBLogPrinter[] printers;

  MultiLogPrinter(String paramString, SPBLogPrinter[] paramArrayOfSPBLogPrinter)
  {
    super(paramString);
    this.printers = paramArrayOfSPBLogPrinter;
  }

  void println(int paramInt, String paramString, long paramLong)
  {
    SPBLogPrinter[] arrayOfSPBLogPrinter = this.printers;
    int i = arrayOfSPBLogPrinter.length;
    int j = 0;
    while (j < i)
    {
      arrayOfSPBLogPrinter[j].println(paramInt, paramString, paramLong);
      j += 1;
    }
  }

  void setTag(String paramString)
  {
    super.setTag(paramString);
    SPBLogPrinter[] arrayOfSPBLogPrinter = this.printers;
    int i = arrayOfSPBLogPrinter.length;
    int j = 0;
    while (j < i)
    {
      arrayOfSPBLogPrinter[j].setTag(paramString);
      j += 1;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.log.MultiLogPrinter
 * JD-Core Version:    0.6.0
 */