package com.softspb.util.log;

import java.util.concurrent.locks.ReentrantLock;

class DebuggingReentrantLock extends ReentrantLock
{
  static Logger logger = Loggers.getLogger(DebuggingReentrantLock.class.getName());
  private String id;

  DebuggingReentrantLock(String paramString)
  {
    this.id = paramString;
  }

  private void logTrace()
  {
    Exception localException = new Exception();
    Throwable localThrowable = localException.fillInStackTrace();
    StackTraceElement[] arrayOfStackTraceElement = localException.getStackTrace();
    int i = 2;
    while (true)
    {
      int j = arrayOfStackTraceElement.length;
      if (i >= j)
        break;
      Logger localLogger = logger;
      String str = arrayOfStackTraceElement[i].toString();
      localLogger.d(str);
      i += 1;
    }
  }

  public void lock()
  {
    logTrace();
    Thread localThread = getOwner();
    Logger localLogger = logger;
    StringBuilder localStringBuilder1 = new StringBuilder().append("Lock(");
    String str1 = this.id;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1).append(") owned by ");
    if (localThread == null)
    {
      str2 = "null";
      StringBuilder localStringBuilder3 = localStringBuilder2.append(str2).append(" : thread #");
      long l1 = Thread.currentThread().getId();
      StringBuilder localStringBuilder4 = localStringBuilder3.append(l1).append("(");
      String str3 = Thread.currentThread().getName();
      StringBuilder localStringBuilder5 = localStringBuilder4.append(str3).append(")").append(" is entering the lock, count=");
      int i = getHoldCount();
      String str4 = i;
      localLogger.d(str4);
      super.lock();
      localLogger = logger;
      StringBuilder localStringBuilder6 = new StringBuilder().append("Lock(");
      String str5 = this.id;
      localStringBuilder2 = localStringBuilder6.append(str5).append(") owned by ");
      if (localThread != null)
        break label311;
    }
    label311: StringBuilder localStringBuilder12;
    String str8;
    for (String str2 = "null"; ; str2 = str8 + ")")
    {
      StringBuilder localStringBuilder7 = localStringBuilder2.append(str2).append(" : thread #");
      long l2 = Thread.currentThread().getId();
      StringBuilder localStringBuilder8 = localStringBuilder7.append(l2).append(" has entered the lock, count=");
      int j = getHoldCount();
      String str6 = j;
      localLogger.d(str6);
      return;
      StringBuilder localStringBuilder9 = new StringBuilder().append("thread #");
      long l3 = localThread.getId();
      StringBuilder localStringBuilder10 = localStringBuilder9.append(l3).append("(");
      String str7 = localThread.getName();
      str2 = str7 + ")";
      break;
      StringBuilder localStringBuilder11 = new StringBuilder().append("thread #");
      long l4 = localThread.getId();
      localStringBuilder12 = localStringBuilder11.append(l4).append("(");
      str8 = localThread.getName();
    }
  }

  public void unlock()
  {
    Thread localThread = getOwner();
    Logger localLogger = logger;
    StringBuilder localStringBuilder1 = new StringBuilder().append("Lock(");
    String str1 = this.id;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1).append(") owned by ");
    if (localThread == null)
    {
      str2 = "null";
      StringBuilder localStringBuilder3 = localStringBuilder2.append(str2).append(" : thread #");
      long l1 = Thread.currentThread().getId();
      StringBuilder localStringBuilder4 = localStringBuilder3.append(l1).append("(");
      String str3 = Thread.currentThread().getName();
      StringBuilder localStringBuilder5 = localStringBuilder4.append(str3).append(")").append(" is about to release the lock, count=");
      int i = getHoldCount();
      String str4 = i;
      localLogger.d(str4);
      super.unlock();
      localLogger = logger;
      StringBuilder localStringBuilder6 = new StringBuilder().append("Lock(");
      String str5 = this.id;
      localStringBuilder2 = localStringBuilder6.append(str5).append(") owned by ");
      if (localThread != null)
        break label334;
    }
    label334: StringBuilder localStringBuilder13;
    String str9;
    for (String str2 = "null"; ; str2 = str9 + ")")
    {
      StringBuilder localStringBuilder7 = localStringBuilder2.append(str2).append(" : thread #");
      long l2 = Thread.currentThread().getId();
      StringBuilder localStringBuilder8 = localStringBuilder7.append(l2).append("(");
      String str6 = Thread.currentThread().getName();
      StringBuilder localStringBuilder9 = localStringBuilder8.append(str6).append(")").append(" has released the lock, count=");
      int j = getHoldCount();
      String str7 = j;
      localLogger.d(str7);
      return;
      StringBuilder localStringBuilder10 = new StringBuilder().append("thread #");
      long l3 = localThread.getId();
      StringBuilder localStringBuilder11 = localStringBuilder10.append(l3).append("(");
      String str8 = localThread.getName();
      str2 = str8 + ")";
      break;
      StringBuilder localStringBuilder12 = new StringBuilder().append("thread #");
      long l4 = localThread.getId();
      localStringBuilder13 = localStringBuilder12.append(l4).append("(");
      str9 = localThread.getName();
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.log.DebuggingReentrantLock
 * JD-Core Version:    0.6.0
 */