package com.softspb.util.log;

import android.util.Log;

class SystemLogPrinter extends SPBLogPrinter
{
  SystemLogPrinter(String paramString)
  {
    super(paramString);
  }

  public void println(int paramInt, String paramString, long paramLong)
  {
    String str = this.tag;
    int i = Log.println(paramInt, str, paramString);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.log.SystemLogPrinter
 * JD-Core Version:    0.6.0
 */