package com.softspb.util;

import android.content.Context;
import android.preference.ListPreference;
import android.util.AttributeSet;

public class IntListPreference extends ListPreference
  implements IIntListPreference
{
  int mValue;

  public IntListPreference(Context paramContext)
  {
    super(paramContext);
  }

  public IntListPreference(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  protected void onSetInitialValue(boolean paramBoolean, Object paramObject)
  {
    if (paramBoolean)
    {
      int i = this.mValue;
      int j = getPersistedInt(i);
      setValue(j);
    }
    while (true)
    {
      return;
      String str = (String)paramObject;
      setValue(str);
    }
  }

  protected boolean persistString(String paramString)
  {
    return true;
  }

  public void setValue(int paramInt)
  {
    String str = Integer.toString(paramInt);
    setValue(str);
  }

  public void setValue(String paramString)
  {
    super.setValue(paramString);
    int i = Integer.parseInt(paramString);
    this.mValue = i;
    int j = this.mValue;
    boolean bool = persistInt(j);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.IntListPreference
 * JD-Core Version:    0.6.0
 */