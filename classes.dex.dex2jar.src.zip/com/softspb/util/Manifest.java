package com.softspb.util;

public final class Manifest
{
  public final class permission
  {
    public static final String permission = "com.spb.shell3d.spb.permission";
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.Manifest
 * JD-Core Version:    0.6.0
 */