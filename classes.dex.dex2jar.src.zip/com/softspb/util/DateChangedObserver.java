package com.softspb.util;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.text.format.Time;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.util.Iterator;
import java.util.LinkedList;

public final class DateChangedObserver extends BroadcastReceiver
{
  private static final String ACTION_MIDNIGHT = "com.spb.shell3d.ACTION_MIDNIGHT";
  private static volatile DateChangedObserver instance;
  private static Logger logger = Loggers.getLogger(DateChangedObserver.class.getName());
  private int eventCounter;
  private Time latestCurrentDate;
  private final LinkedList<DateChangedListener> listeners;
  private PendingIntent midnightAlarm;
  private boolean notifyEnabled = 0;

  private DateChangedObserver()
  {
    LinkedList localLinkedList = new LinkedList();
    this.listeners = localLinkedList;
  }

  private Time getCurrentDate()
  {
    Time localTime = new Time();
    localTime.setToNow();
    localTime.hour = 0;
    localTime.minute = 0;
    localTime.second = 0;
    long l = localTime.normalize(0);
    return localTime;
  }

  public static DateChangedObserver getInstance()
  {
    if (instance == null);
    synchronized (DateChangedObserver.class)
    {
      if (instance == null)
        instance = new DateChangedObserver();
      return instance;
    }
  }

  private Time getNextMidnight()
  {
    Time localTime = getCurrentDate();
    int i = localTime.monthDay + 1;
    localTime.monthDay = i;
    long l = localTime.normalize(0);
    return localTime;
  }

  private void notifyListeners()
  {
    synchronized (this.listeners)
    {
      Iterator localIterator = this.listeners.iterator();
      if (localIterator.hasNext())
      {
        DateChangedListener localDateChangedListener = (DateChangedListener)localIterator.next();
        Logger localLogger = logger;
        String str = "Notifying listener: " + localDateChangedListener;
        localLogger.d(str);
        localDateChangedListener.onDateChanged();
      }
    }
    Time localTime = getCurrentDate();
    this.latestCurrentDate = localTime;
    monitorexit;
  }

  private void registerForEvents(Context paramContext)
  {
    logger.d("registerForEvents");
    IntentFilter localIntentFilter = new IntentFilter();
    Intent localIntent1 = new Intent("com.spb.shell3d.ACTION_MIDNIGHT");
    PendingIntent localPendingIntent1 = PendingIntent.getBroadcast(paramContext, 0, localIntent1, 1342177280);
    this.midnightAlarm = localPendingIntent1;
    Time localTime = getNextMidnight();
    AlarmManager localAlarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    long l = localTime.toMillis(0);
    PendingIntent localPendingIntent2 = this.midnightAlarm;
    localAlarmManager.set(1, l, localPendingIntent2);
    localIntentFilter.addAction("com.spb.shell3d.ACTION_MIDNIGHT");
    localIntentFilter.addAction("android.intent.action.DATE_CHANGED");
    localIntentFilter.addAction("android.intent.action.TIME_SET");
    localIntentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
    Intent localIntent2 = paramContext.registerReceiver(this, localIntentFilter);
  }

  private void unregisterFromEvents(Context paramContext)
  {
    logger.d("unregisterFromEvents");
    AlarmManager localAlarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    if (this.midnightAlarm != null)
    {
      PendingIntent localPendingIntent = this.midnightAlarm;
      localAlarmManager.cancel(localPendingIntent);
      this.midnightAlarm = null;
    }
    paramContext.unregisterReceiver(this);
  }

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    Logger localLogger = logger;
    StringBuilder localStringBuilder = new StringBuilder().append("event: ");
    String str1 = paramIntent.getAction();
    String str2 = str1;
    localLogger.d(str2);
    int i = this.eventCounter + 1;
    this.eventCounter = i;
    if (this.notifyEnabled)
      notifyListeners();
  }

  public void pause(Context paramContext)
  {
    logger.d("pause");
    this.notifyEnabled = 0;
    this.eventCounter = 0;
  }

  public void registerListener(DateChangedListener paramDateChangedListener)
  {
    synchronized (this.listeners)
    {
      if (!this.listeners.contains(paramDateChangedListener))
      {
        boolean bool = this.listeners.add(paramDateChangedListener);
        Logger localLogger = logger;
        String str = "Added listener: " + paramDateChangedListener;
        localLogger.d(str);
        this.latestCurrentDate = null;
      }
      return;
    }
  }

  public void resume(Context paramContext)
  {
    logger.d("resume");
    Time localTime1 = getCurrentDate();
    if (this.latestCurrentDate != null)
    {
      Time localTime2 = this.latestCurrentDate;
      if ((Time.compare(localTime1, localTime2) == 0) && (this.eventCounter <= 0));
    }
    else
    {
      notifyListeners();
      this.latestCurrentDate = localTime1;
    }
    this.notifyEnabled = 1;
  }

  public void start(Context paramContext)
  {
    logger.d("start");
    registerForEvents(paramContext);
  }

  public void stop(Context paramContext)
  {
    logger.d("stop");
    unregisterFromEvents(paramContext);
  }

  public void unregisterListener(DateChangedListener paramDateChangedListener)
  {
    synchronized (this.listeners)
    {
      boolean bool = this.listeners.remove(paramDateChangedListener);
      Logger localLogger = logger;
      String str = "Removed listener: " + paramDateChangedListener;
      localLogger.d(str);
      return;
    }
  }

  public abstract interface DateChangedListener
  {
    public abstract void onDateChanged();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.softspb.util.DateChangedObserver
 * JD-Core Version:    0.6.0
 */