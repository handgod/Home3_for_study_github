package com.spb.programlist;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

class ProgramList$1 extends BroadcastReceiver
{
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    String str1 = paramIntent.getAction();
    String str2 = paramIntent.getData().getSchemeSpecificPart();
    if (("android.intent.action.PACKAGE_REMOVED".equals(str1)) || ("android.intent.action.PACKAGE_CHANGED".equals(str1)))
      ProgramList.access$000(this.this$0, str2);
    if (("android.intent.action.PACKAGE_ADDED".equals(str1)) || ("android.intent.action.PACKAGE_CHANGED".equals(str1)))
      ProgramList.access$100(this.this$0, str2);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.programlist.ProgramList.1
 * JD-Core Version:    0.6.0
 */