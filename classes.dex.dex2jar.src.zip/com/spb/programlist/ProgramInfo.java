package com.spb.programlist;

public final class ProgramInfo
{
  public final String activityClassName;
  public final String activityIconResource;
  public final String activityLabel;
  public final boolean addToPrograms;
  public final boolean isDefault;
  public final boolean isUninstallable;
  public final String packageName;
  public final String widgetTag;

  ProgramInfo(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
  {
    this.packageName = paramString1;
    this.activityClassName = paramString2;
    this.activityLabel = paramString3;
    this.activityIconResource = paramString4;
    this.widgetTag = paramString5;
    this.addToPrograms = paramBoolean1;
    this.isDefault = paramBoolean2;
    this.isUninstallable = paramBoolean3;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.programlist.ProgramInfo
 * JD-Core Version:    0.6.0
 */