package com.spb.programlist;

public final class R
{
  public final class styleable
  {
    public static final int[] WeatherParameter = ;
    public static final int WeatherParameter_formats = 4;
    public static final int WeatherParameter_initialUnits = 8;
    public static final int WeatherParameter_largeIcon = 7;
    public static final int WeatherParameter_rangeFormats = 5;
    public static final int WeatherParameter_smallIcon = 6;
    public static final int WeatherParameter_title = 0;
    public static final int WeatherParameter_units = 2;
    public static final int WeatherParameter_unitsTitle = 1;
    public static final int WeatherParameter_unitsValues = 3;
  }

  public final class xml
  {
    public static final int services = 2131034112;
    public static final int widget_info = 2131034113;
  }

  public final class style
  {
    public static final int AlertDialogCustom = 2131361795;
    public static final int Theme_NoShadow_NoTitleBar = 2131361792;
    public static final int Theme_NoTitleBar_NoBackground = 2131361803;
    public static final int Theme_Wallpaper_NoTitleBar_NoBackground = 2131361804;
    public static final int WeatherParameter = 2131361796;
    public static final int WeatherParameter_DewPoint = 2131361799;
    public static final int WeatherParameter_Pressure = 2131361797;
    public static final int WeatherParameter_RelativeHumidity = 2131361801;
    public static final int WeatherParameter_Temperature = 2131361798;
    public static final int WeatherParameter_WindDirection = 2131361802;
    public static final int WeatherParameter_WindSpeed = 2131361800;
    public static final int all_services_title = 2131361794;
    public static final int service_title = 2131361793;
  }

  public final class string
  {
    public static final int app_name = 2131099657;
    public static final int cancel = 2131099739;
    public static final int choose_skin = 2131099650;
    public static final int chooser_wallpaper = 2131099731;
    public static final int cities_provider_asset_db_filename = 2131099683;
    public static final int city_location_failed = 2131099692;
    public static final int contacts_failed_pick = 2131099755;
    public static final int delete = 2131099667;
    public static final int dialog_choose_widget = 2131099730;
    public static final int dialog_select_shortcut = 2131099729;
    public static final int dialog_shell_loading = 2131099727;
    public static final int dialog_unsupported_devices_message = 2131099743;
    public static final int dialog_unsupported_devices_title = 2131099742;
    public static final int error = 2131099740;
    public static final int example = 2131099652;
    public static final int exit = 2131099746;
    public static final int gadget_error_text = 2131099728;
    public static final int home_widget_error = 2131099738;
    public static final int infinity = 2131099741;
    public static final int insert_in_search_field = 2131099666;
    public static final int install_dialog_checkbox = 2131099677;
    public static final int install_dialog_description = 2131099676;
    public static final int install_dialog_install = 2131099678;
    public static final int install_dialog_web = 2131099679;
    public static final int launcher_name = 2131099658;
    public static final int legal_notices_title = 2131099747;
    public static final int license_fail = 2131099744;
    public static final int license_fail_handango = 2131099748;
    public static final int logoUrl = 2131099668;
    public static final int menu_clear_history = 2131099653;
    public static final int menu_search_sources = 2131099659;
    public static final int no = 2131099736;
    public static final int pick_wallpaper = 2131099733;
    public static final int purchase = 2131099745;
    public static final int safe_mode_home = 2131099752;
    public static final int safe_mode_retry = 2131099751;
    public static final int safe_mode_text = 2131099750;
    public static final int safe_mode_title = 2131099749;
    public static final int sd_install_text = 2131099754;
    public static final int sd_install_title = 2131099753;
    public static final int search = 2131099660;
    public static final int searchUrl = 2131099681;
    public static final int searching = 2131099651;
    public static final int searching_city_progress = 2131099691;
    public static final int searching_city_title = 2131099690;
    public static final int skin_classic = 2131099654;
    public static final int skin_grey = 2131099656;
    public static final int skin_modern = 2131099655;
    public static final int source_ApplicationsSearchProvider = 2131099663;
    public static final int source_BrowserSearchProvider = 2131099662;
    public static final int source_ContactsSearchProvider = 2131099664;
    public static final int source_SmsSearchProvider = 2131099665;
    public static final int source_SuggestionsSearchProvider = 2131099661;
    public static final int spb_logs_directory_pathname = 2131099648;
    public static final int startup_clid = 2131099726;
    public static final int suggestUrl = 2131099680;
    public static final int voice_search_dialog_cancel_button = 2131099675;
    public static final int voice_search_dialog_hint = 2131099670;
    public static final int voice_search_dialog_network = 2131099674;
    public static final int voice_search_dialog_title = 2131099669;
    public static final int voice_search_dialog_unrecognized = 2131099673;
    public static final int voice_search_dialog_wait = 2131099671;
    public static final int voice_search_dialog_wait_before = 2131099672;
    public static final int voice_search_locale = 2131099682;
    public static final int wait = 2131099737;
    public static final int wallpaper_instructions = 2131099732;
    public static final int wallpapers_spb = 2131099734;
    public static final int weather_add_city_menu_title = 2131099719;
    public static final int weather_change_city_menu_title = 2131099721;
    public static final int weather_city_title = 2131099684;
    public static final int weather_config_launch_mode_widget_title = 2131099725;
    public static final int weather_config_menu_title = 2131099722;
    public static final int weather_config_update_period_title = 2131099723;
    public static final int weather_current_location = 2131099688;
    public static final int weather_enable_location = 2131099689;
    public static final int weather_enter_city_name = 2131099685;
    public static final int weather_format_current_location = 2131099712;
    public static final int weather_humidity_default_units = 2131099708;
    public static final int weather_humidity_range_format_1 = 2131099707;
    public static final int weather_locate_nearest_city = 2131099687;
    public static final int weather_more_cities = 2131099686;
    public static final int weather_parameter_dew_point_title = 2131099703;
    public static final int weather_parameter_humidity_title = 2131099699;
    public static final int weather_parameter_humidity_units_title = 2131099700;
    public static final int weather_parameter_press_title = 2131099695;
    public static final int weather_parameter_press_units_title = 2131099696;
    public static final int weather_parameter_temp_title = 2131099693;
    public static final int weather_parameter_temp_units_title = 2131099694;
    public static final int weather_parameter_wind_dir_title = 2131099701;
    public static final int weather_parameter_wind_dir_units_title = 2131099702;
    public static final int weather_parameter_wind_speed_title = 2131099697;
    public static final int weather_parameter_wind_speed_units_title = 2131099698;
    public static final int weather_pressure_default_units = 2131099705;
    public static final int weather_refresh_menu_title = 2131099718;
    public static final int weather_remove_city_menu_title = 2131099720;
    public static final int weather_status_positioning = 2131099715;
    public static final int weather_status_positioning_failed = 2131099716;
    public static final int weather_status_refreshing = 2131099713;
    public static final int weather_status_update_failed = 2131099714;
    public static final int weather_temp_default_units = 2131099704;
    public static final int weather_updated = 2131099717;
    public static final int weather_use_only_wifi_title = 2131099724;
    public static final int weather_wind_direction_variable = 2131099711;
    public static final int weather_wind_speed_default_units = 2131099706;
    public static final int weather_winddir_default_units = 2131099710;
    public static final int weather_winddir_range_format = 2131099709;
    public static final int widget_name = 2131099649;
    public static final int yes = 2131099735;
  }

  public final class layout
  {
    public static final int add_dialog_list_item = 2130903040;
    public static final int appwidget_error = 2130903041;
    public static final int audio_search_dialog = 2130903042;
    public static final int audio_search_list = 2130903043;
    public static final int audio_search_list_item = 2130903044;
    public static final int bold_line = 2130903045;
    public static final int dialog_check_box = 2130903046;
    public static final int dialog_content_view = 2130903047;
    public static final int dialog_spinner = 2130903048;
    public static final int dialog_text_input = 2130903049;
    public static final int generic_dialog_box = 2130903050;
    public static final int logger_config_screen = 2130903051;
    public static final int logger_header_check = 2130903052;
    public static final int logger_header_plus = 2130903053;
    public static final int logger_list_item = 2130903054;
    public static final int logger_list_separator = 2130903055;
    public static final int main = 2130903056;
    public static final int shortcut_dialog_pick_item = 2130903057;
    public static final int wallpaper_chooser = 2130903058;
    public static final int wallpaper_item = 2130903059;
    public static final int weather_city_dropdown_list_item2 = 2130903060;
    public static final int weather_city_selection = 2130903061;
    public static final int yandex_bar_classic = 2130903062;
    public static final int yandex_bar_grey = 2130903063;
    public static final int yandex_bar_modern = 2130903064;
    public static final int z_install_dialog = 2130903065;
    public static final int z_item_application = 2130903066;
    public static final int z_item_base = 2130903067;
    public static final int z_item_browser = 2130903068;
    public static final int z_item_contact = 2130903069;
    public static final int z_item_sms = 2130903070;
    public static final int z_line = 2130903071;
    public static final int z_main = 2130903072;
    public static final int z_search_provider = 2130903073;
    public static final int z_search_sources = 2130903074;
    public static final int z_services_item = 2130903075;
    public static final int z_services_row = 2130903076;
    public static final int z_settings = 2130903077;
    public static final int z_settings_layout_item = 2130903078;
  }

  public final class integer
  {
    public static final int cities_db_source_version = 2131427332;
    public static final int current_location_default_update_period = 2131427331;
    public static final int location_timeout_sec_gps = 2131427328;
    public static final int location_timeout_sec_network = 2131427329;
    public static final int location_timeout_sec_others = 2131427330;
    public static final int weather_default_update_period = 2131427333;
  }

  public final class id
  {
    public static final int alwaysCheckBox = 2131492904;
    public static final int audio_search_button = 2131492872;
    public static final int bSearch = 2131492915;
    public static final int button = 2131492908;
    public static final int button_done = 2131492886;
    public static final int button_revert = 2131492887;
    public static final int categoryButton = 2131492919;
    public static final int clearButton = 2131492913;
    public static final int comment = 2131492907;
    public static final int countTextView = 2131492922;
    public static final int dialog_box_checkbox01 = 2131492879;
    public static final int dialog_box_checkbox02 = 2131492880;
    public static final int dialog_box_checkbox03 = 2131492881;
    public static final int dialog_box_checkbox04 = 2131492882;
    public static final int dialog_box_input = 2131492878;
    public static final int dialog_box_prompt = 2131492877;
    public static final int fullListBottomLine = 2131492926;
    public static final int gallery = 2131492896;
    public static final int gl_surface_view = 2131492893;
    public static final int header_text1 = 2131492883;
    public static final int header_text2 = 2131492884;
    public static final int icon = 2131492894;
    public static final int image = 2131492905;
    public static final int input_file = 2131492890;
    public static final int input_tag = 2131492889;
    public static final int item_divider = 2131492876;
    public static final int layoutsLinearLayout = 2131492930;
    public static final int logo = 2131492903;
    public static final int micButton = 2131492914;
    public static final int minus = 2131492891;
    public static final int options_list = 2131492885;
    public static final int plus = 2131492888;
    public static final int providerFullList = 2131492924;
    public static final int providerIcon = 2131492921;
    public static final int providerList = 2131492925;
    public static final int providersList = 2131492917;
    public static final int right_shadow = 2131492923;
    public static final int scroll = 2131492916;
    public static final int search_field = 2131492912;
    public static final int serviceImage = 2131492927;
    public static final int serviceTitle = 2131492928;
    public static final int serviceTitleAlone = 2131492929;
    public static final int servicesContainer = 2131492910;
    public static final int servicesPane = 2131492909;
    public static final int set = 2131492897;
    public static final int skin = 2131492932;
    public static final int sourcesLinearLayout = 2131492931;
    public static final int text = 2131492906;
    public static final int top_shadow = 2131492920;
    public static final int voiceButton = 2131492901;
    public static final int voiceImage = 2131492870;
    public static final int voiceItemButton = 2131492875;
    public static final int voiceItemText = 2131492874;
    public static final int voiceList = 2131492873;
    public static final int voiceProgress = 2131492871;
    public static final int voiceTitle = 2131492869;
    public static final int wallpaper = 2131492895;
    public static final int weather_city_dropdown_item_country = 2131492899;
    public static final int weather_city_dropdown_item_name = 2131492898;
    public static final int weather_city_name_input = 2131492900;
    public static final int weather_menu_add_city = 2131492864;
    public static final int weather_menu_change_city = 2131492868;
    public static final int weather_menu_preferences = 2131492867;
    public static final int weather_menu_refresh = 2131492866;
    public static final int weather_menu_remove_city = 2131492865;
    public static final int widg = 2131492892;
    public static final int widget = 2131492902;
    public static final int withoutScrollLayout = 2131492918;
    public static final int yButton = 2131492911;
  }

  public final class drawable
  {
    public static final int bold_line = 2130837504;
    public static final int btn_circle = 2130837505;
    public static final int btn_circle_disable = 2130837506;
    public static final int btn_circle_disable_focused = 2130837507;
    public static final int btn_circle_normal = 2130837508;
    public static final int btn_circle_pressed = 2130837509;
    public static final int btn_circle_selected = 2130837510;
    public static final int button_classic = 2130837511;
    public static final int button_classic_default = 2130837512;
    public static final int button_classic_pressed = 2130837513;
    public static final int button_grey = 2130837514;
    public static final int button_grey_default = 2130837515;
    public static final int button_grey_pressed = 2130837516;
    public static final int button_modern = 2130837517;
    public static final int button_modern_default = 2130837518;
    public static final int button_modern_pressed = 2130837519;
    public static final int clear = 2130837520;
    public static final int clear_default = 2130837521;
    public static final int clear_pressed = 2130837522;
    public static final int dummy_icon = 2130837523;
    public static final int ic_btn_round_minus = 2130837524;
    public static final int ic_btn_round_plus = 2130837525;
    public static final int ic_launcher_appwidget = 2130837526;
    public static final int ic_launcher_shortcut = 2130837527;
    public static final int ic_launcher_wallpaper = 2130837528;
    public static final int ic_menu_add = 2130837529;
    public static final int ic_menu_add_folders = 2130837530;
    public static final int ic_menu_change = 2130837531;
    public static final int ic_menu_clear_playlist = 2130837532;
    public static final int ic_menu_close_clear_cancel = 2130837533;
    public static final int ic_menu_delete = 2130837534;
    public static final int ic_menu_edit = 2130837535;
    public static final int ic_menu_exit = 2130837536;
    public static final int ic_menu_gallery = 2130837537;
    public static final int ic_menu_info_details = 2130837538;
    public static final int ic_menu_manage = 2130837539;
    public static final int ic_menu_preferences = 2130837540;
    public static final int ic_menu_refresh = 2130837541;
    public static final int ic_menu_sort_by_size = 2130837542;
    public static final int ic_shell_edit_panels = 2130837543;
    public static final int ic_shell_launch = 2130837544;
    public static final int ic_shell_notification = 2130837545;
    public static final int ic_shell_settings = 2130837546;
    public static final int icon = 2130837547;
    public static final int input_classic = 2130837548;
    public static final int input_classic_default = 2130837549;
    public static final int input_classic_pressed = 2130837550;
    public static final int input_modern_grey = 2130837551;
    public static final int input_modern_grey_default = 2130837552;
    public static final int input_modern_grey_pressed = 2130837553;
    public static final int item_application = 2130837554;
    public static final int item_browser = 2130837555;
    public static final int item_contact = 2130837556;
    public static final int item_contact_call_button = 2130837557;
    public static final int item_history = 2130837558;
    public static final int item_sms = 2130837559;
    public static final int item_suggest = 2130837560;
    public static final int items_bg = 2130837561;
    public static final int line = 2130837562;
    public static final int mic_button = 2130837563;
    public static final int mic_dialog = 2130837564;
    public static final int pencil = 2130837565;
    public static final int provider_shadow_hor = 2130837566;
    public static final int provider_shadow_ver = 2130837567;
    public static final int search_edit = 2130837568;
    public static final int search_edit_default = 2130837569;
    public static final int search_edit_focused = 2130837570;
    public static final int search_icon = 2130837571;
    public static final int search_icon_default = 2130837572;
    public static final int search_icon_pressed = 2130837573;
    public static final int search_panel_bg = 2130837574;
    public static final int service_images = 2130837575;
    public static final int service_mail = 2130837576;
    public static final int service_map = 2130837577;
    public static final int service_market = 2130837578;
    public static final int service_news = 2130837579;
    public static final int service_pattern = 2130837580;
    public static final int service_pattern_tile = 2130837581;
    public static final int service_search = 2130837582;
    public static final int service_shadow_bottom = 2130837583;
    public static final int service_shadow_top = 2130837584;
    public static final int service_translate = 2130837585;
    public static final int service_weather = 2130837586;
    public static final int voice_classic = 2130837587;
    public static final int voice_classic_default = 2130837588;
    public static final int voice_classic_pressed = 2130837589;
    public static final int voice_grey = 2130837590;
    public static final int voice_grey_default = 2130837591;
    public static final int voice_grey_pressed = 2130837592;
    public static final int voice_modern = 2130837593;
    public static final int voice_modern_default = 2130837594;
    public static final int voice_modern_pressed = 2130837595;
    public static final int weather_humidity = 2130837596;
    public static final int weather_ic_menu_refresh = 2130837597;
    public static final int weather_large_humidity = 2130837598;
    public static final int weather_large_pressure = 2130837599;
    public static final int weather_large_wind_speed = 2130837600;
    public static final int weather_pressure = 2130837601;
    public static final int weather_wind_speed = 2130837602;
    public static final int ya = 2130837603;
    public static final int ya_selected = 2130837604;
    public static final int yandex_bar_classic_bg = 2130837605;
    public static final int yandex_bar_grey_bg = 2130837606;
    public static final int yandex_bar_modern_bg = 2130837607;
    public static final int yandex_text = 2130837608;
  }

  public final class color
  {
    public static final int appwidget_error_color = 2131296259;
    public static final int calc_bgr_color = 2131296260;
    public static final int primary_text_color = 2131296257;
    public static final int search_bg = 2131296256;
    public static final int secondary_text_color = 2131296258;
  }

  public final class bool
  {
    public static final int logging_enabled = 2131165184;
  }

  public final class attr
  {
    public static final int currentScreenWidgetStyle = 2130771978;
    public static final int currentTabIcon = 2130771980;
    public static final int forecastScreenWidgetStyle = 2130771977;
    public static final int forecastTabIcon = 2130771979;
    public static final int formats = 2130771972;
    public static final int initialUnits = 2130771976;
    public static final int largeIcon = 2130771975;
    public static final int rangeFormats = 2130771973;
    public static final int smallIcon = 2130771974;
    public static final int title = 2130771968;
    public static final int units = 2130771970;
    public static final int unitsTitle = 2130771969;
    public static final int unitsValues = 2130771971;
  }

  public final class array
  {
    public static final int examples = 2131230720;
    public static final int weather_humidity_formats = 2131230735;
    public static final int weather_humidity_range_formats = 2131230736;
    public static final int weather_humidity_unit_titles = 2131230733;
    public static final int weather_humidity_unit_values = 2131230734;
    public static final int weather_icon_titles = 2131230744;
    public static final int weather_launch_mode_choices = 2131230747;
    public static final int weather_launch_mode_values = 2131230748;
    public static final int weather_press_formats = 2131230727;
    public static final int weather_press_range_formats = 2131230728;
    public static final int weather_press_unit_titles = 2131230725;
    public static final int weather_press_unit_values = 2131230726;
    public static final int weather_temp_formats = 2131230723;
    public static final int weather_temp_range_formats = 2131230724;
    public static final int weather_temp_unit_titles = 2131230721;
    public static final int weather_temp_unit_values = 2131230722;
    public static final int weather_update_period_choices = 2131230745;
    public static final int weather_update_period_values = 2131230746;
    public static final int weather_wind_directions = 2131230741;
    public static final int weather_wind_directions_finer = 2131230742;
    public static final int weather_wind_directions_marine = 2131230743;
    public static final int weather_wind_speed_formats = 2131230731;
    public static final int weather_wind_speed_range_formats = 2131230732;
    public static final int weather_wind_speed_unit_titles = 2131230729;
    public static final int weather_wind_speed_unit_values = 2131230730;
    public static final int weather_winddir_formats = 2131230739;
    public static final int weather_winddir_range_formats = 2131230740;
    public static final int weather_winddir_unit_titles = 2131230737;
    public static final int weather_winddir_unit_values = 2131230738;
  }

  public final class anim
  {
    public static final int layout_slide_out = 2130968576;
    public static final int slide_out = 2130968577;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.programlist.R
 * JD-Core Version:    0.6.0
 */