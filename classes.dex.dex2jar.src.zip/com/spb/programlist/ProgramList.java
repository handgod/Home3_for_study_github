package com.spb.programlist;

import android.app.Application;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import com.softspb.util.CollectionFactory;
import com.softspb.util.Conditions;
import com.softspb.util.broadcastreceiver.DecoratedBroadcastReceiver;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.lang.reflect.Method;
import java.net.URISyntaxException;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.List<Landroid.content.pm.ResolveInfo;>;
import java.util.Map;
import java.util.Set;

public class ProgramList
{
  public static final String CATEGORY_SPB_LAUNCHER = "com.spb.shell3d.intent.category.SPB_LAUNCHER";
  private static Logger logger = Loggers.getLogger(ProgramList.class.getName());
  private Context context;
  private DecoratedBroadcastReceiver externalAppReceiver;
  private final List<ProgramListListener> listeners;
  private BroadcastReceiver packageChangeReceiver;
  private PackageManager pm;
  private Map<Intent, List<ResolveInfo>> resolvedIntents;
  private Map<String, TagInfo> tags;
  private boolean useCache;
  private Collection<ActivityInfo> withoutTag;
  private Set<String> woTagAdded;

  public ProgramList(Context paramContext)
  {
    LinkedList localLinkedList1 = CollectionFactory.newLinkedList();
    this.listeners = localLinkedList1;
    ProgramList.1 local1 = new ProgramList.1(this);
    this.packageChangeReceiver = local1;
    this.useCache = 0;
    HashMap localHashMap1 = CollectionFactory.newHashMap();
    this.resolvedIntents = localHashMap1;
    LinkedList localLinkedList2 = CollectionFactory.newLinkedList();
    this.withoutTag = localLinkedList2;
    HashSet localHashSet = CollectionFactory.newHashSet();
    this.woTagAdded = localHashSet;
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver = new DecoratedBroadcastReceiver();
    this.externalAppReceiver = localDecoratedBroadcastReceiver;
    this.context = paramContext;
    HashMap localHashMap2 = new HashMap();
    this.tags = localHashMap2;
    Iterator localIterator = TagSources.getTags(new TagFactory(null)).iterator();
    while (localIterator.hasNext())
    {
      TagInfo localTagInfo = (TagInfo)localIterator.next();
      Map localMap = this.tags;
      String str = localTagInfo.getName();
      Object localObject = localMap.put(str, localTagInfo);
    }
    PackageManager localPackageManager = this.context.getPackageManager();
    this.pm = localPackageManager;
  }

  public static ProgramList getInstance(Context paramContext)
  {
    Context localContext = paramContext.getApplicationContext();
    if (!(localContext instanceof Application))
    {
      String str = "Application context is not an Application instance: " + localContext;
      throw new IllegalArgumentException(str);
    }
    Application localApplication = (Application)localContext;
    Class localClass = localApplication.getClass();
    try
    {
      Class[] arrayOfClass = new Class[1];
      arrayOfClass[0] = Context.class;
      Method localMethod = localClass.getMethod("getProgramList", arrayOfClass);
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = paramContext;
      ProgramList localProgramList = (ProgramList)localMethod.invoke(localApplication, arrayOfObject);
      return localProgramList;
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      throw new IllegalArgumentException("Application class must define getProgramList() method", localNoSuchMethodException);
    }
    catch (Exception localException)
    {
    }
    throw new IllegalArgumentException("Failed to invoke getProgramList() method", localException);
  }

  private List<ResolveInfo> getLauncherActivities(String paramString)
  {
    Intent localIntent1 = new Intent("android.intent.action.MAIN");
    Intent localIntent2 = localIntent1.addCategory("android.intent.category.LAUNCHER");
    Intent localIntent3 = new Intent("android.intent.action.MAIN");
    Intent localIntent4 = localIntent3.addCategory("com.spb.shell3d.intent.category.SPB_LAUNCHER");
    if (paramString != null)
    {
      Intent localIntent5 = localIntent1.setPackage(paramString);
      Intent localIntent6 = localIntent3.setPackage(paramString);
    }
    Object localObject = this.pm.queryIntentActivities(localIntent1, 0);
    List localList = this.pm.queryIntentActivities(localIntent3, 0);
    if (localObject == null)
      localObject = new LinkedList();
    if (localList != null)
      boolean bool = ((List)localObject).addAll(localList);
    return (List<ResolveInfo>)localObject;
  }

  static String getUnique(ActivityInfo paramActivityInfo)
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str1 = paramActivityInfo.packageName;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1).append("..");
    String str2 = paramActivityInfo.name;
    return str2;
  }

  private static void logTrace()
  {
    Exception localException = new Exception();
    Throwable localThrowable = localException.fillInStackTrace();
    StackTraceElement[] arrayOfStackTraceElement = localException.getStackTrace();
    int i = 1;
    while (true)
    {
      int j = arrayOfStackTraceElement.length;
      if (i >= j)
        break;
      Logger localLogger = logger;
      StringBuilder localStringBuilder = new StringBuilder().append("|  ");
      StackTraceElement localStackTraceElement = arrayOfStackTraceElement[i];
      String str = localStackTraceElement;
      localLogger.d(str);
      i += 1;
    }
  }

  private void notifyOnAdded(ProgramInfo paramProgramInfo)
  {
    synchronized (this.listeners)
    {
      Iterator localIterator = this.listeners.iterator();
      if (localIterator.hasNext())
        ((ProgramListListener)localIterator.next()).onAdded(paramProgramInfo);
    }
    monitorexit;
  }

  private void notifyOnDeleted(String paramString)
  {
    synchronized (this.listeners)
    {
      Iterator localIterator = this.listeners.iterator();
      if (localIterator.hasNext())
        ((ProgramListListener)localIterator.next()).onDeleted(paramString);
    }
    monitorexit;
  }

  /** @deprecated */
  private void reload(String paramString)
  {
    monitorenter;
    Iterator localIterator1;
    Iterator localIterator2;
    while (true)
    {
      TagInfo localTagInfo1;
      int j;
      try
      {
        Logger localLogger1 = logger;
        String str1 = "reload >>> packageName=" + paramString;
        localLogger1.d(str1);
        logTrace();
        logger.d("reload: querying activities...");
        localIterator1 = getLauncherActivities(paramString).iterator();
        if (!localIterator1.hasNext())
          break;
        ResolveInfo localResolveInfo = (ResolveInfo)localIterator1.next();
        i = 0;
        Logger localLogger2 = logger;
        StringBuilder localStringBuilder1 = new StringBuilder().append("reload: found activity: ");
        String str2 = localResolveInfo.activityInfo.packageName;
        StringBuilder localStringBuilder2 = localStringBuilder1.append(str2).append(":");
        String str3 = localResolveInfo.activityInfo.name;
        String str4 = str3;
        localLogger2.d(str4);
        localIterator2 = this.tags.values().iterator();
        if (!localIterator2.hasNext())
          continue;
        localTagInfo1 = (TagInfo)localIterator2.next();
        ActivityInfo localActivityInfo1 = localResolveInfo.activityInfo;
        PackageManager localPackageManager1 = this.pm;
        j = localTagInfo1.add(localActivityInfo1, localPackageManager1);
        if (j == 0)
        {
          Logger localLogger3 = logger;
          StringBuilder localStringBuilder3 = new StringBuilder().append("Matching against tag \"");
          String str5 = localTagInfo1.getName();
          String str6 = str5 + "\": ADDED";
          localLogger3.d(str6);
          i = 1;
          if (paramString == null)
            continue;
          Context localContext1 = this.context;
          PackageManager localPackageManager2 = this.pm;
          ActivityInfo localActivityInfo2 = localResolveInfo.activityInfo;
          String str7 = localTagInfo1.getName();
          ProgramInfo localProgramInfo1 = ProgramsUtil.addFromActivity(localContext1, localPackageManager2, localActivityInfo2, str7, 0);
          if (localProgramInfo1 == null)
            continue;
          notifyOnAdded(localProgramInfo1);
          String str8 = getUnique(localResolveInfo.activityInfo);
          if ((i != 0) || (this.woTagAdded.contains(str8)))
            continue;
          Context localContext2 = this.context;
          PackageManager localPackageManager3 = this.pm;
          ActivityInfo localActivityInfo3 = localResolveInfo.activityInfo;
          localProgramInfo1 = ProgramsUtil.addFromActivity(localContext2, localPackageManager3, localActivityInfo3, null, 0);
          if (localProgramInfo1 == null)
            continue;
          notifyOnAdded(localProgramInfo1);
          boolean bool1 = this.woTagAdded.add(str8);
          Collection localCollection = this.withoutTag;
          ActivityInfo localActivityInfo4 = localResolveInfo.activityInfo;
          boolean bool2 = localCollection.add(localActivityInfo4);
          continue;
        }
      }
      finally
      {
        monitorexit;
      }
      if (j != 1)
        continue;
      Logger localLogger4 = logger;
      StringBuilder localStringBuilder4 = new StringBuilder().append("Matching against tag \"");
      String str9 = localTagInfo1.getName();
      String str10 = str9 + "\": ALREADY EXISTS";
      localLogger4.d(str10);
      int i = 1;
    }
    if (paramString == null)
    {
      localIterator1 = this.tags.values().iterator();
      while (localIterator1.hasNext())
      {
        TagInfo localTagInfo2 = (TagInfo)localIterator1.next();
        Context localContext3 = this.context;
        PackageManager localPackageManager4 = this.pm;
        localIterator2 = localTagInfo2.getAllPrograms(localContext3, localPackageManager4).iterator();
        while (localIterator2.hasNext())
        {
          ProgramInfo localProgramInfo2 = (ProgramInfo)localIterator2.next();
          notifyOnAdded(localProgramInfo2);
        }
      }
    }
    logger.d("reload <<<");
    monitorexit;
  }

  private void reloadAll()
  {
    logger.d("reloadAll >>>");
    reload(null);
    logger.d("reloadAll <<<");
  }

  /** @deprecated */
  private void remove(String paramString)
  {
    monitorenter;
    try
    {
      notifyOnDeleted(paramString);
      Iterator localIterator1 = this.tags.values().iterator();
      while (localIterator1.hasNext())
      {
        TagInfo localTagInfo = (TagInfo)localIterator1.next();
        PackageManager localPackageManager = this.pm;
        localTagInfo.remove(paramString, localPackageManager);
      }
    }
    finally
    {
      monitorexit;
    }
    Iterator localIterator2 = this.withoutTag.iterator();
    while (localIterator2.hasNext())
    {
      ActivityInfo localActivityInfo = (ActivityInfo)localIterator2.next();
      String str1 = localActivityInfo.packageName;
      if (!paramString.equals(str1))
        continue;
      Set localSet = this.woTagAdded;
      String str2 = getUnique(localActivityInfo);
      boolean bool = localSet.remove(str2);
      localIterator2.remove();
    }
    monitorexit;
  }

  private boolean startActivity(Intent paramIntent)
  {
    try
    {
      String str = paramIntent.getAction();
      if ((!"android.settings.MANAGE_APPLICATIONS_SETTINGS".equals(str)) && (!"android.settings.MANAGE_ALL_APPLICATIONS_SETTINGS".equals(str)))
        Intent localIntent = paramIntent.setFlags(270532608);
      this.context.startActivity(paramIntent);
      i = 1;
      return i;
    }
    catch (ActivityNotFoundException localActivityNotFoundException)
    {
      while (true)
        int i = 0;
    }
  }

  /** @deprecated */
  public ProgramInfo findByTag(String paramString)
  {
    monitorenter;
    ProgramInfo localProgramInfo = null;
    try
    {
      Map localMap = this.tags;
      Object localObject1 = Conditions.checkNotNull(paramString);
      TagInfo localTagInfo = (TagInfo)localMap.get(localObject1);
      if (localTagInfo != null)
      {
        Context localContext1 = this.context;
        ActivityInfo localActivityInfo = localTagInfo.find(localContext1);
        if (localActivityInfo != null)
        {
          Context localContext2 = this.context;
          PackageManager localPackageManager = this.pm;
          String str = paramString;
          localProgramInfo = ProgramsUtil.addFromActivity(localContext2, localPackageManager, localActivityInfo, str, 0, 0);
          if (localProgramInfo != null)
            notifyOnAdded(localProgramInfo);
        }
      }
      return localProgramInfo;
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
    finally
    {
      monitorexit;
    }
    throw localObject2;
  }

  /** @deprecated */
  public Intent getIntent(String paramString)
  {
    monitorenter;
    try
    {
      Map localMap = this.tags;
      Object localObject1 = Conditions.checkNotNull(paramString);
      TagInfo localTagInfo = (TagInfo)localMap.get(localObject1);
      if (localTagInfo != null)
      {
        PackageManager localPackageManager = this.pm;
        Intent localIntent1 = localTagInfo.findIntent(localPackageManager);
        localIntent2 = localIntent1;
        return localIntent2;
      }
      Intent localIntent2 = null;
    }
    finally
    {
      monitorexit;
    }
  }

  /** @deprecated */
  public boolean launch(String paramString)
  {
    monitorenter;
    try
    {
      Map localMap = this.tags;
      Object localObject1 = Conditions.checkNotNull(paramString);
      TagInfo localTagInfo = (TagInfo)localMap.get(localObject1);
      int i = 0;
      if (localTagInfo != null)
      {
        PackageManager localPackageManager = this.pm;
        Intent localIntent = localTagInfo.findIntent(localPackageManager);
        if (localIntent != null)
        {
          boolean bool = startActivity(localIntent);
          i = bool;
        }
      }
      monitorexit;
      return i;
    }
    finally
    {
      localObject2 = finally;
      monitorexit;
    }
    throw localObject2;
  }

  /** @deprecated */
  public boolean launch(String paramString1, String paramString2)
  {
    monitorenter;
    try
    {
      String str = IntentPattern.DUMMY_PACKAGE_NAME;
      boolean bool1 = paramString1.equals(str);
      if (bool1);
      while (true)
      {
        try
        {
          Intent localIntent1 = Intent.getIntent(paramString2);
          localIntent2 = localIntent1;
          boolean bool2 = startActivity(localIntent2);
          boolean bool3 = bool2;
          monitorexit;
          return bool3;
        }
        catch (URISyntaxException localURISyntaxException)
        {
          localURISyntaxException.printStackTrace();
          int i = 0;
          continue;
        }
        Intent localIntent2 = new Intent("android.intent.action.MAIN");
        Intent localIntent3 = localIntent2.addCategory("android.intent.category.LAUNCHER");
        ComponentName localComponentName = new ComponentName(paramString1, paramString2);
        Intent localIntent4 = localIntent2.setComponent(localComponentName);
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public void registerListener(ProgramListListener paramProgramListListener)
  {
    Logger localLogger = logger;
    String str = "registerListener: l=" + paramProgramListListener;
    localLogger.d(str);
    synchronized (this.listeners)
    {
      if (!this.listeners.contains(paramProgramListListener))
        boolean bool = this.listeners.add(paramProgramListListener);
      return;
    }
  }

  public void start()
  {
    logger.d("start >>>");
    this.useCache = 1;
    reloadAll();
    this.useCache = 0;
    IntentFilter localIntentFilter1 = new IntentFilter();
    localIntentFilter1.addAction("android.intent.action.PACKAGE_ADDED");
    localIntentFilter1.addAction("android.intent.action.PACKAGE_REMOVED");
    localIntentFilter1.addAction("android.intent.action.PACKAGE_CHANGED");
    localIntentFilter1.addDataScheme("package");
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver1 = this.externalAppReceiver;
    ProgramList.2 local2 = new ProgramList.2(this);
    localDecoratedBroadcastReceiver1.addActionListener("android.intent.action.EXTERNAL_APPLICATIONS_AVAILABLE", local2);
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver2 = this.externalAppReceiver;
    ProgramList.3 local3 = new ProgramList.3(this);
    localDecoratedBroadcastReceiver2.addActionListener("android.intent.action.EXTERNAL_APPLICATIONS_UNAVAILABLE", local3);
    Context localContext1 = this.context;
    BroadcastReceiver localBroadcastReceiver = this.packageChangeReceiver;
    Intent localIntent1 = localContext1.registerReceiver(localBroadcastReceiver, localIntentFilter1);
    Context localContext2 = this.context;
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver3 = this.externalAppReceiver;
    IntentFilter localIntentFilter2 = this.externalAppReceiver.getIntentFilter();
    Intent localIntent2 = localContext2.registerReceiver(localDecoratedBroadcastReceiver3, localIntentFilter2);
    logger.d("start <<<");
  }

  public void stop()
  {
    Context localContext1 = this.context;
    BroadcastReceiver localBroadcastReceiver = this.packageChangeReceiver;
    localContext1.unregisterReceiver(localBroadcastReceiver);
    Context localContext2 = this.context;
    DecoratedBroadcastReceiver localDecoratedBroadcastReceiver = this.externalAppReceiver;
    localContext2.unregisterReceiver(localDecoratedBroadcastReceiver);
  }

  public void uninstall(String paramString)
  {
    Intent localIntent1 = new Intent("android.intent.action.DELETE");
    StringBuilder localStringBuilder = new StringBuilder().append("package:");
    String str = (String)Conditions.checkNotNull(paramString);
    Uri localUri = Uri.parse(str);
    Intent localIntent2 = localIntent1.setData(localUri);
    ProgramsUtil.startActivitySafely(this.context, localIntent1);
  }

  public void unregisterListener(ProgramListListener paramProgramListListener)
  {
    Logger localLogger = logger;
    String str = "unregisterListener: l=" + paramProgramListListener;
    localLogger.d(str);
    synchronized (this.listeners)
    {
      boolean bool = this.listeners.remove(paramProgramListListener);
      return;
    }
  }

  class TagFactory
    implements TagSources.ITagFactory
  {
    private TagFactory()
    {
    }

    public TagInfo create(String paramString, Collection<Pattern> paramCollection)
    {
      if ("alarm".equals(paramString));
      for (Object localObject = new AlarmTagInfo(paramCollection); ; localObject = new TagInfo(paramString, paramCollection))
        return localObject;
    }

    public IntentPattern.PatternBuilder getPatternBuilder(Intent paramIntent)
    {
      ProgramList localProgramList = ProgramList.this;
      return new ProgramList.PatternBuilder(localProgramList, paramIntent);
    }
  }

  class CachedIntentPattern extends IntentPattern
  {
    private CachedIntentPattern(Intent paramBoolean1, boolean paramBoolean2, boolean arg4)
    {
      super(paramBoolean2, bool);
    }

    public List<ResolveInfo> resolveIntent(PackageManager paramPackageManager, Intent paramIntent)
    {
      List localList;
      if (ProgramList.this.useCache)
      {
        localList = (List)ProgramList.this.resolvedIntents.get(paramIntent);
        if (localList == null)
          localList = super.resolveIntent(paramPackageManager, paramIntent);
        Object localObject = ProgramList.this.resolvedIntents.put(paramIntent, localList);
      }
      while (true)
      {
        return localList;
        localList = super.resolveIntent(paramPackageManager, paramIntent);
      }
    }
  }

  class PatternBuilder extends IntentPattern.PatternBuilder
  {
    public PatternBuilder(Intent arg2)
    {
      super();
    }

    public Pattern create()
    {
      ProgramList localProgramList = ProgramList.this;
      Intent localIntent = this.intent;
      boolean bool1 = this.matchPackage;
      boolean bool2 = this.isAntiPattern;
      return new ProgramList.CachedIntentPattern(localProgramList, localIntent, bool1, bool2, null);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.programlist.ProgramList
 * JD-Core Version:    0.6.0
 */