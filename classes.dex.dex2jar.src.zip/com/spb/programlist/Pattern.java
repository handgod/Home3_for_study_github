package com.spb.programlist;

import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;

abstract class Pattern
{
  abstract ActivityInfo getActivityInfo(PackageManager paramPackageManager);

  abstract boolean isAntiPattern();

  abstract boolean isDefault(PackageManager paramPackageManager, ActivityInfo paramActivityInfo);

  abstract boolean match(PackageManager paramPackageManager, ActivityInfo paramActivityInfo);
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.programlist.Pattern
 * JD-Core Version:    0.6.0
 */