package com.spb.programlist;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.provider.Settings.System;
import android.text.TextUtils;
import java.util.Collection;
import java.util.Iterator;

class AlarmTagInfo extends TagInfo
{
  static final String NAME = "alarm";
  static final String SPB_TIME_PACKAGE = "com.softspb.time";

  AlarmTagInfo(Collection<Pattern> paramCollection)
  {
    super("alarm", paramCollection);
  }

  ActivityInfo find(Context paramContext)
  {
    Object localObject = null;
    Iterator localIterator = this.activities.iterator();
    while (localIterator.hasNext())
    {
      ActivityInfo localActivityInfo = (ActivityInfo)localIterator.next();
      String str1 = localActivityInfo.packageName;
      if (!"com.softspb.time".equals(str1))
        continue;
      localObject = localActivityInfo;
    }
    if (localObject == null)
      localObject = super.find(paramContext);
    while (true)
    {
      return localObject;
      try
      {
        SharedPreferences localSharedPreferences = paramContext.createPackageContext("com.softspb.time", 0).getSharedPreferences("SPBTime", 1);
        String str2 = Settings.System.getString(paramContext.getContentResolver(), "next_alarm_formatted");
        if (localSharedPreferences.getString("SPBAlarm", "").equals(str2))
        {
          boolean bool = TextUtils.isEmpty(str2);
          if (!bool)
            continue;
        }
        localObject = super.find(paramContext);
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        while (true)
          localNameNotFoundException.printStackTrace();
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.programlist.AlarmTagInfo
 * JD-Core Version:    0.6.0
 */