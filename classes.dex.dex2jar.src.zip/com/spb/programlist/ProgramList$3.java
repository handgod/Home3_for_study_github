package com.spb.programlist;

import android.content.Context;
import android.content.Intent;
import com.softspb.util.broadcastreceiver.DecoratedBroadcastReceiver.IActionListener;

class ProgramList$3
  implements DecoratedBroadcastReceiver.IActionListener
{
  public void onAction(Context paramContext, Intent paramIntent)
  {
    String[] arrayOfString = paramIntent.getStringArrayExtra("android.intent.extra.changed_package_list");
    int i = arrayOfString.length;
    int j = 0;
    while (j < i)
    {
      String str = arrayOfString[j];
      ProgramList.access$000(this.this$0, str);
      j += 1;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.programlist.ProgramList.3
 * JD-Core Version:    0.6.0
 */