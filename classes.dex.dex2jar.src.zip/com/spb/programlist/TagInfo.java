package com.spb.programlist;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import com.softspb.util.CollectionFactory;
import com.softspb.util.Conditions;
import java.net.URISyntaxException;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

class TagInfo
{
  static final int ADDED = 0;
  static final int ALREADY_EXIST = 1;
  static final int DOESNT_MATCH = 2;
  Collection<ActivityInfo> activities;
  private Set<String> addedActivities;
  Collection<Pattern> antiPatterns;
  private ActivityInfo defaultActivity;
  private final String name;
  Collection<Pattern> patterns;

  TagInfo(String paramString, Collection<Pattern> paramCollection)
  {
    HashSet localHashSet = CollectionFactory.newHashSet();
    this.addedActivities = localHashSet;
    Iterator localIterator;
    if (!TextUtils.isEmpty(paramString))
    {
      int k = 1;
      Conditions.checkArgument(k);
      this.name = paramString;
      LinkedList localLinkedList1 = CollectionFactory.newLinkedList();
      this.antiPatterns = localLinkedList1;
      LinkedList localLinkedList2 = CollectionFactory.newLinkedList();
      this.patterns = localLinkedList2;
      LinkedList localLinkedList3 = CollectionFactory.newLinkedList();
      this.activities = localLinkedList3;
      localIterator = paramCollection.iterator();
    }
    while (true)
    {
      if (!localIterator.hasNext())
        break label149;
      Pattern localPattern = (Pattern)localIterator.next();
      if (localPattern.isAntiPattern())
      {
        boolean bool1 = this.antiPatterns.add(localPattern);
        continue;
        int m = 0;
        break;
      }
      boolean bool2 = this.patterns.add(localPattern);
    }
    label149: if (!this.patterns.isEmpty());
    while (true)
    {
      Conditions.checkArgument(i, "You must specify at least one pattern");
      return;
      int j = 0;
    }
  }

  final int add(ActivityInfo paramActivityInfo, PackageManager paramPackageManager)
  {
    int i = 2;
    Object localObject1 = Conditions.checkNotNull(paramActivityInfo);
    Object localObject2 = Conditions.checkNotNull(paramPackageManager);
    String str = ProgramList.getUnique(paramActivityInfo);
    if (this.addedActivities.contains(str))
      i = 1;
    while (true)
    {
      return i;
      Iterator localIterator = this.antiPatterns.iterator();
      while (true)
        if (localIterator.hasNext())
        {
          if (!((Pattern)localIterator.next()).match(paramPackageManager, paramActivityInfo))
            continue;
          break;
        }
      localIterator = this.patterns.iterator();
      if (!localIterator.hasNext())
        continue;
      if (!((Pattern)localIterator.next()).match(paramPackageManager, paramActivityInfo))
        break;
      boolean bool1 = this.activities.add(paramActivityInfo);
      boolean bool2 = this.addedActivities.add(str);
      i = 0;
    }
  }

  ActivityInfo find(Context paramContext)
  {
    Object localObject = Conditions.checkNotNull(paramContext);
    PackageManager localPackageManager = paramContext.getPackageManager();
    try
    {
      String str1 = this.defaultActivity.packageName;
      String str2 = this.defaultActivity.name;
      ComponentName localComponentName = new ComponentName(str1, str2);
      ActivityInfo localActivityInfo1 = localPackageManager.getActivityInfo(localComponentName, 0);
      if (this.defaultActivity != null)
      {
        localActivityInfo2 = this.defaultActivity;
        return localActivityInfo2;
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        this.defaultActivity = null;
        continue;
        Iterator localIterator = this.patterns.iterator();
        while (true)
          if (localIterator.hasNext())
          {
            localActivityInfo2 = ((Pattern)localIterator.next()).getActivityInfo(localPackageManager);
            if (localActivityInfo2 == null)
              continue;
            break;
          }
        ActivityInfo localActivityInfo2 = null;
      }
    }
  }

  Intent findIntent(PackageManager paramPackageManager)
  {
    Object localObject = Conditions.checkNotNull(paramPackageManager);
    Iterator localIterator = this.patterns.iterator();
    ActivityInfo localActivityInfo;
    do
    {
      if (!localIterator.hasNext())
        break;
      localActivityInfo = ((Pattern)localIterator.next()).getActivityInfo(paramPackageManager);
    }
    while (localActivityInfo == null);
    while (true)
    {
      try
      {
        Intent localIntent1 = Intent.parseUri(localActivityInfo.name, 0);
        localIntent2 = localIntent1;
        return localIntent2;
      }
      catch (URISyntaxException localURISyntaxException)
      {
        localURISyntaxException.printStackTrace();
      }
      break;
      Intent localIntent2 = null;
    }
  }

  List<ProgramInfo> getAllPrograms(Context paramContext, PackageManager paramPackageManager)
  {
    int i = 0;
    LinkedList localLinkedList = new LinkedList();
    Iterator localIterator1 = this.activities.iterator();
    label200: 
    while (localIterator1.hasNext())
    {
      ActivityInfo localActivityInfo = (ActivityInfo)localIterator1.next();
      ProgramInfo localProgramInfo;
      if ((!localIterator1.hasNext()) && (i == 0))
      {
        this.defaultActivity = localActivityInfo;
        String str1 = this.name;
        localProgramInfo = ProgramsUtil.addFromActivity(paramContext, paramPackageManager, localActivityInfo, str1, 1);
      }
      while (true)
      {
        if (localProgramInfo == null)
          break label200;
        boolean bool = localLinkedList.add(localProgramInfo);
        break;
        if (i == 0)
        {
          Iterator localIterator2 = this.patterns.iterator();
          while (localIterator2.hasNext())
          {
            int j = ((Pattern)localIterator2.next()).isDefault(paramPackageManager, localActivityInfo);
            i |= j;
            if (i == 0)
              continue;
            this.defaultActivity = localActivityInfo;
          }
          String str2 = this.name;
          localProgramInfo = ProgramsUtil.addFromActivity(paramContext, paramPackageManager, localActivityInfo, str2, i);
          continue;
        }
        String str3 = this.name;
        localProgramInfo = ProgramsUtil.addFromActivity(paramContext, paramPackageManager, localActivityInfo, str3, 0);
      }
    }
    return localLinkedList;
  }

  String getName()
  {
    return this.name;
  }

  void remove(String paramString, PackageManager paramPackageManager)
  {
    if (paramString == null)
      return;
    while (true)
    {
      label4: int i = 0;
      Iterator localIterator1 = this.activities.iterator();
      ActivityInfo localActivityInfo;
      while (localIterator1.hasNext())
      {
        localActivityInfo = (ActivityInfo)localIterator1.next();
        String str1 = localActivityInfo.packageName;
        if (!paramString.equals(str1))
          continue;
        if (this.defaultActivity != null)
        {
          String str2 = this.defaultActivity.packageName;
          if (paramString.equals(str2))
            i = 1;
        }
        Set localSet = this.addedActivities;
        String str3 = ProgramList.getUnique(localActivityInfo);
        boolean bool = localSet.remove(str3);
        localIterator1.remove();
      }
      if (i == 0)
        continue;
      localIterator1 = this.activities.iterator();
      Iterator localIterator2;
      label184: 
      do
      {
        break label184;
        if (!localIterator1.hasNext())
          break label4;
        localActivityInfo = (ActivityInfo)localIterator1.next();
        if (!localIterator1.hasNext())
        {
          this.defaultActivity = localActivityInfo;
          break label4;
        }
        localIterator2 = this.patterns.iterator();
        if (!localIterator2.hasNext())
          break;
      }
      while (!((Pattern)localIterator2.next()).isDefault(paramPackageManager, localActivityInfo));
      this.defaultActivity = localActivityInfo;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.programlist.TagInfo
 * JD-Core Version:    0.6.0
 */