package com.spb.programlist;

import android.content.Intent;
import java.util.Collection;

class TagSources
{
  static Collection<TagInfo> getTags(ITagFactory paramITagFactory)
  {
    return new Tags().getTags(paramITagFactory);
  }

  abstract interface TagSource
  {
    public abstract Collection<TagInfo> getTags(TagSources.ITagFactory paramITagFactory);
  }

  abstract interface ITagFactory
  {
    public abstract TagInfo create(String paramString, Collection<Pattern> paramCollection);

    public abstract IntentPattern.PatternBuilder getPatternBuilder(Intent paramIntent);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.programlist.TagSources
 * JD-Core Version:    0.6.0
 */