package com.spb.programlist;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.text.TextUtils;

public class ProgramsUtil
{
  static ProgramInfo addFromActivity(Context paramContext, PackageManager paramPackageManager, ActivityInfo paramActivityInfo, String paramString, boolean paramBoolean)
  {
    String str1 = paramActivityInfo.packageName;
    if (!IntentPattern.DUMMY_PACKAGE_NAME.equals(str1));
    int j;
    for (int i = 1; ; j = 0)
    {
      Context localContext = paramContext;
      PackageManager localPackageManager = paramPackageManager;
      ActivityInfo localActivityInfo = paramActivityInfo;
      String str2 = paramString;
      boolean bool = paramBoolean;
      return addFromActivity(localContext, localPackageManager, localActivityInfo, str2, bool, i);
    }
  }

  static ProgramInfo addFromActivity(Context paramContext, PackageManager paramPackageManager, ActivityInfo paramActivityInfo, String paramString, boolean paramBoolean1, boolean paramBoolean2)
  {
    String str1;
    String str2;
    String str3;
    String str5;
    int j;
    label142: String str6;
    boolean bool1;
    boolean bool2;
    if (paramActivityInfo != null)
    {
      int i = paramActivityInfo.icon;
      str1 = paramActivityInfo.packageName;
      if (i == 0)
        i = paramActivityInfo.applicationInfo.icon;
      str2 = String.valueOf(paramActivityInfo.loadLabel(paramPackageManager));
      str3 = paramActivityInfo.name;
      if (i != 0)
      {
        ApplicationInfo localApplicationInfo = paramActivityInfo.applicationInfo;
        if (paramPackageManager.getDrawable(str1, i, localApplicationInfo) != null)
        {
          Object[] arrayOfObject1 = new Object[3];
          arrayOfObject1[0] = "android.resource";
          String str4 = paramActivityInfo.applicationInfo.packageName;
          arrayOfObject1[1] = str4;
          Integer localInteger1 = Integer.valueOf(i);
          arrayOfObject1[2] = localInteger1;
          str5 = String.format("%s://%s/%d", arrayOfObject1);
          if ((isSystem(paramActivityInfo)) || (TextUtils.equals(paramContext.getPackageName(), str1)))
            break label231;
          j = 1;
          str6 = paramString;
          bool1 = paramBoolean2;
          bool2 = paramBoolean1;
        }
      }
    }
    for (ProgramInfo localProgramInfo = new ProgramInfo(str1, str3, str2, str5, str6, bool1, bool2, j); ; localProgramInfo = null)
    {
      return localProgramInfo;
      Object[] arrayOfObject2 = new Object[3];
      arrayOfObject2[0] = "android.resource";
      String str7 = paramContext.getPackageName();
      arrayOfObject2[1] = str7;
      Integer localInteger2 = Integer.valueOf(R.drawable.dummy_icon);
      arrayOfObject2[2] = localInteger2;
      str5 = String.format("%s://%s/%d", arrayOfObject2);
      break;
      label231: int k = 0;
      break label142;
    }
  }

  public static boolean isSystem(ActivityInfo paramActivityInfo)
  {
    int i = 1;
    int j = 0;
    if (paramActivityInfo == null)
      return j;
    if ((paramActivityInfo.applicationInfo.flags & 0x1) == 1);
    while (true)
    {
      j = i;
      break;
      i = 0;
    }
  }

  public static void startActivitySafely(Context paramContext, Intent paramIntent)
  {
    try
    {
      paramContext.startActivity(paramIntent);
      return;
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.programlist.ProgramsUtil
 * JD-Core Version:    0.6.0
 */