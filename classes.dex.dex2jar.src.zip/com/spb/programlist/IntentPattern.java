package com.spb.programlist;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.text.TextUtils;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.List<Landroid.content.pm.ResolveInfo;>;

class IntentPattern extends Pattern
{
  static String DUMMY_PACKAGE_NAME = ;
  static final String RESOLVER_ACTIVITY_CLASS_NAME = "com.android.internal.app.ResolverActivity";
  static final String RESOLVER_ACTIVITY_PACKAGE_NAME = "android";
  private static Logger logger = Loggers.getLogger(IntentPattern.class);
  private Intent intent;
  private final boolean isAntiPattern;
  private boolean matchPackage;

  static
  {
    DUMMY_PACKAGE_NAME = ".spb.intent";
  }

  IntentPattern(Intent paramIntent, boolean paramBoolean1, boolean paramBoolean2)
  {
    this.intent = paramIntent;
    this.matchPackage = paramBoolean1;
    this.isAntiPattern = paramBoolean2;
  }

  private boolean checkInfoExact(String paramString1, String paramString2, String paramString3, ResolveInfo paramResolveInfo)
  {
    int i = 0;
    if ((paramResolveInfo == null) || (paramString1 == null) || (paramString2 == null));
    while (true)
    {
      return i;
      if (paramString3 == null)
        paramString3 = "";
      ActivityInfo localActivityInfo = paramResolveInfo.activityInfo;
      String str1 = localActivityInfo.packageName;
      if (!paramString1.equals(str1))
        continue;
      String str2 = localActivityInfo.name;
      if (!paramString2.equals(str2))
      {
        String str3 = localActivityInfo.name;
        if (!paramString3.equals(str3))
          continue;
      }
      i = 1;
    }
  }

  private boolean checkInfoPackage(String paramString1, String paramString2, ResolveInfo paramResolveInfo)
  {
    if (paramResolveInfo.activityInfo.packageName.equals(paramString1));
    for (int i = 1; ; i = 0)
      return i;
  }

  private ActivityInfo findSystemOrDefault(PackageManager paramPackageManager)
  {
    Intent localIntent1 = this.intent;
    ResolveInfo localResolveInfo1 = paramPackageManager.resolveActivity(localIntent1, 0);
    ResolveInfo localResolveInfo2;
    if (localResolveInfo1 != null)
    {
      localActivityInfo = localResolveInfo1.activityInfo;
      if (localActivityInfo != null)
      {
        String str1 = localActivityInfo.name;
        if ("com.android.internal.app.ResolverActivity".equals(str1))
        {
          String str2 = localActivityInfo.packageName;
          if ("android".equals(str2))
          {
            Intent localIntent2 = this.intent;
            Iterator localIterator = paramPackageManager.queryIntentActivities(localIntent2, 65536).iterator();
            do
            {
              if (!localIterator.hasNext())
                break;
              localResolveInfo2 = (ResolveInfo)localIterator.next();
            }
            while (!ProgramsUtil.isSystem(localResolveInfo2.activityInfo));
          }
        }
      }
    }
    for (ActivityInfo localActivityInfo = localResolveInfo2.activityInfo; ; localActivityInfo = null)
      return localActivityInfo;
  }

  ActivityInfo getActivityInfo(PackageManager paramPackageManager)
  {
    Intent localIntent = this.intent;
    ActivityInfo localActivityInfo1;
    if (paramPackageManager.resolveActivity(localIntent, 0) == null)
      localActivityInfo1 = null;
    while (true)
    {
      return localActivityInfo1;
      ActivityInfo localActivityInfo2 = findSystemOrDefault(paramPackageManager);
      localActivityInfo1 = new ActivityInfo(localActivityInfo2);
      String str1 = DUMMY_PACKAGE_NAME;
      localActivityInfo1.packageName = str1;
      String str2 = this.intent.toUri(0).toString();
      localActivityInfo1.name = str2;
    }
  }

  boolean isAntiPattern()
  {
    return this.isAntiPattern;
  }

  boolean isDefault(PackageManager paramPackageManager, ActivityInfo paramActivityInfo)
  {
    int i = 1;
    Logger localLogger1 = logger;
    Object[] arrayOfObject = new Object[2];
    Intent localIntent = this.intent;
    arrayOfObject[0] = localIntent;
    arrayOfObject[i] = paramActivityInfo;
    localLogger1.d(">>>IntentPattern.isDefault intent=%s info=%s", arrayOfObject);
    ComponentName localComponentName = this.intent.getComponent();
    String str1;
    boolean bool;
    if (localComponentName != null)
    {
      str1 = localComponentName.getPackageName();
      str2 = localComponentName.getClassName();
      if (str2.equals(""))
      {
        String str3 = paramActivityInfo.packageName;
        bool = TextUtils.equals(str1, str3);
      }
    }
    int j;
    ActivityInfo localActivityInfo;
    while (true)
    {
      return bool;
      if ((!TextUtils.isEmpty(str1)) && (!TextUtils.isEmpty(str2)))
      {
        String str4 = paramActivityInfo.packageName;
        if (str1.equals(str4))
        {
          String str5 = paramActivityInfo.name;
          if (str2.equals(str5))
            continue;
        }
        j = 0;
        continue;
      }
      localActivityInfo = findSystemOrDefault(paramPackageManager);
      if (localActivityInfo != null)
        break;
      j = 0;
    }
    String str6 = paramActivityInfo.packageName;
    String str2 = paramActivityInfo.name;
    if ((TextUtils.equals(localActivityInfo.packageName, str6)) && (TextUtils.equals(localActivityInfo.name, str2)));
    int m;
    for (int k = 1; ; m = 0)
    {
      Logger localLogger2 = logger;
      String str7 = "<<<IntentPattern.isDefault result " + k;
      localLogger2.d(str7);
      j = k;
      break;
    }
  }

  boolean match(PackageManager paramPackageManager, ActivityInfo paramActivityInfo)
  {
    boolean bool = true;
    ComponentName localComponentName = this.intent.getComponent();
    String str1;
    String str2;
    if (localComponentName != null)
    {
      str1 = localComponentName.getPackageName();
      str2 = localComponentName.getClassName();
      if (str2.equals(""))
      {
        String str3 = paramActivityInfo.packageName;
        bool = TextUtils.equals(str1, str3);
      }
    }
    while (true)
    {
      return bool;
      if ((!TextUtils.isEmpty(str1)) && (!TextUtils.isEmpty(str2)))
      {
        String str4 = paramActivityInfo.packageName;
        if (str1.equals(str4))
        {
          String str5 = paramActivityInfo.name;
          if (str2.equals(str5))
            continue;
        }
        bool = false;
        continue;
      }
      str1 = paramActivityInfo.packageName;
      str2 = paramActivityInfo.name;
      String str6 = paramActivityInfo.targetActivity;
      Intent localIntent = this.intent;
      List localList = resolveIntent(paramPackageManager, localIntent);
      Iterator localIterator = localList.iterator();
      while (true)
        if (localIterator.hasNext())
        {
          ResolveInfo localResolveInfo1 = (ResolveInfo)localIterator.next();
          if (!checkInfoExact(str1, str2, str6, localResolveInfo1))
            continue;
          break;
        }
      if (this.matchPackage)
      {
        localIterator = localList.iterator();
        while (true)
          if (localIterator.hasNext())
          {
            ResolveInfo localResolveInfo2 = (ResolveInfo)localIterator.next();
            if (!checkInfoPackage(str1, str2, localResolveInfo2))
              continue;
            break;
          }
      }
      bool = false;
    }
  }

  List<ResolveInfo> resolveIntent(PackageManager paramPackageManager, Intent paramIntent)
  {
    Object localObject = paramPackageManager.queryIntentActivities(paramIntent, 0);
    if (localObject == null)
      localObject = new LinkedList();
    return (List<ResolveInfo>)localObject;
  }

  class PatternBuilder
  {
    boolean isAntiPattern = 0;
    boolean matchPackage = 0;

    PatternBuilder()
    {
    }

    final PatternBuilder antiPattern(boolean paramBoolean)
    {
      this.isAntiPattern = paramBoolean;
      return this;
    }

    Pattern create()
    {
      Intent localIntent = IntentPattern.this;
      boolean bool1 = this.matchPackage;
      boolean bool2 = this.isAntiPattern;
      return new IntentPattern(localIntent, bool1, bool2);
    }

    final PatternBuilder matchPackage(boolean paramBoolean)
    {
      this.matchPackage = paramBoolean;
      return this;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.programlist.IntentPattern
 * JD-Core Version:    0.6.0
 */