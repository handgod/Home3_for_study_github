package com.spb.programlist;

public abstract interface ProgramListListener
{
  public abstract void onAdded(ProgramInfo paramProgramInfo);

  public abstract void onDeleted(String paramString);
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.programlist.ProgramListListener
 * JD-Core Version:    0.6.0
 */