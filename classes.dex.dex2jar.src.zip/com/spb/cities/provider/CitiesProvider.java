package com.spb.cities.provider;

import android.content.BroadcastReceiver;
import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.UriMatcher;
import android.content.pm.ProviderInfo;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.os.SystemClock;
import android.text.TextUtils;
import com.softspb.kana.KanaUtils;
import com.softspb.util.AssetSQLiteOpenHelper;
import com.softspb.util.ProjectionCursor;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import com.spb.cities.nearestcity.NearestCitiesClient;
import com.spb.cities.nearestcity.NearestCitiesClient.QueryParams;
import com.spb.cities.nearestcity.NearestCitiesClient.ResponseItem;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map.Entry;
import java.util.Set;
import org.apache.http.HttpVersion;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpProtocolParams;

public abstract class CitiesProvider extends ContentProvider
{
  static final String CITIES_JOIN_TIMEZONES = ;
  static final String CITY_COLUMNS_LIST = "city_id, city_name, city_name_jp, filter_name , country_short_name, country_short_name_jp, state_short_name, latitude, longitude, timezone_id";
  static final String CITY_NAME_RES_COLUMN_JP = "coalesce( city_name_jp,city_name) AS city_name";
  static final String COPY_CITY_TABLE_append_src_table_name = "INSERT INTO cities (city_id, city_name, city_name_jp, filter_name , country_short_name, country_short_name_jp, state_short_name, latitude, longitude, timezone_id) SELECT city_id, city_name, city_name_jp, filter_name , country_short_name, country_short_name_jp, state_short_name, latitude, longitude, timezone_id FROM ";
  static final String COPY_TIMEZONES_TABLE_append_src_table_name = "INSERT INTO timezones (_id, timezone_id, timezone_name, utc_offset_min) SELECT _id, timezone_id, timezone_name, utc_offset_min FROM ";
  static final String COUNTRY_SHORT_NAME_RES_COLUMN_JP = "coalesce(country_short_name_jp,country_short_name) AS country_short_name";
  static final String CREATE_CITY_INDEX = "CREATE INDEX IF NOT EXISTS idx_cities ON cities (filter_name ASC);";
  static final String CREATE_TABLE_CITIES = "CREATE TABLE IF NOT EXISTS cities (_id INTEGER PRIMARY KEY AUTOINCREMENT, city_id INTEGER, city_name TEXT, city_name_jp TEXT, filter_name TEXT, country_short_name TEXT, country_short_name_jp TEXT, state_short_name  TEXT, latitude REAL, longitude  REAL, timezone_id INTEGER)";
  static final String CREATE_TABLE_CURRENT_LOCATION = "CREATE TABLE IF NOT EXISTS current_location (current_location_id INTEGER UNIQUE NOT NULL, city_id INTEGER, positioning_status INTEGER, last_updated_utc INTEGER)";
  static final String CREATE_TABLE_TIMEZONES = "CREATE TABLE IF NOT EXISTS timezones (_id INTEGER PRIMARY KEY AUTOINCREMENT, timezone_id INTEGER UNIQUE, timezone_name TEXT, utc_offset_min INTEGER)";
  static final String CURRENT_LOCATION_ID = "current_location_id";
  static final String CURRENT_LOCATION_ID_SELECTION = "current_location_id=1";
  static final int CURRENT_LOCATION_ID_VALUE = 1;
  public static final String DEFAULT_NEAREST_CITIES_LIMIT = "5";
  private static final int MATCH_ALL_CITIES = 1;
  private static final int MATCH_CITY_FILTER = 20;
  private static final int MATCH_CURRENT_LOCATION_CITY = 16;
  private static final int MATCH_NEAREST_CITIES = 15;
  private static final int MATCH_SINGLE_CITY = 2;
  static final String TIMEZONES_COLUMNS_LIST = "_id, timezone_id, timezone_name, utc_offset_min";
  private static final IntentFilter localeChangedFilter = new IntentFilter("android.intent.action.LOCALE_CHANGED");
  private static Logger logger;
  private static int requestCount = 0;
  private SQLiteDatabase citiesDB;
  private ContentResolver contentResolver;
  private NearestCitiesClient nearestClient;
  private UriMatcher uriMatcher;
  private CitiesDatabaseHelper weatherDBHelper;

  static
  {
    logger = Loggers.getLogger(CitiesProvider.class.getName());
    CITIES_JOIN_TIMEZONES = "cities" + " JOIN " + "timezones" + " ON " + "cities" + "." + "timezone_id" + "=" + "timezones" + "." + "timezone_id";
  }

  private static HttpClient createThreadSafeHttpClient()
  {
    BasicHttpParams localBasicHttpParams = new BasicHttpParams();
    HttpVersion localHttpVersion = HttpVersion.HTTP_1_1;
    HttpProtocolParams.setVersion(localBasicHttpParams, localHttpVersion);
    HttpProtocolParams.setContentCharset(localBasicHttpParams, "ISO-8859-1");
    HttpProtocolParams.setUseExpectContinue(localBasicHttpParams, 1);
    SchemeRegistry localSchemeRegistry = new SchemeRegistry();
    PlainSocketFactory localPlainSocketFactory = PlainSocketFactory.getSocketFactory();
    Scheme localScheme1 = new Scheme("http", localPlainSocketFactory, 80);
    Scheme localScheme2 = localSchemeRegistry.register(localScheme1);
    SSLSocketFactory localSSLSocketFactory = SSLSocketFactory.getSocketFactory();
    Scheme localScheme3 = new Scheme("https", localSSLSocketFactory, 443);
    Scheme localScheme4 = localSchemeRegistry.register(localScheme3);
    ThreadSafeClientConnManager localThreadSafeClientConnManager = new ThreadSafeClientConnManager(localBasicHttpParams, localSchemeRegistry);
    return new DefaultHttpClient(localThreadSafeClientConnManager, localBasicHttpParams);
  }

  private NearestCitiesClient getNearestClient()
  {
    if (this.nearestClient == null)
      monitorenter;
    try
    {
      if (this.nearestClient == null)
      {
        Context localContext = getContext();
        HttpClient localHttpClient = createThreadSafeHttpClient();
        NearestCitiesClient localNearestCitiesClient = new NearestCitiesClient(localContext, localHttpClient);
        this.nearestClient = localNearestCitiesClient;
      }
      return this.nearestClient;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  private void initAuthority(String paramString, Context paramContext)
  {
    String str1 = "initAuthority: authority=" + paramString;
    logd(str1);
    StringBuilder localStringBuilder = new StringBuilder().append("initAuthority: city content uri: ");
    Uri localUri = CitiesContract.Cities.getContentUri(paramContext);
    String str2 = localUri;
    logd(str2);
    UriMatcher localUriMatcher = new UriMatcher(-1);
    this.uriMatcher = localUriMatcher;
    this.uriMatcher.addURI(paramString, "city", 1);
    this.uriMatcher.addURI(paramString, "city/#", 2);
    this.uriMatcher.addURI(paramString, "nearest", 15);
    this.uriMatcher.addURI(paramString, "city_filter/*", 20);
    this.uriMatcher.addURI(paramString, "currentlocation", 16);
  }

  private static String logUnicode(String paramString)
  {
    if (paramString == null);
    StringBuilder localStringBuilder1;
    for (String str1 = "null"; ; str1 = localStringBuilder1.toString())
    {
      return str1;
      int i = paramString.length();
      int j = 0;
      localStringBuilder1 = new StringBuilder();
      while (j < i)
      {
        StringBuilder localStringBuilder2 = localStringBuilder1.append("\\u");
        String str2 = Integer.toHexString(paramString.codePointAt(j));
        StringBuilder localStringBuilder3 = localStringBuilder2.append(str2);
        j = paramString.offsetByCodePoints(j, 1);
      }
    }
  }

  private void logd(int paramInt, String paramString)
  {
    Logger localLogger = logger;
    String str = 40 + paramInt + ") " + paramString;
    localLogger.d(str);
  }

  private void logd(String paramString)
  {
    logger.d(paramString);
  }

  private void logw(int paramInt, String paramString)
  {
    Logger localLogger = logger;
    String str = 40 + paramInt + ") " + paramString;
    localLogger.w(str);
  }

  private Cursor queryCities(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2, String paramString3, String paramString4)
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str1 = Locale.JAPANESE.getLanguage();
    String str2 = Locale.getDefault().getLanguage();
    boolean bool = str1.equals(str2);
    int i = 0;
    if (paramArrayOfString1 == null);
    int k;
    for (int j = 0; ; j = paramArrayOfString1.length)
    {
      if (paramArrayOfString1 == null)
        i = 1;
      k = 0;
      while (true)
      {
        int m = k;
        int n = j;
        if (m >= n)
          break;
        String str3 = paramArrayOfString1[k];
        if (!"timezone_name".equals(str3))
        {
          String str4 = paramArrayOfString1[k];
          if (!"utc_offset_min".equals(str4));
        }
        else
        {
          i = 1;
        }
        k += 1;
      }
    }
    String str5;
    int i1;
    int i2;
    if (i != 0)
    {
      str5 = CITIES_JOIN_TIMEZONES;
      if (paramString1 != null)
      {
        StringBuilder localStringBuilder2 = localStringBuilder1.append(40);
        String str6 = paramString1;
        StringBuilder localStringBuilder3 = localStringBuilder2.append(str6).append(41);
      }
      if (paramString4 != null)
      {
        paramString4 = paramString4.replaceAll("[ .-]", "").toUpperCase();
        if (localStringBuilder1.length() > 0)
          StringBuilder localStringBuilder4 = localStringBuilder1.append(" AND ");
        StringBuilder localStringBuilder5 = localStringBuilder1.append(40);
        StringBuilder localStringBuilder6 = localStringBuilder1.append("(UPPER(").append("filter_name").append(") GLOB '");
        String str7 = paramString4;
        StringBuilder localStringBuilder7 = localStringBuilder6.append(str7).append("*')");
        StringBuilder localStringBuilder8 = localStringBuilder1.append(" OR ");
        StringBuilder localStringBuilder9 = localStringBuilder1.append("(").append("city_name_jp").append(" GLOB '");
        String str8 = paramString4;
        StringBuilder localStringBuilder10 = localStringBuilder9.append(str8).append("*')");
        StringBuilder localStringBuilder11 = localStringBuilder1.append(41);
      }
      if (paramString3 != null)
      {
        if (localStringBuilder1.length() > 0)
          StringBuilder localStringBuilder12 = localStringBuilder1.append(" AND ");
        StringBuilder localStringBuilder13 = localStringBuilder1.append(40).append("city_id").append("=");
        String str9 = paramString3;
        StringBuilder localStringBuilder14 = localStringBuilder13.append(str9).append(")");
      }
      i1 = -1;
      i2 = -1;
      k = 0;
      label389: int i3 = k;
      int i4 = j;
      if (i3 >= i4)
        break label465;
      String str10 = paramArrayOfString1[k];
      if (!"city_name".equals(str10))
        break label441;
      i1 = k;
    }
    while (true)
    {
      k += 1;
      break label389;
      str5 = "cities";
      break;
      label441: String str11 = paramArrayOfString1[k];
      if (!"country_short_name".equals(str11))
        continue;
      i2 = k;
    }
    label465: if (((i1 != -1) || (i2 != -1)) && (bool))
    {
      String[] arrayOfString1 = new String[j];
      k = 0;
      int i5 = k;
      int i6 = j;
      if (i5 < i6)
      {
        String str12;
        if (k == i1)
          str12 = "coalesce( city_name_jp,city_name) AS city_name";
        while (true)
        {
          arrayOfString1[k] = str12;
          k += 1;
          break;
          if (k == i2)
          {
            str12 = "coalesce(country_short_name_jp,country_short_name) AS country_short_name";
            continue;
          }
          str12 = paramArrayOfString1[k];
        }
      }
      paramArrayOfString1 = arrayOfString1;
    }
    if (paramString2 == null)
      paramString2 = "city_name_jp,city_name";
    String str13 = localStringBuilder1.toString();
    String[] arrayOfString2 = paramArrayOfString1;
    String str14 = paramString2;
    String str15 = SQLiteQueryBuilder.buildQueryString(0, str5, arrayOfString2, str13, null, null, str14, null);
    long l1 = System.currentTimeMillis();
    StringBuilder localStringBuilder15 = new StringBuilder().append("Doing Raw Query: ");
    String str16 = str15;
    String str17 = str16;
    logd(str17);
    SQLiteDatabase localSQLiteDatabase = this.citiesDB;
    String str18 = str15;
    String[] arrayOfString3 = paramArrayOfString2;
    Cursor localCursor = localSQLiteDatabase.rawQuery(str18, arrayOfString3);
    long l2 = System.currentTimeMillis();
    StringBuilder localStringBuilder16 = new StringBuilder().append("Query completed in ");
    long l3 = l2 - l1;
    String str19 = l3 + "ms";
    logd(str19);
    StringBuilder localStringBuilder17 = new StringBuilder().append("Registering cursor [").append(localCursor).append("] with notification URI: ");
    String str20 = paramUri.toString();
    String str21 = str20;
    logd(str21);
    ContentResolver localContentResolver = this.contentResolver;
    Uri localUri = paramUri;
    localCursor.setNotificationUri(localContentResolver, localUri);
    return localCursor;
  }

  private Cursor queryCurrentLocation(String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    SQLiteDatabase localSQLiteDatabase = this.citiesDB;
    String[] arrayOfString1 = paramArrayOfString1;
    String str1 = paramString1;
    String[] arrayOfString2 = paramArrayOfString2;
    String str2 = null;
    String str3 = paramString2;
    Cursor localCursor = localSQLiteDatabase.query("current_location", arrayOfString1, str1, arrayOfString2, null, str2, str3);
    ContentResolver localContentResolver = this.contentResolver;
    Uri localUri = CitiesContract.CurrentLocation.getContentUri(getContext());
    localCursor.setNotificationUri(localContentResolver, localUri);
    return localCursor;
  }

  private Cursor queryNearestCities(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    String str1 = paramUri.getQueryParameter("lon");
    String str2 = paramUri.getQueryParameter("lat");
    String str3 = paramUri.getQueryParameter("limit");
    if (str3 == null)
      str3 = "5";
    NearestCitiesClient localNearestCitiesClient = getNearestClient();
    ArrayList localArrayList = null;
    if ((str1 != null) && (str2 != null))
    {
      String str4 = str1;
      String str5 = str2;
      String str6 = str3;
      NearestCitiesClient.QueryParams localQueryParams = new NearestCitiesClient.QueryParams(str4, str5, str6);
      localArrayList = (ArrayList)localNearestCitiesClient.download(localQueryParams);
    }
    int i;
    if (localArrayList == null)
      i = 0;
    Object localObject1;
    while (true)
    {
      localObject1 = new android/database/MatrixCursor;
      Object localObject2 = localObject1;
      String[] arrayOfString1 = paramArrayOfString1;
      int j = i;
      localObject2.<init>(arrayOfString1, j);
      if (localArrayList == null)
        break;
      String str7 = Locale.JAPANESE.getLanguage();
      String str8 = Locale.getDefault().getLanguage();
      boolean bool = str7.equals(str8);
      String[] arrayOfString2 = paramArrayOfString1;
      int k = 0;
      int m = paramArrayOfString1.length;
      int n = 0;
      while (true)
      {
        int i1 = n;
        int i2 = m;
        if (i1 < i2)
        {
          String str9 = paramArrayOfString1[n];
          if (!"timezone_name".equals(str9))
          {
            String str10 = paramArrayOfString1[n];
            if (!"utc_offset_min".equals(str10));
          }
          else
          {
            k = 1;
          }
          n += 1;
          continue;
          i = localArrayList.size();
          break;
        }
      }
      String str11;
      int i3;
      int i4;
      if (k != 0)
      {
        str11 = CITIES_JOIN_TIMEZONES;
        if (!bool)
          break label429;
        i3 = -1;
        i4 = -1;
        n = 0;
        label267: int i5 = paramArrayOfString1.length;
        if (n >= i5)
          break label339;
        String str12 = paramArrayOfString1[n];
        if (!"city_name".equals(str12))
          break label315;
        i3 = n;
      }
      while (true)
      {
        n += 1;
        break label267;
        str11 = "cities";
        break;
        label315: String str13 = paramArrayOfString1[n];
        if (!"country_short_name".equals(str13))
          continue;
        i4 = n;
      }
      label339: if (((i3 != -1) || (i4 == -1)) && (bool))
      {
        arrayOfString2 = new String[paramArrayOfString1.length];
        n = 0;
        int i6 = paramArrayOfString1.length;
        if (n < i6)
        {
          String str14;
          if (n == i3)
            str14 = "coalesce( city_name_jp,city_name) AS city_name";
          while (true)
          {
            arrayOfString2[n] = str14;
            n += 1;
            break;
            if (n == i4)
            {
              str14 = "coalesce(country_short_name_jp,country_short_name) AS country_short_name";
              continue;
            }
            str14 = paramArrayOfString1[n];
          }
        }
      }
      label429: String str15 = SQLiteQueryBuilder.buildQueryString(0, str11, arrayOfString2, "city_id=?", null, null, null, null);
      String[] arrayOfString3 = new String[1];
      int i8 = paramArrayOfString1.length;
      String[] arrayOfString4 = new String[i8];
      Iterator localIterator = localArrayList.iterator();
      while (localIterator.hasNext())
      {
        NearestCitiesClient.ResponseItem localResponseItem = (NearestCitiesClient.ResponseItem)localIterator.next();
        int i7 = 0;
        try
        {
          String str16 = Integer.toString(localResponseItem.getCityId());
          arrayOfString3[i7] = str16;
          localCursor = this.citiesDB.rawQuery(str15, arrayOfString3);
          if ((localCursor != null) && (localCursor.moveToFirst()))
          {
            n = 0;
            while (true)
            {
              int i9 = n;
              int i10 = i8;
              if (i9 >= i10)
                break;
              int i11 = n;
              String str17 = localCursor.getString(i11);
              arrayOfString4[n] = str17;
              n += 1;
            }
            StringBuilder localStringBuilder1 = new StringBuilder().append("Adding row to cursor: rowLength=");
            int i12 = arrayOfString4.length;
            StringBuilder localStringBuilder2 = localStringBuilder1.append(i12).append(" cursorLength=");
            int i13 = ((MatrixCursor)localObject1).getColumnCount();
            String str18 = i13;
            logd(str18);
            Object localObject3 = localObject1;
            String[] arrayOfString5 = arrayOfString4;
            localObject3.addRow(arrayOfString5);
          }
          localCursor.close();
          continue;
        }
        catch (Exception localException1)
        {
          StringBuilder localStringBuilder3 = new StringBuilder().append("Failed to query city: ");
          Exception localException2 = localException1;
          String str19 = localException2;
          logd(str19);
          localCursor.close();
          continue;
        }
        finally
        {
          Cursor localCursor;
          localCursor.close();
        }
      }
    }
    String[] arrayOfString6 = CitiesContract.Cities.NEAREST_PROJECTION;
    if (!Arrays.equals(paramArrayOfString1, arrayOfString6))
    {
      Object localObject5 = localObject1;
      String[] arrayOfString7 = paramArrayOfString1;
      localObject1 = new ProjectionCursor(localObject5, arrayOfString7);
    }
    return (Cursor)localObject1;
  }

  public void attachInfo(Context paramContext, ProviderInfo paramProviderInfo)
  {
    super.attachInfo(paramContext, paramProviderInfo);
    String str1 = paramProviderInfo.authority;
    String str2 = CitiesContract.getAuthority(paramContext);
    if (!str1.equals(str2))
    {
      String str3 = "Unexpected authority in manifest: " + str1 + ", expected: " + str2;
      throw new RuntimeException(str3);
    }
    String str4 = getClass().getName();
    StringBuilder localStringBuilder = new StringBuilder();
    String str5 = paramContext.getPackageName();
    String str6 = str5 + ".cities.provider.CitiesProvider";
    if (!str4.equals(str6))
    {
      String str7 = "Unexpected CitiesProvider class name: " + str4 + ", must be: " + str6;
      throw new RuntimeException(str7);
    }
    initAuthority(str2, paramContext);
  }

  public int bulkInsert(Uri paramUri, ContentValues[] paramArrayOfContentValues)
  {
    int i = requestCount + 1;
    requestCount = i;
    int j = this.uriMatcher.match(paramUri);
    String str1 = "bulkInsert: uri=" + paramUri;
    logd(i, str1);
    switch (j)
    {
    default:
      String str2 = "Unsupported URI: " + paramUri;
      throw new IllegalArgumentException(str2);
    case 1:
    }
    String str3 = "cities";
    String str4 = "city_name";
    int k = 0;
    ContentValues[] arrayOfContentValues = paramArrayOfContentValues;
    int m = arrayOfContentValues.length;
    int n = 0;
    while (n < m)
    {
      ContentValues localContentValues = arrayOfContentValues[n];
      if (this.citiesDB.replace(str3, str4, localContentValues) > 0L)
        k += 1;
      n += 1;
    }
    if (k > 0)
      this.contentResolver.notifyChange(paramUri, null);
    return k;
  }

  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString)
  {
    String str1 = null;
    String str3;
    StringBuilder localStringBuilder2;
    switch (this.uriMatcher.match(paramUri))
    {
    default:
      String str2 = "Unsupported URI: " + paramUri;
      throw new IllegalArgumentException(str2);
    case 1:
      str3 = "cities";
      if (str1 == null)
        break;
      StringBuilder localStringBuilder1 = new StringBuilder().append(str1).append("=");
      String str4 = (String)paramUri.getPathSegments().get(1);
      localStringBuilder2 = localStringBuilder1.append(str4);
      if (TextUtils.isEmpty(paramString));
    case 2:
    case 16:
    }
    for (String str5 = " AND (" + paramString + 41; ; str5 = "")
    {
      paramString = str5;
      int i = this.citiesDB.delete(str3, paramString, paramArrayOfString);
      StringBuilder localStringBuilder3 = new StringBuilder().append("Notifying change URI=");
      String str6 = paramUri.toString();
      String str7 = str6;
      logd(str7);
      this.contentResolver.notifyChange(paramUri, null);
      return i;
      str3 = "cities";
      str1 = "_id";
      break;
      str3 = "current_location";
      break;
    }
  }

  public String getType(Uri paramUri)
  {
    String str2;
    switch (this.uriMatcher.match(paramUri))
    {
    default:
      String str1 = "Unsupported URI:" + paramUri;
      throw new IllegalArgumentException(str1);
    case 1:
    case 15:
      str2 = "vnd.android.cursor.dir/vnd.softspb.city";
    case 2:
    case 20:
    case 16:
    }
    while (true)
    {
      return str2;
      str2 = "vnd.android.cursor.item/vnd.softspb.city";
      continue;
      str2 = "vnd.android.cursor.dir/vnd.softspb.currentlocation";
    }
  }

  public Uri insert(Uri paramUri, ContentValues paramContentValues)
  {
    int i = requestCount + 1;
    requestCount = i;
    int j = this.uriMatcher.match(paramUri);
    StringBuilder localStringBuilder1 = new StringBuilder().append("insert: uri=");
    String str1 = paramUri.toString();
    String str2 = str1;
    logd(i, str2);
    String str4;
    String str5;
    Uri localUri;
    switch (j)
    {
    default:
      String str3 = "Unsupported URI:" + paramUri;
      throw new IllegalArgumentException(str3);
    case 1:
      str4 = "cities";
      str5 = "city_name";
      long l = this.citiesDB.replace(str4, str5, paramContentValues);
      if (l <= 0L)
        break;
      String str6 = "Inserted: " + paramContentValues;
      logd(i, str6);
      localUri = ContentUris.withAppendedId(paramUri, l);
      StringBuilder localStringBuilder2 = new StringBuilder().append("Notifying change URI=");
      String str7 = localUri.toString();
      String str8 = str7;
      logd(str8);
      this.contentResolver.notifyChange(localUri, null);
    case 16:
    }
    while (true)
    {
      return localUri;
      str4 = "current_location";
      str5 = "positioning_status";
      ContentValues localContentValues = new ContentValues();
      localContentValues.putAll(paramContentValues);
      Integer localInteger = Integer.valueOf(1);
      localContentValues.put("current_location_id", localInteger);
      paramContentValues = localContentValues;
      break;
      localUri = null;
    }
  }

  public boolean onCreate()
  {
    Context localContext = getContext();
    ContentResolver localContentResolver = localContext.getContentResolver();
    this.contentResolver = localContentResolver;
    CitiesDatabaseHelper localCitiesDatabaseHelper = new CitiesDatabaseHelper();
    this.weatherDBHelper = localCitiesDatabaseHelper;
    SQLiteDatabase localSQLiteDatabase = this.weatherDBHelper.getWritableDatabase();
    this.citiesDB = localSQLiteDatabase;
    LocaleChangedReceiver localLocaleChangedReceiver = new LocaleChangedReceiver(null);
    IntentFilter localIntentFilter = localeChangedFilter;
    Intent localIntent = localContext.registerReceiver(localLocaleChangedReceiver, localIntentFilter);
    if (this.citiesDB != null);
    for (int i = 1; ; i = 0)
      return i;
  }

  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    int i = requestCount + 1;
    requestCount = i;
    List localList = paramUri.getPathSegments();
    String str1 = null;
    StringBuilder localStringBuilder1 = new StringBuilder().append("Received QUERY: ");
    String str2 = paramUri.toString();
    String str3 = str2;
    CitiesProvider localCitiesProvider1 = this;
    int j = i;
    localCitiesProvider1.logd(j, str3);
    StringBuilder localStringBuilder2 = new StringBuilder().append("    projection=");
    String str4 = Arrays.toString(paramArrayOfString1);
    String str5 = str4;
    CitiesProvider localCitiesProvider2 = this;
    int k = i;
    localCitiesProvider2.logd(k, str5);
    StringBuilder localStringBuilder3 = new StringBuilder().append("    selection=");
    String str6 = paramString1;
    String str7 = str6;
    CitiesProvider localCitiesProvider3 = this;
    int m = i;
    localCitiesProvider3.logd(m, str7);
    StringBuilder localStringBuilder4 = new StringBuilder().append("    selectionArgs=");
    String str8 = Arrays.toString(paramArrayOfString2);
    String str9 = str8;
    CitiesProvider localCitiesProvider4 = this;
    int n = i;
    localCitiesProvider4.logd(n, str9);
    StringBuilder localStringBuilder5 = new StringBuilder().append("    sort=");
    String str10 = paramString2;
    String str11 = str10;
    CitiesProvider localCitiesProvider5 = this;
    int i1 = i;
    localCitiesProvider5.logd(i1, str11);
    UriMatcher localUriMatcher = this.uriMatcher;
    Uri localUri1 = paramUri;
    Cursor localCursor;
    switch (localUriMatcher.match(localUri1))
    {
    default:
      StringBuilder localStringBuilder6 = new StringBuilder().append("Unssuported URI, throwing exception: uri=");
      String str12 = paramUri.toString();
      String str13 = str12;
      CitiesProvider localCitiesProvider6 = this;
      int i2 = i;
      localCitiesProvider6.logw(i2, str13);
      StringBuilder localStringBuilder7 = new StringBuilder().append("Unsupported URI:");
      Uri localUri2 = paramUri;
      String str14 = localUri2;
      throw new IllegalArgumentException(str14);
    case 20:
      String str15 = (String)localList.get(1);
      CitiesProvider localCitiesProvider7 = this;
      Uri localUri3 = paramUri;
      String[] arrayOfString1 = paramArrayOfString1;
      String str16 = paramString1;
      String[] arrayOfString2 = paramArrayOfString2;
      String str17 = paramString2;
      localCursor = localCitiesProvider7.queryCities(localUri3, arrayOfString1, str16, arrayOfString2, str17, null, str15);
    case 2:
    case 1:
    case 15:
    case 16:
    }
    while (true)
    {
      return localCursor;
      str1 = (String)localList.get(1);
      CitiesProvider localCitiesProvider8 = this;
      Uri localUri4 = paramUri;
      String[] arrayOfString3 = paramArrayOfString1;
      String str18 = paramString1;
      String[] arrayOfString4 = paramArrayOfString2;
      String str19 = paramString2;
      localCursor = localCitiesProvider8.queryCities(localUri4, arrayOfString3, str18, arrayOfString4, str19, str1, null);
      continue;
      localCursor = queryNearestCities(paramUri, paramArrayOfString1, paramString1, paramArrayOfString2, paramString2);
      continue;
      CitiesProvider localCitiesProvider9 = this;
      String[] arrayOfString5 = paramArrayOfString1;
      String str20 = paramString1;
      String[] arrayOfString6 = paramArrayOfString2;
      String str21 = paramString2;
      localCursor = localCitiesProvider9.queryCurrentLocation(arrayOfString5, str20, arrayOfString6, str21);
    }
  }

  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString)
  {
    String str1 = null;
    String str3;
    String str5;
    label163: int i;
    switch (this.uriMatcher.match(paramUri))
    {
    default:
      String str2 = "Unsupported URI: " + paramUri;
      throw new IllegalArgumentException(str2);
    case 1:
      str3 = "cities";
      if (str1 != null)
      {
        StringBuilder localStringBuilder1 = new StringBuilder().append(str1).append("=");
        String str4 = (String)paramUri.getPathSegments().get(1);
        StringBuilder localStringBuilder2 = localStringBuilder1.append(str4);
        if (TextUtils.isEmpty(paramString))
          break;
        str5 = " AND (" + paramString + 41;
        paramString = str5;
      }
      else
      {
        StringBuilder localStringBuilder3 = new StringBuilder().append("update: table=").append(str3).append(" values=").append(paramContentValues).append(" where=").append(paramString).append(" args=");
        String str6 = Arrays.toString(paramArrayOfString);
        String str7 = str6;
        logd(str7);
        i = this.citiesDB.update(str3, paramContentValues, paramString, paramArrayOfString);
        if (i <= 0)
          break label386;
        StringBuilder localStringBuilder4 = new StringBuilder().append("Notifying change URI=");
        String str8 = paramUri.toString();
        String str9 = str8;
        logd(str9);
      }
    case 2:
    case 16:
    }
    while (true)
    {
      this.contentResolver.notifyChange(paramUri, null);
      return i;
      str3 = "cities";
      str1 = "_id";
      break;
      str3 = "current_location";
      if (paramString != null)
      {
        paramString = "current_location_id=1" + " AND (" + paramString + ")";
        break;
      }
      paramString = "current_location_id=1";
      break;
      str5 = "";
      break label163;
      label386: String str10 = "Affected rows: " + i;
      logd(str10);
    }
  }

  class CitiesDatabaseHelper extends AssetSQLiteOpenHelper
  {
    private static final String COUNTRY_JP_SELECTION = "country_short_name_jp=?";
    private static final int DATA_VERSION_MILTIPLIER = 1000;
    private static final int DB_SCHEMA_VERSION_1 = 1;

    public CitiesDatabaseHelper()
    {
      super(str, null, m);
    }

    private static int createDbVersionNumber(int paramInt1, int paramInt2)
    {
      return paramInt2 * 1000 + paramInt1;
    }

    private static int getDataVersion(int paramInt)
    {
      return paramInt / 1000;
    }

    private static int getSchemaVersion(int paramInt)
    {
      return paramInt % 1000;
    }

    private void japaneseCountryNamesToHalfwidthForm(SQLiteDatabase paramSQLiteDatabase)
    {
      long l1 = SystemClock.uptimeMillis();
      logd("japaneseCountryNamesToHalfwidthForm");
      HashMap localHashMap1 = new HashMap();
      Cursor localCursor;
      int i;
      try
      {
        String[] arrayOfString1 = new String[1];
        arrayOfString1[0] = "country_short_name_jp";
        localCursor = paramSQLiteDatabase.query(1, "cities", arrayOfString1, null, null, null, null, null, null);
        if ((localCursor != null) && (localCursor.moveToNext()))
        {
          logd("Converting to halfwidth form...");
          i = 0;
          while (!localCursor.isAfterLast())
          {
            String str1 = localCursor.getString(0);
            if (str1 != null)
            {
              String str2 = KanaUtils.getHalfwidthForm(str1);
              HashMap localHashMap2 = localHashMap1;
              String str3 = str1;
              String str4 = str2;
              Object localObject1 = localHashMap2.put(str3, str4);
              i += 1;
            }
            boolean bool = localCursor.moveToNext();
          }
        }
      }
      finally
      {
        if (localCursor == null);
      }
      try
      {
        localCursor.close();
        label160: throw localObject2;
        String str5 = "Converted to halfwidth form: " + i;
        logd(str5);
        while (true)
        {
          if (localCursor != null);
          try
          {
            localCursor.close();
            label203: logd("Updating database");
            ContentValues localContentValues1 = new ContentValues();
            String[] arrayOfString2 = new String[1];
            arrayOfString2[0] = "";
            Iterator localIterator = localHashMap1.entrySet().iterator();
            while (true)
              if (localIterator.hasNext())
              {
                Map.Entry localEntry = (Map.Entry)localIterator.next();
                String str6 = (String)localEntry.getKey();
                String str7 = (String)localEntry.getValue();
                ContentValues localContentValues2 = localContentValues1;
                String str8 = str7;
                localContentValues2.put("country_short_name_jp", str8);
                arrayOfString2[0] = str6;
                SQLiteDatabase localSQLiteDatabase = paramSQLiteDatabase;
                ContentValues localContentValues3 = localContentValues1;
                int j = localSQLiteDatabase.update("cities", localContentValues3, "country_short_name_jp=?", arrayOfString2);
                continue;
                logd("Failed to load country short names");
                break;
              }
            StringBuilder localStringBuilder = new StringBuilder().append("japaneseCountryNamesToHalfwidthForm: completed in ");
            long l2 = SystemClock.uptimeMillis() - l1;
            String str9 = l2 + "ms";
            logd(str9);
            return;
          }
          catch (Exception localException1)
          {
            break label203;
          }
        }
      }
      catch (Exception localException2)
      {
        break label160;
      }
    }

    private void upgradeAll(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2, String paramString)
    {
      String str = "upgradeAll: oldSchemaVersion=" + paramInt1 + " newSchemaVersion=" + paramInt2;
      logd(str);
      upgradeData(paramSQLiteDatabase, paramString);
    }

    private void upgradeData(SQLiteDatabase paramSQLiteDatabase, String paramString)
    {
      logd("upgradeData");
      paramSQLiteDatabase.execSQL("DROP INDEX IF EXISTS idx_cities");
      paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS cities");
      paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS timezones");
      paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS current_location");
      paramSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS cities (_id INTEGER PRIMARY KEY AUTOINCREMENT, city_id INTEGER, city_name TEXT, city_name_jp TEXT, filter_name TEXT, country_short_name TEXT, country_short_name_jp TEXT, state_short_name  TEXT, latitude REAL, longitude  REAL, timezone_id INTEGER)");
      paramSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS timezones (_id INTEGER PRIMARY KEY AUTOINCREMENT, timezone_id INTEGER UNIQUE, timezone_name TEXT, utc_offset_min INTEGER)");
      String str1 = "INSERT INTO cities (city_id, city_name, city_name_jp, filter_name , country_short_name, country_short_name_jp, state_short_name, latitude, longitude, timezone_id) SELECT city_id, city_name, city_name_jp, filter_name , country_short_name, country_short_name_jp, state_short_name, latitude, longitude, timezone_id FROM " + paramString + "." + "cities";
      paramSQLiteDatabase.execSQL(str1);
      String str2 = "INSERT INTO timezones (_id, timezone_id, timezone_name, utc_offset_min) SELECT _id, timezone_id, timezone_name, utc_offset_min FROM " + paramString + "." + "timezones";
      paramSQLiteDatabase.execSQL(str2);
      paramSQLiteDatabase.execSQL("CREATE INDEX IF NOT EXISTS idx_cities ON cities (filter_name ASC);");
      paramSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS current_location (current_location_id INTEGER UNIQUE NOT NULL, city_id INTEGER, positioning_status INTEGER, last_updated_utc INTEGER)");
    }

    public void onCreate(SQLiteDatabase paramSQLiteDatabase)
    {
      logd("onCreate");
      paramSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS cities (_id INTEGER PRIMARY KEY AUTOINCREMENT, city_id INTEGER, city_name TEXT, city_name_jp TEXT, filter_name TEXT, country_short_name TEXT, country_short_name_jp TEXT, state_short_name  TEXT, latitude REAL, longitude  REAL, timezone_id INTEGER)");
      paramSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS timezones (_id INTEGER PRIMARY KEY AUTOINCREMENT, timezone_id INTEGER UNIQUE, timezone_name TEXT, utc_offset_min INTEGER)");
      paramSQLiteDatabase.execSQL("CREATE INDEX IF NOT EXISTS idx_cities ON cities (filter_name ASC);");
      paramSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS current_location (current_location_id INTEGER UNIQUE NOT NULL, city_id INTEGER, positioning_status INTEGER, last_updated_utc INTEGER)");
    }

    public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2, String paramString)
    {
      String str1 = "onUpgrade: oldVersion=" + paramInt1 + " newVersion=" + paramInt2 + " newDbName=" + paramString;
      logd(str1);
      int i = getSchemaVersion(paramInt1);
      int j = getSchemaVersion(paramInt2);
      int k = getDataVersion(paramInt1);
      int m = getDataVersion(paramInt2);
      String str2 = "onUpgrade: oldSchemaVersion=" + i + " newSchemaVersion=" + j + " oldDataVersion=" + k + " newDataVersion=" + m;
      logd(str2);
      if ((i == j) && (k != m))
        upgradeData(paramSQLiteDatabase, paramString);
      while (true)
      {
        return;
        if (i != j)
        {
          upgradeAll(paramSQLiteDatabase, i, j, paramString);
          continue;
        }
      }
    }
  }

  class LocaleChangedReceiver extends BroadcastReceiver
  {
    private LocaleChangedReceiver()
    {
    }

    public void onReceive(Context paramContext, Intent paramIntent)
    {
      String str = paramIntent.getAction();
      if (("android.intent.action.LOCALE_CHANGED".equals(str)) && (CitiesProvider.this.contentResolver != null))
      {
        CitiesProvider.this.logd("WeatherWidgetUpdateService: received Locale Changed Broadcast, notifying content observers...");
        ContentResolver localContentResolver = CitiesProvider.this.contentResolver;
        Uri localUri = CitiesContract.Cities.getContentUri(paramContext);
        localContentResolver.notifyChange(localUri, null);
      }
    }
  }

  abstract interface Tables
  {
    public static final String CITIES = "cities";
    public static final String CITIES_INDEX = "idx_cities";
    public static final String CURRENT_LOCATION = "current_location";
    public static final String TIMEZONES = "timezones";
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.provider.CitiesProvider
 * JD-Core Version:    0.6.0
 */