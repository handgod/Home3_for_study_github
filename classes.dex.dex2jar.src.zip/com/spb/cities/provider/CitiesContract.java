package com.spb.cities.provider;

import android.content.Context;
import android.net.Uri;
import android.net.Uri.Builder;
import android.provider.BaseColumns;

public final class CitiesContract
{
  private static final String AUTHORITY_SUFFIX = ".cities";
  private static String authority;

  public static String getAuthority(Context paramContext)
  {
    if (authority == null);
    synchronized (CitiesContract.class)
    {
      if (authority == null)
      {
        StringBuilder localStringBuilder = new StringBuilder();
        String str = paramContext.getPackageName();
        authority = str + ".cities";
      }
      return authority;
    }
  }

  public final class CurrentLocation
    implements CitiesContract.CurrentLocationColumns
  {
    public static final String CONTENT_PATH = "currentlocation";
    public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.softspb.currentlocation";
    public static final int DEFAULT_INDEX_CITY_ID = 0;
    public static final int DEFAULT_INDEX_LAST_UPDATED_TIMESTAMP_UTC = 2;
    public static final int DEFAULT_INDEX_POSITIONING_STATUS = 1;
    public static final String[] DEFAULT_PROJECTION = ;
    public static final int POSITIONING_STATUS_FAILED = 1;
    public static final int POSITIONING_STATUS_FAILED_NEAREST_CITY_QUERY = 5;
    public static final int POSITIONING_STATUS_FAILED_POSITIONING = 4;
    public static final int POSITIONING_STATUS_OK = 0;
    public static final int POSITIONING_STATUS_UNKNOWN = 2;
    public static final int POSITIONING_STATUS_UPDATING = 3;
    private static Uri contentUri;

    static
    {
      String[] arrayOfString = new String[3];
      arrayOfString[0] = "city_id";
      arrayOfString[1] = "positioning_status";
      arrayOfString[2] = "last_updated_utc";
      DEFAULT_PROJECTION = arrayOfString;
    }

    public static Uri getContentUri(Context paramContext)
    {
      if (contentUri == null);
      synchronized (CurrentLocation.class)
      {
        if (contentUri == null)
        {
          Uri.Builder localBuilder = new Uri.Builder().scheme("content");
          String str = CitiesContract.getAuthority(paramContext);
          contentUri = localBuilder.authority(str).appendPath("currentlocation").build();
        }
        return contentUri;
      }
    }

    public static boolean isStatusFailed(int paramInt)
    {
      int i = 1;
      if ((paramInt == i) || (paramInt == 4) || (paramInt == 5));
      while (true)
      {
        return i;
        i = 0;
      }
    }

    // ERROR //
    public static com.spb.cities.CurrentLocationInfo queryCurrentLocationInfo(Context paramContext, android.content.ContentResolver paramContentResolver)
    {
      // Byte code:
      //   0: aload_0
      //   1: invokestatic 89	com/spb/cities/provider/CitiesContract$CurrentLocation:getContentUri	(Landroid/content/Context;)Landroid/net/Uri;
      //   4: astore_2
      //   5: getstatic 51	com/spb/cities/provider/CitiesContract$CurrentLocation:DEFAULT_PROJECTION	[Ljava/lang/String;
      //   8: astore_3
      //   9: aload_1
      //   10: aload_2
      //   11: aload_3
      //   12: aconst_null
      //   13: aconst_null
      //   14: aconst_null
      //   15: invokevirtual 95	android/content/ContentResolver:query	(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
      //   18: astore 4
      //   20: aload 4
      //   22: ifnull +73 -> 95
      //   25: aload 4
      //   27: invokeinterface 101 1 0
      //   32: ifeq +63 -> 95
      //   35: aload 4
      //   37: iconst_0
      //   38: invokeinterface 105 2 0
      //   43: istore 5
      //   45: aload 4
      //   47: iconst_1
      //   48: invokeinterface 105 2 0
      //   53: istore 6
      //   55: aload 4
      //   57: iconst_2
      //   58: invokeinterface 109 2 0
      //   63: lstore 7
      //   65: new 111	com/spb/cities/CurrentLocationInfo
      //   68: dup
      //   69: iload 5
      //   71: iload 6
      //   73: lload 7
      //   75: invokespecial 114	com/spb/cities/CurrentLocationInfo:<init>	(IIJ)V
      //   78: astore 9
      //   80: aload 4
      //   82: ifnull +10 -> 92
      //   85: aload 4
      //   87: invokeinterface 117 1 0
      //   92: aload 9
      //   94: areturn
      //   95: aload 4
      //   97: ifnull +10 -> 107
      //   100: aload 4
      //   102: invokeinterface 117 1 0
      //   107: new 111	com/spb/cities/CurrentLocationInfo
      //   110: dup
      //   111: invokespecial 118	com/spb/cities/CurrentLocationInfo:<init>	()V
      //   114: astore 9
      //   116: goto -24 -> 92
      //   119: astore 10
      //   121: new 120	java/lang/StringBuilder
      //   124: dup
      //   125: invokespecial 121	java/lang/StringBuilder:<init>	()V
      //   128: ldc 123
      //   130: invokevirtual 127	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   133: aload 10
      //   135: invokevirtual 130	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   138: invokevirtual 134	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   141: astore 11
      //   143: ldc 135
      //   145: aload 11
      //   147: aload 10
      //   149: invokestatic 141	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   152: istore 12
      //   154: aload 4
      //   156: ifnull -49 -> 107
      //   159: aload 4
      //   161: invokeinterface 117 1 0
      //   166: goto -59 -> 107
      //   169: astore 13
      //   171: goto -64 -> 107
      //   174: astore 9
      //   176: aload 4
      //   178: ifnull +10 -> 188
      //   181: aload 4
      //   183: invokeinterface 117 1 0
      //   188: aload 9
      //   190: athrow
      //   191: astore 14
      //   193: goto -101 -> 92
      //   196: astore 15
      //   198: goto -91 -> 107
      //   201: astore 16
      //   203: goto -15 -> 188
      //
      // Exception table:
      //   from	to	target	type
      //   0	80	119	java/lang/Exception
      //   159	166	169	java/lang/Exception
      //   0	80	174	finally
      //   121	154	174	finally
      //   85	92	191	java/lang/Exception
      //   100	107	196	java/lang/Exception
      //   181	188	201	java/lang/Exception
    }
  }

  public abstract interface CurrentLocationColumns
  {
    public static final String CITY_ID = "city_id";
    public static final String LAST_UPDATED_TIMESTAMP_UTC = "last_updated_utc";
    public static final String POSITIONING_STATUS = "positioning_status";
  }

  public final class Cities
    implements BaseColumns, CitiesContract.CitiesColumns
  {
    public static final int CITY_ID_UNKNOWN = -2147483648;
    public static final String CONTENT_FILTER_PATH = "city_filter";
    public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.softspb.city";
    public static final String CONTENT_PATH = "city";
    public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.softspb.city";
    public static final int CURRENT_LOCATION_CITY_ID = 64512;
    public static final int DEFAULT_CITY_ID_INDEX = 1;
    public static final int DEFAULT_CITY_NAME_INDEX = 2;
    public static final int DEFAULT_COUNTRY_SHORT_NAME_INDEX = 3;
    public static final int DEFAULT_ID_INDEX = 0;
    public static final String[] DEFAULT_PROJECTION = ;
    public static final int DEFAULT_STATE_SHORT_NAME_INDEX = 4;
    public static final int NEAREST_CITY_ID_INDEX = 1;
    public static final int NEAREST_CITY_NAME_INDEX = 2;
    public static final String NEAREST_CONTENT_PATH = "nearest";
    public static final int NEAREST_ID_INDEX = 0;
    public static final String[] NEAREST_PROJECTION = ;
    public static final String NEAREST_QUERY_PARAM_LATITUDE = "lat";
    public static final String NEAREST_QUERY_PARAM_LIMIT = "limit";
    public static final String NEAREST_QUERY_PARAM_LONGITUDE = "lon";
    private static Uri contentFilterUri;
    private static Uri contentUri;
    private static Uri nearestContentUri;

    static
    {
      String[] arrayOfString1 = new String[5];
      arrayOfString1[0] = "_id";
      arrayOfString1[1] = "city_id";
      arrayOfString1[2] = "city_name";
      arrayOfString1[3] = "country_short_name";
      arrayOfString1[4] = "state_short_name";
      DEFAULT_PROJECTION = arrayOfString1;
      String[] arrayOfString2 = new String[3];
      arrayOfString2[0] = "_id";
      arrayOfString2[1] = "city_id";
      arrayOfString2[2] = "city_name";
      NEAREST_PROJECTION = arrayOfString2;
    }

    public static Uri buildNearestQueryUri(Context paramContext, String paramString1, String paramString2, String paramString3)
    {
      Uri.Builder localBuilder = new Uri.Builder().scheme("content");
      String str = CitiesContract.getAuthority(paramContext);
      return localBuilder.authority(str).appendPath("nearest").appendQueryParameter("lat", paramString1).appendQueryParameter("lon", paramString2).appendQueryParameter("limit", paramString3).build();
    }

    static void checkInitUris(Context paramContext)
    {
      if (contentUri == null);
      synchronized (Cities.class)
      {
        if (contentUri == null)
          initUris(CitiesContract.getAuthority(paramContext));
        return;
      }
    }

    public static Uri getContentFilterUri(Context paramContext)
    {
      checkInitUris(paramContext);
      return contentFilterUri;
    }

    public static Uri getContentUri(Context paramContext)
    {
      checkInitUris(paramContext);
      return contentUri;
    }

    public static Uri getNearestContentUri(Context paramContext)
    {
      checkInitUris(paramContext);
      return nearestContentUri;
    }

    static void initUris(String paramString)
    {
      if (contentUri == null);
      synchronized (Cities.class)
      {
        if (contentUri == null)
        {
          contentUri = new Uri.Builder().scheme("content").authority(paramString).appendPath("city").build();
          contentFilterUri = new Uri.Builder().scheme("content").authority(paramString).appendPath("city_filter").build();
          nearestContentUri = new Uri.Builder().scheme("content").authority(paramString).appendPath("nearest").build();
        }
        return;
      }
    }
  }

  public abstract interface CitiesColumns
  {
    public static final String CITY_ID = "city_id";
    public static final String CITY_NAME = "city_name";
    public static final String CITY_NAME_JP = "city_name_jp";
    public static final String COUNTRY_SHORT_NAME = "country_short_name";
    public static final String COUNTRY_SHORT_NAME_JP = "country_short_name_jp";
    public static final String FILTER_NAME = "filter_name";
    public static final String LATITUDE = "latitude";
    public static final String LONGITUDE = "longitude";
    public static final String STATE_SHORT_NAME = "state_short_name";
    public static final String TIMEZONE_ID = "timezone_id";
    public static final String TIMEZONE_NAME = "timezone_name";
    public static final String UTC_OFFSET_MINUTES = "utc_offset_min";
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.provider.CitiesContract
 * JD-Core Version:    0.6.0
 */