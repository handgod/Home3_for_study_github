package com.spb.cities.pick;

import android.view.inputmethod.InputMethodManager;
import com.softspb.util.log.Logger;

class CitySelectionActivity$4
  implements Runnable
{
  public void run()
  {
    InputMethodManager localInputMethodManager = (InputMethodManager)this.this$0.getSystemService("input_method");
    SPBAutoCompleteTextView localSPBAutoCompleteTextView = this.this$0.cityNameInput;
    boolean bool = localInputMethodManager.showSoftInput(localSPBAutoCompleteTextView, 0);
    Logger localLogger = CitySelectionActivity.access$000();
    String str = "showSoftInput returned " + bool;
    localLogger.d(str);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.pick.CitySelectionActivity.4
 * JD-Core Version:    0.6.0
 */