package com.spb.cities.pick;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.MergeCursor;
import android.net.Uri;
import android.widget.FilterQueryProvider;
import com.softspb.util.log.Logger;
import com.spb.cities.R.string;
import com.spb.cities.provider.CitiesContract.Cities;

public class CitiesAutoCompleteAdapter extends AutoCompletionAdapter
{
  public static final long CURRENT_LOCATION = 1000100200L;
  public static final long ENABLE_LOCATION = 1000100300L;
  private static final int JP_CHARACTER_LOWER_BOUND = 1000;
  public static final long LOCATE_NEAREST = 1000100100L;
  Uri contentUri;
  String filteredColumn;
  Context mContext;
  String[] projection;
  boolean showCurrentLocation;
  boolean showEnableLocation;
  boolean showLocateNearest;

  public CitiesAutoCompleteAdapter(Context paramContext, int paramInt, Uri paramUri, String[] paramArrayOfString, String paramString, boolean paramBoolean)
  {
  }

  private static void addDummyRow(Context paramContext, MatrixCursor paramMatrixCursor, int paramInt, long paramLong)
  {
    Object[] arrayOfObject = new Object[5];
    Long localLong = Long.valueOf(paramLong);
    arrayOfObject[0] = localLong;
    Integer localInteger = Integer.valueOf(0);
    arrayOfObject[1] = localInteger;
    String str = paramContext.getString(paramInt);
    arrayOfObject[2] = str;
    arrayOfObject[3] = 0;
    arrayOfObject[4] = 0;
    paramMatrixCursor.addRow(arrayOfObject);
  }

  private boolean constraintEnoughForFiltering(CharSequence paramCharSequence)
  {
    int i = 0;
    int j = paramCharSequence.length();
    int k = this.threshold;
    if ((j >= k) || ((paramCharSequence.length() > 0) && (paramCharSequence.charAt(0) > 1000)))
      i = 1;
    return i;
  }

  private static MatrixCursor createDefaultRows(Context paramContext, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
  {
    String[] arrayOfString = CitiesContract.Cities.DEFAULT_PROJECTION;
    MatrixCursor localMatrixCursor = new MatrixCursor(arrayOfString);
    if (paramBoolean1)
    {
      int i = R.string.weather_locate_nearest_city;
      addDummyRow(paramContext, localMatrixCursor, i, 1000100100L);
    }
    if (paramBoolean2)
    {
      int j = R.string.weather_current_location;
      addDummyRow(paramContext, localMatrixCursor, j, 1000100200L);
    }
    if (paramBoolean3)
    {
      int k = R.string.weather_enable_location;
      addDummyRow(paramContext, localMatrixCursor, k, 1000100300L);
    }
    return localMatrixCursor;
  }

  public String convertToString(Cursor paramCursor)
  {
    return paramCursor.getString(2);
  }

  public Cursor runQueryOnBackgroundThread(CharSequence paramCharSequence)
  {
    logd("runQueryOnBackgroundThread");
    Object localObject1 = null;
    long l1;
    Uri localUri2;
    if ((paramCharSequence != null) && (constraintEnoughForFiltering(paramCharSequence)))
    {
      if (getFilterQueryProvider() != null)
        localObject1 = getFilterQueryProvider().runQuery(paramCharSequence);
      l1 = System.currentTimeMillis();
      String str1 = "Querying for cities name: constraint=" + paramCharSequence;
      logd(str1);
      Uri localUri1 = CitiesContract.Cities.getContentFilterUri(this.mContext);
      String str2 = paramCharSequence.toString();
      localUri2 = Uri.withAppendedPath(localUri1, str2);
    }
    try
    {
      ContentResolver localContentResolver = this.mContentResolver;
      String[] arrayOfString = this.projection;
      Cursor localCursor = localContentResolver.query(localUri2, arrayOfString, null, null, null);
      localObject1 = localCursor;
      long l2 = System.currentTimeMillis();
      StringBuilder localStringBuilder = new StringBuilder().append("Query completed in ");
      long l3 = l2 - l1;
      String str3 = l3 + "ms";
      logd(str3);
      Context localContext = this.mContext;
      boolean bool1 = this.showLocateNearest;
      boolean bool2 = this.showCurrentLocation;
      boolean bool3 = this.showEnableLocation;
      localObject2 = createDefaultRows(localContext, bool1, bool2, bool3);
      if (localObject1 == null)
        return localObject2;
    }
    catch (Exception localException)
    {
      while (true)
      {
        Logger localLogger = logger;
        String str4 = "City filter query failed: " + localException;
        localLogger.w(str4, localException);
        continue;
        Cursor[] arrayOfCursor = new Cursor[2];
        arrayOfCursor[0] = localObject2;
        arrayOfCursor[1] = localObject1;
        Object localObject2 = new MergeCursor(arrayOfCursor);
      }
    }
  }

  public void setLocationPossible(boolean paramBoolean)
  {
    this.showCurrentLocation = paramBoolean;
    if (!paramBoolean);
    for (int i = 1; ; i = 0)
    {
      this.showEnableLocation = i;
      this.showLocateNearest = paramBoolean;
      return;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.pick.CitiesAutoCompleteAdapter
 * JD-Core Version:    0.6.0
 */