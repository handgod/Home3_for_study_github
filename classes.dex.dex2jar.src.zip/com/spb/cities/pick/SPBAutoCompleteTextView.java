package com.spb.cities.pick;

import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.widget.AutoCompleteTextView;
import com.softspb.kana.Characters;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;

public class SPBAutoCompleteTextView extends AutoCompleteTextView
{
  static Logger logger = Loggers.getLogger("City");
  private CharSequence filterText;
  OnBackKeyListener mBackKeyListener;
  KeyInterceptor mKeyInterceptor;

  public SPBAutoCompleteTextView(Context paramContext)
  {
    super(paramContext);
  }

  public SPBAutoCompleteTextView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  public SPBAutoCompleteTextView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
  }

  private static String logUnicode(String paramString)
  {
    if (paramString == null);
    StringBuilder localStringBuilder1;
    for (String str1 = "null"; ; str1 = localStringBuilder1.toString())
    {
      return str1;
      int i = paramString.length();
      int j = 0;
      localStringBuilder1 = new StringBuilder();
      while (j < i)
      {
        StringBuilder localStringBuilder2 = localStringBuilder1.append("\\u");
        String str2 = Integer.toHexString(paramString.codePointAt(j));
        StringBuilder localStringBuilder3 = localStringBuilder2.append(str2);
        j = paramString.offsetByCodePoints(j, 1);
      }
    }
  }

  public void dismissDropDown()
  {
    logger.d("dismissDropDown");
    Exception localException = new Exception();
    Throwable localThrowable = localException.fillInStackTrace();
    StackTraceElement[] arrayOfStackTraceElement = localException.getStackTrace();
    if (arrayOfStackTraceElement.length >= 2)
    {
      StackTraceElement localStackTraceElement = arrayOfStackTraceElement[1];
      String str1 = localStackTraceElement.getClassName();
      if ("android.widget.AutoCompleteTextView".equals(str1))
      {
        String str2 = localStackTraceElement.getMethodName();
        if ("onWindowFocusChanged".equals(str2))
          logger.d("Ignoring dismissDropDown");
      }
    }
    while (true)
    {
      return;
      super.dismissDropDown();
    }
  }

  public boolean enoughToFilter()
  {
    return true;
  }

  CharSequence getFilterText()
  {
    return this.filterText;
  }

  public boolean onKeyPreIme(int paramInt, KeyEvent paramKeyEvent)
  {
    int i = 1;
    Logger localLogger = logger;
    String str = "SPBAutoCompleteTextView.onKeyPreIme: keyCode=" + paramInt + " event=" + paramKeyEvent;
    localLogger.d(str);
    if (paramInt == 4)
      if ((paramKeyEvent.getAction() == 1) && (this.mBackKeyListener != null))
        this.mBackKeyListener.onBackKey();
    while (true)
    {
      return i;
      boolean bool = super.onKeyPreIme(paramInt, paramKeyEvent);
    }
  }

  public void onWindowFocusChanged(boolean paramBoolean)
  {
    Logger localLogger = logger;
    String str = "AutoCompleteTextView.onWindowFocusChanged: hasWindowFocus=" + paramBoolean;
    localLogger.d(str);
    super.onWindowFocusChanged(paramBoolean);
    if (paramBoolean)
      showDropDown();
  }

  protected void performFiltering(CharSequence paramCharSequence, int paramInt)
  {
    CharSequence localCharSequence = Characters.fullWidthLatinToAsciiLatin(paramCharSequence);
    Logger localLogger = logger;
    StringBuilder localStringBuilder = new StringBuilder().append("City: performFiltering text=");
    String str1 = logUnicode(localCharSequence.toString());
    String str2 = str1 + " keyCode=" + paramInt;
    localLogger.d(str2);
    this.filterText = localCharSequence;
    super.performFiltering(localCharSequence, paramInt);
  }

  public void setOnBackKeyListener(OnBackKeyListener paramOnBackKeyListener)
  {
    this.mBackKeyListener = paramOnBackKeyListener;
  }

  class KeyInterceptor
    implements View.OnKeyListener
  {
    public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent)
    {
      Logger localLogger = SPBAutoCompleteTextView.logger;
      String str = "Intercepted key: keyCode=" + paramInt + " event=" + paramKeyEvent + " view=" + paramView;
      localLogger.d(str);
      return false;
    }
  }

  public abstract interface OnBackKeyListener
  {
    public abstract void onBackKey();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.pick.SPBAutoCompleteTextView
 * JD-Core Version:    0.6.0
 */