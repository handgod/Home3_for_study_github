package com.spb.cities.pick;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.database.Cursor;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.text.Editable;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Filter;
import android.widget.ListAdapter;
import android.widget.Toast;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import com.spb.cities.R.id;
import com.spb.cities.R.layout;
import com.spb.cities.R.string;
import com.spb.cities.location.LocationClient;
import com.spb.cities.nearestcity.NearestCitiesClient.QueryParams;
import com.spb.cities.nearestcity.NearestCitiesClient.ResponseItem;
import com.spb.cities.provider.CitiesContract.Cities;
import java.lang.ref.WeakReference;

public class CitySelectionActivity extends Activity
  implements AdapterView.OnItemClickListener, DialogInterface.OnCancelListener
{
  private static final int AUTOCOMPLETION_THRESHOLD = 3;
  public static final boolean DO_BROADCAST_RESULT_DEFAULT = false;
  public static final String INTENT_PARAM_DO_BROADCAST_RESULT = "do-broadcast-result";
  public static final String INTENT_PARAM_WEATHER_ADAPTER_TOKEN = "weather-adapter-token";
  public static final String INTENT_PARAM_WEATHER_PROVIDER_TOKEN = "weather-provider-token";
  private static final int MAX_NEAREST_CITY_COUNT = 20;
  public static final String SELECT_CITY_RESULT_ACTION = "com.softspb.toshiba.weather.action.SELECT_CITY_RESULT";
  private static final Logger logger = Loggers.getLogger(CitySelectionActivity.class.getName());
  CitiesAutoCompleteAdapter allCitiesAdapter;
  SPBAutoCompleteTextView cityNameInput;
  DataHandler dataHandler;
  private boolean doBroadcastResult;
  Intent incomingIntent;
  private boolean isShowingDialog = 0;
  LocationClient locClient;
  private boolean locationNearestCitiesInProgress = 0;
  private long locationNearestOperationId = 65535L;
  private int nearestCityCount = 5;
  private final Runnable postShowDropDown;
  private boolean showingNearestCities;
  UIHandler uiHandler;

  public CitySelectionActivity()
  {
    CitySelectionActivity.3 local3 = new CitySelectionActivity.3(this);
    this.postShowDropDown = local3;
  }

  private void forceShowOnscreenKbd()
  {
    logger.d("Posting show soft input...");
    SPBAutoCompleteTextView localSPBAutoCompleteTextView = this.cityNameInput;
    CitySelectionActivity.4 local4 = new CitySelectionActivity.4(this);
    boolean bool = localSPBAutoCompleteTextView.post(local4);
  }

  private void onCitySelected(int paramInt, String paramString)
  {
    Logger localLogger = logger;
    String str = "onCitySelected: cityId=" + paramInt + " cityName=" + paramString;
    localLogger.d(str);
    Intent localIntent1 = new Intent();
    Intent localIntent2 = localIntent1.putExtra("city_id", paramInt);
    Intent localIntent3 = localIntent1.putExtra("city_name", paramString);
    Intent localIntent4 = this.incomingIntent;
    Intent localIntent5 = localIntent1.putExtras(localIntent4);
    setResult(-1, localIntent1);
    onResult(paramInt, paramString);
    finish();
  }

  private void onCurrentLocationSelected()
  {
    onCitySelected(64512, null);
    SPBAutoCompleteTextView localSPBAutoCompleteTextView = this.cityNameInput;
    CharSequence localCharSequence = this.cityNameInput.getFilterText();
    localSPBAutoCompleteTextView.setText(localCharSequence);
  }

  private void onEnableLocationSelected()
  {
    Intent localIntent = new Intent("android.settings.LOCATION_SOURCE_SETTINGS");
    startActivity(localIntent);
    SPBAutoCompleteTextView localSPBAutoCompleteTextView = this.cityNameInput;
    CharSequence localCharSequence = this.cityNameInput.getFilterText();
    localSPBAutoCompleteTextView.setText(localCharSequence);
  }

  private void onFinishedNearestCityLocation(int paramInt)
  {
    this.locationNearestCitiesInProgress = 0;
  }

  private void onLocateNearestSelected(int paramInt)
  {
    logger.d("onMyLocationSelected");
    this.cityNameInput.setText("");
    this.locationNearestCitiesInProgress = 1;
    if (this.uiHandler != null)
      this.uiHandler.postShowProgressDialog();
    if (this.dataHandler != null)
      this.dataHandler.postQueryNearestCities(paramInt);
  }

  private void onNothingSelected()
  {
    logger.d("onNothingSelected");
    Intent localIntent = new Intent();
    setResult(0, localIntent);
    onResult(-2147483648, null);
    finish();
  }

  private void onResult(int paramInt, String paramString)
  {
    if (this.doBroadcastResult)
    {
      logger.d("broadcasting result...");
      Intent localIntent1 = new Intent("com.softspb.toshiba.weather.action.SELECT_CITY_RESULT");
      Intent localIntent2 = localIntent1.putExtra("city_id", paramInt);
      if (paramString != null)
        Intent localIntent3 = localIntent1.putExtra("city_name", paramString);
      Intent localIntent4 = this.incomingIntent;
      Intent localIntent5 = localIntent1.putExtras(localIntent4);
      sendBroadcast(localIntent1);
    }
    while (true)
    {
      return;
      logger.d("NOT broadcasting result...");
    }
  }

  private void showAllCities()
  {
    logger.d("showAllCities");
    this.showingNearestCities = 0;
    boolean bool = this.locClient.isLocationPossible();
    if (this.allCitiesAdapter != null)
    {
      this.allCitiesAdapter.setLocationPossible(bool);
      SPBAutoCompleteTextView localSPBAutoCompleteTextView1 = this.cityNameInput;
      CitiesAutoCompleteAdapter localCitiesAutoCompleteAdapter1 = this.allCitiesAdapter;
      localSPBAutoCompleteTextView1.setAdapter(localCitiesAutoCompleteAdapter1);
      this.cityNameInput.showDropDown();
      Filter localFilter = this.allCitiesAdapter.getFilter();
      Editable localEditable = this.cityNameInput.getText();
      localFilter.filter(localEditable);
    }
    while (true)
    {
      return;
      Uri localUri = CitiesContract.Cities.getContentUri(this);
      String[] arrayOfString = CitiesContract.Cities.DEFAULT_PROJECTION;
      CitySelectionActivity localCitySelectionActivity = this;
      CitiesAutoCompleteAdapter localCitiesAutoCompleteAdapter2 = new CitiesAutoCompleteAdapter(localCitySelectionActivity, 3, localUri, arrayOfString, "city_name", bool);
      this.allCitiesAdapter = localCitiesAutoCompleteAdapter2;
      SPBAutoCompleteTextView localSPBAutoCompleteTextView2 = this.cityNameInput;
      CitiesAutoCompleteAdapter localCitiesAutoCompleteAdapter3 = this.allCitiesAdapter;
      localSPBAutoCompleteTextView2.setAdapter(localCitiesAutoCompleteAdapter3);
    }
  }

  public void onBackPressed()
  {
    logger.d("onBackPressed");
    super.onBackPressed();
  }

  public void onCancel(DialogInterface paramDialogInterface)
  {
  }

  protected void onCreate(Bundle paramBundle)
  {
    logger.d("onCreate >>>");
    super.onCreate(paramBundle);
    int i = R.layout.weather_city_selection;
    setContentView(i);
    int j = R.id.weather_city_name_input;
    SPBAutoCompleteTextView localSPBAutoCompleteTextView1 = (SPBAutoCompleteTextView)findViewById(j);
    this.cityNameInput = localSPBAutoCompleteTextView1;
    this.cityNameInput.setThreshold(0);
    SPBAutoCompleteTextView localSPBAutoCompleteTextView2 = this.cityNameInput;
    OnInputBackKeyListener localOnInputBackKeyListener = new OnInputBackKeyListener();
    localSPBAutoCompleteTextView2.setOnBackKeyListener(localOnInputBackKeyListener);
    LocationClient localLocationClient = new LocationClient(this);
    this.locClient = localLocationClient;
    Intent localIntent = getIntent();
    this.incomingIntent = localIntent;
    boolean bool1 = localIntent.getBooleanExtra("do-broadcast-result", 0);
    this.doBroadcastResult = bool1;
    Logger localLogger = logger;
    StringBuilder localStringBuilder = new StringBuilder().append("doBroadcastResult=");
    boolean bool2 = this.doBroadcastResult;
    String str = bool2;
    localLogger.d(str);
    this.cityNameInput.setOnItemClickListener(this);
    SPBAutoCompleteTextView localSPBAutoCompleteTextView3 = this.cityNameInput;
    CitySelectionActivity.1 local1 = new CitySelectionActivity.1(this);
    localSPBAutoCompleteTextView3.setOnFocusChangeListener(local1);
    SPBAutoCompleteTextView localSPBAutoCompleteTextView4 = this.cityNameInput;
    CitySelectionActivity.2 local2 = new CitySelectionActivity.2(this);
    localSPBAutoCompleteTextView4.setOnTouchListener(local2);
    HandlerThread localHandlerThread = new HandlerThread("CitySelection-Data");
    localHandlerThread.start();
    Looper localLooper = localHandlerThread.getLooper();
    DataHandler localDataHandler = new DataHandler(localLooper);
    this.dataHandler = localDataHandler;
    UIHandler localUIHandler = new UIHandler();
    this.uiHandler = localUIHandler;
    logger.d("onCreate <<<");
  }

  protected void onDestroy()
  {
    logger.d("onDestroy >>>");
    this.locClient.dispose();
    this.dataHandler.getLooper().quit();
    this.dataHandler.finish();
    this.dataHandler = null;
    this.uiHandler.finish();
    this.uiHandler = null;
    super.onDestroy();
    logger.d("onDestroy <<<");
  }

  void onInputBackKey()
  {
    if (this.showingNearestCities)
      showAllCities();
    while (true)
    {
      return;
      onNothingSelected();
    }
  }

  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    if (paramLong == 1000100100L)
    {
      int i = this.nearestCityCount;
      onLocateNearestSelected(i);
    }
    while (true)
    {
      return;
      if (paramLong == 1000100200L)
      {
        onCurrentLocationSelected();
        continue;
      }
      if (paramLong == 1000100300L)
      {
        onEnableLocationSelected();
        continue;
      }
      if (paramLong == 2000200200L)
      {
        int j = Math.min(this.nearestCityCount * 2, 20);
        this.nearestCityCount = j;
        int k = this.nearestCityCount;
        onLocateNearestSelected(k);
        continue;
      }
      Cursor localCursor = (Cursor)this.cityNameInput.getAdapter().getItem(paramInt);
      int m = localCursor.getInt(1);
      String str = localCursor.getString(2);
      onCitySelected(m, str);
    }
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    Logger localLogger = logger;
    String str = "onKeyDown: keyCode=" + paramInt + " event=" + paramKeyEvent;
    localLogger.d(str);
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent)
  {
    Logger localLogger = logger;
    String str = "onKeyDown: keyCode=" + paramInt + " event=" + paramKeyEvent;
    localLogger.d(str);
    return super.onKeyUp(paramInt, paramKeyEvent);
  }

  protected void onNewIntent(Intent paramIntent)
  {
    super.onNewIntent(paramIntent);
    boolean bool = paramIntent.getBooleanExtra("do-broadcast-result", 0);
    this.doBroadcastResult = bool;
    this.incomingIntent = paramIntent;
  }

  protected void onPause()
  {
    logger.d("onPause >>>");
    super.onPause();
    InputMethodManager localInputMethodManager = (InputMethodManager)getSystemService("input_method");
    IBinder localIBinder = this.cityNameInput.getWindowToken();
    boolean bool = localInputMethodManager.hideSoftInputFromWindow(localIBinder, 0);
    logger.d("onPause <<<");
  }

  protected void onResume()
  {
    logger.d("onResume >>>");
    super.onResume();
    showAllCities();
    logger.d("onResume <<<");
  }

  class UIHandler extends Handler
    implements DialogInterface.OnCancelListener
  {
    private static final int MSG_HIDE_PROGRESS_DIALOG = 2;
    private static final int MSG_SHOW_NEAREST_CITIES = 4;
    private static final int MSG_SHOW_PROGRESS_DIALOG = 1;
    private static final int MSG_SHOW_TOAST = 3;
    private Dialog dialog;

    UIHandler()
    {
    }

    private void hideProgressDialog()
    {
      if (this.dialog != null)
      {
        this.dialog.dismiss();
        this.dialog = null;
      }
    }

    private void showNearestCities(NearestCitiesClient.ResponseItem[] paramArrayOfResponseItem, int paramInt)
    {
      NearestAutoCompletionAdapter localNearestAutoCompletionAdapter = new com/spb/cities/pick/NearestAutoCompletionAdapter;
      CitySelectionActivity localCitySelectionActivity = CitySelectionActivity.this;
      if (paramInt < 20);
      int j;
      for (int i = 1; ; j = 0)
      {
        localNearestAutoCompletionAdapter.<init>(localCitySelectionActivity, paramArrayOfResponseItem, 3, i);
        CitySelectionActivity.this.cityNameInput.setAdapter(localNearestAutoCompletionAdapter);
        CitySelectionActivity.this.cityNameInput.showDropDown();
        boolean bool = CitySelectionActivity.access$402(CitySelectionActivity.this, 1);
        return;
      }
    }

    private void showProgressDialog()
    {
      hideProgressDialog();
      CitySelectionActivity localCitySelectionActivity1 = CitySelectionActivity.this;
      CitySelectionActivity localCitySelectionActivity2 = CitySelectionActivity.this;
      int i = R.string.searching_city_title;
      String str1 = localCitySelectionActivity2.getString(i);
      CitySelectionActivity localCitySelectionActivity3 = CitySelectionActivity.this;
      int j = R.string.searching_city_progress;
      String str2 = localCitySelectionActivity3.getString(j);
      int k = 1;
      UIHandler localUIHandler = this;
      ProgressDialog localProgressDialog = ProgressDialog.show(localCitySelectionActivity1, str1, str2, 1, k, localUIHandler);
      this.dialog = localProgressDialog;
    }

    private void showToast(int paramInt)
    {
      Toast.makeText(CitySelectionActivity.this, paramInt, 1).show();
    }

    private void showToast(String paramString)
    {
      Toast.makeText(CitySelectionActivity.this, paramString, 1).show();
    }

    void finish()
    {
      hideProgressDialog();
    }

    public void handleMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default:
      case 1:
      case 2:
      case 3:
      case 4:
      }
      while (true)
      {
        return;
        showProgressDialog();
        continue;
        hideProgressDialog();
        continue;
        if (paramMessage.obj != null)
        {
          String str = (String)paramMessage.obj;
          showToast(str);
          continue;
        }
        int i = paramMessage.arg1;
        showToast(i);
        continue;
        NearestCitiesClient.ResponseItem[] arrayOfResponseItem = (NearestCitiesClient.ResponseItem[])(NearestCitiesClient.ResponseItem[])paramMessage.obj;
        int j = paramMessage.arg1;
        showNearestCities(arrayOfResponseItem, j);
      }
    }

    public void onCancel(DialogInterface paramDialogInterface)
    {
      CitySelectionActivity.this.locClient.abort();
      hideProgressDialog();
      CitySelectionActivity.this.onFinishedNearestCityLocation(0);
    }

    void postHideProgressDialog()
    {
      if (!hasMessages(2))
      {
        removeMessages(1);
        Message localMessage = Message.obtain(this, 2);
        boolean bool = sendMessage(localMessage);
      }
    }

    void postShowNearestCities(NearestCitiesClient.ResponseItem[] paramArrayOfResponseItem, int paramInt)
    {
      Message localMessage = Message.obtain(this, 4, paramArrayOfResponseItem);
      localMessage.arg1 = paramInt;
      boolean bool = sendMessage(localMessage);
    }

    void postShowProgressDialog()
    {
      if (!hasMessages(1))
      {
        removeMessages(2);
        Message localMessage = Message.obtain(this, 1);
        boolean bool = sendMessage(localMessage);
      }
    }

    void postShowToast(int paramInt)
    {
      Message localMessage = Message.obtain(this, 3);
      localMessage.arg1 = paramInt;
      boolean bool = sendMessage(localMessage);
    }

    void postShowToast(String paramString)
    {
      Message localMessage = Message.obtain(this, 3, paramString);
      boolean bool = sendMessage(localMessage);
    }
  }

  class DataHandler extends Handler
  {
    private static final int MSG_QUERY_NEAREST_CITIES = 1;

    public DataHandler(Looper arg2)
    {
      super();
    }

    // ERROR //
    private void onQueryNearestCitiesResult(Location paramLocation, Cursor paramCursor, int paramInt)
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 17	com/spb/cities/pick/CitySelectionActivity$DataHandler:this$0	Lcom/spb/cities/pick/CitySelectionActivity;
      //   4: invokestatic 28	com/spb/cities/pick/CitySelectionActivity:access$200	(Lcom/spb/cities/pick/CitySelectionActivity;)Z
      //   7: ifeq +246 -> 253
      //   10: aload_0
      //   11: getfield 17	com/spb/cities/pick/CitySelectionActivity$DataHandler:this$0	Lcom/spb/cities/pick/CitySelectionActivity;
      //   14: bipush 255
      //   16: invokestatic 32	com/spb/cities/pick/CitySelectionActivity:access$300	(Lcom/spb/cities/pick/CitySelectionActivity;I)V
      //   19: aload_1
      //   20: ifnull +7 -> 27
      //   23: aload_2
      //   24: ifnonnull +65 -> 89
      //   27: aload_0
      //   28: getfield 17	com/spb/cities/pick/CitySelectionActivity$DataHandler:this$0	Lcom/spb/cities/pick/CitySelectionActivity;
      //   31: getfield 36	com/spb/cities/pick/CitySelectionActivity:uiHandler	Lcom/spb/cities/pick/CitySelectionActivity$UIHandler;
      //   34: ifnull +24 -> 58
      //   37: aload_0
      //   38: getfield 17	com/spb/cities/pick/CitySelectionActivity$DataHandler:this$0	Lcom/spb/cities/pick/CitySelectionActivity;
      //   41: getfield 36	com/spb/cities/pick/CitySelectionActivity:uiHandler	Lcom/spb/cities/pick/CitySelectionActivity$UIHandler;
      //   44: astore 4
      //   46: getstatic 41	com/spb/cities/R$string:city_location_failed	I
      //   49: istore 5
      //   51: aload 4
      //   53: iload 5
      //   55: invokevirtual 47	com/spb/cities/pick/CitySelectionActivity$UIHandler:postShowToast	(I)V
      //   58: aload_2
      //   59: ifnull +9 -> 68
      //   62: aload_2
      //   63: invokeinterface 53 1 0
      //   68: aload_0
      //   69: getfield 17	com/spb/cities/pick/CitySelectionActivity$DataHandler:this$0	Lcom/spb/cities/pick/CitySelectionActivity;
      //   72: getfield 36	com/spb/cities/pick/CitySelectionActivity:uiHandler	Lcom/spb/cities/pick/CitySelectionActivity$UIHandler;
      //   75: ifnull +13 -> 88
      //   78: aload_0
      //   79: getfield 17	com/spb/cities/pick/CitySelectionActivity$DataHandler:this$0	Lcom/spb/cities/pick/CitySelectionActivity;
      //   82: getfield 36	com/spb/cities/pick/CitySelectionActivity:uiHandler	Lcom/spb/cities/pick/CitySelectionActivity$UIHandler;
      //   85: invokevirtual 56	com/spb/cities/pick/CitySelectionActivity$UIHandler:postHideProgressDialog	()V
      //   88: return
      //   89: aload_2
      //   90: invokeinterface 60 1 0
      //   95: anewarray 62	com/spb/cities/nearestcity/NearestCitiesClient$ResponseItem
      //   98: astore 6
      //   100: aload_2
      //   101: invokeinterface 66 1 0
      //   106: istore 7
      //   108: iconst_0
      //   109: istore 8
      //   111: aload_2
      //   112: invokeinterface 69 1 0
      //   117: ifne +58 -> 175
      //   120: aload_2
      //   121: iconst_1
      //   122: invokeinterface 73 2 0
      //   127: istore 9
      //   129: aload_2
      //   130: iconst_2
      //   131: invokeinterface 77 2 0
      //   136: astore 10
      //   138: new 62	com/spb/cities/nearestcity/NearestCitiesClient$ResponseItem
      //   141: dup
      //   142: iload 9
      //   144: aload 10
      //   146: invokespecial 80	com/spb/cities/nearestcity/NearestCitiesClient$ResponseItem:<init>	(ILjava/lang/String;)V
      //   149: astore 11
      //   151: aload 6
      //   153: iload 8
      //   155: aload 11
      //   157: aastore
      //   158: aload_2
      //   159: invokeinterface 83 1 0
      //   164: istore 12
      //   166: iload 8
      //   168: iconst_1
      //   169: iadd
      //   170: istore 8
      //   172: goto -61 -> 111
      //   175: aload 6
      //   177: arraylength
      //   178: ifle +42 -> 220
      //   181: aload_0
      //   182: getfield 17	com/spb/cities/pick/CitySelectionActivity$DataHandler:this$0	Lcom/spb/cities/pick/CitySelectionActivity;
      //   185: astore 13
      //   187: new 85	com/spb/cities/location/CurrentLocationPreferences
      //   190: dup
      //   191: aload 13
      //   193: invokespecial 88	com/spb/cities/location/CurrentLocationPreferences:<init>	(Landroid/content/Context;)V
      //   196: astore 14
      //   198: aload 6
      //   200: iconst_0
      //   201: aaload
      //   202: invokevirtual 91	com/spb/cities/nearestcity/NearestCitiesClient$ResponseItem:getCityId	()I
      //   205: istore 15
      //   207: aload 14
      //   209: aload_1
      //   210: iload 15
      //   212: invokevirtual 95	com/spb/cities/location/CurrentLocationPreferences:setLastKnownLocation	(Landroid/location/Location;I)V
      //   215: aload 14
      //   217: invokevirtual 98	com/spb/cities/location/CurrentLocationPreferences:dispose	()V
      //   220: aload_0
      //   221: getfield 17	com/spb/cities/pick/CitySelectionActivity$DataHandler:this$0	Lcom/spb/cities/pick/CitySelectionActivity;
      //   224: invokevirtual 101	com/spb/cities/pick/CitySelectionActivity:isFinishing	()Z
      //   227: ifne +26 -> 253
      //   230: aload_0
      //   231: getfield 17	com/spb/cities/pick/CitySelectionActivity$DataHandler:this$0	Lcom/spb/cities/pick/CitySelectionActivity;
      //   234: getfield 36	com/spb/cities/pick/CitySelectionActivity:uiHandler	Lcom/spb/cities/pick/CitySelectionActivity$UIHandler;
      //   237: ifnull +16 -> 253
      //   240: aload_0
      //   241: getfield 17	com/spb/cities/pick/CitySelectionActivity$DataHandler:this$0	Lcom/spb/cities/pick/CitySelectionActivity;
      //   244: getfield 36	com/spb/cities/pick/CitySelectionActivity:uiHandler	Lcom/spb/cities/pick/CitySelectionActivity$UIHandler;
      //   247: aload 6
      //   249: iload_3
      //   250: invokevirtual 105	com/spb/cities/pick/CitySelectionActivity$UIHandler:postShowNearestCities	([Lcom/spb/cities/nearestcity/NearestCitiesClient$ResponseItem;I)V
      //   253: aload_2
      //   254: ifnull +9 -> 263
      //   257: aload_2
      //   258: invokeinterface 53 1 0
      //   263: aload_0
      //   264: getfield 17	com/spb/cities/pick/CitySelectionActivity$DataHandler:this$0	Lcom/spb/cities/pick/CitySelectionActivity;
      //   267: getfield 36	com/spb/cities/pick/CitySelectionActivity:uiHandler	Lcom/spb/cities/pick/CitySelectionActivity$UIHandler;
      //   270: ifnull -182 -> 88
      //   273: aload_0
      //   274: getfield 17	com/spb/cities/pick/CitySelectionActivity$DataHandler:this$0	Lcom/spb/cities/pick/CitySelectionActivity;
      //   277: getfield 36	com/spb/cities/pick/CitySelectionActivity:uiHandler	Lcom/spb/cities/pick/CitySelectionActivity$UIHandler;
      //   280: invokevirtual 56	com/spb/cities/pick/CitySelectionActivity$UIHandler:postHideProgressDialog	()V
      //   283: goto -195 -> 88
      //   286: astore 16
      //   288: aload_2
      //   289: ifnull +9 -> 298
      //   292: aload_2
      //   293: invokeinterface 53 1 0
      //   298: aload_0
      //   299: getfield 17	com/spb/cities/pick/CitySelectionActivity$DataHandler:this$0	Lcom/spb/cities/pick/CitySelectionActivity;
      //   302: getfield 36	com/spb/cities/pick/CitySelectionActivity:uiHandler	Lcom/spb/cities/pick/CitySelectionActivity$UIHandler;
      //   305: ifnull +13 -> 318
      //   308: aload_0
      //   309: getfield 17	com/spb/cities/pick/CitySelectionActivity$DataHandler:this$0	Lcom/spb/cities/pick/CitySelectionActivity;
      //   312: getfield 36	com/spb/cities/pick/CitySelectionActivity:uiHandler	Lcom/spb/cities/pick/CitySelectionActivity$UIHandler;
      //   315: invokevirtual 56	com/spb/cities/pick/CitySelectionActivity$UIHandler:postHideProgressDialog	()V
      //   318: aload 16
      //   320: athrow
      //   321: astore 17
      //   323: goto -255 -> 68
      //   326: astore 18
      //   328: goto -65 -> 263
      //   331: astore 19
      //   333: goto -35 -> 298
      //
      // Exception table:
      //   from	to	target	type
      //   0	58	286	finally
      //   89	253	286	finally
      //   62	68	321	java/lang/Exception
      //   257	263	326	java/lang/Exception
      //   292	298	331	java/lang/Exception
    }

    private void queryNearestCities(int paramInt)
    {
      Location localLocation = CitySelectionActivity.this.locClient.obtainLocation();
      Logger localLogger1 = CitySelectionActivity.logger;
      String str1 = "obtained location: " + localLocation;
      localLogger1.d(str1);
      if (localLocation == null)
      {
        onQueryNearestCitiesResult(null, null, paramInt);
        return;
      }
      NearestCitiesClient.QueryParams localQueryParams = new NearestCitiesClient.QueryParams(localLocation, paramInt);
      CitySelectionActivity localCitySelectionActivity = CitySelectionActivity.this;
      String str2 = localQueryParams.getLat();
      String str3 = localQueryParams.getLon();
      String str4 = localQueryParams.getLimit();
      Uri localUri = CitiesContract.Cities.buildNearestQueryUri(localCitySelectionActivity, str2, str3, str4);
      Logger localLogger2 = CitySelectionActivity.logger;
      StringBuilder localStringBuilder = new StringBuilder().append("Querying uri=");
      String str5 = localUri.toString();
      String str6 = str5;
      localLogger2.d(str6);
      ContentResolver localContentResolver = CitySelectionActivity.this.getContentResolver();
      String[] arrayOfString1 = CitiesContract.Cities.NEAREST_PROJECTION;
      String[] arrayOfString2 = null;
      String str7 = null;
      Cursor localCursor = localContentResolver.query(localUri, arrayOfString1, null, arrayOfString2, str7);
      if (localCursor == null);
      for (int i = 0; ; i = localCursor.getCount())
      {
        Logger localLogger3 = CitySelectionActivity.logger;
        String str8 = "Nearest cities count: " + i;
        localLogger3.d(str8);
        onQueryNearestCitiesResult(localLocation, localCursor, paramInt);
        break;
      }
    }

    void finish()
    {
    }

    public void handleMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default:
      case 1:
      }
      while (true)
      {
        super.handleMessage(paramMessage);
        return;
        int i = paramMessage.arg1;
        queryNearestCities(i);
      }
    }

    void postQueryNearestCities(int paramInt)
    {
      Message localMessage = Message.obtain(this, 1);
      localMessage.arg1 = paramInt;
      boolean bool = sendMessage(localMessage);
    }
  }

  class OnInputBackKeyListener
    implements SPBAutoCompleteTextView.OnBackKeyListener
  {
    WeakReference<CitySelectionActivity> ref;

    public OnInputBackKeyListener()
    {
      WeakReference localWeakReference = new WeakReference(this$1);
      this.ref = localWeakReference;
    }

    public void onBackKey()
    {
      CitySelectionActivity localCitySelectionActivity = (CitySelectionActivity)this.ref.get();
      if ((localCitySelectionActivity != null) && (!localCitySelectionActivity.isFinishing()))
        localCitySelectionActivity.onInputBackKey();
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.pick.CitySelectionActivity
 * JD-Core Version:    0.6.0
 */