package com.spb.cities.pick;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import com.softspb.util.log.Logger;

class CitySelectionActivity$2
  implements View.OnTouchListener
{
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    Logger localLogger = CitySelectionActivity.access$000();
    StringBuilder localStringBuilder = new StringBuilder().append("onTouch: hasFocus=");
    boolean bool = this.this$0.cityNameInput.hasFocus();
    String str = bool;
    localLogger.d(str);
    if (this.this$0.cityNameInput.hasFocus())
      this.this$0.cityNameInput.showDropDown();
    return false;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.pick.CitySelectionActivity.2
 * JD-Core Version:    0.6.0
 */