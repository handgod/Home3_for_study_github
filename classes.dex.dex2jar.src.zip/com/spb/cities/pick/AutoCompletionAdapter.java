package com.spb.cities.pick;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import com.spb.cities.R.id;
import com.spb.cities.R.layout;

public abstract class AutoCompletionAdapter extends CursorAdapter
  implements Filterable, CursorFilter.CursorFilterClient
{
  protected static final Logger logger = Loggers.getLogger(CitySelectionActivity.class.getName());
  protected ContentResolver mContentResolver;
  protected CursorFilter mCursorFilter;
  protected int threshold;

  public AutoCompletionAdapter(Context paramContext, Cursor paramCursor, int paramInt)
  {
    super(paramContext, paramCursor, 0);
    ContentResolver localContentResolver = paramContext.getContentResolver();
    this.mContentResolver = localContentResolver;
    this.threshold = paramInt;
  }

  protected static String getCountryText(Cursor paramCursor)
  {
    String str1 = null;
    String str2 = null;
    int i = paramCursor.getColumnIndex("country_short_name");
    if (i != -1)
      str1 = paramCursor.getString(i);
    int j = paramCursor.getColumnIndex("state_short_name");
    if (j != -1)
      str2 = paramCursor.getString(j);
    StringBuilder localStringBuilder1 = new StringBuilder();
    if (str1 != null)
    {
      StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
      if (str2 != null)
        StringBuilder localStringBuilder3 = localStringBuilder1.append(" (").append(str2).append(41);
    }
    return localStringBuilder1.toString();
  }

  public void bindView(View paramView, Context paramContext, Cursor paramCursor)
  {
    int i = R.id.weather_city_dropdown_item_name;
    TextView localTextView1 = (TextView)paramView.findViewById(i);
    int j = R.id.weather_city_dropdown_item_country;
    TextView localTextView2 = (TextView)paramView.findViewById(j);
    String str1 = paramCursor.getString(2);
    localTextView1.setText(str1);
    String str2 = getCountryText(paramCursor);
    localTextView2.setText(str2);
  }

  public Filter getFilter()
  {
    if (this.mCursorFilter == null)
    {
      CursorFilter localCursorFilter = new CursorFilter(this);
      this.mCursorFilter = localCursorFilter;
    }
    return this.mCursorFilter;
  }

  protected void logd(String paramString)
  {
    long l = Thread.currentThread().getId();
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str1 = Long.toString(l);
    StringBuilder localStringBuilder2 = localStringBuilder1.append(40);
    int j;
    for (int i = str1.length(); ; i = j)
    {
      j = i + 1;
      if (i >= 4)
        break;
      StringBuilder localStringBuilder3 = localStringBuilder1.append(32);
    }
    StringBuilder localStringBuilder4 = localStringBuilder1.append(str1);
    StringBuilder localStringBuilder5 = localStringBuilder1.append(") ");
    StringBuilder localStringBuilder6 = localStringBuilder1.append(paramString);
    Logger localLogger = logger;
    String str2 = localStringBuilder1.toString();
    localLogger.d(str2);
  }

  public View newView(Context paramContext, Cursor paramCursor, ViewGroup paramViewGroup)
  {
    LayoutInflater localLayoutInflater = LayoutInflater.from(paramContext);
    int i = R.layout.weather_city_dropdown_list_item2;
    View localView = localLayoutInflater.inflate(i, paramViewGroup, 0);
    bindView(localView, paramContext, paramCursor);
    return localView;
  }

  public abstract Cursor runQueryOnBackgroundThread(CharSequence paramCharSequence);
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.pick.AutoCompletionAdapter
 * JD-Core Version:    0.6.0
 */