package com.spb.cities.pick;

class CitySelectionActivity$3
  implements Runnable
{
  public void run()
  {
    this.this$0.cityNameInput.showDropDown();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.pick.CitySelectionActivity.3
 * JD-Core Version:    0.6.0
 */