package com.spb.cities.pick;

import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import com.spb.cities.R.string;
import com.spb.cities.nearestcity.NearestCitiesClient.ResponseItem;
import com.spb.cities.provider.CitiesContract.Cities;

public class NearestAutoCompletionAdapter extends AutoCompletionAdapter
{
  public static final long MORE_CITIES_ID = 2000200200L;
  NearestCitiesClient.ResponseItem[] cities;
  Context context;
  boolean showMoreCities;

  public NearestAutoCompletionAdapter(Context paramContext, NearestCitiesClient.ResponseItem[] paramArrayOfResponseItem, int paramInt, boolean paramBoolean)
  {
    super(paramContext, localMatrixCursor, paramInt);
    this.context = paramContext;
    this.cities = paramArrayOfResponseItem;
    this.showMoreCities = paramBoolean;
  }

  private static MatrixCursor toCursor(Context paramContext, NearestCitiesClient.ResponseItem[] paramArrayOfResponseItem, boolean paramBoolean)
  {
    String[] arrayOfString = CitiesContract.Cities.DEFAULT_PROJECTION;
    MatrixCursor localMatrixCursor = new MatrixCursor(arrayOfString);
    NearestCitiesClient.ResponseItem[] arrayOfResponseItem = paramArrayOfResponseItem;
    int i = arrayOfResponseItem.length;
    int j = 0;
    while (j < i)
    {
      NearestCitiesClient.ResponseItem localResponseItem = arrayOfResponseItem[j];
      Integer localInteger = Integer.valueOf(localResponseItem.getCityId());
      Object[] arrayOfObject1 = new Object[5];
      arrayOfObject1[0] = localInteger;
      arrayOfObject1[1] = localInteger;
      String str1 = localResponseItem.getCityName();
      arrayOfObject1[2] = str1;
      arrayOfObject1[3] = 0;
      arrayOfObject1[4] = 0;
      localMatrixCursor.addRow(arrayOfObject1);
      j += 1;
    }
    if (paramBoolean)
    {
      Object[] arrayOfObject2 = new Object[5];
      Long localLong1 = Long.valueOf(2000200200L);
      arrayOfObject2[0] = localLong1;
      Long localLong2 = Long.valueOf(2000200200L);
      arrayOfObject2[1] = localLong2;
      int k = R.string.weather_more_cities;
      String str2 = paramContext.getString(k);
      arrayOfObject2[2] = str2;
      arrayOfObject2[3] = 0;
      arrayOfObject2[4] = 0;
      localMatrixCursor.addRow(arrayOfObject2);
    }
    return localMatrixCursor;
  }

  public String convertToString(Cursor paramCursor)
  {
    return paramCursor.getString(2);
  }

  public Cursor runQueryOnBackgroundThread(CharSequence paramCharSequence)
  {
    String[] arrayOfString = CitiesContract.Cities.DEFAULT_PROJECTION;
    MatrixCursor localMatrixCursor = new MatrixCursor(arrayOfString);
    String str1 = paramCharSequence.toString().toUpperCase();
    NearestCitiesClient.ResponseItem[] arrayOfResponseItem = this.cities;
    int i = arrayOfResponseItem.length;
    int j = 0;
    while (j < i)
    {
      NearestCitiesClient.ResponseItem localResponseItem = arrayOfResponseItem[j];
      String str2 = localResponseItem.getCityName();
      if (str2.toUpperCase().startsWith(str1))
      {
        Integer localInteger = Integer.valueOf(localResponseItem.getCityId());
        Object[] arrayOfObject1 = new Object[5];
        arrayOfObject1[0] = localInteger;
        arrayOfObject1[1] = localInteger;
        arrayOfObject1[2] = str2;
        arrayOfObject1[3] = 0;
        arrayOfObject1[4] = 0;
        localMatrixCursor.addRow(arrayOfObject1);
      }
      j += 1;
    }
    if (this.showMoreCities)
    {
      Object[] arrayOfObject2 = new Object[5];
      Long localLong1 = Long.valueOf(2000200200L);
      arrayOfObject2[0] = localLong1;
      Long localLong2 = Long.valueOf(2000200200L);
      arrayOfObject2[1] = localLong2;
      Context localContext = this.context;
      int k = R.string.weather_more_cities;
      String str3 = localContext.getString(k);
      arrayOfObject2[2] = str3;
      arrayOfObject2[3] = 0;
      arrayOfObject2[4] = 0;
      localMatrixCursor.addRow(arrayOfObject2);
    }
    return localMatrixCursor;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.pick.NearestAutoCompletionAdapter
 * JD-Core Version:    0.6.0
 */