package com.spb.cities.pick;

import android.view.View;
import android.view.View.OnFocusChangeListener;
import com.softspb.util.log.Logger;

class CitySelectionActivity$1
  implements View.OnFocusChangeListener
{
  public void onFocusChange(View paramView, boolean paramBoolean)
  {
    Logger localLogger = CitySelectionActivity.access$000();
    String str = "onFocusChange: hasFocus=" + paramBoolean + " isShowingDialog";
    localLogger.d(str);
    if ((!CitySelectionActivity.access$100(this.this$0)) && (this.this$0.hasWindowFocus()))
      this.this$0.cityNameInput.showDropDown();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.pick.CitySelectionActivity.1
 * JD-Core Version:    0.6.0
 */