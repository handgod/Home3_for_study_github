package com.spb.cities.service;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.net.Uri;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.os.SystemClock;
import android.text.format.Time;
import com.softspb.updateservice.UpdateService;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import com.spb.cities.location.CurrentLocationPreferences;
import com.spb.cities.provider.CitiesContract.Cities;
import com.spb.cities.provider.CitiesContract.CurrentLocation;

public class CurrentLocationService extends Service
{
  public static final String ACTION_UPDATE = "com.softspb.weather.service.CurrentLocationService.UPDATE";
  private static final long DEFAULT_UPDATE_INTERVAL_MS = 7200000L;
  private static final float LOCATION_THRESHOLD_METERS = 1000.0F;
  public static final String PARAM_FORCE_UPDATE = "location-force-update";
  public static final String PARAM_IS_SCHEDULED = "location-is-scheduled";
  private static final long REGULAR_UPDATES_DELAY_MS = 300000L;
  public static final String TAG_POSITIONING = "Positioning";
  private static Logger logger = Loggers.getLogger(CurrentLocationService.class.getName());
  private Location mLastLocation;
  private int mLastNearestCityId = -2147483648;
  private PowerManager.WakeLock mWakeLock;
  private CurrentLocationPreferences prefs;

  public static void cancelUpdates(Context paramContext)
  {
    logd("GROUPER cancelUpdates");
    Intent localIntent1 = new Intent("com.softspb.weather.service.CurrentLocationService.UPDATE");
    ComponentName localComponentName = new ComponentName(paramContext, CurrentLocationService.class);
    Intent localIntent2 = localIntent1.setComponent(localComponentName);
    PendingIntent localPendingIntent = PendingIntent.getService(paramContext, 0, localIntent1, 268435456);
    ((AlarmManager)paramContext.getSystemService("alarm")).cancel(localPendingIntent);
  }

  private static void logTrace()
  {
    StackTraceElement[] arrayOfStackTraceElement = Thread.currentThread().getStackTrace();
    int i = 3;
    while (true)
    {
      int j = arrayOfStackTraceElement.length;
      if (i >= j)
        break;
      Logger localLogger = logger;
      StringBuilder localStringBuilder = new StringBuilder().append("|   ");
      StackTraceElement localStackTraceElement = arrayOfStackTraceElement[i];
      String str = localStackTraceElement;
      localLogger.d(str);
      i += 1;
    }
  }

  private static void logd(String paramString)
  {
    logger.d(paramString);
  }

  private static void loge(String paramString, Throwable paramThrowable)
  {
    logger.e(paramString, paramThrowable);
  }

  public static void rescheduleUpdates(Context paramContext)
  {
    CurrentLocationPreferences localCurrentLocationPreferences = new CurrentLocationPreferences(paramContext);
    try
    {
      long l = localCurrentLocationPreferences.getUpdateIntervalMs();
      logd("GROUPER rescheduleUpdates: using intervalMs=" + l);
      scheduleUpdates_Int(paramContext, l);
      return;
    }
    finally
    {
      localCurrentLocationPreferences.dispose();
    }
    throw localObject;
  }

  public static void scheduleUpdates(Context paramContext, long paramLong)
  {
    logd("GROUPER scheduleUpdates: intervalMs=" + paramLong);
    scheduleUpdates_Int(paramContext, paramLong);
  }

  private static void scheduleUpdates_Int(Context paramContext, long paramLong)
  {
    Intent localIntent1 = new Intent("com.softspb.weather.service.CurrentLocationService.UPDATE");
    Intent localIntent2 = localIntent1.putExtra("location-is-scheduled", 1);
    ComponentName localComponentName = new ComponentName(paramContext, CurrentLocationService.class);
    Intent localIntent3 = localIntent1.setComponent(localComponentName);
    PendingIntent localPendingIntent = PendingIntent.getService(paramContext, 0, localIntent1, 268435456);
    AlarmManager localAlarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    long l1 = SystemClock.elapsedRealtime() + 300000L;
    long l2 = paramLong;
    localAlarmManager.setInexactRepeating(2, l1, l2, localPendingIntent);
  }

  private void updateCurrentLocationInfo(int paramInt1, int paramInt2)
  {
    logd("updateCurrentLocationInfo: positioningStatus=" + paramInt1 + " cityId=" + paramInt2);
    ContentValues localContentValues = new ContentValues();
    Integer localInteger1 = Integer.valueOf(paramInt1);
    localContentValues.put("positioning_status", localInteger1);
    Integer localInteger2 = Integer.valueOf(paramInt2);
    localContentValues.put("city_id", localInteger2);
    Time localTime = new Time("UTC");
    localTime.setToNow();
    Long localLong = Long.valueOf(localTime.toMillis(0));
    localContentValues.put("last_updated_utc", localLong);
    ContentResolver localContentResolver = getContentResolver();
    Uri localUri1 = CitiesContract.CurrentLocation.getContentUri(getBaseContext());
    Uri localUri2 = localContentResolver.insert(localUri1, localContentValues);
  }

  public static void updateNow(Context paramContext, boolean paramBoolean)
  {
    Logger localLogger = logger;
    String str = "updateNow: forceUpdate=" + paramBoolean;
    localLogger.d(str);
    logTrace();
    Intent localIntent1 = new Intent("com.softspb.weather.service.CurrentLocationService.UPDATE");
    Intent localIntent2 = localIntent1.putExtra("location-force-update", paramBoolean);
    ComponentName localComponentName1 = new ComponentName(paramContext, CurrentLocationService.class);
    Intent localIntent3 = localIntent1.setComponent(localComponentName1);
    ComponentName localComponentName2 = paramContext.startService(localIntent1);
  }

  private void updatePositioningStatus(int paramInt)
  {
    logd("updatePositioningStatus: positioningStatus=" + paramInt);
    ContentValues localContentValues = new ContentValues();
    Integer localInteger = Integer.valueOf(paramInt);
    localContentValues.put("positioning_status", localInteger);
    ContentResolver localContentResolver = getContentResolver();
    Uri localUri = CitiesContract.CurrentLocation.getContentUri(getBaseContext());
    int i = localContentResolver.update(localUri, localContentValues, null, null);
  }

  void doUpdate(boolean paramBoolean, long paramLong)
  {
    UpdateThread localUpdateThread = new UpdateThread(paramBoolean, paramLong);
    this.mWakeLock.acquire();
    localUpdateThread.start();
  }

  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }

  public void onCreate()
  {
    super.onCreate();
    PowerManager localPowerManager = (PowerManager)getSystemService("power");
    String str = getClass().getSimpleName();
    PowerManager.WakeLock localWakeLock = localPowerManager.newWakeLock(1, str);
    this.mWakeLock = localWakeLock;
    CurrentLocationPreferences localCurrentLocationPreferences = new CurrentLocationPreferences(this);
    this.prefs = localCurrentLocationPreferences;
  }

  public void onDestroy()
  {
    super.onDestroy();
    this.prefs.dispose();
  }

  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    int i = 0;
    Logger localLogger1 = logger;
    StringBuilder localStringBuilder = new StringBuilder().append("onStartCommand: intetnt=").append(paramIntent).append(" flags=");
    String str1 = Integer.toHexString(paramInt1);
    String str2 = str1 + " startId=" + paramInt2;
    localLogger1.d(str2);
    String str3;
    if (paramIntent == null)
    {
      str3 = null;
      if (paramIntent != null)
        break label212;
      int j = 0;
      label84: if (paramIntent != null)
        break label225;
      label88: boolean bool3 = this.prefs.isUseOnlyWifi();
      Logger localLogger2 = logger;
      String str4 = "    action=" + str3 + " forceUpdate=" + " isScheduled=" + i + " useOnlyWifi=" + bool3;
      localLogger2.d(str4);
      if ("com.softspb.weather.service.CurrentLocationService.UPDATE".equals(str3))
      {
        Logger localLogger3 = logger;
        if (UpdateService.checkNetworkAvailabilityAndSettings(this, j, bool3, localLogger3))
          break label238;
        logger.d("Update is not allowed, stop.");
        stopSelf();
      }
    }
    while (true)
    {
      return 2;
      str3 = paramIntent.getAction();
      break;
      label212: boolean bool2 = paramIntent.getBooleanExtra("location-force-update", 0);
      break label84;
      label225: boolean bool1 = paramIntent.getBooleanExtra("location-is-scheduled", 0);
      break label88;
      label238: long l = this.prefs.getUpdateIntervalMs();
      doUpdate(bool2, l);
    }
  }

  // ERROR //
  int queryNearestCityId(Location paramLocation)
  {
    // Byte code:
    //   0: new 389	com/spb/cities/nearestcity/NearestCitiesClient$QueryParams
    //   3: dup
    //   4: aload_1
    //   5: iconst_1
    //   6: invokespecial 392	com/spb/cities/nearestcity/NearestCitiesClient$QueryParams:<init>	(Landroid/location/Location;I)V
    //   9: astore_2
    //   10: aload_2
    //   11: ifnonnull +8 -> 19
    //   14: ldc 61
    //   16: istore_3
    //   17: iload_3
    //   18: ireturn
    //   19: aload_0
    //   20: invokevirtual 259	com/spb/cities/service/CurrentLocationService:getBaseContext	()Landroid/content/Context;
    //   23: astore 4
    //   25: aload_2
    //   26: invokevirtual 395	com/spb/cities/nearestcity/NearestCitiesClient$QueryParams:getLat	()Ljava/lang/String;
    //   29: astore 5
    //   31: aload_2
    //   32: invokevirtual 398	com/spb/cities/nearestcity/NearestCitiesClient$QueryParams:getLon	()Ljava/lang/String;
    //   35: astore 6
    //   37: aload_2
    //   38: invokevirtual 401	com/spb/cities/nearestcity/NearestCitiesClient$QueryParams:getLimit	()Ljava/lang/String;
    //   41: astore 7
    //   43: aload 4
    //   45: aload 5
    //   47: aload 6
    //   49: aload 7
    //   51: invokestatic 407	com/spb/cities/provider/CitiesContract$Cities:buildNearestQueryUri	(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;
    //   54: astore 8
    //   56: aload_0
    //   57: invokevirtual 255	com/spb/cities/service/CurrentLocationService:getContentResolver	()Landroid/content/ContentResolver;
    //   60: astore 9
    //   62: getstatic 411	com/spb/cities/provider/CitiesContract$Cities:NEAREST_PROJECTION	[Ljava/lang/String;
    //   65: astore 10
    //   67: aload 9
    //   69: aload 8
    //   71: aload 10
    //   73: aconst_null
    //   74: aconst_null
    //   75: aconst_null
    //   76: invokevirtual 415	android/content/ContentResolver:query	(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   79: astore 11
    //   81: aload 11
    //   83: ifnull +41 -> 124
    //   86: aload 11
    //   88: invokeinterface 420 1 0
    //   93: ifeq +31 -> 124
    //   96: aload 11
    //   98: iconst_1
    //   99: invokeinterface 424 2 0
    //   104: istore 12
    //   106: iload 12
    //   108: istore_3
    //   109: aload 11
    //   111: ifnull -94 -> 17
    //   114: aload 11
    //   116: invokeinterface 427 1 0
    //   121: goto -104 -> 17
    //   124: aload 11
    //   126: ifnull +10 -> 136
    //   129: aload 11
    //   131: invokeinterface 427 1 0
    //   136: ldc 61
    //   138: istore_3
    //   139: goto -122 -> 17
    //   142: astore 13
    //   144: aload 11
    //   146: ifnull -10 -> 136
    //   149: aload 11
    //   151: invokeinterface 427 1 0
    //   156: goto -20 -> 136
    //   159: astore_3
    //   160: aload 11
    //   162: ifnull +10 -> 172
    //   165: aload 11
    //   167: invokeinterface 427 1 0
    //   172: aload_3
    //   173: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   56	106	142	java/lang/Exception
    //   56	106	159	finally
  }

  void releaseLock()
  {
    if ((this.mWakeLock != null) && (this.mWakeLock.isHeld()))
      this.mWakeLock.release();
  }

  boolean updateCurrentLocation(int paramInt)
  {
    ContentValues localContentValues = new ContentValues();
    Integer localInteger = Integer.valueOf(paramInt);
    localContentValues.put("city_id", localInteger);
    try
    {
      Uri localUri1 = CitiesContract.Cities.getContentUri(getBaseContext());
      Uri localUri2 = getContentResolver().insert(localUri1, localContentValues);
      boolean bool1 = localUri1.equals(localUri2);
      bool2 = bool1;
      return bool2;
    }
    catch (Exception localException)
    {
      while (true)
      {
        Logger localLogger = logger;
        String str = "Error while updating current location: " + localException;
        localLogger.d(str, localException);
        boolean bool2 = false;
      }
    }
  }

  class UpdateThread extends Thread
  {
    private final boolean forceUpdate;
    private final long updateIntervalMs;

    UpdateThread(boolean paramLong, long arg3)
    {
      this.forceUpdate = paramLong;
      Object localObject;
      this.updateIntervalMs = localObject;
    }

    // ERROR //
    public void run()
    {
      // Byte code:
      //   0: iconst_2
      //   1: istore_1
      //   2: ldc 29
      //   4: istore_2
      //   5: aconst_null
      //   6: astore_3
      //   7: aload_0
      //   8: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   11: astore 4
      //   13: new 31	com/spb/cities/location/LocationClient
      //   16: dup
      //   17: aload 4
      //   19: invokespecial 34	com/spb/cities/location/LocationClient:<init>	(Landroid/content/Context;)V
      //   22: astore 5
      //   24: aload_0
      //   25: getfield 23	com/spb/cities/service/CurrentLocationService$UpdateThread:forceUpdate	Z
      //   28: ifne +14 -> 42
      //   31: aload_0
      //   32: getfield 25	com/spb/cities/service/CurrentLocationService$UpdateThread:updateIntervalMs	J
      //   35: ldc2_w 35
      //   38: lcmp
      //   39: ifgt +375 -> 414
      //   42: ldc2_w 37
      //   45: lstore 6
      //   47: aload 5
      //   49: lload 6
      //   51: invokevirtual 42	com/spb/cities/location/LocationClient:setExpirationMs	(J)V
      //   54: aload_0
      //   55: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   58: astore 8
      //   60: new 44	com/spb/cities/location/CurrentLocationPreferences
      //   63: dup
      //   64: aload 8
      //   66: invokespecial 45	com/spb/cities/location/CurrentLocationPreferences:<init>	(Landroid/content/Context;)V
      //   69: astore 9
      //   71: aload_0
      //   72: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   75: astore 10
      //   77: aload 9
      //   79: invokevirtual 49	com/spb/cities/location/CurrentLocationPreferences:getLastKnownLocation	()Landroid/location/Location;
      //   82: astore 11
      //   84: aload 10
      //   86: aload 11
      //   88: invokestatic 53	com/spb/cities/service/CurrentLocationService:access$002	(Lcom/spb/cities/service/CurrentLocationService;Landroid/location/Location;)Landroid/location/Location;
      //   91: astore 12
      //   93: aload_0
      //   94: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   97: astore 13
      //   99: aload 9
      //   101: invokevirtual 57	com/spb/cities/location/CurrentLocationPreferences:getLastKnownNearestCityId	()I
      //   104: istore 14
      //   106: aload 13
      //   108: iload 14
      //   110: invokestatic 61	com/spb/cities/service/CurrentLocationService:access$102	(Lcom/spb/cities/service/CurrentLocationService;I)I
      //   113: istore 15
      //   115: aload_0
      //   116: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   119: iconst_3
      //   120: invokestatic 65	com/spb/cities/service/CurrentLocationService:access$200	(Lcom/spb/cities/service/CurrentLocationService;I)V
      //   123: ldc 67
      //   125: invokestatic 71	com/spb/cities/service/CurrentLocationService:access$300	(Ljava/lang/String;)V
      //   128: new 73	java/lang/StringBuilder
      //   131: dup
      //   132: invokespecial 74	java/lang/StringBuilder:<init>	()V
      //   135: ldc 76
      //   137: invokevirtual 80	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   140: astore 16
      //   142: aload_0
      //   143: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   146: invokestatic 84	com/spb/cities/service/CurrentLocationService:access$000	(Lcom/spb/cities/service/CurrentLocationService;)Landroid/location/Location;
      //   149: astore 17
      //   151: aload 16
      //   153: aload 17
      //   155: invokevirtual 87	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   158: invokevirtual 91	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   161: invokestatic 71	com/spb/cities/service/CurrentLocationService:access$300	(Ljava/lang/String;)V
      //   164: new 73	java/lang/StringBuilder
      //   167: dup
      //   168: invokespecial 74	java/lang/StringBuilder:<init>	()V
      //   171: ldc 93
      //   173: invokevirtual 80	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   176: astore 18
      //   178: aload_0
      //   179: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   182: invokestatic 97	com/spb/cities/service/CurrentLocationService:access$100	(Lcom/spb/cities/service/CurrentLocationService;)I
      //   185: istore 19
      //   187: aload 18
      //   189: iload 19
      //   191: invokevirtual 100	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
      //   194: invokevirtual 91	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   197: invokestatic 71	com/spb/cities/service/CurrentLocationService:access$300	(Ljava/lang/String;)V
      //   200: aload 5
      //   202: invokevirtual 103	com/spb/cities/location/LocationClient:obtainLocation	()Landroid/location/Location;
      //   205: astore 20
      //   207: new 73	java/lang/StringBuilder
      //   210: dup
      //   211: invokespecial 74	java/lang/StringBuilder:<init>	()V
      //   214: ldc 105
      //   216: invokevirtual 80	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   219: aload 20
      //   221: invokevirtual 87	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   224: invokevirtual 91	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   227: invokestatic 71	com/spb/cities/service/CurrentLocationService:access$300	(Ljava/lang/String;)V
      //   230: aload 20
      //   232: ifnull +377 -> 609
      //   235: aload_0
      //   236: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   239: invokestatic 84	com/spb/cities/service/CurrentLocationService:access$000	(Lcom/spb/cities/service/CurrentLocationService;)Landroid/location/Location;
      //   242: ifnonnull +185 -> 427
      //   245: ldc 106
      //   247: fstore 21
      //   249: new 73	java/lang/StringBuilder
      //   252: dup
      //   253: invokespecial 74	java/lang/StringBuilder:<init>	()V
      //   256: ldc 108
      //   258: invokevirtual 80	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   261: fload 21
      //   263: invokevirtual 111	java/lang/StringBuilder:append	(F)Ljava/lang/StringBuilder;
      //   266: ldc 113
      //   268: invokevirtual 80	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   271: invokevirtual 91	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   274: invokestatic 71	com/spb/cities/service/CurrentLocationService:access$300	(Ljava/lang/String;)V
      //   277: aload_0
      //   278: getfield 23	com/spb/cities/service/CurrentLocationService$UpdateThread:forceUpdate	Z
      //   281: ifne +33 -> 314
      //   284: aload_0
      //   285: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   288: invokestatic 84	com/spb/cities/service/CurrentLocationService:access$000	(Lcom/spb/cities/service/CurrentLocationService;)Landroid/location/Location;
      //   291: ifnull +23 -> 314
      //   294: fload 21
      //   296: ldc 114
      //   298: fcmpl
      //   299: ifgt +15 -> 314
      //   302: aload_0
      //   303: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   306: invokestatic 97	com/spb/cities/service/CurrentLocationService:access$100	(Lcom/spb/cities/service/CurrentLocationService;)I
      //   309: ldc 29
      //   311: if_icmpne +234 -> 545
      //   314: ldc 116
      //   316: invokestatic 71	com/spb/cities/service/CurrentLocationService:access$300	(Ljava/lang/String;)V
      //   319: aload_0
      //   320: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   323: aload 20
      //   325: invokevirtual 120	com/spb/cities/service/CurrentLocationService:queryNearestCityId	(Landroid/location/Location;)I
      //   328: istore_2
      //   329: new 73	java/lang/StringBuilder
      //   332: dup
      //   333: invokespecial 74	java/lang/StringBuilder:<init>	()V
      //   336: ldc 122
      //   338: invokevirtual 80	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   341: iload_2
      //   342: invokevirtual 100	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
      //   345: invokevirtual 91	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   348: invokestatic 71	com/spb/cities/service/CurrentLocationService:access$300	(Ljava/lang/String;)V
      //   351: iload_2
      //   352: ldc 29
      //   354: if_icmpne +94 -> 448
      //   357: iconst_5
      //   358: istore_1
      //   359: ldc 124
      //   361: invokestatic 71	com/spb/cities/service/CurrentLocationService:access$300	(Ljava/lang/String;)V
      //   364: ldc 126
      //   366: invokestatic 71	com/spb/cities/service/CurrentLocationService:access$300	(Ljava/lang/String;)V
      //   369: iload_1
      //   370: ifeq +249 -> 619
      //   373: aload_0
      //   374: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   377: iload_1
      //   378: invokestatic 65	com/spb/cities/service/CurrentLocationService:access$200	(Lcom/spb/cities/service/CurrentLocationService;I)V
      //   381: aload 9
      //   383: ifnull +8 -> 391
      //   386: aload 9
      //   388: invokevirtual 129	com/spb/cities/location/CurrentLocationPreferences:dispose	()V
      //   391: aload_0
      //   392: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   395: invokevirtual 132	com/spb/cities/service/CurrentLocationService:releaseLock	()V
      //   398: aload_0
      //   399: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   402: invokevirtual 135	com/spb/cities/service/CurrentLocationService:stopSelf	()V
      //   405: aload 9
      //   407: astore 22
      //   409: aload 5
      //   411: astore 23
      //   413: return
      //   414: aload_0
      //   415: getfield 25	com/spb/cities/service/CurrentLocationService$UpdateThread:updateIntervalMs	J
      //   418: ldc2_w 136
      //   421: ldiv
      //   422: lstore 6
      //   424: goto -377 -> 47
      //   427: aload_0
      //   428: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   431: invokestatic 84	com/spb/cities/service/CurrentLocationService:access$000	(Lcom/spb/cities/service/CurrentLocationService;)Landroid/location/Location;
      //   434: astore 24
      //   436: aload 20
      //   438: aload 24
      //   440: invokevirtual 143	android/location/Location:distanceTo	(Landroid/location/Location;)F
      //   443: fstore 21
      //   445: goto -196 -> 249
      //   448: iconst_0
      //   449: istore_1
      //   450: aload 9
      //   452: aload 20
      //   454: iload_2
      //   455: invokevirtual 147	com/spb/cities/location/CurrentLocationPreferences:setLastKnownLocation	(Landroid/location/Location;I)V
      //   458: goto -94 -> 364
      //   461: astore 25
      //   463: aload 9
      //   465: astore_3
      //   466: aload 5
      //   468: astore 26
      //   470: invokestatic 151	com/spb/cities/service/CurrentLocationService:access$400	()Lcom/softspb/util/log/Logger;
      //   473: astore 27
      //   475: new 73	java/lang/StringBuilder
      //   478: dup
      //   479: invokespecial 74	java/lang/StringBuilder:<init>	()V
      //   482: ldc 153
      //   484: invokevirtual 80	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   487: aload 25
      //   489: invokevirtual 87	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   492: invokevirtual 91	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   495: astore 28
      //   497: aload 27
      //   499: aload 28
      //   501: aload 25
      //   503: invokevirtual 159	com/softspb/util/log/Logger:e	(Ljava/lang/String;Ljava/lang/Throwable;)V
      //   506: iconst_1
      //   507: istore_1
      //   508: iload_1
      //   509: ifeq +122 -> 631
      //   512: aload_0
      //   513: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   516: iload_1
      //   517: invokestatic 65	com/spb/cities/service/CurrentLocationService:access$200	(Lcom/spb/cities/service/CurrentLocationService;I)V
      //   520: aload_3
      //   521: ifnull +7 -> 528
      //   524: aload_3
      //   525: invokevirtual 129	com/spb/cities/location/CurrentLocationPreferences:dispose	()V
      //   528: aload_0
      //   529: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   532: invokevirtual 132	com/spb/cities/service/CurrentLocationService:releaseLock	()V
      //   535: aload_0
      //   536: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   539: invokevirtual 135	com/spb/cities/service/CurrentLocationService:stopSelf	()V
      //   542: goto -129 -> 413
      //   545: iconst_0
      //   546: istore_1
      //   547: aload_0
      //   548: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   551: invokestatic 97	com/spb/cities/service/CurrentLocationService:access$100	(Lcom/spb/cities/service/CurrentLocationService;)I
      //   554: istore_2
      //   555: ldc 161
      //   557: invokestatic 71	com/spb/cities/service/CurrentLocationService:access$300	(Ljava/lang/String;)V
      //   560: goto -196 -> 364
      //   563: astore 29
      //   565: aload 9
      //   567: astore_3
      //   568: aload 5
      //   570: astore 30
      //   572: iload_1
      //   573: ifeq +70 -> 643
      //   576: aload_0
      //   577: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   580: iload_1
      //   581: invokestatic 65	com/spb/cities/service/CurrentLocationService:access$200	(Lcom/spb/cities/service/CurrentLocationService;I)V
      //   584: aload_3
      //   585: ifnull +7 -> 592
      //   588: aload_3
      //   589: invokevirtual 129	com/spb/cities/location/CurrentLocationPreferences:dispose	()V
      //   592: aload_0
      //   593: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   596: invokevirtual 132	com/spb/cities/service/CurrentLocationService:releaseLock	()V
      //   599: aload_0
      //   600: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   603: invokevirtual 135	com/spb/cities/service/CurrentLocationService:stopSelf	()V
      //   606: aload 29
      //   608: athrow
      //   609: ldc 163
      //   611: invokestatic 71	com/spb/cities/service/CurrentLocationService:access$300	(Ljava/lang/String;)V
      //   614: iconst_4
      //   615: istore_1
      //   616: goto -252 -> 364
      //   619: aload_0
      //   620: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   623: iload_1
      //   624: iload_2
      //   625: invokestatic 167	com/spb/cities/service/CurrentLocationService:access$500	(Lcom/spb/cities/service/CurrentLocationService;II)V
      //   628: goto -247 -> 381
      //   631: aload_0
      //   632: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   635: iload_1
      //   636: iload_2
      //   637: invokestatic 167	com/spb/cities/service/CurrentLocationService:access$500	(Lcom/spb/cities/service/CurrentLocationService;II)V
      //   640: goto -120 -> 520
      //   643: aload_0
      //   644: getfield 18	com/spb/cities/service/CurrentLocationService$UpdateThread:this$0	Lcom/spb/cities/service/CurrentLocationService;
      //   647: iload_1
      //   648: iload_2
      //   649: invokestatic 167	com/spb/cities/service/CurrentLocationService:access$500	(Lcom/spb/cities/service/CurrentLocationService;II)V
      //   652: goto -68 -> 584
      //   655: astore 29
      //   657: goto -85 -> 572
      //   660: astore 29
      //   662: aload 5
      //   664: astore 31
      //   666: goto -94 -> 572
      //   669: astore 25
      //   671: goto -201 -> 470
      //   674: astore 25
      //   676: aload 5
      //   678: astore 32
      //   680: goto -210 -> 470
      //
      // Exception table:
      //   from	to	target	type
      //   71	369	461	java/lang/Exception
      //   427	458	461	java/lang/Exception
      //   547	560	461	java/lang/Exception
      //   609	614	461	java/lang/Exception
      //   71	369	563	finally
      //   427	458	563	finally
      //   547	560	563	finally
      //   609	614	563	finally
      //   7	24	655	finally
      //   470	506	655	finally
      //   24	71	660	finally
      //   414	424	660	finally
      //   7	24	669	java/lang/Exception
      //   24	71	674	java/lang/Exception
      //   414	424	674	java/lang/Exception
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.service.CurrentLocationService
 * JD-Core Version:    0.6.0
 */