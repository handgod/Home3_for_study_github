package com.spb.cities.service;

import android.app.Application;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.database.ContentObserver;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import android.text.format.Time;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import com.spb.cities.CurrentLocationInfo;
import com.spb.cities.location.CurrentLocationPreferences;
import com.spb.cities.provider.CitiesContract.CurrentLocation;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;

public class CurrentLocationClient
  implements SharedPreferences.OnSharedPreferenceChangeListener
{
  static int instanceCount = 0;
  private final Application application;
  private final ContentResolver contentResolver;
  private int currentLocationCityId;
  private final ArrayList<CurrentLocationListener> currentLocationListeners;
  private CurrentLocationObserver currentLocationObserver;
  private CurrentLocationPreferences currentLocationPreferences;
  private DataHandler dataHandler;
  int instanceNo;
  Logger logger;

  public CurrentLocationClient(Application paramApplication)
  {
    ArrayList localArrayList = new ArrayList();
    this.currentLocationListeners = localArrayList;
    this.currentLocationCityId = -2147483648;
    monitorenter;
    try
    {
      int i = instanceCount + 1;
      instanceCount = i;
      this.instanceNo = i;
      monitorexit;
      Logger localLogger = Loggers.getLogger(CurrentLocationClient.class);
      this.logger = localLogger;
      logd("Ctor >>>");
      this.application = paramApplication;
      ContentResolver localContentResolver = paramApplication.getContentResolver();
      this.contentResolver = localContentResolver;
      CurrentLocationPreferences localCurrentLocationPreferences = new CurrentLocationPreferences(paramApplication);
      this.currentLocationPreferences = localCurrentLocationPreferences;
      this.currentLocationPreferences.registerOnSharedPreferenceChangeListener(this);
      HandlerThread localHandlerThread = new HandlerThread("CurrentLocationClient.Data");
      localHandlerThread.start();
      Looper localLooper = localHandlerThread.getLooper();
      DataHandler localDataHandler = new DataHandler(localLooper);
      this.dataHandler = localDataHandler;
      logd("Ctor <<<");
      return;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public static CurrentLocationClient getInstance(Context paramContext)
  {
    Context localContext = paramContext.getApplicationContext();
    if (!(localContext instanceof Application))
    {
      String str = "Application context is not an Application instance: " + localContext;
      throw new IllegalArgumentException(str);
    }
    Application localApplication = (Application)localContext;
    Class localClass = localApplication.getClass();
    try
    {
      Class[] arrayOfClass = new Class[0];
      Method localMethod = localClass.getMethod("getCurrentLocationClient", arrayOfClass);
      Object[] arrayOfObject = new Object[0];
      CurrentLocationClient localCurrentLocationClient = (CurrentLocationClient)localMethod.invoke(localApplication, arrayOfObject);
      return localCurrentLocationClient;
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      throw new IllegalArgumentException("Application class must define getCurrentLocationClient() method", localNoSuchMethodException);
    }
    catch (Exception localException)
    {
    }
    throw new IllegalArgumentException("Failed to invoke getCurrentLocationClient() method", localException);
  }

  private static boolean isNetworkLocationProviderEnabled(Context paramContext)
  {
    LocationManager localLocationManager = (LocationManager)paramContext.getSystemService("location");
    if ((localLocationManager != null) && (localLocationManager.isProviderEnabled("network")));
    for (int i = 1; ; i = 0)
      return i;
  }

  private void logd(String paramString)
  {
    Logger localLogger = this.logger;
    String str = prepareMessage(paramString);
    localLogger.d(str);
  }

  private void loge(String paramString, Throwable paramThrowable)
  {
    Logger localLogger = this.logger;
    String str = prepareMessage(paramString);
    localLogger.e(str, paramThrowable);
  }

  private void onUpdateRateChanged()
  {
    if (hasListeners())
    {
      long l1 = this.currentLocationPreferences.getUpdateIntervalMs();
      StringBuilder localStringBuilder = new StringBuilder().append("onUpdateRateChanged: new interval: ");
      long l2 = l1 / 1000L / 60L;
      String str = l2 + " min";
      logd(str);
      reschedultUpdates(l1);
    }
    while (true)
    {
      return;
      logd("onUpdateRateChanged: no registered listeners");
    }
  }

  private String prepareMessage(String paramString)
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append(91);
    int i = Process.myPid();
    StringBuilder localStringBuilder2 = localStringBuilder1.append(i).append(58);
    String str = Thread.currentThread().getName();
    StringBuilder localStringBuilder3 = localStringBuilder2.append(str).append(44);
    long l = Thread.currentThread().getId();
    StringBuilder localStringBuilder4 = localStringBuilder3.append(l).append(58);
    int j = this.instanceNo;
    return j + "] " + paramString;
  }

  private boolean updateIntervalElapsed(CurrentLocationInfo paramCurrentLocationInfo)
  {
    Time localTime = new Time("UTC");
    localTime.setToNow();
    long l1 = localTime.toMillis(0);
    long l2 = this.currentLocationPreferences.getUpdateIntervalMs();
    long l3 = paramCurrentLocationInfo.getLastUpdatedMsUtc();
    String str1 = "considerUpdateCurrentLocation: latestSuccessfullTimestamp=" + l3;
    logd(str1);
    long l4 = l1 - l3;
    String str2 = "considerUpdateCurrentLocation: currentMillis=" + l1;
    logd(str2);
    String str3 = "considerUpdateCurrentLocation: lastUpdated=" + l3;
    logd(str3);
    String str4 = "considerUpdateCurrentLocation: updateInterval=" + l2;
    logd(str4);
    String str5 = "considerUpdateCurrentLocation: updateDelay=" + l1;
    logd(str5);
    StringBuilder localStringBuilder1 = new StringBuilder().append("considerUpdateCurrentLocation: update ");
    long l5 = l4 / 60000L;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(l5).append(" min ago, update interval ");
    long l6 = l2 / 60000L;
    String str6 = l6 + " min";
    logd(str6);
    if (l4 >= l2);
    for (int i = 1; ; i = 0)
      return i;
  }

  public void considerUpdateCurrentLocation(boolean paramBoolean)
  {
    String str1 = "considerUpdateCurrentLocation >>> networkConnectedEvent=" + paramBoolean;
    logd(str1);
    if (!hasListeners())
    {
      this.logger.d("considerUpdateCurrentLocation <<< no registered listeners, not updating");
      return;
    }
    Application localApplication = this.application;
    ContentResolver localContentResolver = this.contentResolver;
    CurrentLocationInfo localCurrentLocationInfo = CitiesContract.CurrentLocation.queryCurrentLocationInfo(localApplication, localContentResolver);
    int i = 0;
    int k = localCurrentLocationInfo.getPositioningStatus();
    if (localCurrentLocationInfo == null)
    {
      logd("considerUpdateCurrentLocation: no update status for current location");
      i = 1;
    }
    while (true)
    {
      String str2 = "considerUpdateCurrentLocation <<< need update: " + i;
      logd(str2);
      if (i == 0)
        break;
      CurrentLocationService.updateNow(this.application, 0);
      break;
      if (!updateIntervalElapsed(localCurrentLocationInfo))
      {
        logd("considerUpdateCurrentLocation: update interval has not yet elapsed.");
        continue;
      }
      int j;
      if (k == 0)
      {
        logd("considerUpdateCurrentLocation: update interval has elapsed.");
        logd("considerUpdateCurrentLocation: previous update was successful.");
        j = 1;
        continue;
      }
      if (!paramBoolean)
      {
        logd("considerUpdateCurrentLocation: update interval has elapsed.");
        logd("considerUpdateCurrentLocation: previous update was unsuccessful.");
        logd("considerUpdateCurrentLocation: it's not a network event");
        j = 1;
        continue;
      }
      if ((k == 5) || ((k == 4) && (isNetworkLocationProviderEnabled(this.application))))
      {
        logd("considerUpdateCurrentLocation: update interval has elapsed.");
        logd("considerUpdateCurrentLocation: previous update was unsuccessful.");
        logd("considerUpdateCurrentLocation: it's a network event");
        logd("considerUpdateCurrentLocation: previous failure was due to network");
        j = 1;
        continue;
      }
      logd("considerUpdateCurrentLocation: update interval has elapsed.");
      logd("considerUpdateCurrentLocation: previous update was unsuccessful.");
      logd("considerUpdateCurrentLocation: it's a network event");
      logd("considerUpdateCurrentLocation: previous failure was NOT due to network");
    }
  }

  public void dispose()
  {
    logd("dispose >>>");
    this.currentLocationPreferences.dispose();
    if (this.dataHandler != null)
    {
      this.dataHandler.getLooper().quit();
      this.dataHandler = null;
    }
    logd("dispose <<<");
  }

  public int getCurrentLocationCityId()
  {
    return this.currentLocationCityId;
  }

  boolean hasListeners()
  {
    synchronized (this.currentLocationListeners)
    {
      if (!this.currentLocationListeners.isEmpty())
      {
        i = 1;
        return i;
      }
      int i = 0;
    }
  }

  void notifyCurrentLocationCityIdUpdated(int paramInt)
  {
    String str1 = "notifyCurrentLocationCityIdUpdated >>> cityId=" + paramInt;
    logd(str1);
    synchronized (this.currentLocationListeners)
    {
      Iterator localIterator = this.currentLocationListeners.iterator();
      if (localIterator.hasNext())
        ((CurrentLocationListener)localIterator.next()).onCurrenLocationCityIdUpdated(paramInt);
    }
    monitorexit;
    String str2 = "notifyCurrentLocationCityIdUpdated >>> cityId=" + paramInt;
    logd(str2);
  }

  public void onSharedPreferenceChanged(SharedPreferences paramSharedPreferences, String paramString)
  {
    if ("update-interval".equals(paramString))
      onUpdateRateChanged();
  }

  public void postUpdateCurrentLocation()
  {
    if (this.dataHandler != null)
      this.dataHandler.postUpdateCurrentLocation();
  }

  public void registerCurrentLocationListener(CurrentLocationListener paramCurrentLocationListener)
  {
    registerCurrentLocationListener(paramCurrentLocationListener, 1);
  }

  public void registerCurrentLocationListener(CurrentLocationListener paramCurrentLocationListener, boolean paramBoolean)
  {
    Object localObject1 = null;
    String str1 = "GROUPER registerCurrentLocationListener >>> l=" + paramCurrentLocationListener;
    logd(str1);
    while (true)
    {
      synchronized (this.currentLocationListeners)
      {
        if (this.currentLocationListeners.size() != 0)
          continue;
        int i = 1;
        if (this.currentLocationListeners.contains(paramCurrentLocationListener))
          continue;
        boolean bool = this.currentLocationListeners.add(paramCurrentLocationListener);
        if (this.currentLocationListeners.size() != 1)
          continue;
        if ((i & localObject1) == 0)
          continue;
        startObservingCurrentLocation();
        int j = this.currentLocationListeners.size();
        if (!paramBoolean)
          continue;
        if (this.currentLocationCityId != -2147483648)
        {
          int k = this.currentLocationCityId;
          notifyCurrentLocationCityIdUpdated(k);
          String str2 = "GROUPER registerCurrentLocationListener <<< count=" + j + " l=" + paramCurrentLocationListener;
          logd(str2);
          return;
          i = 0;
          continue;
          localObject1 = null;
        }
      }
      this.dataHandler.postUpdateCurrentLocation();
    }
  }

  public void reschedultUpdates(long paramLong)
  {
    if (this.dataHandler != null)
    {
      DataHandler localDataHandler = this.dataHandler;
      Long localLong = Long.valueOf(paramLong);
      localDataHandler.postScheduleUpdates(localLong);
    }
  }

  void startObservingCurrentLocation()
  {
    this.logger.d("GROUPER startObservingCurrentLocation:");
    if (this.currentLocationObserver == null)
    {
      DataHandler localDataHandler = this.dataHandler;
      CurrentLocationObserver localCurrentLocationObserver = new CurrentLocationObserver(localDataHandler);
      this.currentLocationObserver = localCurrentLocationObserver;
      CurrentLocationService.updateNow(this.application, 0);
      CurrentLocationService.rescheduleUpdates(this.application);
      this.dataHandler.postUpdateCurrentLocation();
    }
  }

  void stopObservingCurrentLocation()
  {
    this.logger.d("GROUPER stopObservingCurrentLocation:");
    if (this.currentLocationObserver != null)
    {
      ContentResolver localContentResolver = this.contentResolver;
      CurrentLocationObserver localCurrentLocationObserver = this.currentLocationObserver;
      localContentResolver.unregisterContentObserver(localCurrentLocationObserver);
      this.currentLocationObserver = null;
      CurrentLocationService.cancelUpdates(this.application);
    }
  }

  public void unregisterCurrentLocationListener(CurrentLocationListener paramCurrentLocationListener)
  {
    Object localObject1 = null;
    String str1 = "GROUPER unregisterCurrentLocationListener >>> l=" + paramCurrentLocationListener;
    logd(str1);
    synchronized (this.currentLocationListeners)
    {
      if (this.currentLocationListeners.size() == 1);
      for (int i = 1; ; i = 0)
      {
        boolean bool = this.currentLocationListeners.remove(paramCurrentLocationListener);
        if (this.currentLocationListeners.size() != 0)
          break;
        if ((i & localObject1) != 0)
          stopObservingCurrentLocation();
        int j = this.currentLocationListeners.size();
        String str2 = "GROUPER unregisterCurrentLocationListener <<< count=" + j + " l=" + paramCurrentLocationListener;
        logd(str2);
        return;
      }
      localObject1 = null;
    }
  }

  class CurrentLocationObserver extends ContentObserver
  {
    public CurrentLocationObserver(Handler arg2)
    {
      super();
      Uri localUri = CitiesContract.CurrentLocation.getContentUri(CurrentLocationClient.this.application);
      String str = "Registering content observer for URI: " + localUri;
      CurrentLocationClient.this.logd(str);
      CurrentLocationClient.this.contentResolver.registerContentObserver(localUri, 1, this);
    }

    public void onChange(boolean paramBoolean)
    {
      CurrentLocationClient localCurrentLocationClient1 = CurrentLocationClient.this;
      StringBuilder localStringBuilder1 = new StringBuilder().append("CurrentLocationObserver.onChange: uri=");
      Uri localUri = CitiesContract.CurrentLocation.getContentUri(CurrentLocationClient.this.application);
      String str1 = localUri;
      localCurrentLocationClient1.logd(str1);
      Application localApplication = CurrentLocationClient.this.application;
      ContentResolver localContentResolver = CurrentLocationClient.this.contentResolver;
      int i = CitiesContract.CurrentLocation.queryCurrentLocationInfo(localApplication, localContentResolver).getCityId();
      CurrentLocationClient localCurrentLocationClient2 = CurrentLocationClient.this;
      String str2 = "CurrentLocationObserver.onChange: new currrent location cityId=" + i;
      localCurrentLocationClient2.logd(str2);
      if (i == -2147483648)
      {
        CurrentLocationClient localCurrentLocationClient3 = CurrentLocationClient.this;
        StringBuilder localStringBuilder2 = new StringBuilder().append("CurrentLocationObserver.onChange: new current location uknown, keep using last known value: cityId=");
        int j = CurrentLocationClient.this.currentLocationCityId;
        String str3 = j;
        localCurrentLocationClient3.logd(str3);
      }
      while (true)
      {
        return;
        if (i > 0)
        {
          int k = CurrentLocationClient.this.currentLocationCityId;
          if (i == k)
            continue;
          int m = CurrentLocationClient.access$402(CurrentLocationClient.this, i);
          CurrentLocationClient.this.notifyCurrentLocationCityIdUpdated(i);
          continue;
        }
      }
    }
  }

  class DataHandler extends Handler
  {
    private static final int MSG_SCHEDULE_UPDATES = 2;
    private static final int MSG_UPDATE_CURRENT_LOCATION = 1;

    public DataHandler(Looper arg2)
    {
      super();
    }

    private void scheduleUpdates(Long paramLong)
    {
      Application localApplication = CurrentLocationClient.this.application;
      long l = paramLong.longValue();
      CurrentLocationService.scheduleUpdates(localApplication, l);
    }

    private void updateCurrentLocation()
    {
      if (CurrentLocationClient.this.currentLocationObserver != null)
        CurrentLocationClient.this.currentLocationObserver.onChange(0);
    }

    public void handleMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default:
      case 1:
      case 2:
      }
      while (true)
      {
        return;
        updateCurrentLocation();
        continue;
        Long localLong = (Long)paramMessage.obj;
        scheduleUpdates(localLong);
      }
    }

    void postScheduleUpdates(Long paramLong)
    {
      Message localMessage = Message.obtain(this, 2, paramLong);
      boolean bool = sendMessage(localMessage);
    }

    void postUpdateCurrentLocation()
    {
      Message localMessage = Message.obtain(this, 1);
      boolean bool = sendMessage(localMessage);
    }
  }

  public abstract interface CurrentLocationListener
  {
    public abstract void onCurrenLocationCityIdUpdated(int paramInt);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.service.CurrentLocationClient
 * JD-Core Version:    0.6.0
 */