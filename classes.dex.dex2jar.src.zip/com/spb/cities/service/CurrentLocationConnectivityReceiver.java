package com.spb.cities.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.NetworkInfo;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import com.spb.cities.location.CurrentLocationPreferences;

public class CurrentLocationConnectivityReceiver extends BroadcastReceiver
{
  private static Logger logger = Loggers.getLogger(CurrentLocationConnectivityReceiver.class);

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    logger.d("onReceive >>>");
    CurrentLocationClient localCurrentLocationClient = CurrentLocationClient.getInstance(paramContext);
    if (!localCurrentLocationClient.hasListeners())
      logger.d("onReceive <<< no registered current location listeners");
    while (true)
    {
      return;
      CurrentLocationPreferences localCurrentLocationPreferences = new CurrentLocationPreferences(paramContext);
      try
      {
        NetworkInfo localNetworkInfo = (NetworkInfo)paramIntent.getParcelableExtra("networkInfo");
        if ((localNetworkInfo.isAvailable()) && ((localNetworkInfo.getType() == 1) || (!localCurrentLocationPreferences.isUseOnlyWifi())))
          localCurrentLocationClient.considerUpdateCurrentLocation(1);
        localCurrentLocationPreferences.dispose();
      }
      finally
      {
        localCurrentLocationPreferences.dispose();
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.service.CurrentLocationConnectivityReceiver
 * JD-Core Version:    0.6.0
 */