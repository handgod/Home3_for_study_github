package com.spb.cities.nearestcity;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;

class DownloadClient$1 extends Thread
{
  public void run()
  {
    Object[] arrayOfObject = this.val$res;
    DownloadClient localDownloadClient = this.this$0;
    HttpClient localHttpClient = this.val$httpClient;
    HttpGet localHttpGet = this.val$req;
    Object localObject1 = this.val$param;
    Object localObject2 = DownloadClient.access$000(localDownloadClient, localHttpClient, localHttpGet, localObject1);
    arrayOfObject[0] = localObject2;
    synchronized (DownloadClient.access$100(this.this$0))
    {
      DownloadClient.access$100(this.this$0).notify();
      return;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.nearestcity.DownloadClient.1
 * JD-Core Version:    0.6.0
 */