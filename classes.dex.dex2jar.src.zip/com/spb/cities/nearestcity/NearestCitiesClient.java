package com.spb.cities.nearestcity;

import android.content.Context;
import android.location.Location;
import com.softspb.util.log.Logger;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import org.apache.http.client.HttpClient;

public class NearestCitiesClient extends DownloadClient
{
  private static final String[] NEAREST_CITIES_SERVER_URLS;
  private String clientToken;

  static
  {
    String[] arrayOfString = new String[1];
    arrayOfString[0] = "http://weather.trv.softspb.com/current_conditions/get_nearest_cities.php";
    NEAREST_CITIES_SERVER_URLS = arrayOfString;
  }

  public NearestCitiesClient(Context paramContext, HttpClient paramHttpClient)
  {
    super(arrayOfString);
    String str = ClientToken.getInstance(paramContext).getToken();
    this.clientToken = str;
  }

  protected String createUrl(String paramString, Object paramObject)
  {
    QueryParams localQueryParams = (QueryParams)paramObject;
    StringBuilder localStringBuilder1 = new StringBuilder().append(paramString).append("?lat=");
    String str1 = localQueryParams.lat;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1).append("&lon=");
    String str2 = localQueryParams.lon;
    StringBuilder localStringBuilder3 = localStringBuilder2.append(str2).append("&count=");
    String str3 = localQueryParams.limit;
    StringBuilder localStringBuilder4 = localStringBuilder3.append(str3).append(38).append("client_token").append(61);
    String str4 = this.clientToken;
    return str4;
  }

  protected Object parseResponse(InputStream paramInputStream, Object paramObject)
    throws Exception
  {
    this.logger.d("parseResponse");
    InputStreamReader localInputStreamReader = new InputStreamReader(paramInputStream);
    BufferedReader localBufferedReader = new BufferedReader(localInputStreamReader);
    ArrayList localArrayList = new ArrayList();
    while (true)
    {
      String str1 = localBufferedReader.readLine();
      if (str1 == null)
        break;
      Logger localLogger1 = this.logger;
      String str2 = "Received line: " + str1;
      localLogger1.d(str2);
      int i = str1.indexOf(',');
      int j = Integer.parseInt(str1.substring(0, i));
      int k = i + 1;
      String str3 = str1.substring(k).trim();
      Logger localLogger2 = this.logger;
      String str4 = "Adding response item: cityId=" + j + " cityName=" + str3;
      localLogger2.d(str4);
      ResponseItem localResponseItem = new ResponseItem(str3);
      boolean bool = localArrayList.add(localResponseItem);
    }
    return localArrayList;
  }

  public class ResponseItem
  {
    int cityId;
    String cityName;

    public ResponseItem(String arg2)
    {
      this.cityId = this$1;
      Object localObject;
      this.cityName = localObject;
    }

    public int getCityId()
    {
      return this.cityId;
    }

    public String getCityName()
    {
      return this.cityName;
    }
  }

  public class QueryParams
  {
    String lat;
    String limit;

    public QueryParams(int arg2)
    {
      this(str2, str3);
    }

    public QueryParams(String paramString1, String arg3)
    {
      this.lat = paramString1;
      Object localObject;
      this.limit = localObject;
    }

    public String getLat()
    {
      return this.lat;
    }

    public String getLimit()
    {
      return this.limit;
    }

    public String getLon()
    {
      return NearestCitiesClient.this;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.nearestcity.NearestCitiesClient
 * JD-Core Version:    0.6.0
 */