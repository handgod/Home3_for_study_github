package com.spb.cities.nearestcity;

import android.content.Context;
import android.telephony.TelephonyManager;

public class ClientToken
{
  public static final String QUERY_PARAM_CLIENT_TOKEN = "client_token";
  private static ClientToken instance;
  private final String token;

  private ClientToken(Context paramContext)
  {
    String str1 = paramContext.getPackageName();
    String str2 = ((TelephonyManager)paramContext.getSystemService("phone")).getDeviceId();
    StringBuilder localStringBuilder1 = new StringBuilder();
    long l1 = getCode(str1);
    StringBuilder localStringBuilder2 = localStringBuilder1.append(l1);
    StringBuilder localStringBuilder3 = localStringBuilder1.append(45);
    long l2 = getCode(str2);
    StringBuilder localStringBuilder4 = localStringBuilder3.append(l2);
    String str3 = localStringBuilder1.toString();
    this.token = str3;
  }

  public static ClientToken getInstance(Context paramContext)
  {
    if (instance == null);
    synchronized (ClientToken.class)
    {
      if (instance == null)
        instance = new ClientToken(paramContext);
      return instance;
    }
  }

  long getCode(String paramString)
  {
    long l1;
    if (paramString == null)
    {
      l1 = 0L;
      return l1;
    }
    int i = paramString.hashCode();
    if (i >= 0)
      l1 = i;
    while (true)
    {
      break;
      long l2 = i;
      l1 = 4294967296L + l2;
    }
  }

  public String getToken()
  {
    return this.token;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.nearestcity.ClientToken
 * JD-Core Version:    0.6.0
 */