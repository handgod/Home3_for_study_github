package com.spb.cities.nearestcity;

import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.io.InputStream;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.DefaultHttpClient;

public abstract class DownloadClient
{
  public static final int COMM_TIMEOUT_MILLIS = 5000;
  protected Logger logger;
  private int reqCount;
  private int serverCount;
  protected String[] serverUrls;
  private final Object stateChangedMonitor;
  private boolean stopFlag = 0;

  public DownloadClient(String[] paramArrayOfString)
  {
    Object localObject = new Object();
    this.stateChangedMonitor = localObject;
    this.reqCount = 0;
    Logger localLogger = Loggers.getLogger(getClass().getName());
    this.logger = localLogger;
    this.serverUrls = paramArrayOfString;
    int i = paramArrayOfString.length;
    this.serverCount = i;
  }

  private Object download(HttpClient paramHttpClient, Object paramObject, String paramString)
  {
    Logger localLogger = this.logger;
    String str1 = "download: param=" + paramObject + " serverUri=" + paramString;
    localLogger.d(str1);
    String str2 = createUrl(paramString, paramObject);
    HttpGet localHttpGet = new HttpGet(str2);
    Object[] arrayOfObject = new Object[1];
    StringBuilder localStringBuilder = new StringBuilder().append("DownloadClient-Request-");
    int i = this.reqCount + 1;
    this.reqCount = i;
    String str3 = i;
    try
    {
      DownloadClient localDownloadClient = this;
      HttpClient localHttpClient = paramHttpClient;
      Object localObject1 = paramObject;
      new DownloadClient.1(localDownloadClient, str3, arrayOfObject, localHttpClient, localHttpGet, localObject1).start();
      synchronized (this.stateChangedMonitor)
      {
        this.stateChangedMonitor.wait(5000L);
        if (localHttpGet != null)
          localHttpGet.abort();
        return arrayOfObject[0];
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        if (localHttpGet == null)
          continue;
        localHttpGet.abort();
      }
    }
    finally
    {
      if (localHttpGet != null)
        localHttpGet.abort();
    }
  }

  // ERROR //
  private Object sendRequest(HttpClient paramHttpClient, HttpGet paramHttpGet, Object paramObject)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 4
    //   3: aconst_null
    //   4: astore 5
    //   6: aload_0
    //   7: getfield 48	com/spb/cities/nearestcity/DownloadClient:logger	Lcom/softspb/util/log/Logger;
    //   10: astore 6
    //   12: new 66	java/lang/StringBuilder
    //   15: dup
    //   16: invokespecial 67	java/lang/StringBuilder:<init>	()V
    //   19: ldc 123
    //   21: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: aload_1
    //   25: invokevirtual 76	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   28: invokevirtual 81	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   31: astore 7
    //   33: aload 6
    //   35: aload 7
    //   37: invokevirtual 87	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   40: aload_0
    //   41: getfield 48	com/spb/cities/nearestcity/DownloadClient:logger	Lcom/softspb/util/log/Logger;
    //   44: astore 8
    //   46: new 66	java/lang/StringBuilder
    //   49: dup
    //   50: invokespecial 67	java/lang/StringBuilder:<init>	()V
    //   53: ldc 125
    //   55: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   58: astore 9
    //   60: aload_2
    //   61: invokevirtual 129	org/apache/http/client/methods/HttpGet:getURI	()Ljava/net/URI;
    //   64: astore 10
    //   66: aload 9
    //   68: aload 10
    //   70: invokevirtual 76	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   73: invokevirtual 81	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   76: astore 11
    //   78: aload 8
    //   80: aload 11
    //   82: invokevirtual 87	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   85: aload_1
    //   86: aload_2
    //   87: invokeinterface 135 2 0
    //   92: astore 12
    //   94: aload 12
    //   96: invokeinterface 141 1 0
    //   101: astore 13
    //   103: aload 13
    //   105: invokeinterface 147 1 0
    //   110: sipush 200
    //   113: if_icmpeq +64 -> 177
    //   116: aload_0
    //   117: getfield 48	com/spb/cities/nearestcity/DownloadClient:logger	Lcom/softspb/util/log/Logger;
    //   120: astore 14
    //   122: new 66	java/lang/StringBuilder
    //   125: dup
    //   126: invokespecial 67	java/lang/StringBuilder:<init>	()V
    //   129: ldc 149
    //   131: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   134: astore 15
    //   136: aload 13
    //   138: invokeinterface 147 1 0
    //   143: istore 16
    //   145: aload 15
    //   147: iload 16
    //   149: invokevirtual 100	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   152: invokevirtual 81	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   155: astore 17
    //   157: aload 14
    //   159: aload 17
    //   161: invokevirtual 152	com/softspb/util/log/Logger:w	(Ljava/lang/String;)V
    //   164: iconst_0
    //   165: ifeq +9 -> 174
    //   168: aconst_null
    //   169: invokeinterface 157 1 0
    //   174: aload 4
    //   176: areturn
    //   177: aload_0
    //   178: getfield 48	com/spb/cities/nearestcity/DownloadClient:logger	Lcom/softspb/util/log/Logger;
    //   181: ldc 159
    //   183: invokevirtual 87	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   186: aload 12
    //   188: invokeinterface 163 1 0
    //   193: astore 5
    //   195: aload 5
    //   197: ifnonnull +32 -> 229
    //   200: aload_0
    //   201: getfield 48	com/spb/cities/nearestcity/DownloadClient:logger	Lcom/softspb/util/log/Logger;
    //   204: ldc 165
    //   206: invokevirtual 87	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   209: aload 5
    //   211: ifnull -37 -> 174
    //   214: aload 5
    //   216: invokeinterface 157 1 0
    //   221: goto -47 -> 174
    //   224: astore 18
    //   226: goto -52 -> 174
    //   229: aload 5
    //   231: invokeinterface 169 1 0
    //   236: astore 19
    //   238: aload_0
    //   239: getfield 48	com/spb/cities/nearestcity/DownloadClient:logger	Lcom/softspb/util/log/Logger;
    //   242: ldc 171
    //   244: invokevirtual 87	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   247: aload_0
    //   248: aload 19
    //   250: aload_3
    //   251: invokevirtual 175	com/spb/cities/nearestcity/DownloadClient:parseResponse	(Ljava/io/InputStream;Ljava/lang/Object;)Ljava/lang/Object;
    //   254: astore 20
    //   256: aload 20
    //   258: astore 4
    //   260: aload 5
    //   262: ifnull -88 -> 174
    //   265: aload 5
    //   267: invokeinterface 157 1 0
    //   272: goto -98 -> 174
    //   275: astore 21
    //   277: goto -103 -> 174
    //   280: astore 22
    //   282: aload_0
    //   283: getfield 48	com/spb/cities/nearestcity/DownloadClient:logger	Lcom/softspb/util/log/Logger;
    //   286: astore 23
    //   288: new 66	java/lang/StringBuilder
    //   291: dup
    //   292: invokespecial 67	java/lang/StringBuilder:<init>	()V
    //   295: ldc 177
    //   297: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   300: aload 22
    //   302: invokevirtual 76	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   305: invokevirtual 81	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   308: astore 24
    //   310: aload 23
    //   312: aload 24
    //   314: aload 22
    //   316: invokevirtual 181	com/softspb/util/log/Logger:e	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   319: aload 5
    //   321: ifnull -147 -> 174
    //   324: aload 5
    //   326: invokeinterface 157 1 0
    //   331: goto -157 -> 174
    //   334: astore 25
    //   336: goto -162 -> 174
    //   339: astore 4
    //   341: aload 5
    //   343: ifnull +10 -> 353
    //   346: aload 5
    //   348: invokeinterface 157 1 0
    //   353: aload 4
    //   355: athrow
    //   356: astore 26
    //   358: goto -184 -> 174
    //   361: astore 27
    //   363: goto -10 -> 353
    //
    // Exception table:
    //   from	to	target	type
    //   214	221	224	java/io/IOException
    //   265	272	275	java/io/IOException
    //   6	164	280	java/lang/Exception
    //   177	209	280	java/lang/Exception
    //   229	256	280	java/lang/Exception
    //   324	331	334	java/io/IOException
    //   6	164	339	finally
    //   177	209	339	finally
    //   229	256	339	finally
    //   282	319	339	finally
    //   168	174	356	java/io/IOException
    //   346	353	361	java/io/IOException
  }

  public void abort()
  {
    this.stopFlag = 1;
  }

  protected abstract String createUrl(String paramString, Object paramObject);

  public Object download(Object paramObject)
  {
    Logger localLogger = this.logger;
    String str1 = "Attempting to download data for param=" + paramObject;
    localLogger.d(str1);
    int i = this.serverCount;
    String[] arrayOfString = this.serverUrls;
    Object localObject1 = null;
    this.stopFlag = 0;
    HttpClient localHttpClient = obtainHttpClient();
    int j = 0;
    while (true)
    {
      if (j < i);
      try
      {
        if (!this.stopFlag)
        {
          String str2 = arrayOfString[j];
          Object localObject2 = download(localHttpClient, paramObject, str2);
          localObject1 = localObject2;
          if (localObject1 == null);
        }
        else
        {
          return localObject1;
        }
        j += 1;
      }
      finally
      {
        releaseHttpClient(localHttpClient);
      }
    }
  }

  protected HttpClient obtainHttpClient()
  {
    return new DefaultHttpClient();
  }

  protected abstract Object parseResponse(InputStream paramInputStream, Object paramObject)
    throws Exception;

  protected void releaseHttpClient(HttpClient paramHttpClient)
  {
    ClientConnectionManager localClientConnectionManager = paramHttpClient.getConnectionManager();
    if (localClientConnectionManager != null)
      localClientConnectionManager.shutdown();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.nearestcity.DownloadClient
 * JD-Core Version:    0.6.0
 */