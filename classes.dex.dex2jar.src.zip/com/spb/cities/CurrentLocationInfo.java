package com.spb.cities;

public class CurrentLocationInfo
{
  protected int cityId;
  protected long lastUpdatedMsUtc;
  protected int positioningStatus;

  public CurrentLocationInfo()
  {
    this(-2147483648, 2, 0L);
  }

  public CurrentLocationInfo(int paramInt1, int paramInt2, long paramLong)
  {
    this.cityId = paramInt1;
    this.positioningStatus = paramInt2;
    this.lastUpdatedMsUtc = paramLong;
  }

  public int getCityId()
  {
    return this.cityId;
  }

  public long getLastUpdatedMsUtc()
  {
    return this.lastUpdatedMsUtc;
  }

  public int getPositioningStatus()
  {
    return this.positioningStatus;
  }

  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("CurrentLocationInfo [cityId=");
    int i = this.cityId;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(i).append(" positioningStatus=");
    int j = this.positioningStatus;
    StringBuilder localStringBuilder3 = localStringBuilder2.append(j).append(" lastUpdatedMsUtc=");
    long l = this.lastUpdatedMsUtc;
    return l + "]";
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.CurrentLocationInfo
 * JD-Core Version:    0.6.0
 */