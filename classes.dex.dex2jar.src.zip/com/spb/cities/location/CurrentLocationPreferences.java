package com.spb.cities.location;

import android.content.Context;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.location.Location;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.softspb.updateservice.UpdatePreferences;
import com.softspb.util.Base64;
import com.softspb.util.CrossProcessusPreferences;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import com.spb.cities.R.integer;

public class CurrentLocationPreferences extends CrossProcessusPreferences
  implements UpdatePreferences
{
  private static final long DEFAULT_UPDATE_PERIOD = 7200000L;
  private static final String PREFS_NAME = "current-location";
  private static final String PREF_LAST_KNOWN_LOCATION = "last-known-location";
  private static final String PREF_LAST_KNOWN_NEAREST_CITY_ID = "last-known-nearest-city-id";
  private static final Logger logger = Loggers.getLogger(CurrentLocationPreferences.class);
  private Context context;

  public CurrentLocationPreferences(Context paramContext)
  {
    super(paramContext, str, "current-location");
    this.context = paramContext;
  }

  private static String encodeByteArray(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null);
    StringBuilder localStringBuilder1;
    for (String str1 = "<null>"; ; str1 = localStringBuilder1.toString())
    {
      return str1;
      localStringBuilder1 = new StringBuilder();
      int i = paramArrayOfByte.length;
      int j = 0;
      while (j < i)
      {
        int k = paramArrayOfByte[j];
        if (k < 0)
          k += 256;
        String str2 = Integer.toHexString(k);
        if (str2.length() < 2)
          StringBuilder localStringBuilder2 = localStringBuilder1.append(48);
        StringBuilder localStringBuilder3 = localStringBuilder1.append(str2);
        j += 1;
      }
    }
  }

  private static final void logd(String paramString)
  {
    logger.d(paramString);
  }

  public long getDefaultUpdateInterval(Context paramContext)
  {
    try
    {
      Resources localResources = paramContext.getResources();
      int i = R.integer.current_location_default_update_period;
      int j = localResources.getInteger(i);
      l = j;
      return l;
    }
    catch (Exception localException)
    {
      while (true)
        long l = 7200000L;
    }
  }

  public Location getLastKnownLocation()
  {
    String str1 = getString("last-known-location", null);
    Location localLocation;
    if (str1 == null)
      localLocation = null;
    while (true)
    {
      return localLocation;
      int i = 0;
      try
      {
        byte[] arrayOfByte = Base64.decode(str1, i);
        Logger localLogger1 = logger;
        StringBuilder localStringBuilder = new StringBuilder().append("Decoded loc bytes: ");
        String str2 = encodeByteArray(arrayOfByte);
        String str3 = str2;
        localLogger1.d(str3);
        localParcel = Parcel.obtain();
        int j = arrayOfByte.length;
        localParcel.unmarshall(arrayOfByte, 0, j);
        localParcel.setDataPosition(0);
        localLocation = (Location)Location.CREATOR.createFromParcel(localParcel);
        Logger localLogger2 = logger;
        String str4 = "Restored from preferences: " + localLocation;
        localLogger2.d(str4);
        if (localParcel == null)
          continue;
        localParcel.recycle();
        continue;
      }
      catch (Exception localException)
      {
        Logger localLogger3 = logger;
        String str5 = "Failed to resore last known location: " + localException;
        localLogger3.d(str5);
        if (localParcel != null)
          localParcel.recycle();
        localLocation = null;
        continue;
      }
      finally
      {
        Parcel localParcel;
        if (localParcel != null)
          localParcel.recycle();
      }
    }
    throw localObject;
  }

  public int getLastKnownNearestCityId()
  {
    return getInt("last-known-nearest-city-id", -2147483648);
  }

  public long getUpdateIntervalMs()
  {
    long l = getLong("update-interval", 65535L);
    if (l == 65535L)
    {
      Context localContext = this.context;
      l = getDefaultUpdateInterval(localContext);
    }
    logd("getUpdateIntervalMs <<< " + l);
    return l;
  }

  public boolean isUseOnlyWifi()
  {
    logd("isUseOnlyWifi >>>");
    boolean bool = getBoolean("use-only-wifi", 0);
    logd("isUseOnlyWifi <<< " + bool);
    return bool;
  }

  public void setLastKnownLocation(Location paramLocation, int paramInt)
  {
    Parcel localParcel = Parcel.obtain();
    paramLocation.writeToParcel(localParcel, 0);
    byte[] arrayOfByte = localParcel.marshall();
    localParcel.recycle();
    String str1 = Base64.encodeToString(arrayOfByte, 0);
    SharedPreferences.Editor localEditor1 = edit();
    SharedPreferences.Editor localEditor2 = localEditor1.putString("last-known-location", str1);
    SharedPreferences.Editor localEditor3 = localEditor1.putInt("last-known-nearest-city-id", paramInt);
    boolean bool = localEditor1.commit();
    Logger localLogger = logger;
    StringBuilder localStringBuilder = new StringBuilder().append("Saved to preferences: location=");
    String str2 = paramLocation.toString();
    String str3 = str2 + " cityId=" + paramInt;
    localLogger.d(str3);
  }

  public void setUpdateIntervalMs(long paramLong)
  {
    logd("setUpdateIntervalMs: " + paramLong);
    boolean bool = edit().putLong("update-interval", paramLong).commit();
  }

  public void setUseOnlyWifi(boolean paramBoolean)
  {
    logd("setUseOnlyWifi: " + paramBoolean);
    boolean bool = edit().putBoolean("use-only-wifi", paramBoolean).commit();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.location.CurrentLocationPreferences
 * JD-Core Version:    0.6.0
 */