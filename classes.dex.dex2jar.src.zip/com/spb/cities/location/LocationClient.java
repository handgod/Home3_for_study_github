package com.spb.cities.location;

import android.content.Context;
import android.content.res.Resources;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import com.spb.cities.R.integer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.List<Ljava.lang.String;>;

public final class LocationClient
  implements LocationListener
{
  private static final long DEFAULT_EXPIRATION_MS = 3600000L;
  private static final long DEFAULT_TIMEOUT_MS = 20000L;
  private static final long DEFAULT_TIMEOUT_MS_GPS = 300000L;
  private static final long DEFAULT_TIMEOUT_MS_NETWORK = 20000L;
  private static final String LOCATION_PROVIDER_PASSIVE = "passive";
  private static final PowerConsumptionComparator POWER_CONSUMPTION_COMPARATOR = ;
  private static final String TAG = "LocationClient";
  private static volatile int instanceCount = 0;
  private static final Logger logger;
  private Criteria criteria;
  private Location currentLocation;
  private volatile boolean currentOperationAborted;
  private long expirationMs;
  private HandlerThread handlerThread;
  private String instanceId;
  private int instanceNo;
  private LocationHandler locationHandler;
  private LocationManager locationManager;
  private final Object locationMonitor;
  private long timeoutMsGps;
  private long timeoutMsNetwork;
  private long timeoutMsOthers;

  static
  {
    POWER_CONSUMPTION_COMPARATOR = new PowerConsumptionComparator();
    logger = Loggers.getLogger(LocationClient.class);
  }

  public LocationClient(Context paramContext)
  {
    this(paramContext, null);
  }

  public LocationClient(Context paramContext, Criteria paramCriteria)
  {
    monitorenter;
    try
    {
      int i = instanceCount + 1;
      instanceCount = i;
      this.instanceNo = i;
      monitorexit;
      StringBuilder localStringBuilder1 = new StringBuilder();
      int j = Process.myPid();
      StringBuilder localStringBuilder2 = localStringBuilder1.append(j).append(":");
      int k = this.instanceNo;
      String str1 = k;
      this.instanceId = str1;
      this.currentOperationAborted = 0;
      this.timeoutMsNetwork = 20000L;
      this.timeoutMsGps = 300000L;
      this.timeoutMsOthers = 20000L;
      this.expirationMs = 3600000L;
      Object localObject1 = new Object();
      this.locationMonitor = localObject1;
      StringBuilder localStringBuilder3 = new StringBuilder().append("Ctor >>> context=");
      String str2 = paramContext.getPackageName();
      String str3 = str2;
      logd(str3);
      logTrace();
      LocationManager localLocationManager = (LocationManager)paramContext.getSystemService("location");
      this.locationManager = localLocationManager;
      this.criteria = paramCriteria;
      HandlerThread localHandlerThread = new HandlerThread("LocationClient");
      this.handlerThread = localHandlerThread;
      this.handlerThread.start();
      Looper localLooper = this.handlerThread.getLooper();
      LocationHandler localLocationHandler = new LocationHandler(localLooper);
      this.locationHandler = localLocationHandler;
      Resources localResources = paramContext.getResources();
      int m = R.integer.location_timeout_sec_gps;
      long l1 = localResources.getInteger(m) * 1000L;
      setGpsTimeout(l1);
      int n = R.integer.location_timeout_sec_network;
      long l2 = localResources.getInteger(n) * 1000L;
      setNetworkTimeout(l2);
      int i1 = R.integer.location_timeout_sec_others;
      long l3 = localResources.getInteger(i1) * 1000L;
      setOthersTimeout(l3);
      return;
    }
    finally
    {
      monitorexit;
    }
    throw localObject2;
  }

  private static final List<String> getEnabledProviders(LocationManager paramLocationManager, Criteria paramCriteria, boolean paramBoolean)
  {
    Object localObject1 = null;
    List localList;
    int i;
    label26: int j;
    if (paramCriteria == null)
    {
      localList = paramLocationManager.getProviders(1);
      if (paramBoolean)
        break label168;
      if (localList != null)
        break label133;
      i = 0;
      j = 0;
    }
    while (true)
    {
      if (j >= i)
        break label168;
      String str = (String)localList.get(j);
      if ("passive".equals(str))
      {
        if (localObject1 == null)
        {
          int k = i + -1;
          localObject1 = new ArrayList(k);
          int m = 0;
          while (m < j)
          {
            Object localObject2 = localList.get(m);
            boolean bool1 = ((List)localObject1).add(localObject2);
            m += 1;
          }
          localList = paramLocationManager.getProviders(paramCriteria, 1);
          break;
          label133: i = localList.size();
          break label26;
        }
      }
      else if (localObject1 != null)
        boolean bool2 = ((List)localObject1).add(str);
      j += 1;
    }
    label168: if (localObject1 == null)
      localObject1 = localList;
    if (localObject1 == null)
      localObject1 = Collections.emptyList();
    return (List<String>)localObject1;
  }

  private Location getLastKnownLocation(List<LocationProvider> paramList, long paramLong)
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("getLastKnownLocation >>> providers: ");
    List<LocationProvider> localList = paramList;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(localList).append(" expirationToleranceMs=");
    long l1 = paramLong;
    String str1 = l1;
    logd(str1);
    Object localObject = null;
    long l2 = 9223372036854775807L;
    if (paramLong == 0L);
    while (true)
    {
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        String str2 = ((LocationProvider)localIterator.next()).getName();
        String str3 = "getLastKnownLocation: trying provider: " + str2 + "...";
        logd(str3);
        Location localLocation = this.locationManager.getLastKnownLocation(str2);
        String str4 = "getLastKnownLocation: location=" + localLocation;
        logd(str4);
        if (localLocation == null)
          continue;
        long l3 = System.currentTimeMillis();
        long l4 = localLocation.getTime();
        long l5 = l3 - l4;
        if ((l5 >= l2) || ((paramLong != 0L) && (l5 >= paramLong)))
          continue;
        localObject = localLocation;
        l2 = l5;
      }
      long l6 = System.currentTimeMillis();
    }
    String str5 = "getLastKnownLocation <<< return " + localObject;
    logd(str5);
    return localObject;
  }

  private static List<LocationProvider> getOrderedProvider(LocationManager paramLocationManager, Criteria paramCriteria)
  {
    List localList = getEnabledProviders(paramLocationManager, paramCriteria, 0);
    int i = localList.size();
    ArrayList localArrayList = new ArrayList(i);
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      LocationProvider localLocationProvider = paramLocationManager.getProvider(str);
      boolean bool = localArrayList.add(localLocationProvider);
    }
    PowerConsumptionComparator localPowerConsumptionComparator = POWER_CONSUMPTION_COMPARATOR;
    Collections.sort(localArrayList, localPowerConsumptionComparator);
    return localArrayList;
  }

  private long getTimeout(LocationProvider paramLocationProvider)
  {
    String str = paramLocationProvider.getName();
    long l;
    if ("gps".equals(str))
      l = this.timeoutMsGps;
    while (true)
    {
      return l;
      if ("network".equals(str))
      {
        l = this.timeoutMsNetwork;
        continue;
      }
      l = this.timeoutMsOthers;
    }
  }

  private void logTrace()
  {
    StackTraceElement[] arrayOfStackTraceElement = Thread.currentThread().getStackTrace();
    int i = 3;
    while (true)
    {
      int j = arrayOfStackTraceElement.length;
      if (i >= j)
        break;
      StringBuilder localStringBuilder = new StringBuilder().append("|   ");
      StackTraceElement localStackTraceElement = arrayOfStackTraceElement[i];
      String str = localStackTraceElement;
      logd(str);
      i += 1;
    }
  }

  private void logd(String paramString)
  {
    Logger localLogger = logger;
    StringBuilder localStringBuilder = new StringBuilder().append("[");
    String str1 = this.instanceId;
    String str2 = str1 + "]" + paramString;
    localLogger.d(str2);
  }

  // ERROR //
  private Location queryLocation(LocationProvider paramLocationProvider)
  {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual 277	android/location/LocationProvider:getName	()Ljava/lang/String;
    //   4: astore_2
    //   5: new 85	java/lang/StringBuilder
    //   8: dup
    //   9: invokespecial 86	java/lang/StringBuilder:<init>	()V
    //   12: ldc_w 344
    //   15: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   18: aload_2
    //   19: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   22: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   25: astore_3
    //   26: aload_0
    //   27: aload_3
    //   28: invokespecial 131	com/spb/cities/location/LocationClient:logd	(Ljava/lang/String;)V
    //   31: invokestatic 292	java/lang/System:currentTimeMillis	()J
    //   34: lstore 4
    //   36: aload_0
    //   37: aload_1
    //   38: invokespecial 346	com/spb/cities/location/LocationClient:getTimeout	(Landroid/location/LocationProvider;)J
    //   41: lstore 6
    //   43: aload_0
    //   44: aconst_null
    //   45: putfield 348	com/spb/cities/location/LocationClient:currentLocation	Landroid/location/Location;
    //   48: aload_0
    //   49: getfield 164	com/spb/cities/location/LocationClient:locationHandler	Lcom/spb/cities/location/LocationClient$LocationHandler;
    //   52: aload_2
    //   53: invokevirtual 351	com/spb/cities/location/LocationClient$LocationHandler:postRequestUpdates	(Ljava/lang/String;)V
    //   56: aload_0
    //   57: getfield 164	com/spb/cities/location/LocationClient:locationHandler	Lcom/spb/cities/location/LocationClient$LocationHandler;
    //   60: lload 6
    //   62: invokevirtual 354	com/spb/cities/location/LocationClient$LocationHandler:postTimeout	(J)V
    //   65: aload_0
    //   66: getfield 110	com/spb/cities/location/LocationClient:currentOperationAborted	Z
    //   69: ifne +78 -> 147
    //   72: aload_0
    //   73: getfield 348	com/spb/cities/location/LocationClient:currentLocation	Landroid/location/Location;
    //   76: ifnonnull +71 -> 147
    //   79: invokestatic 292	java/lang/System:currentTimeMillis	()J
    //   82: lload 4
    //   84: lsub
    //   85: lload 6
    //   87: lcmp
    //   88: ifge +59 -> 147
    //   91: aload_0
    //   92: getfield 120	com/spb/cities/location/LocationClient:locationMonitor	Ljava/lang/Object;
    //   95: astore 8
    //   97: aload 8
    //   99: monitorenter
    //   100: aload_0
    //   101: getfield 120	com/spb/cities/location/LocationClient:locationMonitor	Ljava/lang/Object;
    //   104: invokevirtual 357	java/lang/Object:wait	()V
    //   107: aload 8
    //   109: monitorexit
    //   110: goto -45 -> 65
    //   113: astore 9
    //   115: aload 8
    //   117: monitorexit
    //   118: aload 9
    //   120: athrow
    //   121: astore 10
    //   123: aload_0
    //   124: getfield 144	com/spb/cities/location/LocationClient:locationManager	Landroid/location/LocationManager;
    //   127: aload_0
    //   128: invokevirtual 361	android/location/LocationManager:removeUpdates	(Landroid/location/LocationListener;)V
    //   131: aload_0
    //   132: getfield 164	com/spb/cities/location/LocationClient:locationHandler	Lcom/spb/cities/location/LocationClient$LocationHandler;
    //   135: aconst_null
    //   136: invokevirtual 365	com/spb/cities/location/LocationClient$LocationHandler:removeCallbacksAndMessages	(Ljava/lang/Object;)V
    //   139: aload 10
    //   141: athrow
    //   142: astore 11
    //   144: aload 8
    //   146: monitorexit
    //   147: aload_0
    //   148: getfield 144	com/spb/cities/location/LocationClient:locationManager	Landroid/location/LocationManager;
    //   151: aload_0
    //   152: invokevirtual 361	android/location/LocationManager:removeUpdates	(Landroid/location/LocationListener;)V
    //   155: aload_0
    //   156: getfield 164	com/spb/cities/location/LocationClient:locationHandler	Lcom/spb/cities/location/LocationClient$LocationHandler;
    //   159: aconst_null
    //   160: invokevirtual 365	com/spb/cities/location/LocationClient$LocationHandler:removeCallbacksAndMessages	(Ljava/lang/Object;)V
    //   163: new 85	java/lang/StringBuilder
    //   166: dup
    //   167: invokespecial 86	java/lang/StringBuilder:<init>	()V
    //   170: ldc_w 367
    //   173: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   176: astore 12
    //   178: aload_0
    //   179: getfield 348	com/spb/cities/location/LocationClient:currentLocation	Landroid/location/Location;
    //   182: astore 13
    //   184: aload 12
    //   186: aload 13
    //   188: invokevirtual 249	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   191: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   194: astore 14
    //   196: aload_0
    //   197: aload 14
    //   199: invokespecial 131	com/spb/cities/location/LocationClient:logd	(Ljava/lang/String;)V
    //   202: new 85	java/lang/StringBuilder
    //   205: dup
    //   206: invokespecial 86	java/lang/StringBuilder:<init>	()V
    //   209: ldc_w 369
    //   212: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   215: astore 15
    //   217: invokestatic 292	java/lang/System:currentTimeMillis	()J
    //   220: lload 4
    //   222: lsub
    //   223: lstore 16
    //   225: aload 15
    //   227: lload 16
    //   229: invokevirtual 254	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   232: ldc_w 371
    //   235: invokevirtual 101	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   238: invokevirtual 105	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   241: astore 18
    //   243: aload_0
    //   244: aload 18
    //   246: invokespecial 131	com/spb/cities/location/LocationClient:logd	(Ljava/lang/String;)V
    //   249: aload_0
    //   250: getfield 348	com/spb/cities/location/LocationClient:currentLocation	Landroid/location/Location;
    //   253: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   100	107	113	finally
    //   107	113	113	finally
    //   144	147	113	finally
    //   65	100	121	finally
    //   118	121	121	finally
    //   100	107	142	java/lang/InterruptedException
  }

  public void abort()
  {
    logd("abort");
    this.currentOperationAborted = 1;
    synchronized (this.locationMonitor)
    {
      this.locationMonitor.notifyAll();
      return;
    }
  }

  public void dispose()
  {
    logd("dispose");
    if (this.locationManager != null)
      this.locationManager.removeUpdates(this);
    this.handlerThread.getLooper().quit();
    this.locationHandler.removeCallbacksAndMessages(null);
  }

  public boolean isLocationPossible()
  {
    int i = 0;
    if (this.locationManager != null)
    {
      LocationManager localLocationManager = this.locationManager;
      Criteria localCriteria = this.criteria;
      List localList = getEnabledProviders(localLocationManager, localCriteria, 0);
      if ((localList == null) || (localList.size() <= 0))
        break label47;
    }
    label47: for (i = 1; ; i = 0)
      return i;
  }

  public Location obtainLocation()
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("obtainLocation >>> expirationMs=");
    long l1 = this.expirationMs;
    String str1 = l1;
    logd(str1);
    logTrace();
    long l2 = System.currentTimeMillis();
    this.currentOperationAborted = 0;
    if (this.locationManager == null)
    {
      logd("obtainLocation: LocationManager is null, returning null");
      StringBuilder localStringBuilder2 = new StringBuilder().append("obtainLocation <<< finished in ");
      long l3 = (System.currentTimeMillis() - l2) / 1000L;
      String str2 = l3 + " secs";
      logd(str2);
      localLocation = null;
      return localLocation;
    }
    LocationManager localLocationManager = this.locationManager;
    Criteria localCriteria = this.criteria;
    List localList = getOrderedProvider(localLocationManager, localCriteria);
    String str3 = "obtainLocation: available providers: " + localList;
    logd(str3);
    long l4 = this.expirationMs;
    Location localLocation = getLastKnownLocation(localList, l4);
    int i;
    int j;
    if (localLocation == null)
    {
      i = localList.size();
      j = 0;
    }
    while (true)
    {
      if ((j < i) && (!this.currentOperationAborted))
      {
        LocationProvider localLocationProvider = (LocationProvider)localList.get(j);
        localLocation = queryLocation(localLocationProvider);
        if (localLocation == null);
      }
      else
      {
        if (localLocation == null)
          localLocation = getLastKnownLocation(localList, 0L);
        String str4 = "obtainLocation: returning location: " + localLocation;
        logd(str4);
        StringBuilder localStringBuilder3 = new StringBuilder().append("obtainLocation <<< finished in ");
        long l5 = (System.currentTimeMillis() - l2) / 1000L;
        String str5 = l5 + " secs";
        logd(str5);
        break;
      }
      j += 1;
    }
  }

  public void onLocationChanged(Location paramLocation)
  {
    String str = "onLocationChanged: " + paramLocation;
    logd(str);
    synchronized (this.locationMonitor)
    {
      this.currentLocation = paramLocation;
      this.locationMonitor.notify();
      return;
    }
  }

  public void onProviderDisabled(String paramString)
  {
    String str = "onProviderDisabled: " + paramString;
    logd(str);
  }

  public void onProviderEnabled(String paramString)
  {
    String str = "onProviderEnabled: " + paramString;
    logd(str);
  }

  public void onStatusChanged(String paramString, int paramInt, Bundle paramBundle)
  {
    String str = "onStatusCahnged: provider=" + paramString + " status=" + paramInt;
    logd(str);
  }

  public void setExpirationMs(long paramLong)
  {
    this.expirationMs = paramLong;
  }

  public void setGpsTimeout(long paramLong)
  {
    this.timeoutMsGps = paramLong;
  }

  public void setNetworkTimeout(long paramLong)
  {
    this.timeoutMsNetwork = paramLong;
  }

  public void setOthersTimeout(long paramLong)
  {
    this.timeoutMsOthers = paramLong;
  }

  final class PowerConsumptionComparator
    implements Comparator<LocationProvider>
  {
    private static final List<Criteria> CRITERIAS = new ArrayList(4);

    static
    {
      Criteria localCriteria1 = new Criteria();
      localCriteria1.setPowerRequirement(1);
      boolean bool1 = CRITERIAS.add(localCriteria1);
      Criteria localCriteria2 = new Criteria();
      localCriteria2.setPowerRequirement(2);
      boolean bool2 = CRITERIAS.add(localCriteria2);
      Criteria localCriteria3 = new Criteria();
      localCriteria3.setCostAllowed(0);
      boolean bool3 = CRITERIAS.add(localCriteria3);
      Criteria localCriteria4 = new Criteria();
      localCriteria4.setAccuracy(1);
      boolean bool4 = CRITERIAS.add(localCriteria4);
    }

    public int compare(LocationProvider paramLocationProvider1, LocationProvider paramLocationProvider2)
    {
      Iterator localIterator = CRITERIAS.iterator();
      boolean bool1;
      boolean bool2;
      int i;
      if (localIterator.hasNext())
      {
        Criteria localCriteria = (Criteria)localIterator.next();
        bool1 = paramLocationProvider1.meetsCriteria(localCriteria);
        bool2 = paramLocationProvider2.meetsCriteria(localCriteria);
        if ((bool1) && (!bool2))
          i = -1;
      }
      while (true)
      {
        return i;
        if ((bool1) || (!bool2))
          break;
        i = 1;
        continue;
        String str1 = paramLocationProvider1.getName();
        String str2 = paramLocationProvider2.getName();
        i = str1.compareTo(str2);
      }
    }
  }

  class LocationHandler extends Handler
  {
    private static final int MSG_REQUEST_UPDATES = 1;
    private static final int MSG_TIMEOUT = 2;

    LocationHandler(Looper arg2)
    {
      super();
    }

    public void handleMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default:
      case 1:
      case 2:
      }
      while (true)
      {
        return;
        String str1 = (String)paramMessage.obj;
        LocationClient localLocationClient1 = LocationClient.this;
        String str2 = "request updates: " + str1;
        localLocationClient1.logd(str2);
        LocationManager localLocationManager = LocationClient.this.locationManager;
        LocationClient localLocationClient2 = LocationClient.this;
        Looper localLooper = getLooper();
        localLocationManager.requestLocationUpdates(str1, 0L, 0.0F, localLocationClient2, localLooper);
        continue;
        LocationClient.this.logd("timeout");
        synchronized (LocationClient.this.locationMonitor)
        {
          LocationClient.this.locationMonitor.notifyAll();
        }
      }
    }

    void postRequestUpdates(String paramString)
    {
      Message localMessage = Message.obtain(this, 1, paramString);
      boolean bool = sendMessage(localMessage);
    }

    void postTimeout(long paramLong)
    {
      boolean bool = sendEmptyMessageDelayed(2, paramLong);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.cities.location.LocationClient
 * JD-Core Version:    0.6.0
 */