package com.spb.contacts;

import android.os.RemoteCallbackList;
import android.os.RemoteException;

public class PhoneNumberCallbacksHelper
{
  private final RemoteCallbackList<IPhoneNumberResolvingServiceCallback> callbackList;

  public PhoneNumberCallbacksHelper()
  {
    RemoteCallbackList localRemoteCallbackList = new RemoteCallbackList();
    this.callbackList = localRemoteCallbackList;
  }

  void notifyResolvedPhonesChanged(int paramInt)
  {
    int i = this.callbackList.beginBroadcast();
    int j = 0;
    while (true)
    {
      if (j < i);
      try
      {
        ((IPhoneNumberResolvingServiceCallback)this.callbackList.getBroadcastItem(j)).onResolvedPhonesChanged(paramInt);
        label32: j += 1;
        continue;
        this.callbackList.finishBroadcast();
        return;
      }
      catch (RemoteException localRemoteException)
      {
        break label32;
      }
    }
  }

  void register(IPhoneNumberResolvingServiceCallback paramIPhoneNumberResolvingServiceCallback)
  {
    boolean bool = this.callbackList.register(paramIPhoneNumberResolvingServiceCallback);
  }

  void unregister(IPhoneNumberResolvingServiceCallback paramIPhoneNumberResolvingServiceCallback)
  {
    boolean bool = this.callbackList.unregister(paramIPhoneNumberResolvingServiceCallback);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.PhoneNumberCallbacksHelper
 * JD-Core Version:    0.6.0
 */