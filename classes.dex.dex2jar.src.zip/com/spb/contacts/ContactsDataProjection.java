package com.spb.contacts;

abstract interface ContactsDataProjection
{
  public static final String[] CONTACTS_DATA_PROJECTION = ;
  public static final int INDEX_CONTACT_ID = 0;
  public static final int INDEX_DATA1 = 3;
  public static final int INDEX_DATA2 = 4;
  public static final int INDEX_DATA3 = 5;
  public static final int INDEX_DATA_ID = 9;
  public static final int INDEX_DATA_VERSION = 10;
  public static final int INDEX_DISPLAY_NAME = 1;
  public static final int INDEX_EVENT_DATE = 3;
  public static final int INDEX_EVENT_LABEL = 5;
  public static final int INDEX_EVENT_TYPE = 4;
  public static final int INDEX_FIRST_NAME = 4;
  public static final int INDEX_LABEL = 5;
  public static final int INDEX_LAST_NAME = 5;
  public static final int INDEX_LOCATION_TYPE = 4;
  public static final int INDEX_LOOKUP_KEY = 6;
  public static final int INDEX_MIMETYPE = 2;
  public static final int INDEX_NUMBER_ADDRESS = 3;
  public static final int INDEX_PHOTO_ID = 8;
  public static final int INDEX_STARRED = 7;
  public static final int INDEX_STRUCTURED_DISPLAY_NAME = 3;

  static
  {
    String[] arrayOfString = new String[11];
    arrayOfString[0] = "contact_id";
    arrayOfString[1] = "display_name";
    arrayOfString[2] = "mimetype";
    arrayOfString[3] = "data1";
    arrayOfString[4] = "data2";
    arrayOfString[5] = "data3";
    arrayOfString[6] = "lookup";
    arrayOfString[7] = "starred";
    arrayOfString[8] = "photo_id";
    arrayOfString[9] = "_id";
    arrayOfString[10] = "data_version";
    CONTACTS_DATA_PROJECTION = arrayOfString;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.ContactsDataProjection
 * JD-Core Version:    0.6.0
 */