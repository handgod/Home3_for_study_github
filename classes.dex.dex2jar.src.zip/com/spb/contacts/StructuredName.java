package com.spb.contacts;

import android.text.TextUtils;

class StructuredName extends DataEntry
{
  final String displayName;
  final String firstName;
  final String lastName;

  StructuredName(int paramInt1, int paramInt2, String paramString1, String paramString2, String paramString3)
  {
    super(paramInt1, paramInt2);
    this.displayName = paramString1;
    this.firstName = paramString2;
    this.lastName = paramString3;
  }

  private boolean sameFirstLastName(StructuredName paramStructuredName)
  {
    String str1 = this.firstName;
    String str2 = paramStructuredName.firstName;
    if (TextUtils.equals(str1, str2))
    {
      String str3 = this.lastName;
      String str4 = paramStructuredName.lastName;
      if (!TextUtils.equals(str3, str4));
    }
    for (int i = 1; ; i = 0)
      return i;
  }

  public boolean equals(Object paramObject)
  {
    int i = 0;
    if (paramObject == null);
    while (true)
    {
      return i;
      Class localClass1 = paramObject.getClass();
      Class localClass2 = getClass();
      if (localClass1 != localClass2)
        continue;
      StructuredName localStructuredName = (StructuredName)paramObject;
      int j = this.id;
      int k = localStructuredName.id;
      if ((j != k) || (!sameFirstLastName(localStructuredName)))
        continue;
      i = 1;
    }
  }

  boolean isDuplicate(DataEntry paramDataEntry)
  {
    int i = 0;
    if (paramDataEntry == null);
    while (true)
    {
      return i;
      Class localClass1 = paramDataEntry.getClass();
      Class localClass2 = getClass();
      if (localClass1 != localClass2)
        continue;
      StructuredName localStructuredName = (StructuredName)paramDataEntry;
      boolean bool = sameFirstLastName(localStructuredName);
    }
  }

  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("StructuredName[firstName=\"");
    String str1 = this.firstName;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1).append("\" lastName=\"");
    String str2 = this.lastName;
    StringBuilder localStringBuilder3 = localStringBuilder2.append(str2).append("\" displayName=\"");
    String str3 = this.displayName;
    return str3 + "\"]";
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.StructuredName
 * JD-Core Version:    0.6.0
 */