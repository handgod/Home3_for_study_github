package com.spb.contacts;

import android.os.Process;
import android.os.RemoteException;

class ContactsService$1 extends IGetPid.Stub
{
  public int getPid()
    throws RemoteException
  {
    return Process.myPid();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.ContactsService.1
 * JD-Core Version:    0.6.0
 */