package com.spb.contacts;

import android.text.format.Time;

class EventEntry extends DataEntry
{
  Time date;
  int type;

  EventEntry(int paramInt1, int paramInt2, Time paramTime, int paramInt3)
  {
    super(paramInt1, paramInt2);
    this.date = paramTime;
    this.type = paramInt3;
  }

  private boolean hasSameContent(EventEntry paramEventEntry)
  {
    boolean bool = false;
    int i = this.type;
    int j = paramEventEntry.type;
    if (i == j)
    {
      if (this.type != 3)
        break label35;
      bool = sameDayAndMonth(paramEventEntry);
    }
    while (true)
    {
      return bool;
      label35: Time localTime1 = this.date;
      Time localTime2 = paramEventEntry.date;
      if (Time.compare(localTime1, localTime2) != 0)
        continue;
      bool = true;
    }
  }

  public boolean equals(Object paramObject)
  {
    int i = 0;
    if (paramObject == null);
    while (true)
    {
      return i;
      Class localClass1 = paramObject.getClass();
      Class localClass2 = getClass();
      if (localClass1 != localClass2)
        continue;
      EventEntry localEventEntry = (EventEntry)paramObject;
      int j = this.id;
      int k = localEventEntry.id;
      if ((j != k) || (!hasSameContent(localEventEntry)))
        continue;
      i = 1;
    }
  }

  boolean isDuplicate(DataEntry paramDataEntry)
  {
    int i = 0;
    if (paramDataEntry == null);
    while (true)
    {
      return i;
      Class localClass1 = paramDataEntry.getClass();
      Class localClass2 = getClass();
      if (localClass1 != localClass2)
        continue;
      EventEntry localEventEntry = (EventEntry)paramDataEntry;
      boolean bool = hasSameContent(localEventEntry);
    }
  }

  boolean sameDayAndMonth(EventEntry paramEventEntry)
  {
    int i = this.date.month;
    int j = paramEventEntry.date.month;
    if (i == j)
    {
      int k = this.date.monthDay;
      int m = paramEventEntry.date.monthDay;
      if (k != m);
    }
    for (int n = 1; ; n = 0)
      return n;
  }

  public String toString()
  {
    String str1;
    if (this.type == 3)
      str1 = "B";
    while (true)
    {
      StringBuilder localStringBuilder1 = new StringBuilder().append("Event[id=");
      int i = this.id;
      StringBuilder localStringBuilder2 = localStringBuilder1.append(i).append(" ");
      String str2 = this.date.format3339(1);
      return str2 + " " + str1 + "]";
      if (this.type == 1)
      {
        str1 = "A";
        continue;
      }
      str1 = "O";
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.EventEntry
 * JD-Core Version:    0.6.0
 */