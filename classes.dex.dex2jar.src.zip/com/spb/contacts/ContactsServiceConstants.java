package com.spb.contacts;

public abstract interface ContactsServiceConstants
{
  public static final int KIND_ALL = 1;
  public static final int KIND_FAVORITE = 2;
  public static final long UNRESOLVED_CONTACT_ID;
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.ContactsServiceConstants
 * JD-Core Version:    0.6.0
 */