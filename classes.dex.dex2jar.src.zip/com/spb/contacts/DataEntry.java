package com.spb.contacts;

class DataEntry
{
  public final int id;
  public int version;

  DataEntry(int paramInt1, int paramInt2)
  {
    this.id = paramInt1;
    this.version = paramInt2;
  }

  public boolean equals(Object paramObject)
  {
    int i = 0;
    if (paramObject == null);
    while (true)
    {
      return i;
      Class localClass1 = paramObject.getClass();
      Class localClass2 = getClass();
      if (localClass1 != localClass2)
        continue;
      DataEntry localDataEntry = (DataEntry)paramObject;
      int j = localDataEntry.id;
      int k = this.id;
      if (j != k)
        continue;
      int m = localDataEntry.version;
      int n = this.version;
      if (m != n)
        continue;
      i = 1;
    }
  }

  boolean isDuplicate(DataEntry paramDataEntry)
  {
    return false;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.DataEntry
 * JD-Core Version:    0.6.0
 */