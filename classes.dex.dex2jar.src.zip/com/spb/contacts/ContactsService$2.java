package com.spb.contacts;

import android.os.RemoteException;
import com.softspb.util.log.Logger;
import java.util.concurrent.locks.Lock;

class ContactsService$2 extends IContactsService.Stub
{
  public void crash()
    throws RemoteException
  {
    ContactsService.access$400().d("crash");
    throw new Error("ContactsService has crashed");
  }

  public void registerCallback(IContactsServiceCallback paramIContactsServiceCallback)
    throws RemoteException
  {
    Logger localLogger = ContactsService.access$400();
    String str = "registerCallback: " + paramIContactsServiceCallback;
    localLogger.d(str);
    if (paramIContactsServiceCallback != null)
      this.this$0.callbacksHelper.register(paramIContactsServiceCallback);
  }

  public void reloadBirthdays(int paramInt, boolean paramBoolean)
    throws RemoteException
  {
    ContactsService.access$100("IContactsService.reloadBirthdays >>> kins=" + paramInt + " notifyAll=" + paramBoolean);
    ContactsService.access$500(this.this$0).lock();
    this.this$0.callbacksHelper.notifyStartedReloadingBirthdays();
    try
    {
      ContactsService.access$600(this.this$0, paramInt, paramBoolean);
      return;
    }
    finally
    {
      this.this$0.callbacksHelper.notifyFinishedReloadingBirthdays();
      ContactsService.access$500(this.this$0).unlock();
      ContactsService.access$100("IContactsService.reloadBirthdays <<< kins=" + paramInt + " notifyAll=" + paramBoolean);
    }
    throw localObject;
  }

  public void reloadContact(int paramInt)
    throws RemoteException
  {
    ContactsService.access$700(this.this$0, paramInt);
  }

  public void reloadContacts(int paramInt)
    throws RemoteException
  {
    ContactsService.access$500(this.this$0).lock();
    try
    {
      ContactsService.access$800(this.this$0, paramInt);
      return;
    }
    finally
    {
      ContactsService.access$500(this.this$0).unlock();
    }
    throw localObject;
  }

  public void unregisterCallback(IContactsServiceCallback paramIContactsServiceCallback)
    throws RemoteException
  {
    Logger localLogger = ContactsService.access$400();
    String str = "unregisterCallback: " + paramIContactsServiceCallback;
    localLogger.d(str);
    if (paramIContactsServiceCallback != null)
      this.this$0.callbacksHelper.unregister(paramIContactsServiceCallback);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.ContactsService.2
 * JD-Core Version:    0.6.0
 */