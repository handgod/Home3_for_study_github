package com.spb.contacts;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract interface IContactsServiceCallback extends IInterface
{
  public abstract void onBirthdayDeleted(int paramInt)
    throws RemoteException;

  public abstract void onBirthdayUpdated(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
    throws RemoteException;

  public abstract void onConnectionDeleted(int paramInt1, int paramInt2, int paramInt3)
    throws RemoteException;

  public abstract void onConnectionUpdated(int paramInt1, int paramInt2, String paramString1, int paramInt3, String paramString2, String paramString3, int paramInt4)
    throws RemoteException;

  public abstract void onContactDeleted(int paramInt1, int paramInt2)
    throws RemoteException;

  public abstract void onContactPhotoUpdated(int paramInt1, int paramInt2, int paramInt3)
    throws RemoteException;

  public abstract void onContactUpdated(int paramInt1, String paramString1, String paramString2, boolean paramBoolean, int paramInt2, int paramInt3)
    throws RemoteException;

  public abstract void onEventDeleted(int paramInt1, int paramInt2, int paramInt3)
    throws RemoteException;

  public abstract void onEventUpdated(int paramInt1, int paramInt2, int paramInt3, long paramLong, int paramInt4)
    throws RemoteException;

  public abstract void onFinishedReload(int paramInt)
    throws RemoteException;

  public abstract void onFinishedReloadingBirthdays()
    throws RemoteException;

  public abstract void onFinishedUpdatingContact(int paramInt1, int paramInt2)
    throws RemoteException;

  public abstract void onStartedReload(int paramInt)
    throws RemoteException;

  public abstract void onStartedReloadingBirthdays()
    throws RemoteException;

  public abstract void onStartedUpdatingContact(int paramInt1, int paramInt2)
    throws RemoteException;

  public abstract void onStructuredNameUpdated(int paramInt, String paramString1, String paramString2)
    throws RemoteException;

  public abstract class Stub extends Binder
    implements IContactsServiceCallback
  {
    private static final String DESCRIPTOR = "com.spb.contacts.IContactsServiceCallback";
    static final int TRANSACTION_onBirthdayDeleted = 3;
    static final int TRANSACTION_onBirthdayUpdated = 2;
    static final int TRANSACTION_onConnectionDeleted = 8;
    static final int TRANSACTION_onConnectionUpdated = 13;
    static final int TRANSACTION_onContactDeleted = 6;
    static final int TRANSACTION_onContactPhotoUpdated = 5;
    static final int TRANSACTION_onContactUpdated = 10;
    static final int TRANSACTION_onEventDeleted = 7;
    static final int TRANSACTION_onEventUpdated = 14;
    static final int TRANSACTION_onFinishedReload = 16;
    static final int TRANSACTION_onFinishedReloadingBirthdays = 4;
    static final int TRANSACTION_onFinishedUpdatingContact = 12;
    static final int TRANSACTION_onStartedReload = 15;
    static final int TRANSACTION_onStartedReloadingBirthdays = 1;
    static final int TRANSACTION_onStartedUpdatingContact = 9;
    static final int TRANSACTION_onStructuredNameUpdated = 11;

    public Stub()
    {
      attachInterface(this, "com.spb.contacts.IContactsServiceCallback");
    }

    public static IContactsServiceCallback asInterface(IBinder paramIBinder)
    {
      Object localObject;
      if (paramIBinder == null)
        localObject = null;
      while (true)
      {
        return localObject;
        localObject = paramIBinder.queryLocalInterface("com.spb.contacts.IContactsServiceCallback");
        if ((localObject != null) && ((localObject instanceof IContactsServiceCallback)))
        {
          localObject = (IContactsServiceCallback)localObject;
          continue;
        }
        localObject = new Proxy();
      }
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      boolean bool;
      switch (paramInt1)
      {
      default:
        bool = super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
      case 14:
      case 15:
      case 16:
      }
      while (true)
      {
        return bool;
        paramParcel2.writeString("com.spb.contacts.IContactsServiceCallback");
        bool = true;
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsServiceCallback");
        onStartedReloadingBirthdays();
        paramParcel2.writeNoException();
        bool = true;
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsServiceCallback");
        int i = paramParcel1.readInt();
        int j = paramParcel1.readInt();
        int k = paramParcel1.readInt();
        int m = paramParcel1.readInt();
        int n = paramParcel1.readInt();
        int i1 = paramParcel1.readInt();
        onBirthdayUpdated(i, j, k, m, n, i1);
        paramParcel2.writeNoException();
        bool = true;
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsServiceCallback");
        int i2 = paramParcel1.readInt();
        onBirthdayDeleted(i2);
        paramParcel2.writeNoException();
        bool = true;
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsServiceCallback");
        onFinishedReloadingBirthdays();
        paramParcel2.writeNoException();
        bool = true;
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsServiceCallback");
        int i3 = paramParcel1.readInt();
        int i4 = paramParcel1.readInt();
        int i5 = paramParcel1.readInt();
        onContactPhotoUpdated(i3, i4, i5);
        paramParcel2.writeNoException();
        bool = true;
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsServiceCallback");
        int i6 = paramParcel1.readInt();
        int i7 = paramParcel1.readInt();
        onContactDeleted(i6, i7);
        paramParcel2.writeNoException();
        bool = true;
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsServiceCallback");
        int i8 = paramParcel1.readInt();
        int i9 = paramParcel1.readInt();
        int i10 = paramParcel1.readInt();
        onEventDeleted(i8, i9, i10);
        paramParcel2.writeNoException();
        bool = true;
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsServiceCallback");
        int i11 = paramParcel1.readInt();
        int i12 = paramParcel1.readInt();
        int i13 = paramParcel1.readInt();
        onConnectionDeleted(i11, i12, i13);
        paramParcel2.writeNoException();
        bool = true;
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsServiceCallback");
        int i14 = paramParcel1.readInt();
        int i15 = paramParcel1.readInt();
        onStartedUpdatingContact(i14, i15);
        paramParcel2.writeNoException();
        bool = true;
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsServiceCallback");
        int i16 = paramParcel1.readInt();
        String str1 = paramParcel1.readString();
        String str2 = paramParcel1.readString();
        if (paramParcel1.readInt() != 0);
        int i18;
        for (int i17 = 1; ; i18 = 0)
        {
          int i19 = paramParcel1.readInt();
          int i20 = paramParcel1.readInt();
          onContactUpdated(i16, str1, str2, i17, i19, i20);
          paramParcel2.writeNoException();
          bool = true;
          break;
        }
        paramParcel1.enforceInterface("com.spb.contacts.IContactsServiceCallback");
        int i21 = paramParcel1.readInt();
        String str3 = paramParcel1.readString();
        String str4 = paramParcel1.readString();
        onStructuredNameUpdated(i21, str3, str4);
        paramParcel2.writeNoException();
        bool = true;
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsServiceCallback");
        int i22 = paramParcel1.readInt();
        int i23 = paramParcel1.readInt();
        onFinishedUpdatingContact(i22, i23);
        paramParcel2.writeNoException();
        bool = true;
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsServiceCallback");
        int i24 = paramParcel1.readInt();
        int i25 = paramParcel1.readInt();
        String str5 = paramParcel1.readString();
        int i26 = paramParcel1.readInt();
        String str6 = paramParcel1.readString();
        String str7 = paramParcel1.readString();
        int i27 = paramParcel1.readInt();
        onConnectionUpdated(i24, i25, str5, i26, str6, str7, i27);
        paramParcel2.writeNoException();
        bool = true;
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsServiceCallback");
        int i28 = paramParcel1.readInt();
        int i29 = paramParcel1.readInt();
        int i30 = paramParcel1.readInt();
        long l = paramParcel1.readLong();
        int i31 = paramParcel1.readInt();
        Stub localStub = this;
        int i32 = i28;
        int i33 = i29;
        int i34 = i30;
        int i35 = i31;
        localStub.onEventUpdated(i32, i33, i34, l, i35);
        paramParcel2.writeNoException();
        bool = true;
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsServiceCallback");
        int i36 = paramParcel1.readInt();
        onStartedReload(i36);
        paramParcel2.writeNoException();
        bool = true;
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsServiceCallback");
        int i37 = paramParcel1.readInt();
        onFinishedReload(i37);
        paramParcel2.writeNoException();
        bool = true;
      }
    }

    class Proxy
      implements IContactsServiceCallback
    {
      Proxy()
      {
      }

      public IBinder asBinder()
      {
        return IContactsServiceCallback.Stub.this;
      }

      public String getInterfaceDescriptor()
      {
        return "com.spb.contacts.IContactsServiceCallback";
      }

      public void onBirthdayDeleted(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsServiceCallback");
          localParcel1.writeInt(paramInt);
          boolean bool = IContactsServiceCallback.Stub.this.transact(3, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void onBirthdayUpdated(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsServiceCallback");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          localParcel1.writeInt(paramInt3);
          localParcel1.writeInt(paramInt4);
          localParcel1.writeInt(paramInt5);
          localParcel1.writeInt(paramInt6);
          boolean bool = IContactsServiceCallback.Stub.this.transact(2, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void onConnectionDeleted(int paramInt1, int paramInt2, int paramInt3)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsServiceCallback");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          localParcel1.writeInt(paramInt3);
          boolean bool = IContactsServiceCallback.Stub.this.transact(8, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void onConnectionUpdated(int paramInt1, int paramInt2, String paramString1, int paramInt3, String paramString2, String paramString3, int paramInt4)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsServiceCallback");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          localParcel1.writeString(paramString1);
          localParcel1.writeInt(paramInt3);
          localParcel1.writeString(paramString2);
          localParcel1.writeString(paramString3);
          localParcel1.writeInt(paramInt4);
          boolean bool = IContactsServiceCallback.Stub.this.transact(13, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void onContactDeleted(int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsServiceCallback");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          boolean bool = IContactsServiceCallback.Stub.this.transact(6, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void onContactPhotoUpdated(int paramInt1, int paramInt2, int paramInt3)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsServiceCallback");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          localParcel1.writeInt(paramInt3);
          boolean bool = IContactsServiceCallback.Stub.this.transact(5, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void onContactUpdated(int paramInt1, String paramString1, String paramString2, boolean paramBoolean, int paramInt2, int paramInt3)
        throws RemoteException
      {
        int i = 0;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsServiceCallback");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeString(paramString1);
          localParcel1.writeString(paramString2);
          if (paramBoolean)
            i = 1;
          localParcel1.writeInt(i);
          localParcel1.writeInt(paramInt2);
          localParcel1.writeInt(paramInt3);
          boolean bool = IContactsServiceCallback.Stub.this.transact(10, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void onEventDeleted(int paramInt1, int paramInt2, int paramInt3)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsServiceCallback");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          localParcel1.writeInt(paramInt3);
          boolean bool = IContactsServiceCallback.Stub.this.transact(7, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void onEventUpdated(int paramInt1, int paramInt2, int paramInt3, long paramLong, int paramInt4)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsServiceCallback");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          localParcel1.writeInt(paramInt3);
          localParcel1.writeLong(paramLong);
          localParcel1.writeInt(paramInt4);
          boolean bool = IContactsServiceCallback.Stub.this.transact(14, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void onFinishedReload(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsServiceCallback");
          localParcel1.writeInt(paramInt);
          boolean bool = IContactsServiceCallback.Stub.this.transact(16, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void onFinishedReloadingBirthdays()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsServiceCallback");
          boolean bool = IContactsServiceCallback.Stub.this.transact(4, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void onFinishedUpdatingContact(int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsServiceCallback");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          boolean bool = IContactsServiceCallback.Stub.this.transact(12, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void onStartedReload(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsServiceCallback");
          localParcel1.writeInt(paramInt);
          boolean bool = IContactsServiceCallback.Stub.this.transact(15, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void onStartedReloadingBirthdays()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsServiceCallback");
          boolean bool = IContactsServiceCallback.Stub.this.transact(1, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void onStartedUpdatingContact(int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsServiceCallback");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          boolean bool = IContactsServiceCallback.Stub.this.transact(9, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void onStructuredNameUpdated(int paramInt, String paramString1, String paramString2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsServiceCallback");
          localParcel1.writeInt(paramInt);
          localParcel1.writeString(paramString1);
          localParcel1.writeString(paramString2);
          boolean bool = IContactsServiceCallback.Stub.this.transact(11, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.IContactsServiceCallback
 * JD-Core Version:    0.6.0
 */