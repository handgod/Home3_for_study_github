package com.spb.contacts;

import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;

class ContactsCallbacksHelper
{
  private final RemoteCallbackList<IContactsServiceCallback> callbackList;
  private int callbacksCount;

  ContactsCallbacksHelper()
  {
    RemoteCallbackList localRemoteCallbackList = new RemoteCallbackList();
    this.callbackList = localRemoteCallbackList;
    this.callbacksCount = 0;
  }

  /** @deprecated */
  boolean hasRegisteredCallbacks()
  {
    monitorenter;
    try
    {
      int i = this.callbacksCount;
      if (i > 0)
      {
        i = 1;
        return i;
      }
      i = 0;
    }
    finally
    {
      monitorexit;
    }
  }

  /** @deprecated */
  // ERROR //
  void notifyBirthdayDeleted(int paramInt)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   6: invokevirtual 31	android/os/RemoteCallbackList:beginBroadcast	()I
    //   9: istore_2
    //   10: iload_2
    //   11: istore_3
    //   12: iconst_0
    //   13: istore 4
    //   15: iload 4
    //   17: iload_3
    //   18: if_icmpge +30 -> 48
    //   21: aload_0
    //   22: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   25: iload 4
    //   27: invokevirtual 35	android/os/RemoteCallbackList:getBroadcastItem	(I)Landroid/os/IInterface;
    //   30: checkcast 37	com/spb/contacts/IContactsServiceCallback
    //   33: iload_1
    //   34: invokeinterface 40 2 0
    //   39: iload 4
    //   41: iconst_1
    //   42: iadd
    //   43: istore 4
    //   45: goto -30 -> 15
    //   48: aload_0
    //   49: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   52: invokevirtual 43	android/os/RemoteCallbackList:finishBroadcast	()V
    //   55: aload_0
    //   56: monitorexit
    //   57: return
    //   58: astore 5
    //   60: aload_0
    //   61: monitorexit
    //   62: aload 5
    //   64: athrow
    //   65: astore 6
    //   67: goto -28 -> 39
    //
    // Exception table:
    //   from	to	target	type
    //   2	10	58	finally
    //   21	39	58	finally
    //   48	55	58	finally
    //   21	39	65	android/os/RemoteException
  }

  /** @deprecated */
  // ERROR //
  void notifyBirthdayUpdated(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   6: invokevirtual 31	android/os/RemoteCallbackList:beginBroadcast	()I
    //   9: istore 7
    //   11: iload 7
    //   13: istore 8
    //   15: iconst_0
    //   16: istore 9
    //   18: iload 9
    //   20: iload 8
    //   22: if_icmpge +66 -> 88
    //   25: aload_0
    //   26: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   29: iload 9
    //   31: invokevirtual 35	android/os/RemoteCallbackList:getBroadcastItem	(I)Landroid/os/IInterface;
    //   34: checkcast 37	com/spb/contacts/IContactsServiceCallback
    //   37: astore 10
    //   39: iload_1
    //   40: istore 11
    //   42: iload_2
    //   43: istore 12
    //   45: iload_3
    //   46: istore 13
    //   48: iload 4
    //   50: istore 14
    //   52: iload 5
    //   54: istore 15
    //   56: iload 6
    //   58: istore 16
    //   60: aload 10
    //   62: iload 11
    //   64: iload 12
    //   66: iload 13
    //   68: iload 14
    //   70: iload 15
    //   72: iload 16
    //   74: invokeinterface 48 7 0
    //   79: iload 9
    //   81: iconst_1
    //   82: iadd
    //   83: istore 9
    //   85: goto -67 -> 18
    //   88: aload_0
    //   89: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   92: invokevirtual 43	android/os/RemoteCallbackList:finishBroadcast	()V
    //   95: aload_0
    //   96: monitorexit
    //   97: return
    //   98: astore 17
    //   100: aload_0
    //   101: monitorexit
    //   102: aload 17
    //   104: athrow
    //   105: astore 18
    //   107: goto -28 -> 79
    //
    // Exception table:
    //   from	to	target	type
    //   2	11	98	finally
    //   25	79	98	finally
    //   88	95	98	finally
    //   25	79	105	android/os/RemoteException
  }

  /** @deprecated */
  // ERROR //
  void notifyConnectionDeleted(int paramInt1, int paramInt2, int paramInt3)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   6: invokevirtual 31	android/os/RemoteCallbackList:beginBroadcast	()I
    //   9: istore 4
    //   11: iload 4
    //   13: istore 5
    //   15: iconst_0
    //   16: istore 6
    //   18: iload 6
    //   20: iload 5
    //   22: if_icmpge +32 -> 54
    //   25: aload_0
    //   26: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   29: iload 6
    //   31: invokevirtual 35	android/os/RemoteCallbackList:getBroadcastItem	(I)Landroid/os/IInterface;
    //   34: checkcast 37	com/spb/contacts/IContactsServiceCallback
    //   37: iload_1
    //   38: iload_2
    //   39: iload_3
    //   40: invokeinterface 53 4 0
    //   45: iload 6
    //   47: iconst_1
    //   48: iadd
    //   49: istore 6
    //   51: goto -33 -> 18
    //   54: aload_0
    //   55: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   58: invokevirtual 43	android/os/RemoteCallbackList:finishBroadcast	()V
    //   61: aload_0
    //   62: monitorexit
    //   63: return
    //   64: astore 7
    //   66: aload_0
    //   67: monitorexit
    //   68: aload 7
    //   70: athrow
    //   71: astore 8
    //   73: goto -28 -> 45
    //
    // Exception table:
    //   from	to	target	type
    //   2	11	64	finally
    //   25	45	64	finally
    //   54	61	64	finally
    //   25	45	71	android/os/RemoteException
  }

  /** @deprecated */
  // ERROR //
  void notifyConnectionUpdated(int paramInt1, int paramInt2, String paramString1, int paramInt3, String paramString2, String paramString3, int paramInt4)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   6: invokevirtual 31	android/os/RemoteCallbackList:beginBroadcast	()I
    //   9: istore 8
    //   11: iload 8
    //   13: istore 9
    //   15: iconst_0
    //   16: istore 10
    //   18: iload 10
    //   20: iload 9
    //   22: if_icmpge +72 -> 94
    //   25: aload_0
    //   26: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   29: iload 10
    //   31: invokevirtual 35	android/os/RemoteCallbackList:getBroadcastItem	(I)Landroid/os/IInterface;
    //   34: checkcast 37	com/spb/contacts/IContactsServiceCallback
    //   37: astore 11
    //   39: iload_1
    //   40: istore 12
    //   42: iload_2
    //   43: istore 13
    //   45: aload_3
    //   46: astore 14
    //   48: iload 4
    //   50: istore 15
    //   52: aload 5
    //   54: astore 16
    //   56: aload 6
    //   58: astore 17
    //   60: iload 7
    //   62: istore 18
    //   64: aload 11
    //   66: iload 12
    //   68: iload 13
    //   70: aload 14
    //   72: iload 15
    //   74: aload 16
    //   76: aload 17
    //   78: iload 18
    //   80: invokeinterface 58 8 0
    //   85: iload 10
    //   87: iconst_1
    //   88: iadd
    //   89: istore 10
    //   91: goto -73 -> 18
    //   94: aload_0
    //   95: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   98: invokevirtual 43	android/os/RemoteCallbackList:finishBroadcast	()V
    //   101: aload_0
    //   102: monitorexit
    //   103: return
    //   104: astore 19
    //   106: aload_0
    //   107: monitorexit
    //   108: aload 19
    //   110: athrow
    //   111: astore 20
    //   113: goto -28 -> 85
    //
    // Exception table:
    //   from	to	target	type
    //   2	11	104	finally
    //   25	85	104	finally
    //   94	101	104	finally
    //   25	85	111	android/os/RemoteException
  }

  /** @deprecated */
  // ERROR //
  void notifyContactDeleted(int paramInt1, int paramInt2)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   6: invokevirtual 31	android/os/RemoteCallbackList:beginBroadcast	()I
    //   9: istore_3
    //   10: iload_3
    //   11: istore 4
    //   13: iconst_0
    //   14: istore 5
    //   16: iload 5
    //   18: iload 4
    //   20: if_icmpge +31 -> 51
    //   23: aload_0
    //   24: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   27: iload 5
    //   29: invokevirtual 35	android/os/RemoteCallbackList:getBroadcastItem	(I)Landroid/os/IInterface;
    //   32: checkcast 37	com/spb/contacts/IContactsServiceCallback
    //   35: iload_1
    //   36: iload_2
    //   37: invokeinterface 63 3 0
    //   42: iload 5
    //   44: iconst_1
    //   45: iadd
    //   46: istore 5
    //   48: goto -32 -> 16
    //   51: aload_0
    //   52: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   55: invokevirtual 43	android/os/RemoteCallbackList:finishBroadcast	()V
    //   58: aload_0
    //   59: monitorexit
    //   60: return
    //   61: astore 6
    //   63: aload_0
    //   64: monitorexit
    //   65: aload 6
    //   67: athrow
    //   68: astore 7
    //   70: goto -28 -> 42
    //
    // Exception table:
    //   from	to	target	type
    //   2	10	61	finally
    //   23	42	61	finally
    //   51	58	61	finally
    //   23	42	68	android/os/RemoteException
  }

  /** @deprecated */
  // ERROR //
  void notifyContactPhotoUpdated(int paramInt1, int paramInt2, int paramInt3)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   6: invokevirtual 31	android/os/RemoteCallbackList:beginBroadcast	()I
    //   9: istore 4
    //   11: iload 4
    //   13: istore 5
    //   15: iconst_0
    //   16: istore 6
    //   18: iload 6
    //   20: iload 5
    //   22: if_icmpge +32 -> 54
    //   25: aload_0
    //   26: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   29: iload 6
    //   31: invokevirtual 35	android/os/RemoteCallbackList:getBroadcastItem	(I)Landroid/os/IInterface;
    //   34: checkcast 37	com/spb/contacts/IContactsServiceCallback
    //   37: iload_1
    //   38: iload_2
    //   39: iload_3
    //   40: invokeinterface 67 4 0
    //   45: iload 6
    //   47: iconst_1
    //   48: iadd
    //   49: istore 6
    //   51: goto -33 -> 18
    //   54: aload_0
    //   55: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   58: invokevirtual 43	android/os/RemoteCallbackList:finishBroadcast	()V
    //   61: aload_0
    //   62: monitorexit
    //   63: return
    //   64: astore 7
    //   66: aload_0
    //   67: monitorexit
    //   68: aload 7
    //   70: athrow
    //   71: astore 8
    //   73: goto -28 -> 45
    //
    // Exception table:
    //   from	to	target	type
    //   2	11	64	finally
    //   25	45	64	finally
    //   54	61	64	finally
    //   25	45	71	android/os/RemoteException
  }

  /** @deprecated */
  void notifyContactUpdated(int paramInt1, String paramString1, String paramString2, boolean paramBoolean, int paramInt2, int paramInt3)
  {
    monitorenter;
    try
    {
      String str1 = "notifyContactUpdated: contactId=" + paramInt1 + " >>>";
      int i = Log.d("CallbacksHelper", str1);
      int j = this.callbackList.beginBroadcast();
      int k = j;
      int m = 0;
      while (true)
        if (m < k)
          try
          {
            IContactsServiceCallback localIContactsServiceCallback = (IContactsServiceCallback)this.callbackList.getBroadcastItem(m);
            int n = paramInt1;
            String str2 = paramString1;
            String str3 = paramString2;
            boolean bool = paramBoolean;
            int i1 = paramInt2;
            int i2 = paramInt3;
            localIContactsServiceCallback.onContactUpdated(n, str2, str3, bool, i1, i2);
            String str4 = "notifyContactUpdated: contactId=" + paramInt1 + " <<< done";
            int i3 = Log.d("CallbacksHelper", str4);
            m += 1;
          }
          catch (RemoteException localRemoteException)
          {
            while (true)
            {
              String str5 = "notifyContactUpdated: contactId=" + paramInt1 + " <<< error: " + localRemoteException;
              int i4 = Log.e("CallbacksHelper", str5, localRemoteException);
            }
          }
    }
    finally
    {
      monitorexit;
    }
    this.callbackList.finishBroadcast();
    monitorexit;
  }

  /** @deprecated */
  // ERROR //
  void notifyEventDeleted(int paramInt1, int paramInt2, int paramInt3)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   6: invokevirtual 31	android/os/RemoteCallbackList:beginBroadcast	()I
    //   9: istore 4
    //   11: iload 4
    //   13: istore 5
    //   15: iconst_0
    //   16: istore 6
    //   18: iload 6
    //   20: iload 5
    //   22: if_icmpge +32 -> 54
    //   25: aload_0
    //   26: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   29: iload 6
    //   31: invokevirtual 35	android/os/RemoteCallbackList:getBroadcastItem	(I)Landroid/os/IInterface;
    //   34: checkcast 37	com/spb/contacts/IContactsServiceCallback
    //   37: iload_1
    //   38: iload_2
    //   39: iload_3
    //   40: invokeinterface 113 4 0
    //   45: iload 6
    //   47: iconst_1
    //   48: iadd
    //   49: istore 6
    //   51: goto -33 -> 18
    //   54: aload_0
    //   55: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   58: invokevirtual 43	android/os/RemoteCallbackList:finishBroadcast	()V
    //   61: aload_0
    //   62: monitorexit
    //   63: return
    //   64: astore 7
    //   66: aload_0
    //   67: monitorexit
    //   68: aload 7
    //   70: athrow
    //   71: astore 8
    //   73: goto -28 -> 45
    //
    // Exception table:
    //   from	to	target	type
    //   2	11	64	finally
    //   25	45	64	finally
    //   54	61	64	finally
    //   25	45	71	android/os/RemoteException
  }

  /** @deprecated */
  // ERROR //
  void notifyEventUpdated(int paramInt1, int paramInt2, int paramInt3, android.text.format.Time paramTime, int paramInt4)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   6: invokevirtual 31	android/os/RemoteCallbackList:beginBroadcast	()I
    //   9: istore 6
    //   11: iload 6
    //   13: istore 7
    //   15: iconst_0
    //   16: istore 8
    //   18: iload 8
    //   20: iload 7
    //   22: if_icmpge +69 -> 91
    //   25: ldc 116
    //   27: istore 9
    //   29: aload 4
    //   31: iload 9
    //   33: invokevirtual 122	android/text/format/Time:toMillis	(Z)J
    //   36: lstore 10
    //   38: aload_0
    //   39: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   42: iload 8
    //   44: invokevirtual 35	android/os/RemoteCallbackList:getBroadcastItem	(I)Landroid/os/IInterface;
    //   47: checkcast 37	com/spb/contacts/IContactsServiceCallback
    //   50: astore 12
    //   52: iload_1
    //   53: istore 13
    //   55: iload_2
    //   56: istore 14
    //   58: iload_3
    //   59: istore 15
    //   61: iload 5
    //   63: istore 16
    //   65: aload 12
    //   67: iload 13
    //   69: iload 14
    //   71: iload 15
    //   73: lload 10
    //   75: iload 16
    //   77: invokeinterface 126 7 0
    //   82: iload 8
    //   84: iconst_1
    //   85: iadd
    //   86: istore 8
    //   88: goto -70 -> 18
    //   91: aload_0
    //   92: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   95: invokevirtual 43	android/os/RemoteCallbackList:finishBroadcast	()V
    //   98: aload_0
    //   99: monitorexit
    //   100: return
    //   101: astore 17
    //   103: aload_0
    //   104: monitorexit
    //   105: aload 17
    //   107: athrow
    //   108: astore 18
    //   110: goto -28 -> 82
    //
    // Exception table:
    //   from	to	target	type
    //   2	11	101	finally
    //   29	82	101	finally
    //   91	98	101	finally
    //   29	82	108	android/os/RemoteException
  }

  /** @deprecated */
  // ERROR //
  void notifyFinishedReload(int paramInt)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   6: invokevirtual 31	android/os/RemoteCallbackList:beginBroadcast	()I
    //   9: istore_2
    //   10: iload_2
    //   11: istore_3
    //   12: iconst_0
    //   13: istore 4
    //   15: iload 4
    //   17: iload_3
    //   18: if_icmpge +30 -> 48
    //   21: aload_0
    //   22: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   25: iload 4
    //   27: invokevirtual 35	android/os/RemoteCallbackList:getBroadcastItem	(I)Landroid/os/IInterface;
    //   30: checkcast 37	com/spb/contacts/IContactsServiceCallback
    //   33: iload_1
    //   34: invokeinterface 130 2 0
    //   39: iload 4
    //   41: iconst_1
    //   42: iadd
    //   43: istore 4
    //   45: goto -30 -> 15
    //   48: aload_0
    //   49: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   52: invokevirtual 43	android/os/RemoteCallbackList:finishBroadcast	()V
    //   55: aload_0
    //   56: monitorexit
    //   57: return
    //   58: astore 5
    //   60: aload_0
    //   61: monitorexit
    //   62: aload 5
    //   64: athrow
    //   65: astore 6
    //   67: goto -28 -> 39
    //
    // Exception table:
    //   from	to	target	type
    //   2	10	58	finally
    //   21	39	58	finally
    //   48	55	58	finally
    //   21	39	65	android/os/RemoteException
  }

  /** @deprecated */
  // ERROR //
  void notifyFinishedReloadingBirthdays()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   6: invokevirtual 31	android/os/RemoteCallbackList:beginBroadcast	()I
    //   9: istore_1
    //   10: iload_1
    //   11: istore_2
    //   12: iconst_0
    //   13: istore_3
    //   14: iload_3
    //   15: iload_2
    //   16: if_icmpge +26 -> 42
    //   19: aload_0
    //   20: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   23: iload_3
    //   24: invokevirtual 35	android/os/RemoteCallbackList:getBroadcastItem	(I)Landroid/os/IInterface;
    //   27: checkcast 37	com/spb/contacts/IContactsServiceCallback
    //   30: invokeinterface 134 1 0
    //   35: iload_3
    //   36: iconst_1
    //   37: iadd
    //   38: istore_3
    //   39: goto -25 -> 14
    //   42: aload_0
    //   43: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   46: invokevirtual 43	android/os/RemoteCallbackList:finishBroadcast	()V
    //   49: aload_0
    //   50: monitorexit
    //   51: return
    //   52: astore 4
    //   54: aload_0
    //   55: monitorexit
    //   56: aload 4
    //   58: athrow
    //   59: astore 5
    //   61: goto -26 -> 35
    //
    // Exception table:
    //   from	to	target	type
    //   2	10	52	finally
    //   19	35	52	finally
    //   42	49	52	finally
    //   19	35	59	android/os/RemoteException
  }

  /** @deprecated */
  // ERROR //
  void notifyFinishedUpdatingContact(int paramInt1, int paramInt2)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   6: invokevirtual 31	android/os/RemoteCallbackList:beginBroadcast	()I
    //   9: istore_3
    //   10: iload_3
    //   11: istore 4
    //   13: iconst_0
    //   14: istore 5
    //   16: iload 5
    //   18: iload 4
    //   20: if_icmpge +31 -> 51
    //   23: aload_0
    //   24: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   27: iload 5
    //   29: invokevirtual 35	android/os/RemoteCallbackList:getBroadcastItem	(I)Landroid/os/IInterface;
    //   32: checkcast 37	com/spb/contacts/IContactsServiceCallback
    //   35: iload_1
    //   36: iload_2
    //   37: invokeinterface 138 3 0
    //   42: iload 5
    //   44: iconst_1
    //   45: iadd
    //   46: istore 5
    //   48: goto -32 -> 16
    //   51: aload_0
    //   52: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   55: invokevirtual 43	android/os/RemoteCallbackList:finishBroadcast	()V
    //   58: aload_0
    //   59: monitorexit
    //   60: return
    //   61: astore 6
    //   63: aload_0
    //   64: monitorexit
    //   65: aload 6
    //   67: athrow
    //   68: astore 7
    //   70: goto -28 -> 42
    //
    // Exception table:
    //   from	to	target	type
    //   2	10	61	finally
    //   23	42	61	finally
    //   51	58	61	finally
    //   23	42	68	android/os/RemoteException
  }

  /** @deprecated */
  // ERROR //
  void notifyStartedReload(int paramInt)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   6: invokevirtual 31	android/os/RemoteCallbackList:beginBroadcast	()I
    //   9: istore_2
    //   10: iload_2
    //   11: istore_3
    //   12: iconst_0
    //   13: istore 4
    //   15: iload 4
    //   17: iload_3
    //   18: if_icmpge +30 -> 48
    //   21: aload_0
    //   22: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   25: iload 4
    //   27: invokevirtual 35	android/os/RemoteCallbackList:getBroadcastItem	(I)Landroid/os/IInterface;
    //   30: checkcast 37	com/spb/contacts/IContactsServiceCallback
    //   33: iload_1
    //   34: invokeinterface 142 2 0
    //   39: iload 4
    //   41: iconst_1
    //   42: iadd
    //   43: istore 4
    //   45: goto -30 -> 15
    //   48: aload_0
    //   49: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   52: invokevirtual 43	android/os/RemoteCallbackList:finishBroadcast	()V
    //   55: aload_0
    //   56: monitorexit
    //   57: return
    //   58: astore 5
    //   60: aload_0
    //   61: monitorexit
    //   62: aload 5
    //   64: athrow
    //   65: astore 6
    //   67: goto -28 -> 39
    //
    // Exception table:
    //   from	to	target	type
    //   2	10	58	finally
    //   21	39	58	finally
    //   48	55	58	finally
    //   21	39	65	android/os/RemoteException
  }

  /** @deprecated */
  // ERROR //
  void notifyStartedReloadingBirthdays()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   6: invokevirtual 31	android/os/RemoteCallbackList:beginBroadcast	()I
    //   9: istore_1
    //   10: iload_1
    //   11: istore_2
    //   12: iconst_0
    //   13: istore_3
    //   14: iload_3
    //   15: iload_2
    //   16: if_icmpge +26 -> 42
    //   19: aload_0
    //   20: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   23: iload_3
    //   24: invokevirtual 35	android/os/RemoteCallbackList:getBroadcastItem	(I)Landroid/os/IInterface;
    //   27: checkcast 37	com/spb/contacts/IContactsServiceCallback
    //   30: invokeinterface 146 1 0
    //   35: iload_3
    //   36: iconst_1
    //   37: iadd
    //   38: istore_3
    //   39: goto -25 -> 14
    //   42: aload_0
    //   43: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   46: invokevirtual 43	android/os/RemoteCallbackList:finishBroadcast	()V
    //   49: aload_0
    //   50: monitorexit
    //   51: return
    //   52: astore 4
    //   54: aload_0
    //   55: monitorexit
    //   56: aload 4
    //   58: athrow
    //   59: astore 5
    //   61: goto -26 -> 35
    //
    // Exception table:
    //   from	to	target	type
    //   2	10	52	finally
    //   19	35	52	finally
    //   42	49	52	finally
    //   19	35	59	android/os/RemoteException
  }

  /** @deprecated */
  // ERROR //
  void notifyStartedUpdatingContact(int paramInt1, int paramInt2)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   6: invokevirtual 31	android/os/RemoteCallbackList:beginBroadcast	()I
    //   9: istore_3
    //   10: iload_3
    //   11: istore 4
    //   13: iconst_0
    //   14: istore 5
    //   16: iload 5
    //   18: iload 4
    //   20: if_icmpge +31 -> 51
    //   23: aload_0
    //   24: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   27: iload 5
    //   29: invokevirtual 35	android/os/RemoteCallbackList:getBroadcastItem	(I)Landroid/os/IInterface;
    //   32: checkcast 37	com/spb/contacts/IContactsServiceCallback
    //   35: iload_1
    //   36: iload_2
    //   37: invokeinterface 150 3 0
    //   42: iload 5
    //   44: iconst_1
    //   45: iadd
    //   46: istore 5
    //   48: goto -32 -> 16
    //   51: aload_0
    //   52: getfield 19	com/spb/contacts/ContactsCallbacksHelper:callbackList	Landroid/os/RemoteCallbackList;
    //   55: invokevirtual 43	android/os/RemoteCallbackList:finishBroadcast	()V
    //   58: aload_0
    //   59: monitorexit
    //   60: return
    //   61: astore 6
    //   63: aload_0
    //   64: monitorexit
    //   65: aload 6
    //   67: athrow
    //   68: astore 7
    //   70: goto -28 -> 42
    //
    // Exception table:
    //   from	to	target	type
    //   2	10	61	finally
    //   23	42	61	finally
    //   51	58	61	finally
    //   23	42	68	android/os/RemoteException
  }

  /** @deprecated */
  void notifyStructuredNameChanged(int paramInt, String paramString1, String paramString2)
  {
    monitorenter;
    try
    {
      String str1 = "notifyStructuredNameUpdated: contactId=" + paramInt + " firstName=" + paramString1 + " lastName=" + paramString2;
      int i = Log.d("CallbacksHelper", str1);
      int j = this.callbackList.beginBroadcast();
      int k = j;
      int m = 0;
      while (true)
        if (m < k)
          try
          {
            ((IContactsServiceCallback)this.callbackList.getBroadcastItem(m)).onStructuredNameUpdated(paramInt, paramString1, paramString2);
            String str2 = "notifyStructuredNameUpdated: contactId=" + paramInt + " <<< done";
            int n = Log.d("CallbacksHelper", str2);
            m += 1;
          }
          catch (RemoteException localRemoteException)
          {
            while (true)
            {
              String str3 = "notifyStructuredNameUpdated: contactId=" + paramInt + " <<< error: " + localRemoteException;
              int i1 = Log.e("CallbacksHelper", str3, localRemoteException);
            }
          }
    }
    finally
    {
      monitorexit;
    }
    this.callbackList.finishBroadcast();
    monitorexit;
  }

  /** @deprecated */
  void register(IContactsServiceCallback paramIContactsServiceCallback)
  {
    monitorenter;
    try
    {
      if (this.callbackList.register(paramIContactsServiceCallback))
      {
        int i = this.callbacksCount + 1;
        this.callbacksCount = i;
      }
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  /** @deprecated */
  void unregister(IContactsServiceCallback paramIContactsServiceCallback)
  {
    monitorenter;
    try
    {
      if (this.callbackList.unregister(paramIContactsServiceCallback))
      {
        int i = this.callbacksCount + -1;
        this.callbacksCount = i;
      }
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.ContactsCallbacksHelper
 * JD-Core Version:    0.6.0
 */