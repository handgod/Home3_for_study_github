package com.spb.contacts;

import android.telephony.PhoneNumberUtils;
import android.text.TextUtils;

class ConnectionEntry extends DataEntry
{
  final String address;
  final boolean isPhone;
  final String label;
  final int locationType;
  final String mimetype;

  ConnectionEntry(int paramInt1, int paramInt2, String paramString1, String paramString2, int paramInt3, String paramString3)
  {
    super(paramInt1, paramInt2);
    this.address = paramString1;
    this.mimetype = paramString2;
    boolean bool = "vnd.android.cursor.item/phone_v2".equals(paramString2);
    this.isPhone = bool;
    this.locationType = paramInt3;
    this.label = paramString3;
  }

  private boolean hasSameAddress(ConnectionEntry paramConnectionEntry)
  {
    boolean bool1 = this.isPhone;
    boolean bool2 = paramConnectionEntry.isPhone;
    if (bool1 != bool2)
    {
      int i = 0;
      return i;
    }
    String str1;
    String str2;
    if (this.isPhone)
    {
      str1 = this.address;
      str2 = paramConnectionEntry.address;
    }
    String str3;
    String str4;
    for (boolean bool3 = PhoneNumberUtils.compare(str1, str2); ; bool3 = TextUtils.equals(str3, str4))
    {
      break;
      str3 = this.address;
      str4 = paramConnectionEntry.address;
    }
  }

  public boolean equals(Object paramObject)
  {
    int i = 0;
    if (paramObject == null);
    while (true)
    {
      return i;
      Class localClass1 = paramObject.getClass();
      Class localClass2 = getClass();
      if (localClass1 != localClass2)
        continue;
      ConnectionEntry localConnectionEntry = (ConnectionEntry)paramObject;
      int j = this.id;
      int k = localConnectionEntry.id;
      if ((j != k) || (!hasSameAddress(localConnectionEntry)))
        continue;
      int m = this.locationType;
      int n = localConnectionEntry.locationType;
      if (m != n)
        continue;
      String str1 = this.label;
      String str2 = localConnectionEntry.label;
      if (!TextUtils.equals(str1, str2))
        continue;
      i = 1;
    }
  }

  boolean isDuplicate(DataEntry paramDataEntry)
  {
    int i = 0;
    if (paramDataEntry == null);
    while (true)
    {
      return i;
      Class localClass1 = paramDataEntry.getClass();
      Class localClass2 = getClass();
      if (localClass1 != localClass2)
        continue;
      ConnectionEntry localConnectionEntry = (ConnectionEntry)paramDataEntry;
      boolean bool = hasSameAddress(localConnectionEntry);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.ConnectionEntry
 * JD-Core Version:    0.6.0
 */