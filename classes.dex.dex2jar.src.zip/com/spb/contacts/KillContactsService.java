package com.spb.contacts;

import android.app.Service;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;

public class KillContactsService extends Service
{
  ServiceConnection connection;
  Logger logger;

  public KillContactsService()
  {
    KillContactsService.1 local1 = new KillContactsService.1(this);
    this.connection = local1;
    Logger localLogger = Loggers.getLogger(KillContactsService.class);
    this.logger = localLogger;
  }

  private void killContactsService()
  {
    this.logger.d("killContactsService >>>");
    String str1 = IGetPid.class.getName();
    Intent localIntent1 = new Intent(str1);
    String str2 = ContactsService.class.getName();
    Intent localIntent2 = localIntent1.setClassName(this, str2);
    ServiceConnection localServiceConnection = this.connection;
    boolean bool = bindService(localIntent1, localServiceConnection, 1);
    this.logger.d("killContactsService <<<");
  }

  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }

  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    killContactsService();
    return 2;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.KillContactsService
 * JD-Core Version:    0.6.0
 */