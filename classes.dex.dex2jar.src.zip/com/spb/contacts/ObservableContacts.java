package com.spb.contacts;

import android.database.Cursor;
import android.util.SparseArray;
import android.util.SparseIntArray;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;

abstract class ObservableContacts
  implements ContactsDataProjection
{
  private static final Logger logger = Loggers.getLogger(ContactsService.class);
  private final SparseIntArray contactIds;
  private final SparseIntArray deletedIds;
  private final SparseArray<String> displayNames;
  private final String logPrefix;
  private final SparseIntArray photoVersions;

  ObservableContacts(String paramString, SparseIntArray paramSparseIntArray)
  {
    SparseIntArray localSparseIntArray1 = new SparseIntArray();
    this.contactIds = localSparseIntArray1;
    SparseArray localSparseArray = new SparseArray();
    this.displayNames = localSparseArray;
    SparseIntArray localSparseIntArray2 = new SparseIntArray();
    this.deletedIds = localSparseIntArray2;
    String str = paramString + " ";
    this.logPrefix = str;
    this.photoVersions = paramSparseIntArray;
  }

  private void delete(int paramInt)
  {
    this.contactIds.delete(paramInt);
    this.displayNames.delete(paramInt);
    onContactDeleted(paramInt);
  }

  private void logd(String paramString)
  {
    Logger localLogger = logger;
    StringBuilder localStringBuilder = new StringBuilder();
    String str1 = this.logPrefix;
    String str2 = str1 + paramString;
    localLogger.d(str2);
  }

  private void loge(String paramString, Throwable paramThrowable)
  {
    Logger localLogger = logger;
    StringBuilder localStringBuilder = new StringBuilder();
    String str1 = this.logPrefix;
    String str2 = str1 + paramString;
    localLogger.e(str2, paramThrowable);
  }

  private void update(int paramInt1, String paramString1, String paramString2, boolean paramBoolean, int paramInt2, int paramInt3)
  {
    this.contactIds.put(paramInt1, 1);
    this.displayNames.put(paramInt1, paramString2);
    onContactUpdated(paramInt1, paramString1, paramString2, paramBoolean, paramInt2, paramInt3);
  }

  void finishReloading()
  {
    logd("finishReloading >>>");
    int i = this.deletedIds.size();
    int j = 0;
    while (j < i)
    {
      int k = this.deletedIds.keyAt(j);
      String str = "Contact has been deleted: id=" + k;
      logd(str);
      delete(k);
      j += 1;
    }
    logd("finishReloading <<<");
  }

  String getDisplayName(int paramInt)
  {
    return (String)this.displayNames.get(paramInt);
  }

  boolean hasContact(int paramInt)
  {
    if (this.contactIds.indexOfKey(paramInt) >= 0);
    for (int i = 1; ; i = 0)
      return i;
  }

  int loadContact(Cursor paramCursor)
  {
    int i = 1;
    int k = (int)paramCursor.getLong(0);
    String str1 = paramCursor.getString(i);
    if (paramCursor.getInt(7) == i);
    while (true)
    {
      String str2 = paramCursor.getString(6);
      int m = 0;
      int n = 8;
      try
      {
        String str3 = paramCursor.getString(n);
        if (str3 != null)
        {
          int i1 = Integer.parseInt(str3);
          m = i1;
        }
        label75: if (m == 0);
        for (int i2 = 0; ; i2 = this.photoVersions.get(m, 0))
        {
          update(k, str2, str1, i, m, i2);
          this.deletedIds.delete(k);
          return k;
          int j = 0;
          break;
        }
      }
      catch (NumberFormatException localNumberFormatException)
      {
        break label75;
      }
    }
  }

  abstract void onContactDeleted(int paramInt);

  abstract void onContactUpdated(int paramInt1, String paramString1, String paramString2, boolean paramBoolean, int paramInt2, int paramInt3);

  void startReloading()
  {
    logd("startReloading");
    this.deletedIds.clear();
    int i = this.contactIds.size();
    int j = 0;
    while (j < i)
    {
      int k = this.contactIds.keyAt(j);
      this.deletedIds.put(k, 1);
      j += 1;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.ObservableContacts
 * JD-Core Version:    0.6.0
 */