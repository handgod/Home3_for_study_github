package com.spb.contacts;

import android.database.Cursor;
import android.util.SparseArray;
import android.util.SparseIntArray;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.util.ArrayList;

abstract class ObservableData<T extends DataEntry>
  implements ContactsDataProjection
{
  private static final int RESULT_CHANGED_EVENT = 2;
  private static final int RESULT_DUPLICATE_EVENT = 1;
  private static final int RESULT_NEW_EVENT = 3;
  private static final int RESULT_NOT_CHANGED_EVENT;
  private static final Logger logger = Loggers.getLogger(ContactsService.class);
  final SparseIntArray data2Contact;
  final SparseArray<T> dataById;
  final SparseArray<ArrayList<T>> dataPerContact;
  final SparseIntArray dataVersions;
  final SparseIntArray deletedData;
  private final String logPrefix;
  final String[] mimetypes;

  ObservableData(String paramString, String[] paramArrayOfString)
  {
    SparseArray localSparseArray1 = new SparseArray();
    this.dataPerContact = localSparseArray1;
    SparseArray localSparseArray2 = new SparseArray();
    this.dataById = localSparseArray2;
    SparseIntArray localSparseIntArray1 = new SparseIntArray();
    this.dataVersions = localSparseIntArray1;
    SparseIntArray localSparseIntArray2 = new SparseIntArray();
    this.data2Contact = localSparseIntArray2;
    SparseIntArray localSparseIntArray3 = new SparseIntArray();
    this.deletedData = localSparseIntArray3;
    String str = paramString + " ";
    this.logPrefix = str;
    this.mimetypes = paramArrayOfString;
  }

  private int checkForDuplicatesAndInsert(T paramT, ArrayList<T> paramArrayList)
  {
    String str1 = "checkForDuplicatesAndInsert >>> data=" + paramT + " entries=" + paramArrayList;
    logd(str1);
    int i = paramArrayList.size();
    int j = 0;
    DataEntry localDataEntry;
    int n;
    if (j < i)
    {
      localDataEntry = (DataEntry)paramArrayList.get(j);
      int k = paramT.id;
      int m = localDataEntry.id;
      if (k == m)
        if (paramT.equals(localDataEntry))
        {
          String str2 = "checkForDuplicatesAndInsert <<< NOT CHANGED: " + localDataEntry;
          logd(str2);
          n = 0;
        }
    }
    while (true)
    {
      return n;
      String str3 = "checkForDuplicatesAndInsert <<< CHANGED: " + localDataEntry;
      logd(str3);
      Object localObject = paramArrayList.set(j, paramT);
      n = 2;
      continue;
      if (paramT.isDuplicate(localDataEntry))
      {
        String str4 = "checkForDuplicatesAndInsert <<< DUPLICATE: " + localDataEntry;
        logd(str4);
        n = 1;
        continue;
      }
      j += 1;
      break;
      logd("checkForDuplicatesAndInsert <<< NEW");
      boolean bool = paramArrayList.add(paramT);
      n = 3;
    }
  }

  private static boolean deleteDataEntry(int paramInt, ArrayList<? extends DataEntry> paramArrayList)
  {
    int i;
    if (paramArrayList == null)
      i = 0;
    while (true)
    {
      return i;
      int j = paramArrayList.size();
      int k = 0;
      while (true)
      {
        if (k >= j)
          break label60;
        if (((DataEntry)paramArrayList.get(k)).id == paramInt)
        {
          Object localObject = paramArrayList.remove(k);
          i = 1;
          break;
        }
        k += 1;
      }
      label60: i = 0;
    }
  }

  private void logd(String paramString)
  {
    Logger localLogger = logger;
    StringBuilder localStringBuilder = new StringBuilder();
    String str1 = this.logPrefix;
    String str2 = str1 + paramString;
    localLogger.d(str2);
  }

  private void loge(String paramString, Throwable paramThrowable)
  {
    Logger localLogger = logger;
    StringBuilder localStringBuilder = new StringBuilder();
    String str1 = this.logPrefix;
    String str2 = str1 + paramString;
    localLogger.e(str2, paramThrowable);
  }

  abstract T createDataFromRow(Cursor paramCursor);

  void deleteData(int paramInt1, int paramInt2)
  {
    ArrayList localArrayList = getEntriesForContact(paramInt2);
    boolean bool = deleteDataEntry(paramInt1, localArrayList);
    this.data2Contact.delete(paramInt1);
    this.dataVersions.delete(paramInt1);
    onDataDeleted(paramInt2, paramInt1);
  }

  void finishReloading()
  {
    int i = this.deletedData.size();
    int j = 0;
    while (j < i)
    {
      int k = this.deletedData.valueAt(j);
      if (!isContactDeleted(k))
      {
        int m = this.deletedData.keyAt(j);
        deleteData(m, k);
      }
      j += 1;
    }
  }

  ArrayList<T> getEntriesForContact(int paramInt)
  {
    ArrayList localArrayList = (ArrayList)this.dataPerContact.get(paramInt);
    if (localArrayList == null)
    {
      localArrayList = new ArrayList();
      this.dataPerContact.put(paramInt, localArrayList);
    }
    return localArrayList;
  }

  abstract boolean isContactDeleted(int paramInt);

  void loadRow(Cursor paramCursor, boolean paramBoolean, int paramInt)
  {
    int i = (int)paramCursor.getLong(9);
    int j = paramCursor.getInt(10);
    int k = this.dataVersions.get(i, -1);
    int m = this.data2Contact.get(i, -1);
    String str1 = "loadRow: dataId=" + i + " dataVersion=" + j + " storedVersion=" + k;
    logd(str1);
    if ((j != k) || (paramInt != m) || (paramBoolean));
    try
    {
      DataEntry localDataEntry = createDataFromRow(paramCursor);
      if (paramInt != m)
      {
        this.data2Contact.delete(i);
        ArrayList localArrayList1 = getEntriesForContact(m);
        boolean bool = deleteDataEntry(i, localArrayList1);
        onDataDeleted(m, i);
      }
      ArrayList localArrayList2 = getEntriesForContact(paramInt);
      int n = checkForDuplicatesAndInsert(localDataEntry, localArrayList2);
      if ((n != 1) && ((n == 3) || (n == 2) || (paramBoolean)))
        updateData(localDataEntry, paramInt);
      this.deletedData.delete(i);
      return;
    }
    catch (Exception localException)
    {
      while (true)
      {
        String str2 = "Failed to load data row: " + localException;
        loge(str2, localException);
        deleteData(i, paramInt);
      }
    }
  }

  abstract void onDataDeleted(int paramInt1, int paramInt2);

  abstract void onDataUpdated(int paramInt, T paramT);

  void startReloading()
  {
    this.deletedData.clear();
    int i = this.data2Contact.size();
    int j = 0;
    while (j < i)
    {
      int k = this.data2Contact.valueAt(j);
      if (!isContactDeleted(k))
      {
        int m = this.data2Contact.keyAt(j);
        this.deletedData.put(m, k);
      }
      j += 1;
    }
  }

  void updateData(T paramT, int paramInt)
  {
    int i = paramT.id;
    int j = paramT.version;
    this.dataVersions.put(i, j);
    this.dataById.put(i, paramT);
    this.data2Contact.put(i, paramInt);
    onDataUpdated(paramInt, paramT);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.ObservableData
 * JD-Core Version:    0.6.0
 */