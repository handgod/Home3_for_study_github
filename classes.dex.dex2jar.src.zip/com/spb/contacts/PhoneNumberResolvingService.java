package com.spb.contacts;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.os.SystemClock;
import android.provider.ContactsContract.Contacts;
import android.provider.ContactsContract.Data;
import android.provider.ContactsContract.PhoneLookup;
import android.text.TextUtils;
import android.util.SparseArray;
import android.util.SparseIntArray;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

class PhoneNumberResolvingService
  implements ContactsServiceConstants
{
  private static final String[] CONTACT_PHONE_LOOKUP_PROJECTION = ;
  private static final String[] DATA_PROJECTION = ;
  private static final int INDEX_CONTACT_LOOKUP_KEY = 1;
  private static final int INDEX_DATA_CONTACT_ID = 1;
  private static final int INDEX_DATA_DATA_ID = 0;
  private static final int INDEX_DATA_ID = 0;
  private static final int INDEX_DATA_NUMBER = 3;
  private static final int INDEX_DATA_VERSION = 2;
  static final int MSG_DATA_CHANGED = 2;
  static final int MSG_DO_NOTIFY_LISTENERS = 5;
  static final int MSG_DO_RELOAD_PHONES = 3;
  static final int MSG_DO_RESOLVE_UNRESOLVED = 4;
  static final int MSG_NEW_PHONE_NUMBER = 1;
  private static final String SELECTION_PHONES;
  static final Logger logger;
  final PhoneNumberCallbacksHelper callbacksHelper;
  final SparseIntArray contactIdByPhoneId;
  final ContactsService contactsService;
  private ContentResolver contentResolver;
  final SparseIntArray dataVersions;
  private PhonesObserver observer;
  final SparseArray<ArrayList<String>> phoneNumbersByContactId;
  final ConcurrentHashMap<String, PhoneLookupResult> resolvedNumbers;
  ResolverHandler resolverHandler;
  final Set<String> unresolvedNumbers;

  static
  {
    String[] arrayOfString1 = new String[2];
    arrayOfString1[0] = "_id";
    arrayOfString1[1] = "lookup";
    CONTACT_PHONE_LOOKUP_PROJECTION = arrayOfString1;
    String[] arrayOfString2 = new String[4];
    arrayOfString2[0] = "_id";
    arrayOfString2[1] = "contact_id";
    arrayOfString2[2] = "data_version";
    arrayOfString2[3] = "data1";
    DATA_PROJECTION = arrayOfString2;
    SELECTION_PHONES = "mimetype" + "='" + "vnd.android.cursor.item/phone_v2" + 39;
    logger = Loggers.getLogger(PhoneNumberResolvingService.class.getName());
  }

  PhoneNumberResolvingService(ContactsService paramContactsService)
  {
    ConcurrentHashMap localConcurrentHashMap = new ConcurrentHashMap();
    this.resolvedNumbers = localConcurrentHashMap;
    Set localSet = Collections.synchronizedSet(new HashSet());
    this.unresolvedNumbers = localSet;
    SparseArray localSparseArray = new SparseArray();
    this.phoneNumbersByContactId = localSparseArray;
    SparseIntArray localSparseIntArray1 = new SparseIntArray();
    this.contactIdByPhoneId = localSparseIntArray1;
    SparseIntArray localSparseIntArray2 = new SparseIntArray();
    this.dataVersions = localSparseIntArray2;
    PhoneNumberCallbacksHelper localPhoneNumberCallbacksHelper = new PhoneNumberCallbacksHelper();
    this.callbacksHelper = localPhoneNumberCallbacksHelper;
    this.contactsService = paramContactsService;
    ContentResolver localContentResolver1 = paramContactsService.getContentResolver();
    this.contentResolver = localContentResolver1;
    HandlerThread localHandlerThread = new HandlerThread("PhoneNumberResolverService");
    localHandlerThread.start();
    Looper localLooper = localHandlerThread.getLooper();
    ResolverHandler localResolverHandler1 = new ResolverHandler(localLooper);
    this.resolverHandler = localResolverHandler1;
    ResolverHandler localResolverHandler2 = this.resolverHandler;
    PhonesObserver localPhonesObserver1 = new PhonesObserver();
    this.observer = localPhonesObserver1;
    ContentResolver localContentResolver2 = this.contentResolver;
    Uri localUri = ContactsContract.Data.CONTENT_URI;
    PhonesObserver localPhonesObserver2 = this.observer;
    localContentResolver2.registerContentObserver(localUri, 1, localPhonesObserver2);
    doReloadPhones();
  }

  /** @deprecated */
  // ERROR //
  private void doReloadPhones()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: invokestatic 219	android/os/SystemClock:uptimeMillis	()J
    //   5: lstore_1
    //   6: getstatic 121	com/spb/contacts/PhoneNumberResolvingService:logger	Lcom/softspb/util/log/Logger;
    //   9: ldc 221
    //   11: invokevirtual 226	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   14: new 146	android/util/SparseIntArray
    //   17: dup
    //   18: invokespecial 147	android/util/SparseIntArray:<init>	()V
    //   21: astore_3
    //   22: aload_0
    //   23: getfield 149	com/spb/contacts/PhoneNumberResolvingService:contactIdByPhoneId	Landroid/util/SparseIntArray;
    //   26: invokevirtual 230	android/util/SparseIntArray:size	()I
    //   29: istore 4
    //   31: iconst_0
    //   32: istore 5
    //   34: iload 5
    //   36: iload 4
    //   38: if_icmpge +58 -> 96
    //   41: aload_0
    //   42: getfield 149	com/spb/contacts/PhoneNumberResolvingService:contactIdByPhoneId	Landroid/util/SparseIntArray;
    //   45: astore 6
    //   47: iload 5
    //   49: istore 7
    //   51: aload 6
    //   53: iload 7
    //   55: invokevirtual 234	android/util/SparseIntArray:keyAt	(I)I
    //   58: istore 8
    //   60: aload_0
    //   61: getfield 149	com/spb/contacts/PhoneNumberResolvingService:contactIdByPhoneId	Landroid/util/SparseIntArray;
    //   64: astore 9
    //   66: iload 5
    //   68: istore 10
    //   70: aload 9
    //   72: iload 10
    //   74: invokevirtual 237	android/util/SparseIntArray:valueAt	(I)I
    //   77: istore 11
    //   79: aload_3
    //   80: iload 8
    //   82: iload 11
    //   84: invokevirtual 241	android/util/SparseIntArray:put	(II)V
    //   87: iload 5
    //   89: iconst_1
    //   90: iadd
    //   91: istore 5
    //   93: goto -59 -> 34
    //   96: iconst_0
    //   97: istore 12
    //   99: new 243	java/util/ArrayList
    //   102: dup
    //   103: invokespecial 244	java/util/ArrayList:<init>	()V
    //   106: astore 13
    //   108: aload_0
    //   109: getfield 166	com/spb/contacts/PhoneNumberResolvingService:contentResolver	Landroid/content/ContentResolver;
    //   112: astore 14
    //   114: getstatic 196	android/provider/ContactsContract$Data:CONTENT_URI	Landroid/net/Uri;
    //   117: astore 15
    //   119: getstatic 83	com/spb/contacts/PhoneNumberResolvingService:DATA_PROJECTION	[Ljava/lang/String;
    //   122: astore 16
    //   124: getstatic 108	com/spb/contacts/PhoneNumberResolvingService:SELECTION_PHONES	Ljava/lang/String;
    //   127: astore 17
    //   129: aload 14
    //   131: aload 15
    //   133: aload 16
    //   135: aload 17
    //   137: aconst_null
    //   138: aconst_null
    //   139: invokevirtual 248	android/content/ContentResolver:query	(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   142: astore 18
    //   144: aload 18
    //   146: ifnull +583 -> 729
    //   149: aload 18
    //   151: invokeinterface 254 1 0
    //   156: ifeq +573 -> 729
    //   159: aload 18
    //   161: invokeinterface 257 1 0
    //   166: ifne +563 -> 729
    //   169: aload 18
    //   171: iconst_0
    //   172: invokeinterface 261 2 0
    //   177: l2i
    //   178: istore 19
    //   180: aload 18
    //   182: iconst_1
    //   183: invokeinterface 261 2 0
    //   188: l2i
    //   189: istore 20
    //   191: aload 18
    //   193: iconst_2
    //   194: invokeinterface 264 2 0
    //   199: istore 21
    //   201: aload_3
    //   202: iload 19
    //   204: invokevirtual 268	android/util/SparseIntArray:delete	(I)V
    //   207: aload_0
    //   208: getfield 151	com/spb/contacts/PhoneNumberResolvingService:dataVersions	Landroid/util/SparseIntArray;
    //   211: iload 19
    //   213: bipush 255
    //   215: invokevirtual 272	android/util/SparseIntArray:get	(II)I
    //   218: istore 22
    //   220: aload_0
    //   221: getfield 149	com/spb/contacts/PhoneNumberResolvingService:contactIdByPhoneId	Landroid/util/SparseIntArray;
    //   224: iload 19
    //   226: bipush 255
    //   228: invokevirtual 272	android/util/SparseIntArray:get	(II)I
    //   231: istore 23
    //   233: iload 23
    //   235: bipush 255
    //   237: if_icmpne +258 -> 495
    //   240: aload 18
    //   242: iconst_3
    //   243: invokeinterface 276 2 0
    //   248: astore 24
    //   250: getstatic 121	com/spb/contacts/PhoneNumberResolvingService:logger	Lcom/softspb/util/log/Logger;
    //   253: astore 25
    //   255: new 85	java/lang/StringBuilder
    //   258: dup
    //   259: invokespecial 88	java/lang/StringBuilder:<init>	()V
    //   262: ldc_w 278
    //   265: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   268: iload 19
    //   270: invokevirtual 281	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   273: ldc_w 283
    //   276: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   279: iload 20
    //   281: invokevirtual 281	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   284: ldc_w 285
    //   287: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   290: astore 26
    //   292: aload 24
    //   294: astore 27
    //   296: aload 26
    //   298: aload 27
    //   300: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   303: invokevirtual 106	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   306: astore 28
    //   308: aload 25
    //   310: aload 28
    //   312: invokevirtual 226	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   315: aload 24
    //   317: invokestatic 291	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   320: ifne +65 -> 385
    //   323: iconst_1
    //   324: istore 12
    //   326: aload_0
    //   327: astore 29
    //   329: aload 24
    //   331: astore 30
    //   333: aload 29
    //   335: aload 30
    //   337: invokevirtual 295	com/spb/contacts/PhoneNumberResolvingService:getResolvedContactId	(Ljava/lang/String;)J
    //   340: lstore 31
    //   342: lload 31
    //   344: ldc2_w 296
    //   347: lcmp
    //   348: ifeq +37 -> 385
    //   351: lload 31
    //   353: invokestatic 303	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   356: astore 33
    //   358: aload 13
    //   360: aload 33
    //   362: invokevirtual 307	java/util/ArrayList:contains	(Ljava/lang/Object;)Z
    //   365: ifne +20 -> 385
    //   368: lload 31
    //   370: l2i
    //   371: invokestatic 312	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   374: astore 34
    //   376: aload 13
    //   378: aload 34
    //   380: invokevirtual 315	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   383: istore 35
    //   385: aload_0
    //   386: getfield 149	com/spb/contacts/PhoneNumberResolvingService:contactIdByPhoneId	Landroid/util/SparseIntArray;
    //   389: iload 19
    //   391: iload 20
    //   393: invokevirtual 241	android/util/SparseIntArray:put	(II)V
    //   396: aload_0
    //   397: getfield 151	com/spb/contacts/PhoneNumberResolvingService:dataVersions	Landroid/util/SparseIntArray;
    //   400: iload 19
    //   402: iload 21
    //   404: invokevirtual 241	android/util/SparseIntArray:put	(II)V
    //   407: aload 18
    //   409: invokeinterface 318 1 0
    //   414: istore 36
    //   416: goto -257 -> 159
    //   419: astore 37
    //   421: aload 18
    //   423: ifnull +10 -> 433
    //   426: aload 18
    //   428: invokeinterface 321 1 0
    //   433: getstatic 121	com/spb/contacts/PhoneNumberResolvingService:logger	Lcom/softspb/util/log/Logger;
    //   436: astore 38
    //   438: new 85	java/lang/StringBuilder
    //   441: dup
    //   442: invokespecial 88	java/lang/StringBuilder:<init>	()V
    //   445: ldc_w 323
    //   448: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   451: astore 39
    //   453: invokestatic 219	android/os/SystemClock:uptimeMillis	()J
    //   456: lload_1
    //   457: lsub
    //   458: lstore 40
    //   460: aload 39
    //   462: lload 40
    //   464: invokevirtual 326	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   467: ldc_w 328
    //   470: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   473: invokevirtual 106	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   476: astore 42
    //   478: aload 38
    //   480: aload 42
    //   482: invokevirtual 226	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   485: aload 37
    //   487: athrow
    //   488: astore 43
    //   490: aload_0
    //   491: monitorexit
    //   492: aload 43
    //   494: athrow
    //   495: iload 22
    //   497: iload 21
    //   499: if_icmpeq +118 -> 617
    //   502: getstatic 121	com/spb/contacts/PhoneNumberResolvingService:logger	Lcom/softspb/util/log/Logger;
    //   505: astore 44
    //   507: new 85	java/lang/StringBuilder
    //   510: dup
    //   511: invokespecial 88	java/lang/StringBuilder:<init>	()V
    //   514: ldc_w 330
    //   517: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   520: iload 19
    //   522: invokevirtual 281	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   525: ldc_w 283
    //   528: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   531: iload 20
    //   533: invokevirtual 281	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   536: ldc_w 332
    //   539: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   542: iload 21
    //   544: invokevirtual 281	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   547: ldc_w 334
    //   550: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   553: astore 45
    //   555: iload 22
    //   557: istore 46
    //   559: aload 45
    //   561: iload 46
    //   563: invokevirtual 281	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   566: invokevirtual 106	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   569: astore 47
    //   571: aload 44
    //   573: aload 47
    //   575: invokevirtual 226	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   578: iconst_1
    //   579: istore 12
    //   581: iload 23
    //   583: invokestatic 312	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   586: astore 48
    //   588: aload 13
    //   590: aload 48
    //   592: invokevirtual 307	java/util/ArrayList:contains	(Ljava/lang/Object;)Z
    //   595: ifne -210 -> 385
    //   598: iload 20
    //   600: invokestatic 312	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   603: astore 49
    //   605: aload 13
    //   607: aload 49
    //   609: invokevirtual 315	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   612: istore 50
    //   614: goto -229 -> 385
    //   617: iload 23
    //   619: istore 51
    //   621: iload 20
    //   623: iload 51
    //   625: if_icmpeq -240 -> 385
    //   628: getstatic 121	com/spb/contacts/PhoneNumberResolvingService:logger	Lcom/softspb/util/log/Logger;
    //   631: astore 52
    //   633: new 85	java/lang/StringBuilder
    //   636: dup
    //   637: invokespecial 88	java/lang/StringBuilder:<init>	()V
    //   640: ldc_w 336
    //   643: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   646: iload 19
    //   648: invokevirtual 281	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   651: ldc_w 283
    //   654: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   657: iload 20
    //   659: invokevirtual 281	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   662: ldc_w 338
    //   665: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   668: astore 53
    //   670: iload 23
    //   672: istore 54
    //   674: aload 53
    //   676: iload 54
    //   678: invokevirtual 281	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   681: invokevirtual 106	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   684: astore 55
    //   686: aload 52
    //   688: aload 55
    //   690: invokevirtual 226	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   693: iload 23
    //   695: invokestatic 312	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   698: astore 56
    //   700: aload 13
    //   702: aload 56
    //   704: invokevirtual 307	java/util/ArrayList:contains	(Ljava/lang/Object;)Z
    //   707: ifne -322 -> 385
    //   710: iload 23
    //   712: invokestatic 312	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   715: astore 57
    //   717: aload 13
    //   719: aload 57
    //   721: invokevirtual 315	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   724: istore 58
    //   726: goto -341 -> 385
    //   729: aload_3
    //   730: invokevirtual 230	android/util/SparseIntArray:size	()I
    //   733: istore 59
    //   735: iconst_0
    //   736: istore 5
    //   738: iload 5
    //   740: iload 59
    //   742: if_icmpge +116 -> 858
    //   745: iload 5
    //   747: istore 60
    //   749: aload_3
    //   750: iload 60
    //   752: invokevirtual 234	android/util/SparseIntArray:keyAt	(I)I
    //   755: istore 61
    //   757: iload 5
    //   759: istore 62
    //   761: aload_3
    //   762: iload 62
    //   764: invokevirtual 237	android/util/SparseIntArray:valueAt	(I)I
    //   767: istore 63
    //   769: getstatic 121	com/spb/contacts/PhoneNumberResolvingService:logger	Lcom/softspb/util/log/Logger;
    //   772: astore 64
    //   774: new 85	java/lang/StringBuilder
    //   777: dup
    //   778: invokespecial 88	java/lang/StringBuilder:<init>	()V
    //   781: ldc_w 340
    //   784: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   787: iload 61
    //   789: invokevirtual 281	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   792: ldc_w 283
    //   795: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   798: iload 63
    //   800: invokevirtual 281	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   803: invokevirtual 106	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   806: astore 65
    //   808: aload 64
    //   810: aload 65
    //   812: invokevirtual 226	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   815: aload_0
    //   816: getfield 149	com/spb/contacts/PhoneNumberResolvingService:contactIdByPhoneId	Landroid/util/SparseIntArray;
    //   819: iload 61
    //   821: invokevirtual 268	android/util/SparseIntArray:delete	(I)V
    //   824: aload_0
    //   825: getfield 151	com/spb/contacts/PhoneNumberResolvingService:dataVersions	Landroid/util/SparseIntArray;
    //   828: iload 61
    //   830: invokevirtual 268	android/util/SparseIntArray:delete	(I)V
    //   833: iload 63
    //   835: invokestatic 312	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   838: astore 66
    //   840: aload 13
    //   842: aload 66
    //   844: invokevirtual 315	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   847: istore 67
    //   849: iload 5
    //   851: iconst_1
    //   852: iadd
    //   853: istore 5
    //   855: goto -117 -> 738
    //   858: aload 13
    //   860: invokevirtual 341	java/util/ArrayList:size	()I
    //   863: istore 68
    //   865: iload 68
    //   867: ifle +247 -> 1114
    //   870: iconst_0
    //   871: istore 5
    //   873: iload 5
    //   875: istore 69
    //   877: iload 68
    //   879: istore 70
    //   881: iload 69
    //   883: iload 70
    //   885: if_icmpge +229 -> 1114
    //   888: aload 13
    //   890: astore 71
    //   892: iload 5
    //   894: istore 72
    //   896: aload 71
    //   898: iload 72
    //   900: invokevirtual 344	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   903: checkcast 309	java/lang/Integer
    //   906: invokevirtual 347	java/lang/Integer:intValue	()I
    //   909: istore 20
    //   911: aload_0
    //   912: getfield 144	com/spb/contacts/PhoneNumberResolvingService:phoneNumbersByContactId	Landroid/util/SparseArray;
    //   915: iload 20
    //   917: invokevirtual 348	android/util/SparseArray:get	(I)Ljava/lang/Object;
    //   920: checkcast 243	java/util/ArrayList
    //   923: astore 73
    //   925: getstatic 121	com/spb/contacts/PhoneNumberResolvingService:logger	Lcom/softspb/util/log/Logger;
    //   928: astore 74
    //   930: new 85	java/lang/StringBuilder
    //   933: dup
    //   934: invokespecial 88	java/lang/StringBuilder:<init>	()V
    //   937: ldc_w 350
    //   940: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   943: iload 20
    //   945: invokevirtual 281	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   948: ldc_w 352
    //   951: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   954: astore 75
    //   956: aload 73
    //   958: ifnonnull +125 -> 1083
    //   961: ldc_w 354
    //   964: astore 37
    //   966: aload 75
    //   968: aload 37
    //   970: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   973: invokevirtual 106	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   976: astore 76
    //   978: aload 74
    //   980: aload 76
    //   982: invokevirtual 226	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   985: aload_0
    //   986: iload 20
    //   988: invokespecial 357	com/spb/contacts/PhoneNumberResolvingService:postNotifyListeners	(I)V
    //   991: aload 73
    //   993: ifnull +103 -> 1096
    //   996: aload 73
    //   998: invokevirtual 341	java/util/ArrayList:size	()I
    //   1001: istore 77
    //   1003: iconst_0
    //   1004: istore 78
    //   1006: iload 78
    //   1008: istore 79
    //   1010: iload 77
    //   1012: istore 80
    //   1014: iload 79
    //   1016: iload 80
    //   1018: if_icmpge +78 -> 1096
    //   1021: aload 73
    //   1023: astore 81
    //   1025: iload 78
    //   1027: istore 82
    //   1029: aload 81
    //   1031: iload 82
    //   1033: invokevirtual 344	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   1036: checkcast 69	java/lang/String
    //   1039: astore 83
    //   1041: aload_0
    //   1042: getfield 128	com/spb/contacts/PhoneNumberResolvingService:resolvedNumbers	Ljava/util/concurrent/ConcurrentHashMap;
    //   1045: astore 84
    //   1047: aload 83
    //   1049: astore 85
    //   1051: aload 84
    //   1053: aload 85
    //   1055: invokevirtual 361	java/util/concurrent/ConcurrentHashMap:remove	(Ljava/lang/Object;)Ljava/lang/Object;
    //   1058: astore 86
    //   1060: aload_0
    //   1061: astore 87
    //   1063: aload 83
    //   1065: astore 88
    //   1067: aload 87
    //   1069: aload 88
    //   1071: invokespecial 364	com/spb/contacts/PhoneNumberResolvingService:postResolveNumber	(Ljava/lang/String;)V
    //   1074: iload 78
    //   1076: iconst_1
    //   1077: iadd
    //   1078: istore 78
    //   1080: goto -74 -> 1006
    //   1083: aload 73
    //   1085: invokevirtual 368	java/util/ArrayList:toArray	()[Ljava/lang/Object;
    //   1088: invokestatic 373	java/util/Arrays:toString	([Ljava/lang/Object;)Ljava/lang/String;
    //   1091: astore 37
    //   1093: goto -127 -> 966
    //   1096: aload_0
    //   1097: getfield 144	com/spb/contacts/PhoneNumberResolvingService:phoneNumbersByContactId	Landroid/util/SparseArray;
    //   1100: iload 20
    //   1102: invokevirtual 375	android/util/SparseArray:remove	(I)V
    //   1105: iload 5
    //   1107: iconst_1
    //   1108: iadd
    //   1109: istore 5
    //   1111: goto -238 -> 873
    //   1114: iload 12
    //   1116: ifeq +37 -> 1153
    //   1119: getstatic 121	com/spb/contacts/PhoneNumberResolvingService:logger	Lcom/softspb/util/log/Logger;
    //   1122: ldc_w 377
    //   1125: invokevirtual 226	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   1128: aload_0
    //   1129: getfield 185	com/spb/contacts/PhoneNumberResolvingService:resolverHandler	Lcom/spb/contacts/PhoneNumberResolvingService$ResolverHandler;
    //   1132: astore 89
    //   1134: aload_0
    //   1135: getfield 185	com/spb/contacts/PhoneNumberResolvingService:resolverHandler	Lcom/spb/contacts/PhoneNumberResolvingService$ResolverHandler;
    //   1138: iconst_4
    //   1139: invokestatic 383	android/os/Message:obtain	(Landroid/os/Handler;I)Landroid/os/Message;
    //   1142: astore 90
    //   1144: aload 89
    //   1146: aload 90
    //   1148: invokevirtual 387	com/spb/contacts/PhoneNumberResolvingService$ResolverHandler:sendMessage	(Landroid/os/Message;)Z
    //   1151: istore 91
    //   1153: aload 18
    //   1155: ifnull +10 -> 1165
    //   1158: aload 18
    //   1160: invokeinterface 321 1 0
    //   1165: getstatic 121	com/spb/contacts/PhoneNumberResolvingService:logger	Lcom/softspb/util/log/Logger;
    //   1168: astore 92
    //   1170: new 85	java/lang/StringBuilder
    //   1173: dup
    //   1174: invokespecial 88	java/lang/StringBuilder:<init>	()V
    //   1177: ldc_w 323
    //   1180: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1183: astore 93
    //   1185: invokestatic 219	android/os/SystemClock:uptimeMillis	()J
    //   1188: lload_1
    //   1189: lsub
    //   1190: lstore 94
    //   1192: aload 93
    //   1194: lload 94
    //   1196: invokevirtual 326	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   1199: ldc_w 328
    //   1202: invokevirtual 94	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1205: invokevirtual 106	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   1208: astore 96
    //   1210: aload 92
    //   1212: aload 96
    //   1214: invokevirtual 226	com/softspb/util/log/Logger:d	(Ljava/lang/String;)V
    //   1217: aload_0
    //   1218: monitorexit
    //   1219: return
    //   1220: astore 97
    //   1222: goto -57 -> 1165
    //   1225: astore 98
    //   1227: goto -794 -> 433
    //
    // Exception table:
    //   from	to	target	type
    //   108	416	419	finally
    //   502	1153	419	finally
    //   2	108	488	finally
    //   426	433	488	finally
    //   433	488	488	finally
    //   1158	1165	488	finally
    //   1165	1217	488	finally
    //   1158	1165	1220	java/lang/Exception
    //   426	433	1225	java/lang/Exception
  }

  private void doResolveUnresolvedNumbers()
  {
    long l1 = SystemClock.uptimeMillis();
    Set localSet = this.unresolvedNumbers;
    String[] arrayOfString1 = new String[this.unresolvedNumbers.size()];
    String[] arrayOfString2 = (String[])localSet.toArray(arrayOfString1);
    Logger localLogger1 = logger;
    StringBuilder localStringBuilder1 = new StringBuilder().append("doResolveUnresolvedNumbers >>> numbers=");
    String str1 = Arrays.toString(arrayOfString2);
    String str2 = str1;
    localLogger1.d(str2);
    int i = arrayOfString2.length;
    int j = 0;
    while (j < i)
    {
      String str3 = arrayOfString2[j];
      boolean bool = this.unresolvedNumbers.remove(str3);
      doResolvePhoneNumber(str3);
      j += 1;
    }
    Logger localLogger2 = logger;
    StringBuilder localStringBuilder2 = new StringBuilder().append("doResolveUnresolvedNumbers <<< completed in");
    long l2 = SystemClock.uptimeMillis() - l1;
    String str4 = l2 + "ms";
    localLogger2.d(str4);
  }

  private void onNotResolved(String paramString)
  {
    Logger localLogger = logger;
    ??? = "onNotResolved: number=" + paramString;
    localLogger.d((String)???);
    boolean bool1 = this.unresolvedNumbers.add(paramString);
    PhoneLookupResult localPhoneLookupResult = (PhoneLookupResult)this.resolvedNumbers.remove(paramString);
    int i;
    if (localPhoneLookupResult != null)
    {
      i = (int)localPhoneLookupResult.contactId;
      postNotifyListeners(i);
    }
    synchronized (this.phoneNumbersByContactId)
    {
      ArrayList localArrayList = (ArrayList)this.phoneNumbersByContactId.get(i);
      if (localArrayList != null)
      {
        boolean bool2 = localArrayList.remove(paramString);
        if (localArrayList.size() == 0)
          this.phoneNumbersByContactId.remove(i);
      }
      return;
    }
  }

  private void onResolved(String paramString, PhoneLookupResult paramPhoneLookupResult)
  {
    Logger localLogger = logger;
    StringBuilder localStringBuilder1 = new StringBuilder().append("onResolved: number=").append(paramString).append(" contactId=");
    long l1 = paramPhoneLookupResult.contactId;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(l1).append(" dataId=");
    long l2 = paramPhoneLookupResult.dataId;
    String str = l2;
    localLogger.d(str);
    Object localObject1 = this.resolvedNumbers.put(paramString, paramPhoneLookupResult);
    boolean bool1 = this.unresolvedNumbers.remove(paramString);
    int i = (int)paramPhoneLookupResult.contactId;
    postNotifyListeners(i);
    synchronized (this.phoneNumbersByContactId)
    {
      ArrayList localArrayList = (ArrayList)this.phoneNumbersByContactId.get(i);
      if (localArrayList == null)
      {
        localArrayList = new ArrayList();
        this.phoneNumbersByContactId.put(i, localArrayList);
      }
      if (!localArrayList.contains(paramString))
        boolean bool2 = localArrayList.add(paramString);
      return;
    }
  }

  private void postNotifyListeners(int paramInt)
  {
    Integer localInteger = Integer.valueOf(paramInt);
    if (!this.resolverHandler.hasMessages(5, localInteger))
    {
      ResolverHandler localResolverHandler = this.resolverHandler;
      Message localMessage = Message.obtain(this.resolverHandler, 5, localInteger);
      boolean bool = localResolverHandler.sendMessage(localMessage);
    }
  }

  private void postResolveNumber(String paramString)
  {
    String str1 = paramString.intern();
    if (!this.resolverHandler.hasMessages(1, str1))
    {
      Logger localLogger1 = logger;
      String str2 = "postResolveNumber: adding phone number to resolver queue: " + paramString;
      localLogger1.d(str2);
      ResolverHandler localResolverHandler = this.resolverHandler;
      Message localMessage = Message.obtain(this.resolverHandler, 1, str1);
      boolean bool = localResolverHandler.sendMessage(localMessage);
    }
    while (true)
    {
      return;
      Logger localLogger2 = logger;
      String str3 = "postResolveNumber: phone number already in queue: " + paramString;
      localLogger2.d(str3);
    }
  }

  public void addPhoneNumber(String paramString)
  {
    if (this.resolvedNumbers.containsKey(paramString))
    {
      Logger localLogger1 = logger;
      String str1 = "addPhoneNumber: phoneNumber=" + paramString + ": already resolved";
      localLogger1.d(str1);
    }
    while (true)
    {
      return;
      if (this.unresolvedNumbers.contains(paramString))
      {
        Logger localLogger2 = logger;
        String str2 = "addPhoneNumber: phoneNumber=" + paramString + ": already unresolved";
        localLogger2.d(str2);
        continue;
      }
      postResolveNumber(paramString);
    }
  }

  void doResolvePhoneNumber(String paramString)
  {
    Logger localLogger = logger;
    String str = "doResolvePhoneNumber: " + paramString;
    localLogger.d(str);
    PhoneLookupResult localPhoneLookupResult = lookup(paramString);
    if (localPhoneLookupResult != null)
      onResolved(paramString, localPhoneLookupResult);
    while (true)
    {
      return;
      onNotResolved(paramString);
    }
  }

  public long getResolvedContactId(String paramString)
  {
    long l = 0L;
    if (TextUtils.isEmpty(paramString));
    while (true)
    {
      return l;
      PhoneLookupResult localPhoneLookupResult = (PhoneLookupResult)this.resolvedNumbers.get(paramString);
      if (localPhoneLookupResult == null)
        continue;
      l = localPhoneLookupResult.contactId;
    }
  }

  List<String> getResolvedPhoneNumbers(int paramInt)
  {
    synchronized (this.phoneNumbersByContactId)
    {
      List localList = (List)this.phoneNumbersByContactId.get(paramInt);
      return localList;
    }
  }

  PhoneLookupResult lookup(String paramString)
  {
    PhoneLookupResult localPhoneLookupResult;
    if (paramString != null)
    {
      String str1 = paramString;
      if (!"".equals(str1));
    }
    else
    {
      localPhoneLookupResult = null;
    }
    while (true)
    {
      return localPhoneLookupResult;
      try
      {
        Uri localUri1 = ContactsContract.PhoneLookup.CONTENT_FILTER_URI;
        String str2 = Uri.encode(paramString);
        Uri localUri2 = Uri.withAppendedPath(localUri1, str2);
        ContentResolver localContentResolver = this.contentResolver;
        String[] arrayOfString = CONTACT_PHONE_LOOKUP_PROJECTION;
        localCursor = localContentResolver.query(localUri2, arrayOfString, null, null, null);
        if ((localCursor != null) && (localCursor.moveToFirst()))
        {
          String str3 = localCursor.getString(1);
          long l1 = localCursor.getLong(0);
          localCursor.close();
          Uri localUri3 = ContactsContract.Contacts.getLookupUri(0L, str3);
          Uri localUri4 = ContactsContract.Contacts.lookupContact(this.contentResolver, localUri3);
          if (localUri4 != null)
          {
            long l2 = ContentUris.parseId(localUri4);
            localPhoneLookupResult = new PhoneLookupResult();
            localPhoneLookupResult.contactId = l2;
            localPhoneLookupResult.dataId = l1;
            if ((localCursor == null) || (localCursor.isClosed()))
              continue;
            localCursor.close();
            continue;
          }
        }
        if ((localCursor != null) && (!localCursor.isClosed()))
          localCursor.close();
        localPhoneLookupResult = null;
      }
      finally
      {
        Cursor localCursor;
        if ((localCursor != null) && (!localCursor.isClosed()))
          localCursor.close();
      }
    }
  }

  public long lookupContactId(String paramString)
  {
    PhoneLookupResult localPhoneLookupResult = lookup(paramString);
    long l;
    if (localPhoneLookupResult == null)
      l = 0L;
    while (true)
    {
      return l;
      l = localPhoneLookupResult.contactId;
    }
  }

  void registerCallback(IPhoneNumberResolvingServiceCallback paramIPhoneNumberResolvingServiceCallback)
    throws RemoteException
  {
    if (paramIPhoneNumberResolvingServiceCallback != null)
      this.callbacksHelper.register(paramIPhoneNumberResolvingServiceCallback);
  }

  public void removePhoneNumber(String paramString)
  {
    ResolverHandler localResolverHandler = this.resolverHandler;
    String str = paramString.intern();
    localResolverHandler.removeMessages(1, str);
    Object localObject = this.resolvedNumbers.remove(paramString);
    boolean bool = this.unresolvedNumbers.remove(paramString);
  }

  void stop()
  {
    ContentResolver localContentResolver = this.contentResolver;
    PhonesObserver localPhonesObserver = this.observer;
    localContentResolver.unregisterContentObserver(localPhonesObserver);
    this.resolverHandler.removeCallbacksAndMessages(null);
    this.resolverHandler.getLooper().quit();
  }

  void unregisterCallback(IPhoneNumberResolvingServiceCallback paramIPhoneNumberResolvingServiceCallback)
    throws RemoteException
  {
    if (paramIPhoneNumberResolvingServiceCallback != null)
      this.callbacksHelper.unregister(paramIPhoneNumberResolvingServiceCallback);
  }

  class PhonesObserver extends ContentObserver
  {
    public PhonesObserver()
    {
      super();
    }

    public void onChange(boolean paramBoolean)
    {
      Handler localHandler = PhoneNumberResolvingService.this;
      Message localMessage = Message.obtain(PhoneNumberResolvingService.this, 2);
      boolean bool = localHandler.sendMessageAtFrontOfQueue(localMessage);
    }
  }

  class ResolverHandler extends Handler
  {
    public ResolverHandler(Looper arg2)
    {
      super();
    }

    public void handleMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      }
      while (true)
      {
        return;
        PhoneNumberResolvingService localPhoneNumberResolvingService = PhoneNumberResolvingService.this;
        String str = (String)paramMessage.obj;
        localPhoneNumberResolvingService.doResolvePhoneNumber(str);
        continue;
        Message localMessage = Message.obtain(this, 3);
        boolean bool = sendMessageDelayed(localMessage, 1000L);
        continue;
        if (hasMessages(3))
          continue;
        PhoneNumberResolvingService.this.doReloadPhones();
        continue;
        PhoneNumberResolvingService.this.doResolveUnresolvedNumbers();
        continue;
        PhoneNumberCallbacksHelper localPhoneNumberCallbacksHelper = PhoneNumberResolvingService.this.callbacksHelper;
        int i = ((Integer)paramMessage.obj).intValue();
        localPhoneNumberCallbacksHelper.notifyResolvedPhonesChanged(i);
      }
    }
  }

  public class PhoneLookupResult
  {
    long contactId;
    long dataId;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.PhoneNumberResolvingService
 * JD-Core Version:    0.6.0
 */