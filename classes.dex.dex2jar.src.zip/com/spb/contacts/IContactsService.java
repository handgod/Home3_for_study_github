package com.spb.contacts;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract interface IContactsService extends IInterface
{
  public abstract void crash()
    throws RemoteException;

  public abstract void registerCallback(IContactsServiceCallback paramIContactsServiceCallback)
    throws RemoteException;

  public abstract void reloadBirthdays(int paramInt, boolean paramBoolean)
    throws RemoteException;

  public abstract void reloadContact(int paramInt)
    throws RemoteException;

  public abstract void reloadContacts(int paramInt)
    throws RemoteException;

  public abstract void unregisterCallback(IContactsServiceCallback paramIContactsServiceCallback)
    throws RemoteException;

  public abstract class Stub extends Binder
    implements IContactsService
  {
    private static final String DESCRIPTOR = "com.spb.contacts.IContactsService";
    static final int TRANSACTION_crash = 6;
    static final int TRANSACTION_registerCallback = 4;
    static final int TRANSACTION_reloadBirthdays = 1;
    static final int TRANSACTION_reloadContact = 3;
    static final int TRANSACTION_reloadContacts = 2;
    static final int TRANSACTION_unregisterCallback = 5;

    public Stub()
    {
      attachInterface(this, "com.spb.contacts.IContactsService");
    }

    public static IContactsService asInterface(IBinder paramIBinder)
    {
      Object localObject;
      if (paramIBinder == null)
        localObject = null;
      while (true)
      {
        return localObject;
        localObject = paramIBinder.queryLocalInterface("com.spb.contacts.IContactsService");
        if ((localObject != null) && ((localObject instanceof IContactsService)))
        {
          localObject = (IContactsService)localObject;
          continue;
        }
        localObject = new Proxy();
      }
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      boolean bool = true;
      switch (paramInt1)
      {
      default:
        bool = super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      }
      while (true)
      {
        return bool;
        paramParcel2.writeString("com.spb.contacts.IContactsService");
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsService");
        int i = paramParcel1.readInt();
        if (paramParcel1.readInt() != 0);
        int k;
        for (int j = 1; ; k = 0)
        {
          reloadBirthdays(i, j);
          paramParcel2.writeNoException();
          break;
        }
        paramParcel1.enforceInterface("com.spb.contacts.IContactsService");
        int m = paramParcel1.readInt();
        reloadContacts(m);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsService");
        int n = paramParcel1.readInt();
        reloadContact(n);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsService");
        IContactsServiceCallback localIContactsServiceCallback1 = IContactsServiceCallback.Stub.asInterface(paramParcel1.readStrongBinder());
        registerCallback(localIContactsServiceCallback1);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsService");
        IContactsServiceCallback localIContactsServiceCallback2 = IContactsServiceCallback.Stub.asInterface(paramParcel1.readStrongBinder());
        unregisterCallback(localIContactsServiceCallback2);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IContactsService");
        crash();
        paramParcel2.writeNoException();
      }
    }

    class Proxy
      implements IContactsService
    {
      Proxy()
      {
      }

      public IBinder asBinder()
      {
        return IContactsService.Stub.this;
      }

      public void crash()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsService");
          boolean bool = IContactsService.Stub.this.transact(6, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public String getInterfaceDescriptor()
      {
        return "com.spb.contacts.IContactsService";
      }

      public void registerCallback(IContactsServiceCallback paramIContactsServiceCallback)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsService");
          if (paramIContactsServiceCallback != null)
          {
            localIBinder = paramIContactsServiceCallback.asBinder();
            localParcel1.writeStrongBinder(localIBinder);
            boolean bool = IContactsService.Stub.this.transact(4, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
          IBinder localIBinder = null;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public void reloadBirthdays(int paramInt, boolean paramBoolean)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsService");
          localParcel1.writeInt(paramInt);
          if (paramBoolean)
          {
            localParcel1.writeInt(i);
            boolean bool = IContactsService.Stub.this.transact(1, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
          i = 0;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public void reloadContact(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsService");
          localParcel1.writeInt(paramInt);
          boolean bool = IContactsService.Stub.this.transact(3, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void reloadContacts(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsService");
          localParcel1.writeInt(paramInt);
          boolean bool = IContactsService.Stub.this.transact(2, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void unregisterCallback(IContactsServiceCallback paramIContactsServiceCallback)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IContactsService");
          if (paramIContactsServiceCallback != null)
          {
            localIBinder = paramIContactsServiceCallback.asBinder();
            localParcel1.writeStrongBinder(localIBinder);
            boolean bool = IContactsService.Stub.this.transact(5, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
          IBinder localIBinder = null;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.IContactsService
 * JD-Core Version:    0.6.0
 */