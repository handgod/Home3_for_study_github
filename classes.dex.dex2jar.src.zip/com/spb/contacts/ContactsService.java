package com.spb.contacts;

import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.res.Resources;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.ContactsContract.CommonDataKinds.Email;
import android.provider.ContactsContract.CommonDataKinds.Im;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.provider.ContactsContract.Contacts;
import android.provider.ContactsContract.Data;
import android.text.TextUtils;
import android.text.format.Time;
import android.util.SparseIntArray;
import com.softspb.util.DelayedHandler;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.util.ArrayList;
import java.util.TimeZone;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ContactsService extends Service
  implements ContactsServiceConstants, ContactsDataProjection
{
  private static final String ALL_CONTACTS_SELECTION = ;
  private static final String[] ALL_CONTACTS_SELECTION_ARGS = ;
  private static final String CONTACT_ID_SELECTION = ;
  private static final String FAVORITES_SELECTION = ;
  private static final String[] FAVORITE_SELECTION_ARGS = ;
  static final String[] PROJECTION_DATA_VERSIONS = ;
  static final String[] SELECTION_ARGS_BIRTHDAYS = ;
  static final String[] SELECTION_ARGS_PHOTO_MIMETYPE = ;
  private static final String SELECTION_BIRTHDAYS = ;
  private static final String SELECTION_BIRTHDAYS_FAVORITES = ;
  static final String SELECTION_DATA_MIMETYPE = ;
  static final String SELECTION_DATA_MIMETYPE_FAVORITE = ;
  private static final String SORT_ORDER_DISPLAY_NAME_ID_ASC = "display_name ASC, _id ASC";
  private static final Logger logger;
  final ObservableContacts allContacts;
  final ObservableBirthdays birthdays;
  final ContactsCallbacksHelper callbacksHelper;
  private final SparseIntArray contactIdByPhotoId;
  DelayedHandler contactsHandler;
  ContactsObserver contactsObserver;
  private final IContactsService.Stub contactsServiceBinder;
  volatile boolean contactsServiceIsBound;
  private int currentContactsKind;
  final ObservableEvents events;
  final ObservableContacts favoriteContacts;
  private final IGetPid.Stub getPidBinder;
  private TimeZone localTimeZone;
  final ObservableNames names;
  final ObservableConnections otherConnections;
  PhoneNumberResolvingService phoneNumberResolvingService;
  private final IPhoneNumberResolvingService.Stub phoneNumberResolvingServiceBinder;
  volatile boolean phoneNumberResolvingServiceIsBound;
  final ObservableConnections phones;
  private final SparseIntArray photoVersions;
  private final Lock reloadContactsLock;
  volatile boolean serviceIsStarted;
  private final UpdateContactsAndBirthdaysRunnable updateContactsAndBirthdaysRunnable_notifyAll;
  private final UpdateContactsAndBirthdaysRunnable updateContactsAndBirthdaysRunnable_notifyOnlyChanged;

  static
  {
    String[] arrayOfString1 = new String[3];
    arrayOfString1[0] = "vnd.android.cursor.item/contact_event";
    String str1 = Integer.toString(3);
    arrayOfString1[1] = str1;
    String str2 = Integer.toString(1);
    arrayOfString1[2] = str2;
    SELECTION_ARGS_BIRTHDAYS = arrayOfString1;
    SELECTION_DATA_MIMETYPE = "mimetype" + "=?";
    SELECTION_DATA_MIMETYPE_FAVORITE = "(" + "mimetype" + "=?" + ") AND (" + "starred" + "=1)";
    String[] arrayOfString2 = new String[1];
    arrayOfString2[0] = "vnd.android.cursor.item/photo";
    SELECTION_ARGS_PHOTO_MIMETYPE = arrayOfString2;
    String[] arrayOfString3 = new String[3];
    arrayOfString3[0] = "_id";
    arrayOfString3[1] = "data_version";
    arrayOfString3[2] = "contact_id";
    PROJECTION_DATA_VERSIONS = arrayOfString3;
    StringBuilder localStringBuilder1 = new StringBuilder();
    StringBuilder localStringBuilder2 = localStringBuilder1.append("mimetype");
    StringBuilder localStringBuilder3 = localStringBuilder1.append("=? OR ");
    StringBuilder localStringBuilder4 = localStringBuilder1.append("mimetype");
    StringBuilder localStringBuilder5 = localStringBuilder1.append("=? OR ");
    StringBuilder localStringBuilder6 = localStringBuilder1.append("mimetype");
    StringBuilder localStringBuilder7 = localStringBuilder1.append("=? OR ");
    StringBuilder localStringBuilder8 = localStringBuilder1.append("mimetype");
    StringBuilder localStringBuilder9 = localStringBuilder1.append("=? OR ");
    StringBuilder localStringBuilder10 = localStringBuilder1.append("mimetype");
    StringBuilder localStringBuilder11 = localStringBuilder1.append("=? OR ");
    StringBuilder localStringBuilder12 = localStringBuilder1.append("mimetype");
    StringBuilder localStringBuilder13 = localStringBuilder1.append("=?");
    ALL_CONTACTS_SELECTION = localStringBuilder1.toString();
    String[] arrayOfString4 = new String[6];
    arrayOfString4[0] = "vnd.android.cursor.item/name";
    arrayOfString4[1] = "vnd.android.cursor.item/phone_v2";
    arrayOfString4[2] = "vnd.android.cursor.item/email_v2";
    arrayOfString4[3] = "vnd.android.cursor.item/im";
    arrayOfString4[4] = "vnd.android.cursor.item/contact_event";
    arrayOfString4[5] = "vnd.android.cursor.item/nickname";
    ALL_CONTACTS_SELECTION_ARGS = arrayOfString4;
    StringBuilder localStringBuilder14 = new StringBuilder();
    StringBuilder localStringBuilder15 = localStringBuilder14.append(40).append(localStringBuilder1).append(") AND ");
    StringBuilder localStringBuilder16 = localStringBuilder14.append("starred");
    StringBuilder localStringBuilder17 = localStringBuilder14.append("=1");
    FAVORITES_SELECTION = localStringBuilder14.toString();
    FAVORITE_SELECTION_ARGS = ALL_CONTACTS_SELECTION_ARGS;
    StringBuilder localStringBuilder18 = new StringBuilder();
    StringBuilder localStringBuilder19 = localStringBuilder18.append(40).append(localStringBuilder1).append(") AND ");
    StringBuilder localStringBuilder20 = localStringBuilder18.append("contact_id");
    StringBuilder localStringBuilder21 = localStringBuilder18.append("=?");
    CONTACT_ID_SELECTION = localStringBuilder18.toString();
    logger = Loggers.getLogger(ContactsService.class.getName());
  }

  public ContactsService()
  {
    ReentrantLock localReentrantLock = new ReentrantLock();
    this.reloadContactsLock = localReentrantLock;
    SparseIntArray localSparseIntArray1 = new SparseIntArray();
    this.photoVersions = localSparseIntArray1;
    SparseIntArray localSparseIntArray2 = new SparseIntArray();
    this.contactIdByPhotoId = localSparseIntArray2;
    ContactsCallbacksHelper localContactsCallbacksHelper = new ContactsCallbacksHelper();
    this.callbacksHelper = localContactsCallbacksHelper;
    ObservableEvents localObservableEvents = new ObservableEvents();
    this.events = localObservableEvents;
    ObservableBirthdays localObservableBirthdays = new ObservableBirthdays();
    this.birthdays = localObservableBirthdays;
    String[] arrayOfString1 = new String[1];
    arrayOfString1[0] = "vnd.android.cursor.item/phone_v2";
    ObservableConnections localObservableConnections1 = new ObservableConnections("Phones", arrayOfString1);
    this.phones = localObservableConnections1;
    String[] arrayOfString2 = new String[2];
    arrayOfString2[0] = "vnd.android.cursor.item/email_v2";
    arrayOfString2[1] = "vnd.android.cursor.item/im";
    ObservableConnections localObservableConnections2 = new ObservableConnections("Connections", arrayOfString2);
    this.otherConnections = localObservableConnections2;
    ObservableNames localObservableNames = new ObservableNames();
    this.names = localObservableNames;
    ObservableAllContacts localObservableAllContacts = new ObservableAllContacts();
    this.allContacts = localObservableAllContacts;
    ObservableFavoriteContacts localObservableFavoriteContacts = new ObservableFavoriteContacts();
    this.favoriteContacts = localObservableFavoriteContacts;
    this.contactsServiceIsBound = 0;
    this.phoneNumberResolvingServiceIsBound = 0;
    this.serviceIsStarted = 0;
    ContactsService.1 local1 = new ContactsService.1(this);
    this.getPidBinder = local1;
    ContactsService.2 local2 = new ContactsService.2(this);
    this.contactsServiceBinder = local2;
    ContactsService.3 local3 = new ContactsService.3(this);
    this.phoneNumberResolvingServiceBinder = local3;
    UpdateContactsAndBirthdaysRunnable localUpdateContactsAndBirthdaysRunnable1 = new UpdateContactsAndBirthdaysRunnable(1);
    this.updateContactsAndBirthdaysRunnable_notifyAll = localUpdateContactsAndBirthdaysRunnable1;
    UpdateContactsAndBirthdaysRunnable localUpdateContactsAndBirthdaysRunnable2 = new UpdateContactsAndBirthdaysRunnable(0);
    this.updateContactsAndBirthdaysRunnable_notifyOnlyChanged = localUpdateContactsAndBirthdaysRunnable2;
  }

  private void doReloadBirthdays(int paramInt, boolean paramBoolean)
  {
    logd("reloadBirthdays >>>");
    long l1 = SystemClock.uptimeMillis();
    String str;
    if (paramInt == 2)
      str = SELECTION_BIRTHDAYS_FAVORITES;
    while (true)
    {
      Uri localUri = ContactsContract.Data.CONTENT_URI;
      Cursor localCursor;
      try
      {
        TimeZone localTimeZone1 = TimeZone.getDefault();
        this.localTimeZone = localTimeZone1;
        this.birthdays.startReloading();
        ContentResolver localContentResolver = getContentResolver();
        String[] arrayOfString1 = CONTACTS_DATA_PROJECTION;
        String[] arrayOfString2 = SELECTION_ARGS_BIRTHDAYS;
        localCursor = localContentResolver.query(localUri, arrayOfString1, str, arrayOfString2, null);
        if ((localCursor != null) && (localCursor.moveToFirst()))
          while (!localCursor.isAfterLast())
          {
            int i = (int)localCursor.getLong(0);
            this.birthdays.loadRow(localCursor, paramBoolean, i);
            boolean bool = localCursor.moveToNext();
          }
      }
      finally
      {
        if (localCursor == null);
      }
      try
      {
        localCursor.close();
        label149: long l2 = SystemClock.uptimeMillis() - l1;
        logd("reloadBirthdays <<< " + l2 + " ms");
        throw localObject;
        str = SELECTION_BIRTHDAYS;
        continue;
        this.birthdays.finishReloading();
        if (localCursor != null);
        try
        {
          localCursor.close();
          label216: long l3 = SystemClock.uptimeMillis() - l1;
          logd("reloadBirthdays <<< " + l3 + " ms");
          return;
        }
        catch (Exception localException1)
        {
          break label216;
        }
      }
      catch (Exception localException2)
      {
        break label149;
      }
    }
  }

  private void doReloadContact(int paramInt)
  {
    long l1 = SystemClock.uptimeMillis();
    logd("getContact >>> contactId=" + paramInt);
    this.reloadContactsLock.lock();
    try
    {
      ContactsCallbacksHelper localContactsCallbacksHelper1 = this.callbacksHelper;
      int i = this.currentContactsKind;
      localContactsCallbacksHelper1.notifyStartedReload(i);
      ContentResolver localContentResolver = getContentResolver();
      Uri localUri = ContactsContract.Data.CONTENT_URI;
      String[] arrayOfString1 = CONTACTS_DATA_PROJECTION;
      String str = CONTACT_ID_SELECTION;
      String[] arrayOfString2 = getContactIDSelectionArgs(paramInt);
      localCursor = localContentResolver.query(localUri, arrayOfString1, str, arrayOfString2, null);
      if (localCursor != null)
        loadContactDataCursor(localCursor);
      long l2;
      ContactsCallbacksHelper localContactsCallbacksHelper2;
      int j;
      return;
    }
    finally
    {
      Cursor localCursor;
      if (localCursor != null)
        localCursor.close();
      long l3 = SystemClock.uptimeMillis() - l1;
      logd("getContact <<< " + l3 + " ms");
      ContactsCallbacksHelper localContactsCallbacksHelper3 = this.callbacksHelper;
      int k = this.currentContactsKind;
      localContactsCallbacksHelper3.notifyFinishedReload(k);
      this.reloadContactsLock.unlock();
    }
    throw localObject;
  }

  // ERROR //
  private void doReloadContacts(int paramInt)
  {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: putfield 293	com/spb/contacts/ContactsService:currentContactsKind	I
    //   5: invokestatic 329	android/os/SystemClock:uptimeMillis	()J
    //   8: lstore_2
    //   9: new 100	java/lang/StringBuilder
    //   12: dup
    //   13: invokespecial 103	java/lang/StringBuilder:<init>	()V
    //   16: ldc_w 421
    //   19: invokevirtual 109	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   22: iload_1
    //   23: invokevirtual 395	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   26: invokevirtual 125	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   29: invokestatic 289	com/spb/contacts/ContactsService:logd	(Ljava/lang/String;)V
    //   32: aload_0
    //   33: iconst_1
    //   34: invokespecial 424	com/spb/contacts/ContactsService:reloadPhotoVersions	(I)V
    //   37: aload_0
    //   38: iload_1
    //   39: invokespecial 426	com/spb/contacts/ContactsService:startReloading	(I)V
    //   42: aload_0
    //   43: iload_1
    //   44: invokespecial 430	com/spb/contacts/ContactsService:queryContacts	(I)Landroid/database/Cursor;
    //   47: astore 4
    //   49: aload 4
    //   51: ifnull +9 -> 60
    //   54: aload_0
    //   55: aload 4
    //   57: invokespecial 411	com/spb/contacts/ContactsService:loadContactDataCursor	(Landroid/database/Cursor;)V
    //   60: aload_0
    //   61: iload_1
    //   62: invokespecial 432	com/spb/contacts/ContactsService:finishReloading	(I)V
    //   65: aload 4
    //   67: ifnull +10 -> 77
    //   70: aload 4
    //   72: invokeinterface 380 1 0
    //   77: new 100	java/lang/StringBuilder
    //   80: dup
    //   81: invokespecial 103	java/lang/StringBuilder:<init>	()V
    //   84: ldc_w 434
    //   87: invokevirtual 109	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   90: astore 5
    //   92: invokestatic 329	android/os/SystemClock:uptimeMillis	()J
    //   95: lload_2
    //   96: lsub
    //   97: lstore 6
    //   99: aload 5
    //   101: lload 6
    //   103: invokevirtual 385	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   106: ldc_w 387
    //   109: invokevirtual 109	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   112: invokevirtual 125	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   115: invokestatic 289	com/spb/contacts/ContactsService:logd	(Ljava/lang/String;)V
    //   118: return
    //   119: astore 8
    //   121: getstatic 206	com/spb/contacts/ContactsService:logger	Lcom/softspb/util/log/Logger;
    //   124: astore 9
    //   126: new 100	java/lang/StringBuilder
    //   129: dup
    //   130: invokespecial 103	java/lang/StringBuilder:<init>	()V
    //   133: ldc_w 436
    //   136: invokevirtual 109	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   139: aload 8
    //   141: invokevirtual 439	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   144: invokevirtual 125	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   147: astore 10
    //   149: aload 9
    //   151: aload 10
    //   153: aload 8
    //   155: invokevirtual 445	com/softspb/util/log/Logger:e	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   158: aload 4
    //   160: ifnull +10 -> 170
    //   163: aload 4
    //   165: invokeinterface 380 1 0
    //   170: new 100	java/lang/StringBuilder
    //   173: dup
    //   174: invokespecial 103	java/lang/StringBuilder:<init>	()V
    //   177: ldc_w 434
    //   180: invokevirtual 109	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   183: astore 11
    //   185: invokestatic 329	android/os/SystemClock:uptimeMillis	()J
    //   188: lload_2
    //   189: lsub
    //   190: lstore 12
    //   192: aload 11
    //   194: lload 12
    //   196: invokevirtual 385	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   199: ldc_w 387
    //   202: invokevirtual 109	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   205: invokevirtual 125	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   208: invokestatic 289	com/spb/contacts/ContactsService:logd	(Ljava/lang/String;)V
    //   211: goto -93 -> 118
    //   214: astore 14
    //   216: aload 4
    //   218: ifnull +10 -> 228
    //   221: aload 4
    //   223: invokeinterface 380 1 0
    //   228: new 100	java/lang/StringBuilder
    //   231: dup
    //   232: invokespecial 103	java/lang/StringBuilder:<init>	()V
    //   235: ldc_w 434
    //   238: invokevirtual 109	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   241: astore 15
    //   243: invokestatic 329	android/os/SystemClock:uptimeMillis	()J
    //   246: lload_2
    //   247: lsub
    //   248: lstore 16
    //   250: aload 15
    //   252: lload 16
    //   254: invokevirtual 385	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   257: ldc_w 387
    //   260: invokevirtual 109	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   263: invokevirtual 125	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   266: invokestatic 289	com/spb/contacts/ContactsService:logd	(Ljava/lang/String;)V
    //   269: aload 14
    //   271: athrow
    //   272: astore 18
    //   274: goto -197 -> 77
    //   277: astore 19
    //   279: goto -109 -> 170
    //   282: astore 20
    //   284: goto -56 -> 228
    //
    // Exception table:
    //   from	to	target	type
    //   32	65	119	java/lang/Exception
    //   32	65	214	finally
    //   121	158	214	finally
    //   70	77	272	java/lang/Exception
    //   163	170	277	java/lang/Exception
    //   221	228	282	java/lang/Exception
  }

  private void finishReloading(int paramInt)
  {
    logd("finishReloading: kind=" + paramInt);
    if (paramInt == 1)
      this.allContacts.finishReloading();
    this.favoriteContacts.finishReloading();
    this.events.finishReloading();
    this.phones.finishReloading();
    this.otherConnections.finishReloading();
    this.names.finishReloading();
  }

  static String getConnectionTypeLabel(Resources paramResources, String paramString1, String paramString2, int paramInt)
  {
    String str;
    if ("vnd.android.cursor.item/phone_v2".equals(paramString1))
      str = ContactsContract.CommonDataKinds.Phone.getTypeLabel(paramResources, paramInt, paramString2).toString();
    while (true)
    {
      return str;
      if ("vnd.android.cursor.item/email_v2".equals(paramString1))
      {
        str = ContactsContract.CommonDataKinds.Email.getTypeLabel(paramResources, paramInt, paramString2).toString();
        continue;
      }
      if ("vnd.android.cursor.item/im".equals(paramString1))
      {
        str = ContactsContract.CommonDataKinds.Im.getProtocolLabel(paramResources, paramInt, paramString2).toString();
        continue;
      }
      str = ContactsContract.CommonDataKinds.Phone.getTypeLabel(paramResources, 2, null).toString();
    }
  }

  private static String[] getContactIDSelectionArgs(int paramInt)
  {
    String[] arrayOfString1 = new String[ALL_CONTACTS_SELECTION_ARGS.length + 1];
    String[] arrayOfString2 = ALL_CONTACTS_SELECTION_ARGS;
    int i = ALL_CONTACTS_SELECTION_ARGS.length;
    System.arraycopy(arrayOfString2, 0, arrayOfString1, 0, i);
    int j = ALL_CONTACTS_SELECTION_ARGS.length;
    String str = Integer.toString(paramInt);
    arrayOfString1[j] = str;
    return arrayOfString1;
  }

  private void loadContactDataCursor(Cursor paramCursor)
  {
    long l1 = SystemClock.uptimeMillis();
    logd("loadContactDataCursor >>>");
    try
    {
      if (paramCursor.moveToFirst())
      {
        int i;
        do
          i = loadOneContact(paramCursor);
        while (i != -2147483648);
      }
      long l2;
      return;
    }
    finally
    {
      long l3 = SystemClock.uptimeMillis() - l1;
      logd("loadContactDataCursor <<< " + l3 + " ms");
    }
    throw localObject;
  }

  private boolean loadDataRow(Cursor paramCursor, int paramInt)
  {
    int i = 0;
    int j = (int)paramCursor.getLong(i);
    if (paramInt != j)
      return i;
    String str = paramCursor.getString(2);
    if ("vnd.android.cursor.item/phone_v2".equals(str))
      this.phones.loadRow(paramCursor, 0, paramInt);
    while (true)
    {
      i = 1;
      break;
      if (("vnd.android.cursor.item/email_v2".equals(str)) || ("vnd.android.cursor.item/im".equals(str)))
      {
        this.otherConnections.loadRow(paramCursor, 0, paramInt);
        continue;
      }
      if ("vnd.android.cursor.item/contact_event".equals(str))
      {
        this.events.loadRow(paramCursor, 0, paramInt);
        continue;
      }
      if (!"vnd.android.cursor.item/name".equals(str))
        continue;
      this.names.loadRow(paramCursor, 0, paramInt);
    }
  }

  private int loadOneContact(Cursor paramCursor)
  {
    int i;
    if (paramCursor.isAfterLast())
      i = -2147483648;
    while (true)
    {
      return i;
      i = (int)paramCursor.getLong(0);
      logd("loadOneContact >>> contactId=" + i);
      try
      {
        ContactsCallbacksHelper localContactsCallbacksHelper1 = this.callbacksHelper;
        int j = this.currentContactsKind;
        localContactsCallbacksHelper1.notifyStartedUpdatingContact(i, j);
        if (this.currentContactsKind == 1)
          int k = this.allContacts.loadContact(paramCursor);
        int m = this.favoriteContacts.loadContact(paramCursor);
        while (true)
        {
          if (!paramCursor.isAfterLast())
          {
            boolean bool1 = loadDataRow(paramCursor, i);
            if (bool1);
          }
          else
          {
            ContactsCallbacksHelper localContactsCallbacksHelper2 = this.callbacksHelper;
            int n = this.currentContactsKind;
            localContactsCallbacksHelper2.notifyFinishedUpdatingContact(i, n);
            logd("loadOneContact <<< contactId=" + i);
            break;
          }
          boolean bool2 = paramCursor.moveToNext();
        }
      }
      finally
      {
        ContactsCallbacksHelper localContactsCallbacksHelper3 = this.callbacksHelper;
        int i1 = this.currentContactsKind;
        localContactsCallbacksHelper3.notifyFinishedUpdatingContact(i, i1);
      }
    }
    throw localObject;
  }

  private static void logd(String paramString)
  {
    Thread localThread = Thread.currentThread();
    StringBuilder localStringBuilder1 = new StringBuilder().append("[Thread id=");
    long l = localThread.getId();
    StringBuilder localStringBuilder2 = localStringBuilder1.append(l).append(" name=");
    String str1 = localThread.getName();
    String str2 = str1 + "] " + paramString;
    logger.d(str2);
  }

  private Cursor queryContacts(int paramInt)
  {
    Uri localUri;
    String str;
    if (paramInt == 2)
    {
      localUri = ContactsContract.Data.CONTENT_URI;
      str = FAVORITES_SELECTION;
    }
    for (String[] arrayOfString1 = FAVORITE_SELECTION_ARGS; ; arrayOfString1 = ALL_CONTACTS_SELECTION_ARGS)
    {
      ContentResolver localContentResolver = getContentResolver();
      String[] arrayOfString2 = CONTACTS_DATA_PROJECTION;
      return localContentResolver.query(localUri, arrayOfString2, str, arrayOfString1, "display_name ASC, _id ASC");
      localUri = ContactsContract.Data.CONTENT_URI;
      str = ALL_CONTACTS_SELECTION;
    }
  }

  private void reloadPhotoVersions(int paramInt)
  {
    logd("reloadPhotoVersions >>>");
    long l1 = SystemClock.uptimeMillis();
    if (paramInt == 2);
    for (String str = SELECTION_DATA_MIMETYPE_FAVORITE; ; str = SELECTION_DATA_MIMETYPE)
    {
      String[] arrayOfString = SELECTION_ARGS_PHOTO_MIMETYPE;
      reloadPhotoVersions(str, arrayOfString);
      long l2 = SystemClock.uptimeMillis() - l1;
      logd("reloadPhotoVersions <<< " + l2 + " ms");
      return;
    }
  }

  private void reloadPhotoVersions(String paramString, String[] paramArrayOfString)
  {
    Cursor localCursor = null;
    SparseIntArray localSparseIntArray1 = this.photoVersions;
    SparseIntArray localSparseIntArray2 = this.contactIdByPhotoId;
    Uri localUri = ContactsContract.Data.CONTENT_URI;
    this.reloadContactsLock.lock();
    SparseIntArray localSparseIntArray3;
    int i;
    int j;
    int i1;
    try
    {
      localSparseIntArray3 = new SparseIntArray();
      i = localSparseIntArray1.size();
      j = 0;
      while (j < i)
      {
        int k = this.photoVersions.keyAt(j);
        localSparseIntArray3.put(k, 1);
        j += 1;
      }
      ContentResolver localContentResolver = getContentResolver();
      String[] arrayOfString1 = PROJECTION_DATA_VERSIONS;
      String str = paramString;
      String[] arrayOfString2 = paramArrayOfString;
      localCursor = localContentResolver.query(localUri, arrayOfString1, str, arrayOfString2, null);
      if ((localCursor != null) && (localCursor.moveToFirst()))
        while (!localCursor.isAfterLast())
        {
          int m = (int)localCursor.getLong(0);
          int n = localCursor.getInt(1);
          i1 = (int)localCursor.getLong(2);
          int i2 = localSparseIntArray1.get(m, -2147483648);
          int i3 = localSparseIntArray2.get(m, -2147483648);
          if (i2 != n)
          {
            localSparseIntArray1.put(m, n);
            this.callbacksHelper.notifyContactPhotoUpdated(i1, m, n);
          }
          if (i3 != i1)
          {
            localSparseIntArray2.put(m, i1);
            if (i3 != -2147483648)
            {
              ContactsCallbacksHelper localContactsCallbacksHelper = this.callbacksHelper;
              int i4 = i3;
              localContactsCallbacksHelper.notifyContactPhotoUpdated(i4, m, n);
            }
            if (i2 == n)
              this.callbacksHelper.notifyContactPhotoUpdated(i1, m, n);
          }
          localSparseIntArray3.delete(m);
          boolean bool = localCursor.moveToNext();
        }
    }
    finally
    {
      this.reloadContactsLock.unlock();
      if (localCursor == null);
    }
    try
    {
      localCursor.close();
      label322: throw localObject;
      i = localSparseIntArray3.size();
      j = 0;
      while (j < i)
      {
        int i5 = localSparseIntArray3.keyAt(j);
        i1 = localSparseIntArray2.get(i5, -2147483648);
        if (i1 != -2147483648)
          this.callbacksHelper.notifyContactPhotoUpdated(i1, 0, 0);
        localSparseIntArray1.delete(i5);
        localSparseIntArray2.delete(i5);
        j += 1;
      }
      this.reloadContactsLock.unlock();
      if (localCursor != null);
      try
      {
        localCursor.close();
        label424: return;
      }
      catch (Exception localException1)
      {
        break label424;
      }
    }
    catch (Exception localException2)
    {
      break label322;
    }
  }

  private void startReloading(int paramInt)
  {
    if (paramInt == 1)
      this.allContacts.startReloading();
    this.favoriteContacts.startReloading();
    this.events.startReloading();
    this.phones.startReloading();
    this.otherConnections.startReloading();
    this.names.startReloading();
  }

  /** @deprecated */
  private void startService()
  {
    monitorenter;
    try
    {
      logd("startService >>>");
      HandlerThread localHandlerThread = new HandlerThread("ContactsAdapter_Observer");
      localHandlerThread.start();
      localHandlerThread.setPriority(1);
      Looper localLooper = localHandlerThread.getLooper();
      DelayedHandler localDelayedHandler1 = new DelayedHandler(localLooper, 1000L);
      this.contactsHandler = localDelayedHandler1;
      DelayedHandler localDelayedHandler2 = this.contactsHandler;
      ContactsObserver localContactsObserver1 = new ContactsObserver(localDelayedHandler2);
      this.contactsObserver = localContactsObserver1;
      ContentResolver localContentResolver = getContentResolver();
      Uri localUri1 = ContactsContract.Contacts.CONTENT_URI;
      ContactsObserver localContactsObserver2 = this.contactsObserver;
      localContentResolver.registerContentObserver(localUri1, 1, localContactsObserver2);
      Uri localUri2 = ContactsContract.Data.CONTENT_URI;
      ContactsObserver localContactsObserver3 = this.contactsObserver;
      localContentResolver.registerContentObserver(localUri2, 1, localContactsObserver3);
      PhoneNumberResolvingService localPhoneNumberResolvingService = new PhoneNumberResolvingService(this);
      this.phoneNumberResolvingService = localPhoneNumberResolvingService;
      logd("startService <<<");
      this.serviceIsStarted = 1;
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  /** @deprecated */
  private void stopService()
  {
    monitorenter;
    try
    {
      logd("stopService >>>");
      if (this.phoneNumberResolvingService != null)
      {
        this.phoneNumberResolvingService.stop();
        this.phoneNumberResolvingService = null;
      }
      if (this.contactsObserver != null)
      {
        ContentResolver localContentResolver = getContentResolver();
        ContactsObserver localContactsObserver = this.contactsObserver;
        localContentResolver.unregisterContentObserver(localContactsObserver);
        this.contactsHandler.getLooper().quit();
        this.contactsHandler.removeCallbacksAndMessages(null);
        this.contactsObserver = null;
      }
      this.serviceIsStarted = 0;
      logd("stopService <<<");
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  int compareStructuredNames(StructuredName paramStructuredName1, StructuredName paramStructuredName2, String paramString)
  {
    int i = 0;
    int j = 1;
    logd("compareStructuredNames >>>");
    logd("compareStructuredNames: name1=" + paramStructuredName1);
    logd("compareStructuredNames: name2=" + paramStructuredName2);
    if (paramStructuredName1 == null)
      if (paramStructuredName2 == null)
      {
        logd("compareStructuredNames <<< " + i);
        j = i;
      }
    while (true)
    {
      return j;
      i = -1;
      break;
      if (paramStructuredName2 == null)
      {
        logd("compareStructuredNames <<< 1");
        continue;
      }
      logd("compareStructuredNames: contactDisplayName=\"" + paramString + "\"");
      boolean bool1 = TextUtils.equals(paramStructuredName1.displayName, paramString);
      boolean bool2 = TextUtils.equals(paramStructuredName2.displayName, paramString);
      logd("compareStructuredNames: matchesContactDisplayName1=" + bool1 + " matchesContactDisplayName2=" + bool2);
      if ((bool1) && (!bool2))
      {
        logd("compareStructuredNames <<< 1");
        continue;
      }
      if ((!bool1) && (bool2))
      {
        logd("compareStructuredNames <<< -1");
        j = -1;
        continue;
      }
      int k;
      if ((paramStructuredName1.firstName != null) && (paramStructuredName1.lastName != null))
      {
        k = 1;
        label262: if ((paramStructuredName2.firstName == null) || (paramStructuredName2.lastName == null))
          break label342;
      }
      int m;
      label342: int i1;
      for (int n = 1; ; i1 = 0)
      {
        logd("compareStructuredNames: hasBothComponents1=" + k + " hasBothComponents2=" + n);
        if ((k == 0) || (n != 0))
          break label349;
        logd("compareStructuredNames <<< 1");
        break;
        m = 0;
        break label262;
      }
      label349: if ((i1 != 0) && (m == 0))
      {
        logd("compareStructuredNames <<< -1");
        j = -1;
        continue;
      }
      logd("compareStructuredNames <<< 0");
      j = 0;
    }
  }

  /** @deprecated */
  public IBinder onBind(Intent paramIntent)
  {
    monitorenter;
    while (true)
    {
      String str;
      try
      {
        str = paramIntent.getAction();
        logd("onBind >>> " + str);
        localObject1 = null;
        if (!IContactsService.class.getName().equals(str))
          continue;
        this.contactsServiceIsBound = 1;
        localObject1 = this.contactsServiceBinder;
        if (this.serviceIsStarted)
          continue;
        startService();
        logd("onBind <<< " + str + ", return " + localObject1);
        return localObject1;
        if (IPhoneNumberResolvingService.class.getName().equals(str))
        {
          localObject1 = this.phoneNumberResolvingServiceBinder;
          this.phoneNumberResolvingServiceIsBound = 1;
          continue;
        }
      }
      finally
      {
        monitorexit;
      }
      if (!IGetPid.class.getName().equals(str))
        continue;
      Object localObject1 = this.getPidBinder;
    }
  }

  /** @deprecated */
  public boolean onUnbind(Intent paramIntent)
  {
    monitorenter;
    while (true)
    {
      String str;
      try
      {
        str = paramIntent.getAction();
        logd("onUnbind >>> " + str);
        if (!IContactsService.class.getName().equals(str))
          continue;
        this.contactsServiceIsBound = 0;
        if ((this.contactsServiceIsBound) || (this.phoneNumberResolvingServiceIsBound))
          continue;
        stopService();
        logd("onUnbind <<< " + str);
        return false;
        if (IPhoneNumberResolvingService.class.getName().equals(str))
        {
          this.phoneNumberResolvingServiceIsBound = 0;
          continue;
        }
      }
      finally
      {
        monitorexit;
      }
      boolean bool = IGetPid.class.getName().equals(str);
      if (!bool)
        continue;
    }
  }

  final class UpdateContactsAndBirthdaysRunnable
    implements Runnable
  {
    private final boolean doNotifyAll;

    UpdateContactsAndBirthdaysRunnable(boolean arg2)
    {
      boolean bool;
      this.doNotifyAll = bool;
    }

    public void run()
    {
      ContactsService.access$100("updateContactsAndBirthdaysCallback.run");
      ContactsService.this.reloadContactsLock.lock();
      ContactsService.this.callbacksHelper.notifyStartedReload(2);
      try
      {
        ContactsService.this.callbacksHelper.notifyStartedReloadingBirthdays();
        try
        {
          ContactsService localContactsService = ContactsService.this;
          boolean bool = this.doNotifyAll;
          localContactsService.doReloadBirthdays(1, bool);
          ContactsService.this.callbacksHelper.notifyFinishedReloadingBirthdays();
          ContactsService.this.doReloadContacts(2);
          ContactsService.this.callbacksHelper.notifyFinishedReload(2);
          ContactsService.this.reloadContactsLock.unlock();
          return;
        }
        finally
        {
          ContactsService.this.callbacksHelper.notifyFinishedReloadingBirthdays();
        }
      }
      finally
      {
        ContactsService.this.callbacksHelper.notifyFinishedReload(2);
        ContactsService.this.reloadContactsLock.unlock();
      }
      throw localObject2;
    }
  }

  class ContactsObserver extends ContentObserver
  {
    DelayedHandler delayedHandler;

    ContactsObserver(DelayedHandler arg2)
    {
      super();
      this.delayedHandler = localHandler;
    }

    public void onChange(boolean paramBoolean)
    {
      boolean bool = ContactsService.this.callbacksHelper.hasRegisteredCallbacks();
      ContactsService.access$100("ContactsObserver.onChange: hasRegisteredCallbacks=" + bool);
      if (bool)
      {
        DelayedHandler localDelayedHandler = this.delayedHandler;
        ContactsService.UpdateContactsAndBirthdaysRunnable localUpdateContactsAndBirthdaysRunnable = ContactsService.this.updateContactsAndBirthdaysRunnable_notifyOnlyChanged;
        localDelayedHandler.handleDelayed(localUpdateContactsAndBirthdaysRunnable);
      }
    }
  }

  class ObservableNames extends ObservableData<StructuredName>
  {
    ObservableNames()
    {
      super(arrayOfString);
    }

    private StructuredName getPrimaryStucturedName(int paramInt)
    {
      ContactsService.access$100("getPrimaryStucturedName >>> contactId=" + paramInt);
      ArrayList localArrayList = getEntriesForContact(paramInt);
      int i;
      Object localObject;
      if (localArrayList == null)
      {
        i = 0;
        if (i != 0)
          break label52;
        localObject = null;
      }
      while (true)
      {
        return localObject;
        i = localArrayList.size();
        break;
        label52: String str = ContactsService.this.allContacts.getDisplayName(paramInt);
        if (str == null)
          str = ContactsService.this.favoriteContacts.getDisplayName(paramInt);
        localObject = null;
        int j = 0;
        while (j < i)
        {
          StructuredName localStructuredName = (StructuredName)localArrayList.get(j);
          if (ContactsService.this.compareStructuredNames(localStructuredName, (StructuredName)localObject, str) > 0)
            localObject = localStructuredName;
          ContactsService.access$100("getPrimaryStucturedName: bestName=" + localObject);
          j += 1;
        }
        ContactsService.access$100("getPrimaryStucturedName <<< contactId=" + paramInt + " bestName=" + localObject);
      }
    }

    StructuredName createDataFromRow(Cursor paramCursor)
    {
      int i = (int)paramCursor.getLong(9);
      int j = paramCursor.getInt(10);
      String str1 = paramCursor.getString(4);
      String str2 = paramCursor.getString(5);
      String str3 = paramCursor.getString(3);
      return new StructuredName(i, j, str3, str1, str2);
    }

    boolean isContactDeleted(int paramInt)
    {
      if (!ContactsService.this.allContacts.hasContact(paramInt));
      for (int i = 1; ; i = 0)
        return i;
    }

    void notifyStructuredNameChanged(int paramInt)
    {
      StructuredName localStructuredName = getPrimaryStucturedName(paramInt);
      if (localStructuredName == null)
        ContactsService.this.callbacksHelper.notifyStructuredNameChanged(paramInt, null, null);
      while (true)
      {
        return;
        ContactsCallbacksHelper localContactsCallbacksHelper = ContactsService.this.callbacksHelper;
        String str1 = localStructuredName.firstName;
        String str2 = localStructuredName.lastName;
        localContactsCallbacksHelper.notifyStructuredNameChanged(paramInt, str1, str2);
      }
    }

    void onDataDeleted(int paramInt1, int paramInt2)
    {
      notifyStructuredNameChanged(paramInt1);
    }

    void onDataUpdated(int paramInt, StructuredName paramStructuredName)
    {
      notifyStructuredNameChanged(paramInt);
    }
  }

  class ObservableConnections extends ObservableData<ConnectionEntry>
  {
    ObservableConnections(String paramArrayOfString, String[] arg3)
    {
      super(arrayOfString);
    }

    ConnectionEntry createDataFromRow(Cursor paramCursor)
    {
      int i = (int)paramCursor.getLong(9);
      int j = paramCursor.getInt(10);
      String str1 = paramCursor.getString(3);
      String str2 = paramCursor.getString(2);
      int k = paramCursor.getInt(4);
      String str3 = paramCursor.getString(5);
      String str4 = ContactsService.getConnectionTypeLabel(ContactsService.this.getResources(), str2, str3, k);
      return new ConnectionEntry(i, j, str1, str2, k, str4);
    }

    boolean isContactDeleted(int paramInt)
    {
      if (!ContactsService.this.allContacts.hasContact(paramInt));
      for (int i = 1; ; i = 0)
        return i;
    }

    void onDataDeleted(int paramInt1, int paramInt2)
    {
      ContactsCallbacksHelper localContactsCallbacksHelper = ContactsService.this.callbacksHelper;
      int i = ContactsService.this.currentContactsKind;
      localContactsCallbacksHelper.notifyConnectionDeleted(paramInt1, paramInt2, i);
    }

    void onDataUpdated(int paramInt, ConnectionEntry paramConnectionEntry)
    {
      ContactsCallbacksHelper localContactsCallbacksHelper = ContactsService.this.callbacksHelper;
      int i = paramConnectionEntry.id;
      String str1 = paramConnectionEntry.mimetype;
      int j = paramConnectionEntry.locationType;
      String str2 = paramConnectionEntry.address;
      String str3 = paramConnectionEntry.label;
      int k = paramConnectionEntry.version;
      int m = paramInt;
      localContactsCallbacksHelper.notifyConnectionUpdated(m, i, str1, j, str2, str3, k);
    }
  }

  class ObservableBirthdays extends ObservableData<EventEntry>
  {
    private Time now;

    ObservableBirthdays()
    {
      super(arrayOfString);
    }

    EventEntry createDataFromRow(Cursor paramCursor)
    {
      int i = (int)paramCursor.getLong(9);
      int j = paramCursor.getInt(10);
      String str = paramCursor.getString(3);
      int k = this.now.year;
      TimeZone localTimeZone = ContactsService.this.localTimeZone;
      Logger localLogger = ContactsService.logger;
      Time localTime = ContactsUtils.parseBirthdayDate(str, k, localTimeZone, localLogger);
      int m = paramCursor.getInt(4);
      return new EventEntry(i, j, localTime, m);
    }

    boolean isContactDeleted(int paramInt)
    {
      if (!ContactsService.this.allContacts.hasContact(paramInt));
      for (int i = 1; ; i = 0)
        return i;
    }

    void onDataDeleted(int paramInt1, int paramInt2)
    {
      ContactsService.this.callbacksHelper.notifyBirthdayDeleted(paramInt2);
    }

    void onDataUpdated(int paramInt, EventEntry paramEventEntry)
    {
      ContactsCallbacksHelper localContactsCallbacksHelper = ContactsService.this.callbacksHelper;
      int i = paramEventEntry.type;
      int j = paramEventEntry.id;
      int k = paramEventEntry.date.year;
      int m = paramEventEntry.date.month;
      int n = paramEventEntry.date.monthDay;
      int i1 = paramInt;
      localContactsCallbacksHelper.notifyBirthdayUpdated(i, i1, j, k, m, n);
    }

    void startReloading()
    {
      super.startReloading();
      if (this.now == null)
      {
        Time localTime = new Time();
        this.now = localTime;
      }
      this.now.setToNow();
    }
  }

  class ObservableEvents extends ObservableData<EventEntry>
  {
    ObservableEvents()
    {
      super(arrayOfString);
    }

    EventEntry createDataFromRow(Cursor paramCursor)
    {
      int i = (int)paramCursor.getLong(9);
      int j = paramCursor.getInt(10);
      int k = (int)paramCursor.getLong(0);
      String str1 = paramCursor.getString(3);
      Time localTime = ContactsUtils.parseEventDate(str1, null);
      StringBuilder localStringBuilder = new StringBuilder().append("loading event data: contactId=").append(k).append(" dateSrc=").append(str1).append(" parsedDate=");
      if (localTime == null);
      for (String str2 = "null"; ; str2 = localTime.format3339(1))
      {
        ContactsService.access$100(str2);
        int m = paramCursor.getInt(4);
        return new EventEntry(i, j, localTime, m);
      }
    }

    boolean isContactDeleted(int paramInt)
    {
      if (!ContactsService.this.allContacts.hasContact(paramInt));
      for (int i = 1; ; i = 0)
        return i;
    }

    void onDataDeleted(int paramInt1, int paramInt2)
    {
      ContactsCallbacksHelper localContactsCallbacksHelper = ContactsService.this.callbacksHelper;
      int i = ContactsService.this.currentContactsKind;
      localContactsCallbacksHelper.notifyEventDeleted(paramInt1, paramInt2, i);
    }

    void onDataUpdated(int paramInt, EventEntry paramEventEntry)
    {
      ContactsCallbacksHelper localContactsCallbacksHelper = ContactsService.this.callbacksHelper;
      int i = paramEventEntry.id;
      int j = paramEventEntry.type;
      Time localTime = paramEventEntry.date;
      int k = paramEventEntry.version;
      int m = paramInt;
      localContactsCallbacksHelper.notifyEventUpdated(m, i, j, localTime, k);
    }
  }

  class ObservableFavoriteContacts extends ObservableContacts
  {
    ObservableFavoriteContacts()
    {
      super(localSparseIntArray);
    }

    void onContactDeleted(int paramInt)
    {
      ContactsService.this.callbacksHelper.notifyContactDeleted(paramInt, 2);
    }

    void onContactUpdated(int paramInt1, String paramString1, String paramString2, boolean paramBoolean, int paramInt2, int paramInt3)
    {
      ContactsService.access$100("onContactUpdated: contactId=" + paramInt1 + " displayName=" + paramString2 + " isStarred=" + paramBoolean + " photoId=" + paramInt2);
      ContactsCallbacksHelper localContactsCallbacksHelper = ContactsService.this.callbacksHelper;
      int i = paramInt1;
      String str1 = paramString1;
      String str2 = paramString2;
      boolean bool = paramBoolean;
      int j = paramInt2;
      int k = paramInt3;
      localContactsCallbacksHelper.notifyContactUpdated(i, str1, str2, bool, j, k);
      ContactsService.this.names.notifyStructuredNameChanged(paramInt1);
    }
  }

  class ObservableAllContacts extends ObservableContacts
  {
    ObservableAllContacts()
    {
      super(localSparseIntArray);
    }

    void onContactDeleted(int paramInt)
    {
      ContactsService.this.callbacksHelper.notifyContactDeleted(paramInt, 1);
    }

    void onContactUpdated(int paramInt1, String paramString1, String paramString2, boolean paramBoolean, int paramInt2, int paramInt3)
    {
      ContactsService.access$100("onContactUpdated: contactId=" + paramInt1 + " displayName=" + paramString2 + " isStarred=" + paramBoolean + " photoId=" + paramInt2);
      ContactsCallbacksHelper localContactsCallbacksHelper = ContactsService.this.callbacksHelper;
      int i = paramInt1;
      String str1 = paramString1;
      String str2 = paramString2;
      boolean bool = paramBoolean;
      int j = paramInt2;
      int k = paramInt3;
      localContactsCallbacksHelper.notifyContactUpdated(i, str1, str2, bool, j, k);
      ContactsService.this.names.notifyStructuredNameChanged(paramInt1);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.ContactsService
 * JD-Core Version:    0.6.0
 */