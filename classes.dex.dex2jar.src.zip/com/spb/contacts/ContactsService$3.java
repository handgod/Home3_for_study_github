package com.spb.contacts;

import android.os.RemoteException;
import java.util.List;

class ContactsService$3 extends IPhoneNumberResolvingService.Stub
{
  public void addPhoneNumber(String paramString)
    throws RemoteException
  {
    this.this$0.phoneNumberResolvingService.addPhoneNumber(paramString);
  }

  public long getResolvedContactId(String paramString)
    throws RemoteException
  {
    return this.this$0.phoneNumberResolvingService.getResolvedContactId(paramString);
  }

  public List<String> getResolvedPhoneNumbers(int paramInt)
    throws RemoteException
  {
    return this.this$0.phoneNumberResolvingService.getResolvedPhoneNumbers(paramInt);
  }

  public void registerCallback(IPhoneNumberResolvingServiceCallback paramIPhoneNumberResolvingServiceCallback)
    throws RemoteException
  {
    this.this$0.phoneNumberResolvingService.registerCallback(paramIPhoneNumberResolvingServiceCallback);
  }

  public void removePhoneNumber(String paramString)
    throws RemoteException
  {
    this.this$0.phoneNumberResolvingService.removePhoneNumber(paramString);
  }

  public void unregisterCallback(IPhoneNumberResolvingServiceCallback paramIPhoneNumberResolvingServiceCallback)
    throws RemoteException
  {
    this.this$0.phoneNumberResolvingService.unregisterCallback(paramIPhoneNumberResolvingServiceCallback);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.ContactsService.3
 * JD-Core Version:    0.6.0
 */