package com.spb.contacts;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import java.util.ArrayList;
import java.util.List;

public abstract interface IPhoneNumberResolvingService extends IInterface
{
  public abstract void addPhoneNumber(String paramString)
    throws RemoteException;

  public abstract long getResolvedContactId(String paramString)
    throws RemoteException;

  public abstract List<String> getResolvedPhoneNumbers(int paramInt)
    throws RemoteException;

  public abstract void registerCallback(IPhoneNumberResolvingServiceCallback paramIPhoneNumberResolvingServiceCallback)
    throws RemoteException;

  public abstract void removePhoneNumber(String paramString)
    throws RemoteException;

  public abstract void unregisterCallback(IPhoneNumberResolvingServiceCallback paramIPhoneNumberResolvingServiceCallback)
    throws RemoteException;

  public abstract class Stub extends Binder
    implements IPhoneNumberResolvingService
  {
    private static final String DESCRIPTOR = "com.spb.contacts.IPhoneNumberResolvingService";
    static final int TRANSACTION_addPhoneNumber = 2;
    static final int TRANSACTION_getResolvedContactId = 1;
    static final int TRANSACTION_getResolvedPhoneNumbers = 6;
    static final int TRANSACTION_registerCallback = 4;
    static final int TRANSACTION_removePhoneNumber = 3;
    static final int TRANSACTION_unregisterCallback = 5;

    public Stub()
    {
      attachInterface(this, "com.spb.contacts.IPhoneNumberResolvingService");
    }

    public static IPhoneNumberResolvingService asInterface(IBinder paramIBinder)
    {
      Object localObject;
      if (paramIBinder == null)
        localObject = null;
      while (true)
      {
        return localObject;
        localObject = paramIBinder.queryLocalInterface("com.spb.contacts.IPhoneNumberResolvingService");
        if ((localObject != null) && ((localObject instanceof IPhoneNumberResolvingService)))
        {
          localObject = (IPhoneNumberResolvingService)localObject;
          continue;
        }
        localObject = new Proxy();
      }
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      boolean bool = true;
      switch (paramInt1)
      {
      default:
        bool = super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      }
      while (true)
      {
        return bool;
        paramParcel2.writeString("com.spb.contacts.IPhoneNumberResolvingService");
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IPhoneNumberResolvingService");
        String str1 = paramParcel1.readString();
        long l = getResolvedContactId(str1);
        paramParcel2.writeNoException();
        paramParcel2.writeLong(l);
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IPhoneNumberResolvingService");
        String str2 = paramParcel1.readString();
        addPhoneNumber(str2);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IPhoneNumberResolvingService");
        String str3 = paramParcel1.readString();
        removePhoneNumber(str3);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IPhoneNumberResolvingService");
        IPhoneNumberResolvingServiceCallback localIPhoneNumberResolvingServiceCallback1 = IPhoneNumberResolvingServiceCallback.Stub.asInterface(paramParcel1.readStrongBinder());
        registerCallback(localIPhoneNumberResolvingServiceCallback1);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IPhoneNumberResolvingService");
        IPhoneNumberResolvingServiceCallback localIPhoneNumberResolvingServiceCallback2 = IPhoneNumberResolvingServiceCallback.Stub.asInterface(paramParcel1.readStrongBinder());
        unregisterCallback(localIPhoneNumberResolvingServiceCallback2);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IPhoneNumberResolvingService");
        int i = paramParcel1.readInt();
        List localList = getResolvedPhoneNumbers(i);
        paramParcel2.writeNoException();
        paramParcel2.writeStringList(localList);
      }
    }

    class Proxy
      implements IPhoneNumberResolvingService
    {
      Proxy()
      {
      }

      public void addPhoneNumber(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IPhoneNumberResolvingService");
          localParcel1.writeString(paramString);
          boolean bool = IPhoneNumberResolvingService.Stub.this.transact(2, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public IBinder asBinder()
      {
        return IPhoneNumberResolvingService.Stub.this;
      }

      public String getInterfaceDescriptor()
      {
        return "com.spb.contacts.IPhoneNumberResolvingService";
      }

      public long getResolvedContactId(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IPhoneNumberResolvingService");
          localParcel1.writeString(paramString);
          boolean bool = IPhoneNumberResolvingService.Stub.this.transact(1, localParcel1, localParcel2, 0);
          localParcel2.readException();
          long l1 = localParcel2.readLong();
          long l2 = l1;
          return l2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public List<String> getResolvedPhoneNumbers(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IPhoneNumberResolvingService");
          localParcel1.writeInt(paramInt);
          boolean bool = IPhoneNumberResolvingService.Stub.this.transact(6, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList1 = localParcel2.createStringArrayList();
          ArrayList localArrayList2 = localArrayList1;
          return localArrayList2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void registerCallback(IPhoneNumberResolvingServiceCallback paramIPhoneNumberResolvingServiceCallback)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IPhoneNumberResolvingService");
          if (paramIPhoneNumberResolvingServiceCallback != null)
          {
            localIBinder = paramIPhoneNumberResolvingServiceCallback.asBinder();
            localParcel1.writeStrongBinder(localIBinder);
            boolean bool = IPhoneNumberResolvingService.Stub.this.transact(4, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
          IBinder localIBinder = null;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public void removePhoneNumber(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IPhoneNumberResolvingService");
          localParcel1.writeString(paramString);
          boolean bool = IPhoneNumberResolvingService.Stub.this.transact(3, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void unregisterCallback(IPhoneNumberResolvingServiceCallback paramIPhoneNumberResolvingServiceCallback)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IPhoneNumberResolvingService");
          if (paramIPhoneNumberResolvingServiceCallback != null)
          {
            localIBinder = paramIPhoneNumberResolvingServiceCallback.asBinder();
            localParcel1.writeStrongBinder(localIBinder);
            boolean bool = IPhoneNumberResolvingService.Stub.this.transact(5, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
          IBinder localIBinder = null;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.IPhoneNumberResolvingService
 * JD-Core Version:    0.6.0
 */