package com.spb.contacts;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.Process;
import android.os.RemoteException;
import com.softspb.util.log.Logger;

class KillContactsService$1
  implements ServiceConnection
{
  public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
  {
    Logger localLogger1 = this.this$0.logger;
    String str1 = "onServiceConnected: " + paramComponentName;
    localLogger1.d(str1);
    try
    {
      i = IGetPid.Stub.asInterface(paramIBinder).getPid();
      Logger localLogger2 = this.this$0.logger;
      String str2 = "Got pid from contacts service: " + i;
      localLogger2.d(str2);
      this.this$0.unbindService(this);
      if (i == 0)
      {
        this.this$0.logger.w("Contacts service pid unknown");
        this.this$0.stopSelf();
        return;
      }
    }
    catch (RemoteException localRemoteException)
    {
      while (true)
      {
        int i;
        Logger localLogger3 = this.this$0.logger;
        String str3 = "Failed to get pid from contacts service: " + localRemoteException;
        localLogger3.e(str3, localRemoteException);
        continue;
        Logger localLogger4 = this.this$0.logger;
        String str4 = "Killing contacts service process: " + i;
        localLogger4.d(str4);
        Process.killProcess(i);
      }
    }
  }

  public void onServiceDisconnected(ComponentName paramComponentName)
  {
    Logger localLogger = this.this$0.logger;
    String str = "onServiceDisconnected: " + paramComponentName;
    localLogger.d(str);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.KillContactsService.1
 * JD-Core Version:    0.6.0
 */