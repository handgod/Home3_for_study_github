package com.spb.contacts;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract interface IPhoneNumberResolvingServiceCallback extends IInterface
{
  public abstract void onResolvedPhonesChanged(int paramInt)
    throws RemoteException;

  public abstract class Stub extends Binder
    implements IPhoneNumberResolvingServiceCallback
  {
    private static final String DESCRIPTOR = "com.spb.contacts.IPhoneNumberResolvingServiceCallback";
    static final int TRANSACTION_onResolvedPhonesChanged = 1;

    public Stub()
    {
      attachInterface(this, "com.spb.contacts.IPhoneNumberResolvingServiceCallback");
    }

    public static IPhoneNumberResolvingServiceCallback asInterface(IBinder paramIBinder)
    {
      Object localObject;
      if (paramIBinder == null)
        localObject = null;
      while (true)
      {
        return localObject;
        localObject = paramIBinder.queryLocalInterface("com.spb.contacts.IPhoneNumberResolvingServiceCallback");
        if ((localObject != null) && ((localObject instanceof IPhoneNumberResolvingServiceCallback)))
        {
          localObject = (IPhoneNumberResolvingServiceCallback)localObject;
          continue;
        }
        localObject = new Proxy();
      }
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      boolean bool = true;
      switch (paramInt1)
      {
      default:
        bool = super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
      case 1:
      }
      while (true)
      {
        return bool;
        paramParcel2.writeString("com.spb.contacts.IPhoneNumberResolvingServiceCallback");
        continue;
        paramParcel1.enforceInterface("com.spb.contacts.IPhoneNumberResolvingServiceCallback");
        int i = paramParcel1.readInt();
        onResolvedPhonesChanged(i);
        paramParcel2.writeNoException();
      }
    }

    class Proxy
      implements IPhoneNumberResolvingServiceCallback
    {
      Proxy()
      {
      }

      public IBinder asBinder()
      {
        return IPhoneNumberResolvingServiceCallback.Stub.this;
      }

      public String getInterfaceDescriptor()
      {
        return "com.spb.contacts.IPhoneNumberResolvingServiceCallback";
      }

      public void onResolvedPhonesChanged(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.spb.contacts.IPhoneNumberResolvingServiceCallback");
          localParcel1.writeInt(paramInt);
          boolean bool = IPhoneNumberResolvingServiceCallback.Stub.this.transact(1, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.spb.contacts.IPhoneNumberResolvingServiceCallback
 * JD-Core Version:    0.6.0
 */