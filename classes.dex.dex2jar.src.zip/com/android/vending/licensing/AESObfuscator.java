package com.android.vending.licensing;

import com.android.vending.licensing.util.Base64;
import com.android.vending.licensing.util.Base64DecoderException;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class AESObfuscator
  implements Obfuscator
{
  private static final String CIPHER_ALGORITHM = "AES/CBC/PKCS5Padding";
  private static final byte[] IV = ;
  private static final String KEYGEN_ALGORITHM = "PBEWITHSHAAND256BITAES-CBC-BC";
  private static final String UTF8 = "UTF-8";
  private static final String header = "com.android.vending.licensing.AESObfuscator-1|";
  private Cipher mDecryptor;
  private Cipher mEncryptor;

  public AESObfuscator(byte[] paramArrayOfByte, String paramString1, String paramString2)
  {
    try
    {
      SecretKeyFactory localSecretKeyFactory = SecretKeyFactory.getInstance("PBEWITHSHAAND256BITAES-CBC-BC");
      char[] arrayOfChar = (paramString1 + paramString2).toCharArray();
      PBEKeySpec localPBEKeySpec = new PBEKeySpec(arrayOfChar, paramArrayOfByte, 1024, 256);
      byte[] arrayOfByte1 = localSecretKeyFactory.generateSecret(localPBEKeySpec).getEncoded();
      SecretKeySpec localSecretKeySpec = new SecretKeySpec(arrayOfByte1, "AES");
      Cipher localCipher1 = Cipher.getInstance("AES/CBC/PKCS5Padding");
      this.mEncryptor = localCipher1;
      Cipher localCipher2 = this.mEncryptor;
      byte[] arrayOfByte2 = IV;
      IvParameterSpec localIvParameterSpec1 = new IvParameterSpec(arrayOfByte2);
      localCipher2.init(1, localSecretKeySpec, localIvParameterSpec1);
      Cipher localCipher3 = Cipher.getInstance("AES/CBC/PKCS5Padding");
      this.mDecryptor = localCipher3;
      Cipher localCipher4 = this.mDecryptor;
      byte[] arrayOfByte3 = IV;
      IvParameterSpec localIvParameterSpec2 = new IvParameterSpec(arrayOfByte3);
      localCipher4.init(2, localSecretKeySpec, localIvParameterSpec2);
      return;
    }
    catch (GeneralSecurityException localGeneralSecurityException)
    {
    }
    throw new RuntimeException("Invalid environment", localGeneralSecurityException);
  }

  public String obfuscate(String paramString)
  {
    Object localObject;
    if (paramString == null)
      localObject = null;
    while (true)
    {
      return localObject;
      try
      {
        Cipher localCipher = this.mEncryptor;
        byte[] arrayOfByte = ("com.android.vending.licensing.AESObfuscator-1|" + paramString).getBytes("UTF-8");
        String str = Base64.encode(localCipher.doFinal(arrayOfByte));
        localObject = str;
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
        throw new RuntimeException("Invalid environment", localUnsupportedEncodingException);
      }
      catch (GeneralSecurityException localGeneralSecurityException)
      {
      }
    }
    throw new RuntimeException("Invalid environment", localGeneralSecurityException);
  }

  public String unobfuscate(String paramString)
    throws ValidationException
  {
    Object localObject;
    if (paramString == null)
      localObject = null;
    while (true)
    {
      return localObject;
      try
      {
        Cipher localCipher = this.mDecryptor;
        byte[] arrayOfByte1 = Base64.decode(paramString);
        byte[] arrayOfByte2 = localCipher.doFinal(arrayOfByte1);
        str1 = new String(arrayOfByte2, "UTF-8");
        if (str1.indexOf("com.android.vending.licensing.AESObfuscator-1|") != 0)
        {
          String str2 = "Header not found (invalid data or key):" + paramString;
          throw new ValidationException(str2);
        }
      }
      catch (Base64DecoderException localBase64DecoderException)
      {
        String str1;
        StringBuilder localStringBuilder1 = new StringBuilder();
        String str3 = localBase64DecoderException.getMessage();
        String str4 = str3 + ":" + paramString;
        throw new ValidationException(str4);
        int i = "com.android.vending.licensing.AESObfuscator-1|".length();
        int j = str1.length();
        String str5 = str1.substring(i, j);
        localObject = str5;
      }
      catch (IllegalBlockSizeException localIllegalBlockSizeException)
      {
        StringBuilder localStringBuilder2 = new StringBuilder();
        String str6 = localIllegalBlockSizeException.getMessage();
        String str7 = str6 + ":" + paramString;
        throw new ValidationException(str7);
      }
      catch (BadPaddingException localBadPaddingException)
      {
        StringBuilder localStringBuilder3 = new StringBuilder();
        String str8 = localBadPaddingException.getMessage();
        String str9 = str8 + ":" + paramString;
        throw new ValidationException(str9);
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
      }
    }
    throw new RuntimeException("Invalid environment", localUnsupportedEncodingException);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.android.vending.licensing.AESObfuscator
 * JD-Core Version:    0.6.0
 */