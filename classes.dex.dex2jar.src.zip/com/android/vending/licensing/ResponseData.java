package com.android.vending.licensing;

import android.text.TextUtils;
import android.text.TextUtils.SimpleStringSplitter;
import android.text.TextUtils.StringSplitter;
import java.util.Iterator;
import java.util.regex.Pattern;

class ResponseData
{
  public String extra;
  public int nonce;
  public String packageName;
  public int responseCode;
  public long timestamp;
  public String userId;
  public String versionCode;

  public static ResponseData parse(String paramString)
  {
    TextUtils.SimpleStringSplitter localSimpleStringSplitter = new TextUtils.SimpleStringSplitter(58);
    localSimpleStringSplitter.setString(paramString);
    Iterator localIterator = localSimpleStringSplitter.iterator();
    if (!localIterator.hasNext())
      throw new IllegalArgumentException("Blank response.");
    String str1 = (String)localIterator.next();
    String str2 = "";
    if (localIterator.hasNext())
      str2 = (String)localIterator.next();
    String str3 = Pattern.quote("|");
    String[] arrayOfString = TextUtils.split(str1, str3);
    if (arrayOfString.length < 6)
      throw new IllegalArgumentException("Wrong number of fields.");
    ResponseData localResponseData = new ResponseData();
    localResponseData.extra = str2;
    int i = Integer.parseInt(arrayOfString[0]);
    localResponseData.responseCode = i;
    int j = Integer.parseInt(arrayOfString[1]);
    localResponseData.nonce = j;
    String str4 = arrayOfString[2];
    localResponseData.packageName = str4;
    String str5 = arrayOfString[3];
    localResponseData.versionCode = str5;
    String str6 = arrayOfString[4];
    localResponseData.userId = str6;
    long l = Long.parseLong(arrayOfString[5]);
    localResponseData.timestamp = l;
    return localResponseData;
  }

  public String toString()
  {
    Object[] arrayOfObject = new Object[6];
    Integer localInteger1 = Integer.valueOf(this.responseCode);
    arrayOfObject[0] = localInteger1;
    Integer localInteger2 = Integer.valueOf(this.nonce);
    arrayOfObject[1] = localInteger2;
    String str1 = this.packageName;
    arrayOfObject[2] = str1;
    String str2 = this.versionCode;
    arrayOfObject[3] = str2;
    String str3 = this.userId;
    arrayOfObject[4] = str3;
    Long localLong = Long.valueOf(this.timestamp);
    arrayOfObject[5] = localLong;
    return TextUtils.join("|", arrayOfObject);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.android.vending.licensing.ResponseData
 * JD-Core Version:    0.6.0
 */