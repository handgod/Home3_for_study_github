package com.android.vending.licensing;

public abstract interface Obfuscator
{
  public abstract String obfuscate(String paramString);

  public abstract String unobfuscate(String paramString)
    throws ValidationException;
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.android.vending.licensing.Obfuscator
 * JD-Core Version:    0.6.0
 */