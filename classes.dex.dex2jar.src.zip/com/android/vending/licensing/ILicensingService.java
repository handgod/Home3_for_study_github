package com.android.vending.licensing;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract interface ILicensingService extends IInterface
{
  public abstract void checkLicense(long paramLong, String paramString, ILicenseResultListener paramILicenseResultListener)
    throws RemoteException;

  public abstract class Stub extends Binder
    implements ILicensingService
  {
    private static final String DESCRIPTOR = "com.android.vending.licensing.ILicensingService";
    static final int TRANSACTION_checkLicense = 1;

    public Stub()
    {
      attachInterface(this, "com.android.vending.licensing.ILicensingService");
    }

    public static ILicensingService asInterface(IBinder paramIBinder)
    {
      Object localObject;
      if (paramIBinder == null)
        localObject = null;
      while (true)
      {
        return localObject;
        localObject = paramIBinder.queryLocalInterface("com.android.vending.licensing.ILicensingService");
        if ((localObject != null) && ((localObject instanceof ILicensingService)))
        {
          localObject = (ILicensingService)localObject;
          continue;
        }
        localObject = new Proxy();
      }
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      boolean bool = true;
      switch (paramInt1)
      {
      default:
        bool = super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
      case 1:
      }
      while (true)
      {
        return bool;
        paramParcel2.writeString("com.android.vending.licensing.ILicensingService");
        continue;
        paramParcel1.enforceInterface("com.android.vending.licensing.ILicensingService");
        long l = paramParcel1.readLong();
        String str = paramParcel1.readString();
        ILicenseResultListener localILicenseResultListener = ILicenseResultListener.Stub.asInterface(paramParcel1.readStrongBinder());
        checkLicense(l, str, localILicenseResultListener);
      }
    }

    class Proxy
      implements ILicensingService
    {
      Proxy()
      {
      }

      public IBinder asBinder()
      {
        return ILicensingService.Stub.this;
      }

      public void checkLicense(long paramLong, String paramString, ILicenseResultListener paramILicenseResultListener)
        throws RemoteException
      {
        IBinder localIBinder = null;
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.vending.licensing.ILicensingService");
          localParcel.writeLong(paramLong);
          localParcel.writeString(paramString);
          if (paramILicenseResultListener != null)
            localIBinder = paramILicenseResultListener.asBinder();
          localParcel.writeStrongBinder(localIBinder);
          boolean bool = ILicensingService.Stub.this.transact(1, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
        throw localObject;
      }

      public String getInterfaceDescriptor()
      {
        return "com.android.vending.licensing.ILicensingService";
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.android.vending.licensing.ILicensingService
 * JD-Core Version:    0.6.0
 */