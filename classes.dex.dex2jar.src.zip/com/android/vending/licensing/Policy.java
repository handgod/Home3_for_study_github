package com.android.vending.licensing;

public abstract interface Policy
{
  public abstract boolean allowAccess();

  public abstract void processServerResponse(LicenseResponse paramLicenseResponse, ResponseData paramResponseData);

  public enum LicenseResponse
  {
    static
    {
      LicenseResponse[] arrayOfLicenseResponse = new LicenseResponse[3];
      LicenseResponse localLicenseResponse1 = LICENSED;
      arrayOfLicenseResponse[0] = localLicenseResponse1;
      LicenseResponse localLicenseResponse2 = NOT_LICENSED;
      arrayOfLicenseResponse[1] = localLicenseResponse2;
      LicenseResponse localLicenseResponse3 = RETRY;
      arrayOfLicenseResponse[2] = localLicenseResponse3;
      $VALUES = arrayOfLicenseResponse;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.android.vending.licensing.Policy
 * JD-Core Version:    0.6.0
 */