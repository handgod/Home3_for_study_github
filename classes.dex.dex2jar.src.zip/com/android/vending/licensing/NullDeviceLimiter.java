package com.android.vending.licensing;

public class NullDeviceLimiter
  implements DeviceLimiter
{
  public Policy.LicenseResponse isDeviceAllowed(String paramString)
  {
    return Policy.LicenseResponse.LICENSED;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.android.vending.licensing.NullDeviceLimiter
 * JD-Core Version:    0.6.0
 */