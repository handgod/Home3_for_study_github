package com.android.vending.licensing;

import com.softspb.util.log.Logger;
import java.security.PublicKey;
import java.util.Set;

class LicenseChecker$ResultListener$2
  implements Runnable
{
  public void run()
  {
    LicenseChecker.access$000().i("Received response.");
    Set localSet = LicenseChecker.access$400(this.this$1.this$0);
    LicenseValidator localLicenseValidator1 = LicenseChecker.ResultListener.access$100(this.this$1);
    if (localSet.contains(localLicenseValidator1))
    {
      LicenseChecker.ResultListener.access$500(this.this$1);
      LicenseValidator localLicenseValidator2 = LicenseChecker.ResultListener.access$100(this.this$1);
      PublicKey localPublicKey = LicenseChecker.access$600(this.this$1.this$0);
      int i = this.val$responseCode;
      String str1 = this.val$signedData;
      String str2 = this.val$signature;
      localLicenseValidator2.verify(localPublicKey, i, str1, str2);
      LicenseChecker localLicenseChecker = this.this$1.this$0;
      LicenseValidator localLicenseValidator3 = LicenseChecker.ResultListener.access$100(this.this$1);
      LicenseChecker.access$300(localLicenseChecker, localLicenseValidator3);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.android.vending.licensing.LicenseChecker.ResultListener.2
 * JD-Core Version:    0.6.0
 */