package com.android.vending.licensing;

public abstract interface DeviceLimiter
{
  public abstract Policy.LicenseResponse isDeviceAllowed(String paramString);
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.android.vending.licensing.DeviceLimiter
 * JD-Core Version:    0.6.0
 */