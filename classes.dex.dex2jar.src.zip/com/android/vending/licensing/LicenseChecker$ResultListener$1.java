package com.android.vending.licensing;

import com.softspb.util.log.Logger;

class LicenseChecker$ResultListener$1
  implements Runnable
{
  public void run()
  {
    LicenseChecker.access$000().i("Check timed out.");
    LicenseChecker localLicenseChecker1 = this.this$1.this$0;
    LicenseValidator localLicenseValidator1 = LicenseChecker.ResultListener.access$100(this.this$1);
    LicenseChecker.access$200(localLicenseChecker1, localLicenseValidator1);
    LicenseChecker localLicenseChecker2 = this.this$1.this$0;
    LicenseValidator localLicenseValidator2 = LicenseChecker.ResultListener.access$100(this.this$1);
    LicenseChecker.access$300(localLicenseChecker2, localLicenseValidator2);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.android.vending.licensing.LicenseChecker.ResultListener.1
 * JD-Core Version:    0.6.0
 */