package com.android.vending.licensing;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract interface ILicenseResultListener extends IInterface
{
  public abstract void verifyLicense(int paramInt, String paramString1, String paramString2)
    throws RemoteException;

  public abstract class Stub extends Binder
    implements ILicenseResultListener
  {
    private static final String DESCRIPTOR = "com.android.vending.licensing.ILicenseResultListener";
    static final int TRANSACTION_verifyLicense = 1;

    public Stub()
    {
      attachInterface(this, "com.android.vending.licensing.ILicenseResultListener");
    }

    public static ILicenseResultListener asInterface(IBinder paramIBinder)
    {
      Object localObject;
      if (paramIBinder == null)
        localObject = null;
      while (true)
      {
        return localObject;
        localObject = paramIBinder.queryLocalInterface("com.android.vending.licensing.ILicenseResultListener");
        if ((localObject != null) && ((localObject instanceof ILicenseResultListener)))
        {
          localObject = (ILicenseResultListener)localObject;
          continue;
        }
        localObject = new Proxy();
      }
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      boolean bool = true;
      switch (paramInt1)
      {
      default:
        bool = super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
      case 1:
      }
      while (true)
      {
        return bool;
        paramParcel2.writeString("com.android.vending.licensing.ILicenseResultListener");
        continue;
        paramParcel1.enforceInterface("com.android.vending.licensing.ILicenseResultListener");
        int i = paramParcel1.readInt();
        String str1 = paramParcel1.readString();
        String str2 = paramParcel1.readString();
        verifyLicense(i, str1, str2);
      }
    }

    class Proxy
      implements ILicenseResultListener
    {
      Proxy()
      {
      }

      public IBinder asBinder()
      {
        return ILicenseResultListener.Stub.this;
      }

      public String getInterfaceDescriptor()
      {
        return "com.android.vending.licensing.ILicenseResultListener";
      }

      public void verifyLicense(int paramInt, String paramString1, String paramString2)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.vending.licensing.ILicenseResultListener");
          localParcel.writeInt(paramInt);
          localParcel.writeString(paramString1);
          localParcel.writeString(paramString2);
          boolean bool = ILicenseResultListener.Stub.this.transact(1, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
        throw localObject;
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.android.vending.licensing.ILicenseResultListener
 * JD-Core Version:    0.6.0
 */