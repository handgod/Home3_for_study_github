package com.android.vending.licensing.util;

public class Base64
{
  private static final byte[] ALPHABET = ;
  private static final byte[] DECODABET = ;
  public static final boolean DECODE = false;
  public static final boolean ENCODE = true;
  private static final byte EQUALS_SIGN = 61;
  private static final byte EQUALS_SIGN_ENC = -1;
  private static final byte NEW_LINE = 10;
  private static final byte[] WEBSAFE_ALPHABET = ;
  private static final byte[] WEBSAFE_DECODABET = ;
  private static final byte WHITE_SPACE_ENC = -5;

  static
  {
    if (!Base64.class.desiredAssertionStatus());
    for (int i = 1; ; i = 0)
    {
      $assertionsDisabled = i;
      ALPHABET = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
      WEBSAFE_ALPHABET = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 45, 95 };
      DECODABET = new byte[] { 247, 247, 247, 247, 247, 247, 247, 247, 247, 251, 251, 247, 247, 251, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 251, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 62, 247, 247, 247, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 247, 247, 247, 255, 247, 247, 247, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 247, 247, 247, 247, 247, 247, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 247, 247, 247, 247, 247 };
      WEBSAFE_DECODABET = new byte[] { 247, 247, 247, 247, 247, 247, 247, 247, 247, 251, 251, 247, 247, 251, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 251, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 62, 247, 247, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 247, 247, 247, 255, 247, 247, 247, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 247, 247, 247, 247, 63, 247, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 247, 247, 247, 247, 247 };
      return;
    }
  }

  public static byte[] decode(String paramString)
    throws Base64DecoderException
  {
    byte[] arrayOfByte = paramString.getBytes();
    int i = arrayOfByte.length;
    return decode(arrayOfByte, 0, i);
  }

  public static byte[] decode(byte[] paramArrayOfByte)
    throws Base64DecoderException
  {
    int i = paramArrayOfByte.length;
    return decode(paramArrayOfByte, 0, i);
  }

  public static byte[] decode(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws Base64DecoderException
  {
    byte[] arrayOfByte = DECODABET;
    return decode(paramArrayOfByte, paramInt1, paramInt2, arrayOfByte);
  }

  public static byte[] decode(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2)
    throws Base64DecoderException
  {
    byte[] arrayOfByte1 = new byte[paramInt2 * 3 / 4 + 2];
    int i = 0;
    byte[] arrayOfByte2 = new byte[4];
    int j = 0;
    int k = 0;
    int m = paramInt2;
    if (j < m)
    {
      int n = j + paramInt1;
      int i1 = (byte)(paramArrayOfByte1[n] & 0x7F);
      int i2 = paramArrayOfByte2[i1];
      if (i2 >= -1)
      {
        if (i2 < -1)
          break label464;
        if (i1 == 61)
        {
          int i3 = paramInt2 - j;
          int i4 = paramInt2 + -1 + paramInt1;
          int i5 = (byte)(paramArrayOfByte1[i4] & 0x7F);
          if ((k == 0) || (k == 1))
          {
            String str1 = "invalid padding byte '=' at byte offset " + j;
            throw new Base64DecoderException(str1);
          }
          if (((k == 3) && (i3 > 2)) || ((k == 4) && (i3 > 1)))
          {
            String str2 = "padding byte '=' falsely signals end of encoded value at offset " + j;
            throw new Base64DecoderException(str2);
          }
          if ((i5 == 61) || (i5 == 10))
            break label347;
          throw new Base64DecoderException("encoded value has invalid trailing byte");
        }
        i6 = k + 1;
        arrayOfByte2[k] = i1;
        if (i6 == 4)
        {
          byte[] arrayOfByte3 = paramArrayOfByte2;
          int i7 = decode4to3(arrayOfByte2, 0, arrayOfByte1, i, arrayOfByte3);
          i += i7;
        }
      }
    }
    label464: for (int i6 = 0; ; i6 = k)
    {
      j += 1;
      k = i6;
      break;
      StringBuilder localStringBuilder1 = new StringBuilder().append("Bad Base64 input character at ").append(j).append(": ");
      int i8 = j + paramInt1;
      int i9 = paramArrayOfByte1[i8];
      String str3 = i9 + "(decimal)";
      throw new Base64DecoderException(str3);
      label347: if (k != 0)
      {
        if (k == 1)
        {
          StringBuilder localStringBuilder2 = new StringBuilder().append("single trailing character at offset ");
          int i10 = paramInt2 + -1;
          String str4 = i10;
          throw new Base64DecoderException(str4);
        }
        int i11 = k + 1;
        arrayOfByte2[k] = 61;
        byte[] arrayOfByte4 = paramArrayOfByte2;
        int i12 = decode4to3(arrayOfByte2, 0, arrayOfByte1, i, arrayOfByte4);
        i += i12;
      }
      while (true)
      {
        byte[] arrayOfByte5 = new byte[i];
        System.arraycopy(arrayOfByte1, 0, arrayOfByte5, 0, i);
        return arrayOfByte5;
        int i13 = k;
      }
    }
  }

  private static int decode4to3(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, byte[] paramArrayOfByte3)
  {
    int i = paramInt1 + 2;
    int i3;
    if (paramArrayOfByte1[i] == 61)
    {
      int j = paramArrayOfByte1[paramInt1];
      int k = paramArrayOfByte3[j] << 24 >>> 6;
      int m = paramInt1 + 1;
      int n = paramArrayOfByte1[m];
      int i1 = paramArrayOfByte3[n] << 24 >>> 12;
      int i2 = (byte)((k | i1) >>> 16);
      paramArrayOfByte2[paramInt2] = i2;
      i3 = 1;
    }
    while (true)
    {
      return i3;
      int i4 = paramInt1 + 3;
      if (paramArrayOfByte1[i4] == 61)
      {
        int i5 = paramArrayOfByte1[paramInt1];
        int i6 = paramArrayOfByte3[i5] << 24 >>> 6;
        int i7 = paramInt1 + 1;
        int i8 = paramArrayOfByte1[i7];
        int i9 = paramArrayOfByte3[i8] << 24 >>> 12;
        int i10 = i6 | i9;
        int i11 = paramInt1 + 2;
        int i12 = paramArrayOfByte1[i11];
        int i13 = paramArrayOfByte3[i12] << 24 >>> 18;
        int i14 = i10 | i13;
        int i15 = (byte)(i14 >>> 16);
        paramArrayOfByte2[paramInt2] = i15;
        int i16 = paramInt2 + 1;
        int i17 = (byte)(i14 >>> 8);
        paramArrayOfByte2[i16] = i17;
        i3 = 2;
        continue;
      }
      int i18 = paramArrayOfByte1[paramInt1];
      int i19 = paramArrayOfByte3[i18] << 24 >>> 6;
      int i20 = paramInt1 + 1;
      int i21 = paramArrayOfByte1[i20];
      int i22 = paramArrayOfByte3[i21] << 24 >>> 12;
      int i23 = i19 | i22;
      int i24 = paramInt1 + 2;
      int i25 = paramArrayOfByte1[i24];
      int i26 = paramArrayOfByte3[i25] << 24 >>> 18;
      int i27 = i23 | i26;
      int i28 = paramInt1 + 3;
      int i29 = paramArrayOfByte1[i28];
      int i30 = paramArrayOfByte3[i29] << 24 >>> 24;
      int i31 = i27 | i30;
      int i32 = (byte)(i31 >> 16);
      paramArrayOfByte2[paramInt2] = i32;
      int i33 = paramInt2 + 1;
      int i34 = (byte)(i31 >> 8);
      paramArrayOfByte2[i33] = i34;
      int i35 = paramInt2 + 2;
      int i36 = (byte)i31;
      paramArrayOfByte2[i35] = i36;
      i3 = 3;
    }
  }

  public static byte[] decodeWebSafe(String paramString)
    throws Base64DecoderException
  {
    byte[] arrayOfByte = paramString.getBytes();
    int i = arrayOfByte.length;
    return decodeWebSafe(arrayOfByte, 0, i);
  }

  public static byte[] decodeWebSafe(byte[] paramArrayOfByte)
    throws Base64DecoderException
  {
    int i = paramArrayOfByte.length;
    return decodeWebSafe(paramArrayOfByte, 0, i);
  }

  public static byte[] decodeWebSafe(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws Base64DecoderException
  {
    byte[] arrayOfByte = WEBSAFE_DECODABET;
    return decode(paramArrayOfByte, paramInt1, paramInt2, arrayOfByte);
  }

  public static String encode(byte[] paramArrayOfByte)
  {
    int i = paramArrayOfByte.length;
    byte[] arrayOfByte = ALPHABET;
    return encode(paramArrayOfByte, 0, i, arrayOfByte, 1);
  }

  public static String encode(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, boolean paramBoolean)
  {
    byte[] arrayOfByte = encode(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, 2147483647);
    int i = arrayOfByte.length;
    while (true)
    {
      if ((!paramBoolean) && (i > 0))
      {
        int j = i + -1;
        if (arrayOfByte[j] == 61);
      }
      else
      {
        return new String(arrayOfByte, 0, i);
      }
      i += -1;
    }
  }

  public static byte[] encode(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    int i = (paramInt2 + 2) / 3 * 4;
    byte[] arrayOfByte1 = new byte[i / paramInt3 + i];
    int j = 0;
    int k = 0;
    int m = paramInt2 + -2;
    int n = 0;
    while (j < m)
    {
      int i1 = j + paramInt1;
      int i2 = paramArrayOfByte1[i1] << 24 >>> 8;
      int i3 = j + 1 + paramInt1;
      int i4 = paramArrayOfByte1[i3] << 24 >>> 16;
      int i5 = i2 | i4;
      int i6 = j + 2 + paramInt1;
      int i7 = paramArrayOfByte1[i6] << 24 >>> 24;
      int i8 = i5 | i7;
      int i9 = i8 >>> 18;
      int i10 = paramArrayOfByte2[i9];
      arrayOfByte1[k] = i10;
      int i11 = k + 1;
      int i12 = i8 >>> 12 & 0x3F;
      int i13 = paramArrayOfByte2[i12];
      arrayOfByte1[i11] = i13;
      int i14 = k + 2;
      int i15 = i8 >>> 6 & 0x3F;
      int i16 = paramArrayOfByte2[i15];
      arrayOfByte1[i14] = i16;
      int i17 = k + 3;
      int i18 = i8 & 0x3F;
      int i19 = paramArrayOfByte2[i18];
      arrayOfByte1[i17] = i19;
      n += 4;
      int i20 = paramInt3;
      if (n == i20)
      {
        int i21 = k + 4;
        arrayOfByte1[i21] = 10;
        k += 1;
        n = 0;
      }
      j += 3;
      k += 4;
    }
    if (j < paramInt2)
    {
      int i22 = j + paramInt1;
      int i23 = paramInt2 - j;
      byte[] arrayOfByte2 = paramArrayOfByte1;
      byte[] arrayOfByte3 = paramArrayOfByte2;
      byte[] arrayOfByte4 = encode3to4(arrayOfByte2, i22, i23, arrayOfByte1, k, arrayOfByte3);
      int i24 = n + 4;
      int i25 = paramInt3;
      if (i24 == i25)
      {
        int i26 = k + 4;
        arrayOfByte1[i26] = 10;
        k += 1;
      }
      k += 4;
    }
    if (!$assertionsDisabled)
    {
      int i27 = arrayOfByte1.length;
      if (k != i27)
        throw new AssertionError();
    }
    return arrayOfByte1;
  }

  private static byte[] encode3to4(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, byte[] paramArrayOfByte3)
  {
    int i = 0;
    int j;
    int m;
    label40: int i1;
    if (paramInt2 > 0)
    {
      j = paramArrayOfByte1[paramInt1] << 24 >>> 8;
      if (paramInt2 <= 1)
        break label112;
      int k = paramInt1 + 1;
      m = paramArrayOfByte1[k] << 24 >>> 16;
      m |= j;
      if (paramInt2 > 2)
      {
        int n = paramInt1 + 2;
        i = paramArrayOfByte1[n] << 24 >>> 24;
      }
      i1 = m | i;
      switch (paramInt2)
      {
      default:
      case 3:
      case 2:
      case 1:
      }
    }
    while (true)
    {
      return paramArrayOfByte2;
      j = 0;
      break;
      label112: m = 0;
      break label40;
      int i2 = i1 >>> 18;
      int i3 = paramArrayOfByte3[i2];
      paramArrayOfByte2[paramInt3] = i3;
      int i4 = paramInt3 + 1;
      int i5 = i1 >>> 12 & 0x3F;
      int i6 = paramArrayOfByte3[i5];
      paramArrayOfByte2[i4] = i6;
      int i7 = paramInt3 + 2;
      int i8 = i1 >>> 6 & 0x3F;
      int i9 = paramArrayOfByte3[i8];
      paramArrayOfByte2[i7] = i9;
      int i10 = paramInt3 + 3;
      int i11 = i1 & 0x3F;
      int i12 = paramArrayOfByte3[i11];
      paramArrayOfByte2[i10] = i12;
      continue;
      int i13 = i1 >>> 18;
      int i14 = paramArrayOfByte3[i13];
      paramArrayOfByte2[paramInt3] = i14;
      int i15 = paramInt3 + 1;
      int i16 = i1 >>> 12 & 0x3F;
      int i17 = paramArrayOfByte3[i16];
      paramArrayOfByte2[i15] = i17;
      int i18 = paramInt3 + 2;
      int i19 = i1 >>> 6 & 0x3F;
      int i20 = paramArrayOfByte3[i19];
      paramArrayOfByte2[i18] = i20;
      int i21 = paramInt3 + 3;
      paramArrayOfByte2[i21] = 61;
      continue;
      int i22 = i1 >>> 18;
      int i23 = paramArrayOfByte3[i22];
      paramArrayOfByte2[paramInt3] = i23;
      int i24 = paramInt3 + 1;
      int i25 = i1 >>> 12 & 0x3F;
      int i26 = paramArrayOfByte3[i25];
      paramArrayOfByte2[i24] = i26;
      int i27 = paramInt3 + 2;
      paramArrayOfByte2[i27] = 61;
      int i28 = paramInt3 + 3;
      paramArrayOfByte2[i28] = 61;
    }
  }

  public static String encodeWebSafe(byte[] paramArrayOfByte, boolean paramBoolean)
  {
    int i = paramArrayOfByte.length;
    byte[] arrayOfByte = WEBSAFE_ALPHABET;
    return encode(paramArrayOfByte, 0, i, arrayOfByte, paramBoolean);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.android.vending.licensing.util.Base64
 * JD-Core Version:    0.6.0
 */