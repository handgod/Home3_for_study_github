package com.android.vending.licensing.util;

public class Base64DecoderException extends Exception
{
  private static final long serialVersionUID = 1L;

  public Base64DecoderException()
  {
  }

  public Base64DecoderException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.android.vending.licensing.util.Base64DecoderException
 * JD-Core Version:    0.6.0
 */