package com.android.vending.licensing;

import android.content.Context;
import android.content.SharedPreferences;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;

public class ServerManagedPolicy
  implements Policy
{
  private static final String DEFAULT_MAX_RETRIES = "0";
  private static final String DEFAULT_RETRY_COUNT = "0";
  private static final String DEFAULT_RETRY_UNTIL = "0";
  private static final String DEFAULT_VALIDITY_TIMESTAMP = "0";
  private static final long MILLIS_PER_MINUTE = 60000L;
  private static final String PREFS_FILE = "com.android.vending.licensing.ServerManagedPolicy";
  private static final String PREF_LAST_RESPONSE = "lastResponse";
  private static final String PREF_MAX_RETRIES = "maxRetries";
  private static final String PREF_RETRY_COUNT = "retryCount";
  private static final String PREF_RETRY_UNTIL = "retryUntil";
  private static final String PREF_VALIDITY_TIMESTAMP = "validityTimestamp";
  private static Logger logger = Loggers.getLogger(ServerManagedPolicy.class);
  private Policy.LicenseResponse mLastResponse;
  private long mLastResponseTime = 0L;
  private long mMaxRetries;
  private PreferenceObfuscator mPreferences;
  private long mRetryCount;
  private long mRetryUntil;
  private long mValidityTimestamp;

  public ServerManagedPolicy(Context paramContext, Obfuscator paramObfuscator)
  {
    SharedPreferences localSharedPreferences = paramContext.getSharedPreferences("com.android.vending.licensing.ServerManagedPolicy", 0);
    PreferenceObfuscator localPreferenceObfuscator1 = new PreferenceObfuscator(localSharedPreferences, paramObfuscator);
    this.mPreferences = localPreferenceObfuscator1;
    PreferenceObfuscator localPreferenceObfuscator2 = this.mPreferences;
    String str = Policy.LicenseResponse.RETRY.toString();
    Policy.LicenseResponse localLicenseResponse = Policy.LicenseResponse.valueOf(localPreferenceObfuscator2.getString("lastResponse", str));
    this.mLastResponse = localLicenseResponse;
    long l1 = Long.parseLong(this.mPreferences.getString("validityTimestamp", "0"));
    this.mValidityTimestamp = l1;
    long l2 = Long.parseLong(this.mPreferences.getString("retryUntil", "0"));
    this.mRetryUntil = l2;
    long l3 = Long.parseLong(this.mPreferences.getString("maxRetries", "0"));
    this.mMaxRetries = l3;
    long l4 = Long.parseLong(this.mPreferences.getString("retryCount", "0"));
    this.mRetryCount = l4;
  }

  private Map<String, String> decodeExtras(String paramString)
  {
    HashMap localHashMap = new HashMap();
    try
    {
      String str1 = "?" + paramString;
      Iterator localIterator = URLEncodedUtils.parse(new URI(str1), "UTF-8").iterator();
      while (localIterator.hasNext())
      {
        NameValuePair localNameValuePair = (NameValuePair)localIterator.next();
        String str2 = localNameValuePair.getName();
        String str3 = localNameValuePair.getValue();
        Object localObject = localHashMap.put(str2, str3);
      }
    }
    catch (URISyntaxException localURISyntaxException)
    {
      logger.w("Invalid syntax error while decoding extras data from server.");
    }
    return localHashMap;
  }

  private void setLastResponse(Policy.LicenseResponse paramLicenseResponse)
  {
    Logger localLogger = logger;
    String str1 = "setLastResponse: mLastResponse=" + paramLicenseResponse;
    localLogger.d(str1);
    long l = System.currentTimeMillis();
    this.mLastResponseTime = l;
    this.mLastResponse = paramLicenseResponse;
    PreferenceObfuscator localPreferenceObfuscator = this.mPreferences;
    String str2 = paramLicenseResponse.toString();
    localPreferenceObfuscator.putString("lastResponse", str2);
  }

  private void setMaxRetries(String paramString)
  {
    try
    {
      Long localLong1 = Long.valueOf(Long.parseLong(paramString));
      localLong2 = localLong1;
      long l = localLong2.longValue();
      this.mMaxRetries = l;
      this.mPreferences.putString("maxRetries", paramString);
      return;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      while (true)
      {
        logger.w("Licence retry count (GR) missing, grace period disabled");
        paramString = "0";
        Long localLong2 = Long.valueOf(0L);
      }
    }
  }

  private void setRetryCount(long paramLong)
  {
    this.mRetryCount = paramLong;
    PreferenceObfuscator localPreferenceObfuscator = this.mPreferences;
    String str = Long.toString(paramLong);
    localPreferenceObfuscator.putString("retryCount", str);
  }

  private void setRetryUntil(String paramString)
  {
    try
    {
      Long localLong1 = Long.valueOf(Long.parseLong(paramString));
      localLong2 = localLong1;
      long l = localLong2.longValue();
      this.mRetryUntil = l;
      this.mPreferences.putString("retryUntil", paramString);
      return;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      while (true)
      {
        logger.w("License retry timestamp (GT) missing, grace period disabled");
        paramString = "0";
        Long localLong2 = Long.valueOf(0L);
      }
    }
  }

  private void setValidityTimestamp(String paramString)
  {
    try
    {
      Long localLong1 = Long.valueOf(Long.parseLong(paramString));
      localLong2 = localLong1;
      long l = localLong2.longValue();
      this.mValidityTimestamp = l;
      this.mPreferences.putString("validityTimestamp", paramString);
      return;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      while (true)
      {
        logger.w("License validity timestamp (VT) missing, caching for a minute");
        Long localLong2 = Long.valueOf(System.currentTimeMillis() + 60000L);
        paramString = Long.toString(localLong2.longValue());
      }
    }
  }

  public boolean allowAccess()
  {
    Logger localLogger = logger;
    StringBuilder localStringBuilder = new StringBuilder().append("mLastResponse=");
    Policy.LicenseResponse localLicenseResponse1 = this.mLastResponse;
    String str = localLicenseResponse1;
    localLogger.d(str);
    Policy.LicenseResponse localLicenseResponse2 = this.mLastResponse;
    Policy.LicenseResponse localLicenseResponse3 = Policy.LicenseResponse.NOT_LICENSED;
    if (localLicenseResponse2 != localLicenseResponse3);
    for (int i = 1; ; i = 0)
      return i;
  }

  public long getMaxRetries()
  {
    return this.mMaxRetries;
  }

  public long getRetryCount()
  {
    return this.mRetryCount;
  }

  public long getRetryUntil()
  {
    return this.mRetryUntil;
  }

  public long getValidityTimestamp()
  {
    return this.mValidityTimestamp;
  }

  public void processServerResponse(Policy.LicenseResponse paramLicenseResponse, ResponseData paramResponseData)
  {
    Policy.LicenseResponse localLicenseResponse1 = Policy.LicenseResponse.RETRY;
    if (paramLicenseResponse != localLicenseResponse1)
    {
      setRetryCount(0L);
      Policy.LicenseResponse localLicenseResponse2 = Policy.LicenseResponse.LICENSED;
      if (paramLicenseResponse != localLicenseResponse2)
        break label140;
      String str1 = paramResponseData.extra;
      Map localMap = decodeExtras(str1);
      this.mLastResponse = paramLicenseResponse;
      String str2 = (String)localMap.get("VT");
      setValidityTimestamp(str2);
      String str3 = (String)localMap.get("GT");
      setRetryUntil(str3);
      String str4 = (String)localMap.get("GR");
      setMaxRetries(str4);
    }
    while (true)
    {
      setLastResponse(paramLicenseResponse);
      this.mPreferences.commit();
      return;
      long l = this.mRetryCount + 1L;
      setRetryCount(l);
      break;
      label140: Policy.LicenseResponse localLicenseResponse3 = Policy.LicenseResponse.NOT_LICENSED;
      if (paramLicenseResponse != localLicenseResponse3)
        continue;
      setValidityTimestamp("0");
      setRetryUntil("0");
      setMaxRetries("0");
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.android.vending.licensing.ServerManagedPolicy
 * JD-Core Version:    0.6.0
 */