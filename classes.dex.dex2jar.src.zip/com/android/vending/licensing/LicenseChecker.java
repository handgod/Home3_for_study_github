package com.android.vending.licensing;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import com.android.vending.licensing.util.Base64;
import com.android.vending.licensing.util.Base64DecoderException;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;

public class LicenseChecker
  implements ServiceConnection
{
  private static final String KEY_FACTORY_ALGORITHM = "RSA";
  private static final SecureRandom RANDOM = ;
  private static final int TIMEOUT_MS = 10000;
  private static Logger logger = Loggers.getLogger(LicenseChecker.class);
  private final Set<LicenseValidator> mChecksInProgress;
  private final Context mContext;
  private Handler mHandler;
  private final String mPackageName;
  private final Queue<LicenseValidator> mPendingChecks;
  private final Policy mPolicy;
  private PublicKey mPublicKey;
  private ILicensingService mService;
  private final String mVersionCode;

  static
  {
    RANDOM = new SecureRandom();
  }

  public LicenseChecker(Context paramContext, Policy paramPolicy, String paramString)
  {
    HashSet localHashSet = new HashSet();
    this.mChecksInProgress = localHashSet;
    LinkedList localLinkedList = new LinkedList();
    this.mPendingChecks = localLinkedList;
    this.mContext = paramContext;
    this.mPolicy = paramPolicy;
    PublicKey localPublicKey = generatePublicKey(paramString);
    this.mPublicKey = localPublicKey;
    String str1 = this.mContext.getPackageName();
    this.mPackageName = str1;
    String str2 = this.mPackageName;
    String str3 = getVersionCode(paramContext, str2);
    this.mVersionCode = str3;
    HandlerThread localHandlerThread = new HandlerThread("background thread");
    localHandlerThread.start();
    Looper localLooper = localHandlerThread.getLooper();
    Handler localHandler = new Handler(localLooper);
    this.mHandler = localHandler;
  }

  private void cleanupService()
  {
    if (this.mService != null);
    try
    {
      this.mContext.unbindService(this);
      this.mService = null;
      return;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      while (true)
        logger.e("Unable to unbind from licensing service (already unbound)");
    }
  }

  /** @deprecated */
  private void finishCheck(LicenseValidator paramLicenseValidator)
  {
    monitorenter;
    try
    {
      boolean bool = this.mChecksInProgress.remove(paramLicenseValidator);
      if (this.mChecksInProgress.isEmpty())
        cleanupService();
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  private int generateNonce()
  {
    return RANDOM.nextInt();
  }

  private static PublicKey generatePublicKey(String paramString)
  {
    try
    {
      byte[] arrayOfByte = Base64.decode(paramString);
      KeyFactory localKeyFactory = KeyFactory.getInstance("RSA");
      X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(arrayOfByte);
      PublicKey localPublicKey = localKeyFactory.generatePublic(localX509EncodedKeySpec);
      return localPublicKey;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new RuntimeException(localNoSuchAlgorithmException);
    }
    catch (Base64DecoderException localBase64DecoderException)
    {
      logger.e("Could not decode from Base64.");
      throw new IllegalArgumentException(localBase64DecoderException);
    }
    catch (InvalidKeySpecException localInvalidKeySpecException)
    {
      logger.e("Invalid key specification.");
    }
    throw new IllegalArgumentException(localInvalidKeySpecException);
  }

  private static String getVersionCode(Context paramContext, String paramString)
  {
    try
    {
      String str1 = String.valueOf(paramContext.getPackageManager().getPackageInfo(paramString, 0).versionCode);
      str2 = str1;
      return str2;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      while (true)
      {
        logger.e("Package not found. could not get version code.");
        String str2 = "";
      }
    }
  }

  /** @deprecated */
  private void handleServiceConnectionError(LicenseValidator paramLicenseValidator)
  {
    monitorenter;
    try
    {
      logger.w("Connection error");
      Policy localPolicy = this.mPolicy;
      Policy.LicenseResponse localLicenseResponse = Policy.LicenseResponse.RETRY;
      localPolicy.processServerResponse(localLicenseResponse, null);
      paramLicenseValidator.getCallback().allow(0);
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  private void runChecks()
  {
    while (true)
    {
      LicenseValidator localLicenseValidator = (LicenseValidator)this.mPendingChecks.poll();
      if (localLicenseValidator == null)
        break;
      try
      {
        Logger localLogger = logger;
        StringBuilder localStringBuilder = new StringBuilder().append("Calling checkLicense on service for ");
        String str1 = localLicenseValidator.getPackageName();
        String str2 = str1;
        localLogger.i(str2);
        ILicensingService localILicensingService = this.mService;
        long l = localLicenseValidator.getNonce();
        String str3 = localLicenseValidator.getPackageName();
        ResultListener localResultListener = new ResultListener(localLicenseValidator);
        localILicensingService.checkLicense(l, str3, localResultListener);
        boolean bool = this.mChecksInProgress.add(localLicenseValidator);
      }
      catch (RemoteException localRemoteException)
      {
        logger.w("RemoteException in checkLicense call.", localRemoteException);
        handleServiceConnectionError(localLicenseValidator);
      }
    }
  }

  /** @deprecated */
  public void checkAccess(LicenseCheckerCallback paramLicenseCheckerCallback)
  {
    monitorenter;
    while (true)
    {
      LicenseValidator localLicenseValidator;
      try
      {
        Policy localPolicy = this.mPolicy;
        NullDeviceLimiter localNullDeviceLimiter = new NullDeviceLimiter();
        int i = generateNonce();
        String str1 = this.mPackageName;
        String str2 = this.mVersionCode;
        LicenseCheckerCallback localLicenseCheckerCallback = paramLicenseCheckerCallback;
        localLicenseValidator = new LicenseValidator(localPolicy, localNullDeviceLimiter, localLicenseCheckerCallback, i, str1, str2);
        if (this.mService == null)
        {
          logger.i("Binding to licensing service.");
          try
          {
            Context localContext = this.mContext;
            String str3 = ILicensingService.class.getName();
            Intent localIntent = new Intent(str3);
            if (!localContext.bindService(localIntent, this, 1))
              continue;
            logger.d("bind to service ok");
            boolean bool1 = this.mPendingChecks.offer(localLicenseValidator);
            monitorexit;
            return;
            logger.e("Could not bind to service.");
            handleServiceConnectionError(localLicenseValidator);
            continue;
          }
          catch (SecurityException localSecurityException)
          {
            LicenseCheckerCallback.ApplicationErrorCode localApplicationErrorCode = LicenseCheckerCallback.ApplicationErrorCode.MISSING_PERMISSION;
            paramLicenseCheckerCallback.applicationError(localApplicationErrorCode);
            continue;
          }
        }
      }
      finally
      {
        monitorexit;
      }
      boolean bool2 = this.mPendingChecks.offer(localLicenseValidator);
      runChecks();
    }
  }

  /** @deprecated */
  public void onDestroy()
  {
    monitorenter;
    try
    {
      cleanupService();
      this.mHandler.getLooper().quit();
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  /** @deprecated */
  public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
  {
    monitorenter;
    try
    {
      ILicensingService localILicensingService = ILicensingService.Stub.asInterface(paramIBinder);
      this.mService = localILicensingService;
      runChecks();
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  /** @deprecated */
  public void onServiceDisconnected(ComponentName paramComponentName)
  {
    monitorenter;
    try
    {
      logger.w("Service unexpectedly disconnected.");
      this.mService = null;
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  class ResultListener extends ILicenseResultListener.Stub
  {
    private Runnable mOnTimeout;
    private final LicenseValidator mValidator;

    public ResultListener(LicenseValidator arg2)
    {
      Object localObject;
      this.mValidator = localObject;
      LicenseChecker.ResultListener.1 local1 = new LicenseChecker.ResultListener.1(this, LicenseChecker.this);
      this.mOnTimeout = local1;
      startTimeout();
    }

    private void clearTimeout()
    {
      LicenseChecker.logger.i("Clearing timeout.");
      Handler localHandler = LicenseChecker.this.mHandler;
      Runnable localRunnable = this.mOnTimeout;
      localHandler.removeCallbacks(localRunnable);
    }

    private void startTimeout()
    {
      LicenseChecker.logger.i("Start monitoring timeout.");
      Handler localHandler = LicenseChecker.this.mHandler;
      Runnable localRunnable = this.mOnTimeout;
      boolean bool = localHandler.postDelayed(localRunnable, 10000L);
    }

    public void verifyLicense(int paramInt, String paramString1, String paramString2)
    {
      Handler localHandler = LicenseChecker.this.mHandler;
      LicenseChecker.ResultListener.2 local2 = new LicenseChecker.ResultListener.2(this, paramInt, paramString1, paramString2);
      boolean bool = localHandler.post(local2);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.android.vending.licensing.LicenseChecker
 * JD-Core Version:    0.6.0
 */