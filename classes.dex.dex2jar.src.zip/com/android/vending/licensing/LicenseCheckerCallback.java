package com.android.vending.licensing;

public abstract interface LicenseCheckerCallback
{
  public abstract void allow(boolean paramBoolean);

  public abstract void applicationError(ApplicationErrorCode paramApplicationErrorCode);

  public abstract void dontAllow();

  public enum ApplicationErrorCode
  {
    static
    {
      CHECK_IN_PROGRESS = new ApplicationErrorCode("CHECK_IN_PROGRESS", 3);
      INVALID_PUBLIC_KEY = new ApplicationErrorCode("INVALID_PUBLIC_KEY", 4);
      MISSING_PERMISSION = new ApplicationErrorCode("MISSING_PERMISSION", 5);
      ApplicationErrorCode[] arrayOfApplicationErrorCode = new ApplicationErrorCode[6];
      ApplicationErrorCode localApplicationErrorCode1 = INVALID_PACKAGE_NAME;
      arrayOfApplicationErrorCode[0] = localApplicationErrorCode1;
      ApplicationErrorCode localApplicationErrorCode2 = NON_MATCHING_UID;
      arrayOfApplicationErrorCode[1] = localApplicationErrorCode2;
      ApplicationErrorCode localApplicationErrorCode3 = NOT_MARKET_MANAGED;
      arrayOfApplicationErrorCode[2] = localApplicationErrorCode3;
      ApplicationErrorCode localApplicationErrorCode4 = CHECK_IN_PROGRESS;
      arrayOfApplicationErrorCode[3] = localApplicationErrorCode4;
      ApplicationErrorCode localApplicationErrorCode5 = INVALID_PUBLIC_KEY;
      arrayOfApplicationErrorCode[4] = localApplicationErrorCode5;
      ApplicationErrorCode localApplicationErrorCode6 = MISSING_PERMISSION;
      arrayOfApplicationErrorCode[5] = localApplicationErrorCode6;
      $VALUES = arrayOfApplicationErrorCode;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.android.vending.licensing.LicenseCheckerCallback
 * JD-Core Version:    0.6.0
 */