package com.android.vending.licensing;

public class ValidationException extends Exception
{
  private static final long serialVersionUID = 1L;

  public ValidationException()
  {
  }

  public ValidationException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.android.vending.licensing.ValidationException
 * JD-Core Version:    0.6.0
 */