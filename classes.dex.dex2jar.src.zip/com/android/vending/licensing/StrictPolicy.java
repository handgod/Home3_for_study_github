package com.android.vending.licensing;

public class StrictPolicy
  implements Policy
{
  private static final String TAG = "StrictPolicy";
  private Policy.LicenseResponse mLastResponse;
  private PreferenceObfuscator mPreferences;

  public StrictPolicy()
  {
    Policy.LicenseResponse localLicenseResponse = Policy.LicenseResponse.RETRY;
    this.mLastResponse = localLicenseResponse;
  }

  public boolean allowAccess()
  {
    Policy.LicenseResponse localLicenseResponse1 = this.mLastResponse;
    Policy.LicenseResponse localLicenseResponse2 = Policy.LicenseResponse.LICENSED;
    if (localLicenseResponse1 == localLicenseResponse2);
    for (int i = 1; ; i = 0)
      return i;
  }

  public void processServerResponse(Policy.LicenseResponse paramLicenseResponse, ResponseData paramResponseData)
  {
    this.mLastResponse = paramLicenseResponse;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.android.vending.licensing.StrictPolicy
 * JD-Core Version:    0.6.0
 */