package com.android.vending.licensing;

import android.text.TextUtils;
import com.android.vending.licensing.util.Base64;
import com.android.vending.licensing.util.Base64DecoderException;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;

class LicenseValidator
{
  private static final int ERROR_CONTACTING_SERVER = 257;
  private static final int ERROR_INVALID_PACKAGE_NAME = 258;
  private static final int ERROR_NON_MATCHING_UID = 259;
  private static final int ERROR_NOT_MARKET_MANAGED = 3;
  private static final int ERROR_OVER_QUOTA = 5;
  private static final int ERROR_SERVER_FAILURE = 4;
  private static final int LICENSED = 0;
  private static final int LICENSED_OLD_KEY = 2;
  private static final int NOT_LICENSED = 1;
  private static final String SIGNATURE_ALGORITHM = "SHA1withRSA";
  private static Logger logger = Loggers.getLogger(LicenseValidator.class);
  private final LicenseCheckerCallback mCallback;
  private final DeviceLimiter mDeviceLimiter;
  private final int mNonce;
  private final String mPackageName;
  private final Policy mPolicy;
  private final String mVersionCode;

  LicenseValidator(Policy paramPolicy, DeviceLimiter paramDeviceLimiter, LicenseCheckerCallback paramLicenseCheckerCallback, int paramInt, String paramString1, String paramString2)
  {
    this.mPolicy = paramPolicy;
    this.mDeviceLimiter = paramDeviceLimiter;
    this.mCallback = paramLicenseCheckerCallback;
    this.mNonce = paramInt;
    this.mPackageName = paramString1;
    this.mVersionCode = paramString2;
  }

  private void handleApplicationError(LicenseCheckerCallback.ApplicationErrorCode paramApplicationErrorCode)
  {
    this.mCallback.applicationError(paramApplicationErrorCode);
  }

  private void handleInvalidResponse()
  {
    this.mCallback.dontAllow();
  }

  private void handleResponse(Policy.LicenseResponse paramLicenseResponse, ResponseData paramResponseData)
  {
    this.mPolicy.processServerResponse(paramLicenseResponse, paramResponseData);
    if (this.mPolicy.allowAccess())
    {
      LicenseCheckerCallback localLicenseCheckerCallback = this.mCallback;
      Policy.LicenseResponse localLicenseResponse = Policy.LicenseResponse.RETRY;
      if (paramLicenseResponse != localLicenseResponse)
      {
        int i = 1;
        localLicenseCheckerCallback.allow(i);
      }
    }
    while (true)
    {
      return;
      int j = 0;
      break;
      this.mCallback.dontAllow();
    }
  }

  public LicenseCheckerCallback getCallback()
  {
    return this.mCallback;
  }

  public int getNonce()
  {
    return this.mNonce;
  }

  public String getPackageName()
  {
    return this.mPackageName;
  }

  public void verify(PublicKey paramPublicKey, int paramInt, String paramString1, String paramString2)
  {
    String str1 = null;
    Object localObject = null;
    if ((paramInt == 0) || (paramInt == 1) || (paramInt == 2));
    while (true)
    {
      try
      {
        Signature localSignature = Signature.getInstance("SHA1withRSA");
        localSignature.initVerify(paramPublicKey);
        if (paramString1 != null)
          continue;
        logger.e("Signed data is null");
        handleInvalidResponse();
        return;
        byte[] arrayOfByte1 = paramString1.getBytes();
        localSignature.update(arrayOfByte1);
        byte[] arrayOfByte2 = Base64.decode(paramString2);
        if (localSignature.verify(arrayOfByte2))
          continue;
        logger.e("Signature verification failed.");
        handleInvalidResponse();
        continue;
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
      {
        throw new RuntimeException(localNoSuchAlgorithmException);
      }
      catch (InvalidKeyException localInvalidKeyException)
      {
        LicenseCheckerCallback.ApplicationErrorCode localApplicationErrorCode1 = LicenseCheckerCallback.ApplicationErrorCode.INVALID_PUBLIC_KEY;
        handleApplicationError(localApplicationErrorCode1);
        continue;
      }
      catch (SignatureException localSignatureException)
      {
        throw new RuntimeException(localSignatureException);
      }
      catch (Base64DecoderException localBase64DecoderException)
      {
        logger.e("Could not Base64-decode signature.");
        handleInvalidResponse();
        continue;
        try
        {
          ResponseData localResponseData = ResponseData.parse(paramString1);
          localObject = localResponseData;
          if (localObject.responseCode == paramInt)
            continue;
          logger.e("Response codes don't match.");
          handleInvalidResponse();
        }
        catch (IllegalArgumentException localIllegalArgumentException)
        {
          logger.e("Could not parse response.");
          handleInvalidResponse();
        }
        continue;
        int i = localObject.nonce;
        int j = this.mNonce;
        if (i == j)
          continue;
        logger.e("Nonce doesn't match.");
        handleInvalidResponse();
        continue;
        String str2 = localObject.packageName;
        String str3 = this.mPackageName;
        if (str2.equals(str3))
          continue;
        logger.e("Package name doesn't match.");
        handleInvalidResponse();
        continue;
        String str4 = localObject.versionCode;
        String str5 = this.mVersionCode;
        if (str4.equals(str5))
          continue;
        logger.e("Version codes don't match.");
        handleInvalidResponse();
        continue;
        str1 = localObject.userId;
        if (TextUtils.isEmpty(str1))
        {
          logger.e("User identifier is empty.");
          handleInvalidResponse();
          continue;
        }
      }
      switch (paramInt)
      {
      default:
        logger.e("Unknown response code for license check.");
        handleInvalidResponse();
        break;
      case 0:
      case 2:
        Policy.LicenseResponse localLicenseResponse1 = this.mDeviceLimiter.isDeviceAllowed(str1);
        handleResponse(localLicenseResponse1, localObject);
        break;
      case 1:
        Policy.LicenseResponse localLicenseResponse2 = Policy.LicenseResponse.NOT_LICENSED;
        handleResponse(localLicenseResponse2, localObject);
        break;
      case 257:
        logger.w("Error contacting licensing server.");
        Policy.LicenseResponse localLicenseResponse3 = Policy.LicenseResponse.RETRY;
        handleResponse(localLicenseResponse3, localObject);
        break;
      case 4:
        logger.w("An error has occurred on the licensing server.");
        Policy.LicenseResponse localLicenseResponse4 = Policy.LicenseResponse.RETRY;
        handleResponse(localLicenseResponse4, localObject);
        break;
      case 5:
        logger.w("Licensing server is refusing to talk to this device, over quota.");
        Policy.LicenseResponse localLicenseResponse5 = Policy.LicenseResponse.RETRY;
        handleResponse(localLicenseResponse5, localObject);
        break;
      case 258:
        LicenseCheckerCallback.ApplicationErrorCode localApplicationErrorCode2 = LicenseCheckerCallback.ApplicationErrorCode.INVALID_PACKAGE_NAME;
        handleApplicationError(localApplicationErrorCode2);
        break;
      case 259:
        LicenseCheckerCallback.ApplicationErrorCode localApplicationErrorCode3 = LicenseCheckerCallback.ApplicationErrorCode.NON_MATCHING_UID;
        handleApplicationError(localApplicationErrorCode3);
        break;
      case 3:
        LicenseCheckerCallback.ApplicationErrorCode localApplicationErrorCode4 = LicenseCheckerCallback.ApplicationErrorCode.NOT_MARKET_MANAGED;
        handleApplicationError(localApplicationErrorCode4);
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.android.vending.licensing.LicenseValidator
 * JD-Core Version:    0.6.0
 */