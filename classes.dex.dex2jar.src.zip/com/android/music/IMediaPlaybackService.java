package com.android.music;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract interface IMediaPlaybackService extends IInterface
{
  public abstract long duration()
    throws RemoteException;

  public abstract void enqueue(long[] paramArrayOfLong, int paramInt)
    throws RemoteException;

  public abstract long getAlbumId()
    throws RemoteException;

  public abstract String getAlbumName()
    throws RemoteException;

  public abstract long getArtistId()
    throws RemoteException;

  public abstract String getArtistName()
    throws RemoteException;

  public abstract long getAudioId()
    throws RemoteException;

  public abstract int getMediaMountedCount()
    throws RemoteException;

  public abstract String getPath()
    throws RemoteException;

  public abstract long[] getQueue()
    throws RemoteException;

  public abstract int getQueuePosition()
    throws RemoteException;

  public abstract int getRepeatMode()
    throws RemoteException;

  public abstract int getShuffleMode()
    throws RemoteException;

  public abstract String getTrackName()
    throws RemoteException;

  public abstract boolean isPlaying()
    throws RemoteException;

  public abstract void moveQueueItem(int paramInt1, int paramInt2)
    throws RemoteException;

  public abstract void next()
    throws RemoteException;

  public abstract void open(long[] paramArrayOfLong, int paramInt)
    throws RemoteException;

  public abstract void openFile(String paramString, boolean paramBoolean)
    throws RemoteException;

  public abstract void openFileAsync(String paramString)
    throws RemoteException;

  public abstract void pause()
    throws RemoteException;

  public abstract void play()
    throws RemoteException;

  public abstract long position()
    throws RemoteException;

  public abstract void prev()
    throws RemoteException;

  public abstract int removeTrack(long paramLong)
    throws RemoteException;

  public abstract int removeTracks(int paramInt1, int paramInt2)
    throws RemoteException;

  public abstract long seek(long paramLong)
    throws RemoteException;

  public abstract void setQueuePosition(int paramInt)
    throws RemoteException;

  public abstract void setRepeatMode(int paramInt)
    throws RemoteException;

  public abstract void setShuffleMode(int paramInt)
    throws RemoteException;

  public abstract void stop()
    throws RemoteException;

  public abstract class Stub extends Binder
    implements IMediaPlaybackService
  {
    private static final String DESCRIPTOR = "com.android.music.IMediaPlaybackService";
    static final int TRANSACTION_duration = 11;
    static final int TRANSACTION_enqueue = 19;
    static final int TRANSACTION_getAlbumId = 16;
    static final int TRANSACTION_getAlbumName = 15;
    static final int TRANSACTION_getArtistId = 18;
    static final int TRANSACTION_getArtistName = 17;
    static final int TRANSACTION_getAudioId = 24;
    static final int TRANSACTION_getMediaMountedCount = 31;
    static final int TRANSACTION_getPath = 23;
    static final int TRANSACTION_getQueue = 20;
    static final int TRANSACTION_getQueuePosition = 4;
    static final int TRANSACTION_getRepeatMode = 30;
    static final int TRANSACTION_getShuffleMode = 26;
    static final int TRANSACTION_getTrackName = 14;
    static final int TRANSACTION_isPlaying = 5;
    static final int TRANSACTION_moveQueueItem = 21;
    static final int TRANSACTION_next = 10;
    static final int TRANSACTION_open = 3;
    static final int TRANSACTION_openFile = 1;
    static final int TRANSACTION_openFileAsync = 2;
    static final int TRANSACTION_pause = 7;
    static final int TRANSACTION_play = 8;
    static final int TRANSACTION_position = 12;
    static final int TRANSACTION_prev = 9;
    static final int TRANSACTION_removeTrack = 28;
    static final int TRANSACTION_removeTracks = 27;
    static final int TRANSACTION_seek = 13;
    static final int TRANSACTION_setQueuePosition = 22;
    static final int TRANSACTION_setRepeatMode = 29;
    static final int TRANSACTION_setShuffleMode = 25;
    static final int TRANSACTION_stop = 6;

    public Stub()
    {
      attachInterface(this, "com.android.music.IMediaPlaybackService");
    }

    public static IMediaPlaybackService asInterface(IBinder paramIBinder)
    {
      Object localObject;
      if (paramIBinder == null)
        localObject = null;
      while (true)
      {
        return localObject;
        localObject = paramIBinder.queryLocalInterface("com.android.music.IMediaPlaybackService");
        if ((localObject != null) && ((localObject instanceof IMediaPlaybackService)))
        {
          localObject = (IMediaPlaybackService)localObject;
          continue;
        }
        localObject = new Proxy();
      }
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      int i = 0;
      boolean bool1 = true;
      switch (paramInt1)
      {
      default:
        bool1 = super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
      case 14:
      case 15:
      case 16:
      case 17:
      case 18:
      case 19:
      case 20:
      case 21:
      case 22:
      case 23:
      case 24:
      case 25:
      case 26:
      case 27:
      case 28:
      case 29:
      case 30:
      case 31:
      }
      while (true)
      {
        return bool1;
        paramParcel2.writeString("com.android.music.IMediaPlaybackService");
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        String str1 = paramParcel1.readString();
        if (paramParcel1.readInt() != 0)
          i = 1;
        openFile(str1, i);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        String str2 = paramParcel1.readString();
        openFileAsync(str2);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        long[] arrayOfLong1 = paramParcel1.createLongArray();
        int j = paramParcel1.readInt();
        open(arrayOfLong1, j);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        int k = getQueuePosition();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(k);
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        boolean bool2 = isPlaying();
        paramParcel2.writeNoException();
        if (bool2)
          i = 1;
        paramParcel2.writeInt(i);
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        stop();
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        pause();
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        play();
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        prev();
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        next();
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        long l1 = duration();
        paramParcel2.writeNoException();
        paramParcel2.writeLong(l1);
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        long l2 = position();
        paramParcel2.writeNoException();
        paramParcel2.writeLong(l2);
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        long l3 = paramParcel1.readLong();
        long l4 = seek(l3);
        paramParcel2.writeNoException();
        paramParcel2.writeLong(l4);
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        String str3 = getTrackName();
        paramParcel2.writeNoException();
        paramParcel2.writeString(str3);
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        String str4 = getAlbumName();
        paramParcel2.writeNoException();
        paramParcel2.writeString(str4);
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        long l5 = getAlbumId();
        paramParcel2.writeNoException();
        paramParcel2.writeLong(l5);
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        String str5 = getArtistName();
        paramParcel2.writeNoException();
        paramParcel2.writeString(str5);
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        long l6 = getArtistId();
        paramParcel2.writeNoException();
        paramParcel2.writeLong(l6);
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        long[] arrayOfLong2 = paramParcel1.createLongArray();
        int m = paramParcel1.readInt();
        enqueue(arrayOfLong2, m);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        long[] arrayOfLong3 = getQueue();
        paramParcel2.writeNoException();
        paramParcel2.writeLongArray(arrayOfLong3);
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        int n = paramParcel1.readInt();
        int i1 = paramParcel1.readInt();
        moveQueueItem(n, i1);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        int i2 = paramParcel1.readInt();
        setQueuePosition(i2);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        String str6 = getPath();
        paramParcel2.writeNoException();
        paramParcel2.writeString(str6);
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        long l7 = getAudioId();
        paramParcel2.writeNoException();
        paramParcel2.writeLong(l7);
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        int i3 = paramParcel1.readInt();
        setShuffleMode(i3);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        int i4 = getShuffleMode();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i4);
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        int i5 = paramParcel1.readInt();
        int i6 = paramParcel1.readInt();
        int i7 = removeTracks(i5, i6);
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i7);
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        long l8 = paramParcel1.readLong();
        int i8 = removeTrack(l8);
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i8);
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        int i9 = paramParcel1.readInt();
        setRepeatMode(i9);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        int i10 = getRepeatMode();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i10);
        continue;
        paramParcel1.enforceInterface("com.android.music.IMediaPlaybackService");
        int i11 = getMediaMountedCount();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i11);
      }
    }

    class Proxy
      implements IMediaPlaybackService
    {
      Proxy()
      {
      }

      public IBinder asBinder()
      {
        return IMediaPlaybackService.Stub.this;
      }

      public long duration()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(11, localParcel1, localParcel2, 0);
          localParcel2.readException();
          long l1 = localParcel2.readLong();
          long l2 = l1;
          return l2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void enqueue(long[] paramArrayOfLong, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          localParcel1.writeLongArray(paramArrayOfLong);
          localParcel1.writeInt(paramInt);
          boolean bool = IMediaPlaybackService.Stub.this.transact(19, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public long getAlbumId()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(16, localParcel1, localParcel2, 0);
          localParcel2.readException();
          long l1 = localParcel2.readLong();
          long l2 = l1;
          return l2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public String getAlbumName()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(15, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str1 = localParcel2.readString();
          String str2 = str1;
          return str2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public long getArtistId()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(18, localParcel1, localParcel2, 0);
          localParcel2.readException();
          long l1 = localParcel2.readLong();
          long l2 = l1;
          return l2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public String getArtistName()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(17, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str1 = localParcel2.readString();
          String str2 = str1;
          return str2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public long getAudioId()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(24, localParcel1, localParcel2, 0);
          localParcel2.readException();
          long l1 = localParcel2.readLong();
          long l2 = l1;
          return l2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public String getInterfaceDescriptor()
      {
        return "com.android.music.IMediaPlaybackService";
      }

      public int getMediaMountedCount()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(31, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = i;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public String getPath()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(23, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str1 = localParcel2.readString();
          String str2 = str1;
          return str2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public long[] getQueue()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(20, localParcel1, localParcel2, 0);
          localParcel2.readException();
          long[] arrayOfLong1 = localParcel2.createLongArray();
          long[] arrayOfLong2 = arrayOfLong1;
          return arrayOfLong2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int getQueuePosition()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(4, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = i;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int getRepeatMode()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(30, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = i;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int getShuffleMode()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(26, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = i;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public String getTrackName()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(14, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str1 = localParcel2.readString();
          String str2 = str1;
          return str2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public boolean isPlaying()
        throws RemoteException
      {
        int i = 0;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(5, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int j = localParcel2.readInt();
          if (j != 0)
            i = 1;
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void moveQueueItem(int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          boolean bool = IMediaPlaybackService.Stub.this.transact(21, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void next()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(10, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void open(long[] paramArrayOfLong, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          localParcel1.writeLongArray(paramArrayOfLong);
          localParcel1.writeInt(paramInt);
          boolean bool = IMediaPlaybackService.Stub.this.transact(3, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void openFile(String paramString, boolean paramBoolean)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          localParcel1.writeString(paramString);
          if (paramBoolean)
          {
            localParcel1.writeInt(i);
            boolean bool = IMediaPlaybackService.Stub.this.transact(1, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
          i = 0;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public void openFileAsync(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          localParcel1.writeString(paramString);
          boolean bool = IMediaPlaybackService.Stub.this.transact(2, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void pause()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(7, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void play()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(8, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public long position()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(12, localParcel1, localParcel2, 0);
          localParcel2.readException();
          long l1 = localParcel2.readLong();
          long l2 = l1;
          return l2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void prev()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(9, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int removeTrack(long paramLong)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          localParcel1.writeLong(paramLong);
          boolean bool = IMediaPlaybackService.Stub.this.transact(28, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = i;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int removeTracks(int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          boolean bool = IMediaPlaybackService.Stub.this.transact(27, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = i;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public long seek(long paramLong)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          localParcel1.writeLong(paramLong);
          boolean bool = IMediaPlaybackService.Stub.this.transact(13, localParcel1, localParcel2, 0);
          localParcel2.readException();
          long l1 = localParcel2.readLong();
          long l2 = l1;
          return l2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void setQueuePosition(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          localParcel1.writeInt(paramInt);
          boolean bool = IMediaPlaybackService.Stub.this.transact(22, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void setRepeatMode(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          localParcel1.writeInt(paramInt);
          boolean bool = IMediaPlaybackService.Stub.this.transact(29, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void setShuffleMode(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          localParcel1.writeInt(paramInt);
          boolean bool = IMediaPlaybackService.Stub.this.transact(25, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void stop()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(6, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.android.music.IMediaPlaybackService
 * JD-Core Version:    0.6.0
 */