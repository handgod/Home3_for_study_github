package com.google.gson;

import com.google.gson.internal..Gson.Types;
import java.lang.reflect.Array;
import java.lang.reflect.Type;

final class JsonArrayDeserializationVisitor<T> extends JsonDeserializationVisitor<T>
{
  JsonArrayDeserializationVisitor(JsonArray paramJsonArray, Type paramType, ObjectNavigator paramObjectNavigator, FieldNamingStrategy2 paramFieldNamingStrategy2, ObjectConstructor paramObjectConstructor, ParameterizedTypeHandlerMap<JsonDeserializer<?>> paramParameterizedTypeHandlerMap, JsonDeserializationContext paramJsonDeserializationContext)
  {
    super(paramJsonArray, paramType, paramObjectNavigator, paramFieldNamingStrategy2, paramObjectConstructor, paramParameterizedTypeHandlerMap, paramJsonDeserializationContext);
  }

  protected T constructTarget()
  {
    if (!this.json.isJsonArray())
    {
      StringBuilder localStringBuilder = new StringBuilder().append("Expecting array found: ");
      JsonElement localJsonElement = this.json;
      String str = localJsonElement;
      throw new JsonParseException(str);
    }
    JsonArray localJsonArray = this.json.getAsJsonArray();
    ObjectConstructor localObjectConstructor1;
    Type localType;
    int i;
    if (.Gson.Types.isArray(this.targetType))
    {
      localObjectConstructor1 = this.objectConstructor;
      localType = .Gson.Types.getArrayComponentType(this.targetType);
      i = localJsonArray.size();
    }
    ObjectConstructor localObjectConstructor2;
    Class localClass;
    for (Object localObject = localObjectConstructor1.constructArray(localType, i); ; localObject = localObjectConstructor2.construct(localClass))
    {
      return localObject;
      localObjectConstructor2 = this.objectConstructor;
      localClass = .Gson.Types.getRawType(this.targetType);
    }
  }

  public void startVisitingObject(Object paramObject)
  {
    String str = "Expecting array but found object: " + paramObject;
    throw new JsonParseException(str);
  }

  public void visitArray(Object paramObject, Type paramType)
  {
    if (!this.json.isJsonArray())
    {
      StringBuilder localStringBuilder = new StringBuilder().append("Expecting array found: ");
      JsonElement localJsonElement1 = this.json;
      String str = localJsonElement1;
      throw new JsonParseException(str);
    }
    JsonArray localJsonArray1 = this.json.getAsJsonArray();
    int i = 0;
    int j = localJsonArray1.size();
    if (i < j)
    {
      JsonElement localJsonElement2 = localJsonArray1.get(i);
      Object localObject;
      if ((localJsonElement2 == null) || (localJsonElement2.isJsonNull()))
        localObject = null;
      while (true)
      {
        Array.set(paramObject, i, localObject);
        i += 1;
        break;
        if ((localJsonElement2 instanceof JsonObject))
        {
          Type localType1 = .Gson.Types.getArrayComponentType(paramType);
          localObject = visitChildAsObject(localType1, localJsonElement2);
          continue;
        }
        if ((localJsonElement2 instanceof JsonArray))
        {
          Type localType2 = .Gson.Types.getArrayComponentType(paramType);
          JsonArray localJsonArray2 = localJsonElement2.getAsJsonArray();
          localObject = visitChildAsArray(localType2, localJsonArray2);
          continue;
        }
        if (!(localJsonElement2 instanceof JsonPrimitive))
          break label213;
        Type localType3 = .Gson.Types.getArrayComponentType(paramType);
        JsonPrimitive localJsonPrimitive = localJsonElement2.getAsJsonPrimitive();
        localObject = visitChildAsObject(localType3, localJsonPrimitive);
      }
      label213: throw new IllegalStateException();
    }
  }

  public void visitArrayField(FieldAttributes paramFieldAttributes, Type paramType, Object paramObject)
  {
    StringBuilder localStringBuilder = new StringBuilder().append("Expecting array but found array field ");
    String str1 = paramFieldAttributes.getName();
    String str2 = str1 + ": " + paramObject;
    throw new JsonParseException(str2);
  }

  public boolean visitFieldUsingCustomHandler(FieldAttributes paramFieldAttributes, Type paramType, Object paramObject)
  {
    StringBuilder localStringBuilder = new StringBuilder().append("Expecting array but found field ");
    String str1 = paramFieldAttributes.getName();
    String str2 = str1 + ": " + paramObject;
    throw new JsonParseException(str2);
  }

  public void visitObjectField(FieldAttributes paramFieldAttributes, Type paramType, Object paramObject)
  {
    StringBuilder localStringBuilder = new StringBuilder().append("Expecting array but found object field ");
    String str1 = paramFieldAttributes.getName();
    String str2 = str1 + ": " + paramObject;
    throw new JsonParseException(str2);
  }

  public void visitPrimitive(Object paramObject)
  {
    StringBuilder localStringBuilder = new StringBuilder().append("Type information is unavailable, and the target is not a primitive: ");
    JsonElement localJsonElement = this.json;
    String str = localJsonElement;
    throw new JsonParseException(str);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.JsonArrayDeserializationVisitor
 * JD-Core Version:    0.6.0
 */