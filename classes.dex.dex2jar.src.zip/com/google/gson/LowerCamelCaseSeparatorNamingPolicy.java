package com.google.gson;

final class LowerCamelCaseSeparatorNamingPolicy extends CompositionFieldNamingPolicy
{
  public LowerCamelCaseSeparatorNamingPolicy(String paramString)
  {
    super(arrayOfRecursiveFieldNamingPolicy);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.LowerCamelCaseSeparatorNamingPolicy
 * JD-Core Version:    0.6.0
 */