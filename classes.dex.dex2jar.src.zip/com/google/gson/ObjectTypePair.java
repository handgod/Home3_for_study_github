package com.google.gson;

import java.lang.reflect.Type;

final class ObjectTypePair
{
  private Object obj;
  private final boolean preserveType;
  final Type type;

  ObjectTypePair(Object paramObject, Type paramType, boolean paramBoolean)
  {
    this.obj = paramObject;
    this.type = paramType;
    this.preserveType = paramBoolean;
  }

  static Type getActualTypeIfMoreSpecific(Type paramType, Class<?> paramClass)
  {
    if ((paramType instanceof Class))
    {
      if (((Class)paramType).isAssignableFrom(paramClass))
        paramType = paramClass;
      if (paramType == Object.class)
        paramType = paramClass;
    }
    return paramType;
  }

  public boolean equals(Object paramObject)
  {
    int i = 1;
    int j = 0;
    if (this == paramObject)
      j = 1;
    ObjectTypePair localObjectTypePair;
    while (true)
    {
      return j;
      if (paramObject == null)
        continue;
      Class localClass1 = getClass();
      Class localClass2 = paramObject.getClass();
      if (localClass1 != localClass2)
        continue;
      localObjectTypePair = (ObjectTypePair)paramObject;
      if (this.obj != null)
        break;
      if (localObjectTypePair.obj != null)
        continue;
      label57: if (this.type != null)
        break label120;
      if (localObjectTypePair.type != null)
        continue;
      label72: boolean bool1 = this.preserveType;
      boolean bool2 = localObjectTypePair.preserveType;
      if (bool1 != bool2)
        break label146;
    }
    while (true)
    {
      j = i;
      break;
      Object localObject1 = this.obj;
      Object localObject2 = localObjectTypePair.obj;
      if (localObject1 == localObject2)
        break label57;
      break;
      label120: Type localType1 = this.type;
      Type localType2 = localObjectTypePair.type;
      if (localType1.equals(localType2))
        break label72;
      break;
      label146: i = 0;
    }
  }

  <HANDLER> Pair<HANDLER, ObjectTypePair> getMatchingHandler(ParameterizedTypeHandlerMap<HANDLER> paramParameterizedTypeHandlerMap)
  {
    Object localObject;
    Pair localPair;
    if ((!this.preserveType) && (this.obj != null))
    {
      ObjectTypePair localObjectTypePair = toMoreSpecificType();
      Type localType1 = localObjectTypePair.type;
      localObject = paramParameterizedTypeHandlerMap.getHandlerFor(localType1);
      if (localObject != null)
        localPair = new Pair(localObject, localObjectTypePair);
    }
    while (true)
    {
      return localPair;
      Type localType2 = this.type;
      localObject = paramParameterizedTypeHandlerMap.getHandlerFor(localType2);
      if (localObject == null)
      {
        localPair = null;
        continue;
      }
      localPair = new Pair(localObject, this);
    }
  }

  Type getMoreSpecificType()
  {
    if ((this.preserveType) || (this.obj == null));
    Type localType2;
    Class localClass;
    for (Type localType1 = this.type; ; localType1 = getActualTypeIfMoreSpecific(localType2, localClass))
    {
      return localType1;
      localType2 = this.type;
      localClass = this.obj.getClass();
    }
  }

  Object getObject()
  {
    return this.obj;
  }

  Type getType()
  {
    return this.type;
  }

  public int hashCode()
  {
    if (this.obj == null);
    for (int i = 31; ; i = this.obj.hashCode())
      return i;
  }

  public boolean isPreserveType()
  {
    return this.preserveType;
  }

  void setObject(Object paramObject)
  {
    this.obj = paramObject;
  }

  ObjectTypePair toMoreSpecificType()
  {
    if ((this.preserveType) || (this.obj == null));
    while (true)
    {
      return this;
      Type localType1 = this.type;
      Class localClass = this.obj.getClass();
      Type localType2 = getActualTypeIfMoreSpecific(localType1, localClass);
      Type localType3 = this.type;
      if (localType2 == localType3)
        continue;
      Object localObject = this.obj;
      boolean bool = this.preserveType;
      this = new ObjectTypePair(localObject, localType2, bool);
    }
  }

  public String toString()
  {
    Object[] arrayOfObject = new Object[3];
    Boolean localBoolean = Boolean.valueOf(this.preserveType);
    arrayOfObject[0] = localBoolean;
    Type localType = this.type;
    arrayOfObject[1] = localType;
    Object localObject = this.obj;
    arrayOfObject[2] = localObject;
    return String.format("preserveType: %b, type: %s, obj: %s", arrayOfObject);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.ObjectTypePair
 * JD-Core Version:    0.6.0
 */