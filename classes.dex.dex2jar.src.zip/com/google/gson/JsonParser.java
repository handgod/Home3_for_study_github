package com.google.gson;

import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.MalformedJsonException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

public final class JsonParser
{
  // ERROR //
  public JsonElement parse(JsonReader paramJsonReader)
    throws JsonIOException, JsonSyntaxException
  {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual 27	com/google/gson/stream/JsonReader:isLenient	()Z
    //   4: istore_2
    //   5: aload_1
    //   6: ldc 28
    //   8: invokevirtual 32	com/google/gson/stream/JsonReader:setLenient	(Z)V
    //   11: aload_1
    //   12: invokestatic 36	com/google/gson/Streams:parse	(Lcom/google/gson/stream/JsonReader;)Lcom/google/gson/JsonElement;
    //   15: astore_3
    //   16: aload_3
    //   17: astore 4
    //   19: aload_1
    //   20: iload_2
    //   21: invokevirtual 32	com/google/gson/stream/JsonReader:setLenient	(Z)V
    //   24: aload 4
    //   26: areturn
    //   27: astore 5
    //   29: new 38	java/lang/StringBuilder
    //   32: dup
    //   33: invokespecial 39	java/lang/StringBuilder:<init>	()V
    //   36: ldc 41
    //   38: invokevirtual 45	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   41: aload_1
    //   42: invokevirtual 48	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   45: ldc 50
    //   47: invokevirtual 45	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   50: invokevirtual 54	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   53: astore 6
    //   55: new 21	com/google/gson/JsonParseException
    //   58: dup
    //   59: aload 6
    //   61: aload 5
    //   63: invokespecial 57	com/google/gson/JsonParseException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   66: athrow
    //   67: astore 7
    //   69: aload_1
    //   70: iload_2
    //   71: invokevirtual 32	com/google/gson/stream/JsonReader:setLenient	(Z)V
    //   74: aload 7
    //   76: athrow
    //   77: astore 5
    //   79: new 38	java/lang/StringBuilder
    //   82: dup
    //   83: invokespecial 39	java/lang/StringBuilder:<init>	()V
    //   86: ldc 41
    //   88: invokevirtual 45	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   91: aload_1
    //   92: invokevirtual 48	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   95: ldc 50
    //   97: invokevirtual 45	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   100: invokevirtual 54	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   103: astore 8
    //   105: new 21	com/google/gson/JsonParseException
    //   108: dup
    //   109: aload 8
    //   111: aload 5
    //   113: invokespecial 57	com/google/gson/JsonParseException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   116: athrow
    //   117: astore 5
    //   119: aload 5
    //   121: invokevirtual 61	com/google/gson/JsonParseException:getCause	()Ljava/lang/Throwable;
    //   124: instanceof 63
    //   127: ifeq +18 -> 145
    //   130: invokestatic 69	com/google/gson/JsonNull:createJsonNull	()Lcom/google/gson/JsonNull;
    //   133: astore_3
    //   134: aload_3
    //   135: astore 4
    //   137: aload_1
    //   138: iload_2
    //   139: invokevirtual 32	com/google/gson/stream/JsonReader:setLenient	(Z)V
    //   142: goto -118 -> 24
    //   145: aload 5
    //   147: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   11	16	27	java/lang/StackOverflowError
    //   11	16	67	finally
    //   29	67	67	finally
    //   79	134	67	finally
    //   145	148	67	finally
    //   11	16	77	java/lang/OutOfMemoryError
    //   11	16	117	com/google/gson/JsonParseException
  }

  public JsonElement parse(Reader paramReader)
    throws JsonIOException, JsonSyntaxException
  {
    JsonElement localJsonElement;
    try
    {
      JsonReader localJsonReader = new JsonReader(paramReader);
      localJsonElement = parse(localJsonReader);
      if (!localJsonElement.isJsonNull())
      {
        JsonToken localJsonToken1 = localJsonReader.peek();
        JsonToken localJsonToken2 = JsonToken.END_DOCUMENT;
        if (localJsonToken1 != localJsonToken2)
          throw new JsonSyntaxException("Did not consume the entire document.");
      }
    }
    catch (MalformedJsonException localMalformedJsonException)
    {
      throw new JsonSyntaxException(localMalformedJsonException);
    }
    catch (IOException localIOException)
    {
      throw new JsonIOException(localIOException);
    }
    catch (NumberFormatException localNumberFormatException)
    {
      throw new JsonSyntaxException(localNumberFormatException);
    }
    return localJsonElement;
  }

  public JsonElement parse(String paramString)
    throws JsonSyntaxException
  {
    StringReader localStringReader = new StringReader(paramString);
    return parse(localStringReader);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.JsonParser
 * JD-Core Version:    0.6.0
 */