package com.google.gson.reflect;

import com.google.gson.internal..Gson.Preconditions;
import com.google.gson.internal..Gson.Types;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.util.HashMap;
import java.util.Map;

public class TypeToken<T>
{
  final int hashCode;
  final Class<? super T> rawType;
  final Type type;

  protected TypeToken()
  {
    Type localType = getSuperclassTypeParameter(getClass());
    this.type = localType;
    Class localClass = .Gson.Types.getRawType(this.type);
    this.rawType = localClass;
    int i = this.type.hashCode();
    this.hashCode = i;
  }

  TypeToken(Type paramType)
  {
    Type localType = .Gson.Types.canonicalize((Type).Gson.Preconditions.checkNotNull(paramType));
    this.type = localType;
    Class localClass = .Gson.Types.getRawType(this.type);
    this.rawType = localClass;
    int i = this.type.hashCode();
    this.hashCode = i;
  }

  private static AssertionError buildUnexpectedTypeError(Type paramType, Class<?>[] paramArrayOfClass)
  {
    StringBuilder localStringBuilder1 = new StringBuilder("Unexpected type. Expected one of: ");
    Class<?>[] arrayOfClass = paramArrayOfClass;
    int i = arrayOfClass.length;
    int j = 0;
    while (j < i)
    {
      String str1 = arrayOfClass[j].getName();
      StringBuilder localStringBuilder2 = localStringBuilder1.append(str1).append(", ");
      j += 1;
    }
    StringBuilder localStringBuilder3 = localStringBuilder1.append("but got: ");
    String str2 = paramType.getClass().getName();
    StringBuilder localStringBuilder4 = localStringBuilder3.append(str2).append(", for type token: ");
    String str3 = paramType.toString();
    StringBuilder localStringBuilder5 = localStringBuilder4.append(str3).append(46);
    String str4 = localStringBuilder1.toString();
    return new AssertionError(str4);
  }

  public static <T> TypeToken<T> get(Class<T> paramClass)
  {
    return new TypeToken(paramClass);
  }

  public static TypeToken<?> get(Type paramType)
  {
    return new TypeToken(paramType);
  }

  static Type getSuperclassTypeParameter(Class<?> paramClass)
  {
    Type localType = paramClass.getGenericSuperclass();
    if ((localType instanceof Class))
      throw new RuntimeException("Missing type parameter.");
    return .Gson.Types.canonicalize(((ParameterizedType)localType).getActualTypeArguments()[0]);
  }

  private static boolean isAssignableFrom(Type paramType, GenericArrayType paramGenericArrayType)
  {
    Type localType = paramGenericArrayType.getGenericComponentType();
    Object localObject;
    ParameterizedType localParameterizedType;
    HashMap localHashMap;
    if ((localType instanceof ParameterizedType))
    {
      localObject = paramType;
      if ((paramType instanceof GenericArrayType))
      {
        localObject = ((GenericArrayType)paramType).getGenericComponentType();
        localParameterizedType = (ParameterizedType)localType;
        localHashMap = new HashMap();
      }
    }
    for (boolean bool = isAssignableFrom((Type)localObject, localParameterizedType, localHashMap); ; bool = true)
    {
      return bool;
      if (!(paramType instanceof Class))
        break;
      for (Class localClass = (Class)paramType; localClass.isArray(); localClass = localClass.getComponentType());
      localObject = localClass;
      break;
    }
  }

  private static boolean isAssignableFrom(Type paramType, ParameterizedType paramParameterizedType, Map<String, Type> paramMap)
  {
    int i;
    if (paramType == null)
      i = 0;
    while (true)
    {
      return i;
      ParameterizedType localParameterizedType1 = paramParameterizedType;
      Type localType1 = paramType;
      if (localParameterizedType1.equals(localType1))
      {
        i = 1;
        continue;
      }
      Class localClass = .Gson.Types.getRawType(paramType);
      ParameterizedType localParameterizedType2 = null;
      if ((paramType instanceof ParameterizedType))
        localParameterizedType2 = (ParameterizedType)paramType;
      if (localParameterizedType2 != null)
      {
        Type[] arrayOfType1 = localParameterizedType2.getActualTypeArguments();
        TypeVariable[] arrayOfTypeVariable = localClass.getTypeParameters();
        int j = 0;
        while (true)
        {
          int k = arrayOfType1.length;
          if (j >= k)
            break;
          Type localType2 = arrayOfType1[j];
          TypeVariable localTypeVariable = arrayOfTypeVariable[j];
          while ((localType2 instanceof TypeVariable))
          {
            String str1 = ((TypeVariable)localType2).getName();
            localType2 = (Type)paramMap.get(str1);
          }
          String str2 = localTypeVariable.getName();
          Object localObject = paramMap.put(str2, localType2);
          j += 1;
        }
        ParameterizedType localParameterizedType3 = paramParameterizedType;
        Map<String, Type> localMap1 = paramMap;
        if (typeEquals(localParameterizedType2, localParameterizedType3, localMap1))
        {
          i = 1;
          continue;
        }
      }
      Type[] arrayOfType2 = localClass.getGenericInterfaces();
      int m = arrayOfType2.length;
      int n = 0;
      while (true)
      {
        if (n >= m)
          break label266;
        Type localType3 = arrayOfType2[n];
        Map<String, Type> localMap2 = paramMap;
        HashMap localHashMap1 = new HashMap(localMap2);
        ParameterizedType localParameterizedType4 = paramParameterizedType;
        if (isAssignableFrom(localType3, localParameterizedType4, localHashMap1))
        {
          i = 1;
          break;
        }
        n += 1;
      }
      label266: Type localType4 = localClass.getGenericSuperclass();
      Map<String, Type> localMap3 = paramMap;
      HashMap localHashMap2 = new HashMap(localMap3);
      ParameterizedType localParameterizedType5 = paramParameterizedType;
      boolean bool = isAssignableFrom(localType4, localParameterizedType5, localHashMap2);
    }
  }

  private static boolean matches(Type paramType1, Type paramType2, Map<String, Type> paramMap)
  {
    if (!paramType2.equals(paramType1))
    {
      if (!(paramType1 instanceof TypeVariable))
        break label49;
      String str = ((TypeVariable)paramType1).getName();
      Object localObject = paramMap.get(str);
      if (!paramType2.equals(localObject))
        break label49;
    }
    label49: for (int i = 1; ; i = 0)
      return i;
  }

  private static boolean typeEquals(ParameterizedType paramParameterizedType1, ParameterizedType paramParameterizedType2, Map<String, Type> paramMap)
  {
    int i = 0;
    Type localType1 = paramParameterizedType1.getRawType();
    Type localType2 = paramParameterizedType2.getRawType();
    int j;
    if (localType1.equals(localType2))
    {
      Type[] arrayOfType1 = paramParameterizedType1.getActualTypeArguments();
      Type[] arrayOfType2 = paramParameterizedType2.getActualTypeArguments();
      j = 0;
      int k = arrayOfType1.length;
      if (j >= k)
        break label95;
      Type localType3 = arrayOfType1[j];
      Type localType4 = arrayOfType2[j];
      if (matches(localType3, localType4, paramMap))
        break label86;
    }
    while (true)
    {
      return i;
      label86: j += 1;
      break;
      label95: i = 1;
    }
  }

  public final boolean equals(Object paramObject)
  {
    if ((paramObject instanceof TypeToken))
    {
      Type localType1 = this.type;
      Type localType2 = ((TypeToken)paramObject).type;
      if (!.Gson.Types.equals(localType1, localType2));
    }
    for (int i = 1; ; i = 0)
      return i;
  }

  public final Class<? super T> getRawType()
  {
    return this.rawType;
  }

  public final Type getType()
  {
    return this.type;
  }

  public final int hashCode()
  {
    return this.hashCode;
  }

  @Deprecated
  public boolean isAssignableFrom(TypeToken<?> paramTypeToken)
  {
    Type localType = paramTypeToken.getType();
    return isAssignableFrom(localType);
  }

  @Deprecated
  public boolean isAssignableFrom(Class<?> paramClass)
  {
    return isAssignableFrom(paramClass);
  }

  @Deprecated
  public boolean isAssignableFrom(Type paramType)
  {
    int i = 0;
    if (paramType == null);
    boolean bool1;
    while (true)
    {
      return i;
      if (this.type.equals(paramType))
      {
        i = 1;
        continue;
      }
      if ((this.type instanceof Class))
      {
        Class localClass1 = this.rawType;
        Class localClass2 = .Gson.Types.getRawType(paramType);
        bool1 = localClass1.isAssignableFrom(localClass2);
        continue;
      }
      if (!(this.type instanceof ParameterizedType))
        break;
      ParameterizedType localParameterizedType = (ParameterizedType)this.type;
      HashMap localHashMap = new HashMap();
      bool1 = isAssignableFrom(paramType, localParameterizedType, localHashMap);
    }
    if ((this.type instanceof GenericArrayType))
    {
      Class localClass3 = this.rawType;
      Class localClass4 = .Gson.Types.getRawType(paramType);
      if (localClass3.isAssignableFrom(localClass4))
      {
        GenericArrayType localGenericArrayType = (GenericArrayType)this.type;
        if (!isAssignableFrom(paramType, localGenericArrayType));
      }
      for (boolean bool2 = true; ; bool2 = false)
      {
        bool1 = bool2;
        break;
      }
    }
    Type localType = this.type;
    Class[] arrayOfClass = new Class[3];
    arrayOfClass[0] = Class.class;
    arrayOfClass[1] = ParameterizedType.class;
    arrayOfClass[2] = GenericArrayType.class;
    throw buildUnexpectedTypeError(localType, arrayOfClass);
  }

  public final String toString()
  {
    return .Gson.Types.typeToString(this.type);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.reflect.TypeToken
 * JD-Core Version:    0.6.0
 */