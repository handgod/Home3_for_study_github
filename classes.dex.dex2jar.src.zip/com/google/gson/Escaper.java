package com.google.gson;

import java.io.IOException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

final class Escaper
{
  private static final char[] HEX_CHARS = { null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null };
  private static final Set<Character> HTML_ESCAPE_CHARS;
  private static final Set<Character> JS_ESCAPE_CHARS;
  private final boolean escapeHtmlCharacters;

  static
  {
    HashSet localHashSet1 = new HashSet();
    Character localCharacter1 = Character.valueOf(34);
    boolean bool1 = localHashSet1.add(localCharacter1);
    Character localCharacter2 = Character.valueOf(92);
    boolean bool2 = localHashSet1.add(localCharacter2);
    JS_ESCAPE_CHARS = Collections.unmodifiableSet(localHashSet1);
    HashSet localHashSet2 = new HashSet();
    Character localCharacter3 = Character.valueOf(60);
    boolean bool3 = localHashSet2.add(localCharacter3);
    Character localCharacter4 = Character.valueOf(62);
    boolean bool4 = localHashSet2.add(localCharacter4);
    Character localCharacter5 = Character.valueOf(38);
    boolean bool5 = localHashSet2.add(localCharacter5);
    Character localCharacter6 = Character.valueOf(61);
    boolean bool6 = localHashSet2.add(localCharacter6);
    Character localCharacter7 = Character.valueOf(39);
    boolean bool7 = localHashSet2.add(localCharacter7);
    HTML_ESCAPE_CHARS = Collections.unmodifiableSet(localHashSet2);
  }

  Escaper(boolean paramBoolean)
  {
    this.escapeHtmlCharacters = paramBoolean;
  }

  private static void appendHexJavaScriptRepresentation(int paramInt, Appendable paramAppendable)
    throws IOException
  {
    if (Character.isSupplementaryCodePoint(paramInt))
    {
      char[] arrayOfChar1 = Character.toChars(paramInt);
      appendHexJavaScriptRepresentation(arrayOfChar1[0], paramAppendable);
      appendHexJavaScriptRepresentation(arrayOfChar1[1], paramAppendable);
    }
    while (true)
    {
      return;
      Appendable localAppendable1 = paramAppendable.append("\\u");
      char[] arrayOfChar2 = HEX_CHARS;
      int i = paramInt >>> 12 & 0xF;
      char c1 = arrayOfChar2[i];
      Appendable localAppendable2 = localAppendable1.append(c1);
      char[] arrayOfChar3 = HEX_CHARS;
      int j = paramInt >>> 8 & 0xF;
      char c2 = arrayOfChar3[j];
      Appendable localAppendable3 = localAppendable2.append(c2);
      char[] arrayOfChar4 = HEX_CHARS;
      int k = paramInt >>> 4 & 0xF;
      char c3 = arrayOfChar4[k];
      Appendable localAppendable4 = localAppendable3.append(c3);
      char[] arrayOfChar5 = HEX_CHARS;
      int m = paramInt & 0xF;
      char c4 = arrayOfChar5[m];
      Appendable localAppendable5 = localAppendable4.append(c4);
    }
  }

  private void escapeJsonString(CharSequence paramCharSequence, StringBuilder paramStringBuilder)
    throws IOException
  {
    int i = 0;
    int j = paramCharSequence.length();
    int k = 0;
    if (k < j)
    {
      int m = Character.codePointAt(paramCharSequence, k);
      int n = Character.charCount(m);
      if ((!isControlCharacter(m)) && (!mustEscapeCharInJsString(m)));
      while (true)
      {
        k += n;
        break;
        StringBuilder localStringBuilder1 = paramStringBuilder.append(paramCharSequence, i, k);
        i = k + n;
        switch (m)
        {
        default:
          appendHexJavaScriptRepresentation(m, paramStringBuilder);
          break;
        case 8:
          StringBuilder localStringBuilder2 = paramStringBuilder.append("\\b");
          break;
        case 9:
          StringBuilder localStringBuilder3 = paramStringBuilder.append("\\t");
          break;
        case 10:
          StringBuilder localStringBuilder4 = paramStringBuilder.append("\\n");
          break;
        case 12:
          StringBuilder localStringBuilder5 = paramStringBuilder.append("\\f");
          break;
        case 13:
          StringBuilder localStringBuilder6 = paramStringBuilder.append("\\r");
          break;
        case 92:
          StringBuilder localStringBuilder7 = paramStringBuilder.append("\\\\");
          break;
        case 47:
          StringBuilder localStringBuilder8 = paramStringBuilder.append("\\/");
          break;
        case 34:
          StringBuilder localStringBuilder9 = paramStringBuilder.append("\\\"");
        }
      }
    }
    StringBuilder localStringBuilder10 = paramStringBuilder.append(paramCharSequence, i, j);
  }

  private static boolean isControlCharacter(int paramInt)
  {
    if ((paramInt < 32) || (paramInt == 8232) || (paramInt == 8233) || ((paramInt >= 127) && (paramInt <= 159)));
    for (int i = 1; ; i = 0)
      return i;
  }

  private boolean mustEscapeCharInJsString(int paramInt)
  {
    int i = 0;
    if (!Character.isSupplementaryCodePoint(paramInt))
    {
      char c = (char)paramInt;
      Set localSet1 = JS_ESCAPE_CHARS;
      Character localCharacter1 = Character.valueOf(c);
      if (!localSet1.contains(localCharacter1))
      {
        if (this.escapeHtmlCharacters)
        {
          Set localSet2 = HTML_ESCAPE_CHARS;
          Character localCharacter2 = Character.valueOf(c);
          if (!localSet2.contains(localCharacter2));
        }
      }
      else
        i = 1;
    }
    return i;
  }

  public String escapeJsonString(CharSequence paramCharSequence)
  {
    int i = paramCharSequence.length() + 20;
    StringBuilder localStringBuilder = new StringBuilder(i);
    try
    {
      escapeJsonString(paramCharSequence, localStringBuilder);
      return localStringBuilder.toString();
    }
    catch (IOException localIOException)
    {
    }
    throw new RuntimeException(localIOException);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.Escaper
 * JD-Core Version:    0.6.0
 */