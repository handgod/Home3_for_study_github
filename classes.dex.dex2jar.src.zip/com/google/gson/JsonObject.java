package com.google.gson;

import com.google.gson.internal..Gson.Preconditions;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public final class JsonObject extends JsonElement
{
  private final Map<String, JsonElement> members;

  public JsonObject()
  {
    LinkedHashMap localLinkedHashMap = new LinkedHashMap();
    this.members = localLinkedHashMap;
  }

  private JsonElement createJsonElement(Object paramObject)
  {
    if (paramObject == null);
    for (Object localObject = JsonNull.createJsonNull(); ; localObject = new JsonPrimitive(paramObject))
      return localObject;
  }

  public void add(String paramString, JsonElement paramJsonElement)
  {
    if (paramJsonElement == null)
      paramJsonElement = JsonNull.createJsonNull();
    Map localMap = this.members;
    Object localObject1 = .Gson.Preconditions.checkNotNull(paramString);
    Object localObject2 = localMap.put(localObject1, paramJsonElement);
  }

  public void addProperty(String paramString, Boolean paramBoolean)
  {
    JsonElement localJsonElement = createJsonElement(paramBoolean);
    add(paramString, localJsonElement);
  }

  public void addProperty(String paramString, Character paramCharacter)
  {
    JsonElement localJsonElement = createJsonElement(paramCharacter);
    add(paramString, localJsonElement);
  }

  public void addProperty(String paramString, Number paramNumber)
  {
    JsonElement localJsonElement = createJsonElement(paramNumber);
    add(paramString, localJsonElement);
  }

  public void addProperty(String paramString1, String paramString2)
  {
    JsonElement localJsonElement = createJsonElement(paramString2);
    add(paramString1, localJsonElement);
  }

  public Set<Map.Entry<String, JsonElement>> entrySet()
  {
    return this.members.entrySet();
  }

  public boolean equals(Object paramObject)
  {
    if (paramObject != this)
    {
      if (!(paramObject instanceof JsonObject))
        break label39;
      Map localMap1 = ((JsonObject)paramObject).members;
      Map localMap2 = this.members;
      if (!localMap1.equals(localMap2))
        break label39;
    }
    label39: for (int i = 1; ; i = 0)
      return i;
  }

  public JsonElement get(String paramString)
  {
    if (this.members.containsKey(paramString))
    {
      localObject = (JsonElement)this.members.get(paramString);
      if (localObject != null);
    }
    for (Object localObject = JsonNull.createJsonNull(); ; localObject = null)
      return localObject;
  }

  public JsonArray getAsJsonArray(String paramString)
  {
    return (JsonArray)this.members.get(paramString);
  }

  public JsonObject getAsJsonObject(String paramString)
  {
    return (JsonObject)this.members.get(paramString);
  }

  public JsonPrimitive getAsJsonPrimitive(String paramString)
  {
    return (JsonPrimitive)this.members.get(paramString);
  }

  public boolean has(String paramString)
  {
    return this.members.containsKey(paramString);
  }

  public int hashCode()
  {
    return this.members.hashCode();
  }

  public JsonElement remove(String paramString)
  {
    return (JsonElement)this.members.remove(paramString);
  }

  protected void toString(Appendable paramAppendable, Escaper paramEscaper)
    throws IOException
  {
    Appendable localAppendable1 = paramAppendable.append(123);
    int i = 1;
    Iterator localIterator = this.members.entrySet().iterator();
    if (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      if (i != 0)
        i = 0;
      while (true)
      {
        Appendable localAppendable2 = paramAppendable.append(34);
        CharSequence localCharSequence = (CharSequence)localEntry.getKey();
        String str = paramEscaper.escapeJsonString(localCharSequence);
        Appendable localAppendable3 = paramAppendable.append(str);
        Appendable localAppendable4 = paramAppendable.append("\":");
        ((JsonElement)localEntry.getValue()).toString(paramAppendable, paramEscaper);
        break;
        Appendable localAppendable5 = paramAppendable.append(44);
      }
    }
    Appendable localAppendable6 = paramAppendable.append(125);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.JsonObject
 * JD-Core Version:    0.6.0
 */