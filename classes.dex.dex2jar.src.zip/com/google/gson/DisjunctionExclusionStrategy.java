package com.google.gson;

import com.google.gson.internal..Gson.Preconditions;
import java.util.Collection;
import java.util.Iterator;

final class DisjunctionExclusionStrategy
  implements ExclusionStrategy
{
  private final Collection<ExclusionStrategy> strategies;

  DisjunctionExclusionStrategy(Collection<ExclusionStrategy> paramCollection)
  {
    Collection localCollection = (Collection).Gson.Preconditions.checkNotNull(paramCollection);
    this.strategies = localCollection;
  }

  public boolean shouldSkipClass(Class<?> paramClass)
  {
    Iterator localIterator = this.strategies.iterator();
    do
      if (!localIterator.hasNext())
        break;
    while (!((ExclusionStrategy)localIterator.next()).shouldSkipClass(paramClass));
    for (int i = 1; ; i = 0)
      return i;
  }

  public boolean shouldSkipField(FieldAttributes paramFieldAttributes)
  {
    Iterator localIterator = this.strategies.iterator();
    do
      if (!localIterator.hasNext())
        break;
    while (!((ExclusionStrategy)localIterator.next()).shouldSkipField(paramFieldAttributes));
    for (int i = 1; ; i = 0)
      return i;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.DisjunctionExclusionStrategy
 * JD-Core Version:    0.6.0
 */