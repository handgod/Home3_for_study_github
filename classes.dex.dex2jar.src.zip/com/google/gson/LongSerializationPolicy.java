package com.google.gson;

public enum LongSerializationPolicy
{
  private final Strategy strategy;

  static
  {
    DefaultStrategy localDefaultStrategy = new DefaultStrategy();
    DEFAULT = new LongSerializationPolicy("DEFAULT", 0, localDefaultStrategy);
    StringStrategy localStringStrategy = new StringStrategy();
    STRING = new LongSerializationPolicy("STRING", 1, localStringStrategy);
    LongSerializationPolicy[] arrayOfLongSerializationPolicy = new LongSerializationPolicy[2];
    LongSerializationPolicy localLongSerializationPolicy1 = DEFAULT;
    arrayOfLongSerializationPolicy[0] = localLongSerializationPolicy1;
    LongSerializationPolicy localLongSerializationPolicy2 = STRING;
    arrayOfLongSerializationPolicy[1] = localLongSerializationPolicy2;
    $VALUES = arrayOfLongSerializationPolicy;
  }

  private LongSerializationPolicy(Strategy paramStrategy)
  {
    this.strategy = paramStrategy;
  }

  public JsonElement serialize(Long paramLong)
  {
    return this.strategy.serialize(paramLong);
  }

  class StringStrategy
    implements LongSerializationPolicy.Strategy
  {
    public JsonElement serialize(Long paramLong)
    {
      String str = String.valueOf(paramLong);
      return new JsonPrimitive(str);
    }
  }

  class DefaultStrategy
    implements LongSerializationPolicy.Strategy
  {
    public JsonElement serialize(Long paramLong)
    {
      return new JsonPrimitive(paramLong);
    }
  }

  abstract interface Strategy
  {
    public abstract JsonElement serialize(Long paramLong);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.LongSerializationPolicy
 * JD-Core Version:    0.6.0
 */