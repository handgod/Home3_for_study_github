package com.google.gson;

import java.lang.reflect.Method;

final class UnsafeAllocator$3 extends UnsafeAllocator
{
  public <T> T newInstance(Class<T> paramClass)
    throws Exception
  {
    Method localMethod = this.val$newInstance;
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = paramClass;
    Integer localInteger = Integer.valueOf(this.val$constructorId);
    arrayOfObject[1] = localInteger;
    return localMethod.invoke(null, arrayOfObject);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.UnsafeAllocator.3
 * JD-Core Version:    0.6.0
 */