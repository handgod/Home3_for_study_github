package com.google.gson;

abstract interface FieldNamingStrategy2
{
  public abstract String translateName(FieldAttributes paramFieldAttributes);
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.FieldNamingStrategy2
 * JD-Core Version:    0.6.0
 */