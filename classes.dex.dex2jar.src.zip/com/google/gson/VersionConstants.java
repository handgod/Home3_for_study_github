package com.google.gson;

final class VersionConstants
{
  static final double IGNORE_VERSIONS = -1.0D;
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.VersionConstants
 * JD-Core Version:    0.6.0
 */