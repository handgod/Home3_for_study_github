package com.google.gson;

import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import com.google.gson.stream.MalformedJsonException;
import java.io.EOFException;
import java.io.IOException;
import java.io.Writer;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

final class Streams
{
  static JsonElement parse(JsonReader paramJsonReader)
    throws JsonParseException
  {
    try
    {
      JsonToken localJsonToken = paramJsonReader.peek();
      i = 0;
      JsonElement localJsonElement = parseRecursive(paramJsonReader);
      localObject = localJsonElement;
      return localObject;
    }
    catch (EOFException localEOFException)
    {
      int i;
      Object localObject;
      while (i != 0)
        localObject = JsonNull.createJsonNull();
      throw new JsonIOException(localEOFException);
    }
    catch (MalformedJsonException localMalformedJsonException)
    {
      throw new JsonSyntaxException(localMalformedJsonException);
    }
    catch (IOException localIOException)
    {
      throw new JsonIOException(localIOException);
    }
    catch (NumberFormatException localNumberFormatException)
    {
    }
    throw new JsonSyntaxException(localNumberFormatException);
  }

  private static JsonElement parseRecursive(JsonReader paramJsonReader)
    throws IOException
  {
    int[] arrayOfInt = 1.$SwitchMap$com$google$gson$stream$JsonToken;
    int i = paramJsonReader.peek().ordinal();
    Object localObject;
    switch (arrayOfInt[i])
    {
    default:
      throw new IllegalArgumentException();
    case 1:
      String str1 = paramJsonReader.nextString();
      localObject = new JsonPrimitive(str1);
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    }
    while (true)
    {
      return localObject;
      Number localNumber = JsonPrimitive.stringToNumber(paramJsonReader.nextString());
      localObject = new JsonPrimitive(localNumber);
      continue;
      Boolean localBoolean = Boolean.valueOf(paramJsonReader.nextBoolean());
      localObject = new JsonPrimitive(localBoolean);
      continue;
      paramJsonReader.nextNull();
      localObject = JsonNull.createJsonNull();
      continue;
      localObject = new JsonArray();
      paramJsonReader.beginArray();
      while (paramJsonReader.hasNext())
      {
        JsonElement localJsonElement1 = parseRecursive(paramJsonReader);
        ((JsonArray)localObject).add(localJsonElement1);
      }
      paramJsonReader.endArray();
      continue;
      JsonObject localJsonObject = new JsonObject();
      paramJsonReader.beginObject();
      while (paramJsonReader.hasNext())
      {
        String str2 = paramJsonReader.nextName();
        JsonElement localJsonElement2 = parseRecursive(paramJsonReader);
        localJsonObject.add(str2, localJsonElement2);
      }
      paramJsonReader.endObject();
      localObject = localJsonObject;
    }
  }

  static void write(JsonElement paramJsonElement, boolean paramBoolean, JsonWriter paramJsonWriter)
    throws IOException
  {
    if ((paramJsonElement == null) || (paramJsonElement.isJsonNull()))
      if (paramBoolean)
        JsonWriter localJsonWriter1 = paramJsonWriter.nullValue();
    while (true)
    {
      return;
      if (paramJsonElement.isJsonPrimitive())
      {
        JsonPrimitive localJsonPrimitive = paramJsonElement.getAsJsonPrimitive();
        if (localJsonPrimitive.isNumber())
        {
          Number localNumber = localJsonPrimitive.getAsNumber();
          JsonWriter localJsonWriter2 = paramJsonWriter.value(localNumber);
          continue;
        }
        if (localJsonPrimitive.isBoolean())
        {
          boolean bool = localJsonPrimitive.getAsBoolean();
          JsonWriter localJsonWriter3 = paramJsonWriter.value(bool);
          continue;
        }
        String str1 = localJsonPrimitive.getAsString();
        JsonWriter localJsonWriter4 = paramJsonWriter.value(str1);
        continue;
      }
      if (paramJsonElement.isJsonArray())
      {
        JsonWriter localJsonWriter5 = paramJsonWriter.beginArray();
        localIterator = paramJsonElement.getAsJsonArray().iterator();
        while (localIterator.hasNext())
        {
          JsonElement localJsonElement1 = (JsonElement)localIterator.next();
          if (localJsonElement1.isJsonNull())
          {
            JsonWriter localJsonWriter6 = paramJsonWriter.nullValue();
            continue;
          }
          write(localJsonElement1, paramBoolean, paramJsonWriter);
        }
        JsonWriter localJsonWriter7 = paramJsonWriter.endArray();
        continue;
      }
      if (!paramJsonElement.isJsonObject())
        break;
      JsonWriter localJsonWriter8 = paramJsonWriter.beginObject();
      Iterator localIterator = paramJsonElement.getAsJsonObject().entrySet().iterator();
      while (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        JsonElement localJsonElement2 = (JsonElement)localEntry.getValue();
        if ((!paramBoolean) && (localJsonElement2.isJsonNull()))
          continue;
        String str2 = (String)localEntry.getKey();
        JsonWriter localJsonWriter9 = paramJsonWriter.name(str2);
        write(localJsonElement2, paramBoolean, paramJsonWriter);
      }
      JsonWriter localJsonWriter10 = paramJsonWriter.endObject();
    }
    StringBuilder localStringBuilder = new StringBuilder().append("Couldn't write ");
    Class localClass = paramJsonElement.getClass();
    String str3 = localClass;
    throw new IllegalArgumentException(str3);
  }

  static Writer writerForAppendable(Appendable paramAppendable)
  {
    if ((paramAppendable instanceof Writer));
    for (paramAppendable = (Writer)paramAppendable; ; paramAppendable = new AppendableWriter(null))
      return paramAppendable;
  }

  class AppendableWriter extends Writer
  {
    private final CurrentWrite currentWrite;

    private AppendableWriter()
    {
      CurrentWrite localCurrentWrite = new CurrentWrite();
      this.currentWrite = localCurrentWrite;
    }

    public void close()
    {
    }

    public void flush()
    {
    }

    public void write(int paramInt)
      throws IOException
    {
      Appendable localAppendable1 = Streams.this;
      char c = (char)paramInt;
      Appendable localAppendable2 = localAppendable1.append(c);
    }

    public void write(char[] paramArrayOfChar, int paramInt1, int paramInt2)
      throws IOException
    {
      this.currentWrite.chars = paramArrayOfChar;
      Appendable localAppendable1 = Streams.this;
      CurrentWrite localCurrentWrite = this.currentWrite;
      int i = paramInt1 + paramInt2;
      Appendable localAppendable2 = localAppendable1.append(localCurrentWrite, paramInt1, i);
    }

    class CurrentWrite
      implements CharSequence
    {
      char[] chars;

      public char charAt(int paramInt)
      {
        return this.chars[paramInt];
      }

      public int length()
      {
        return this.chars.length;
      }

      public CharSequence subSequence(int paramInt1, int paramInt2)
      {
        char[] arrayOfChar = this.chars;
        int i = paramInt2 - paramInt1;
        return new String(arrayOfChar, paramInt1, i);
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.Streams
 * JD-Core Version:    0.6.0
 */