package com.google.gson;

import java.lang.reflect.Method;

final class UnsafeAllocator$1 extends UnsafeAllocator
{
  public <T> T newInstance(Class<T> paramClass)
    throws Exception
  {
    Method localMethod = this.val$allocateInstance;
    Object localObject = this.val$unsafe;
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = paramClass;
    return localMethod.invoke(localObject, arrayOfObject);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.UnsafeAllocator.1
 * JD-Core Version:    0.6.0
 */