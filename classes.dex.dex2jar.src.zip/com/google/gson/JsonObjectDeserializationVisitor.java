package com.google.gson;

import java.lang.reflect.Type;

final class JsonObjectDeserializationVisitor<T> extends JsonDeserializationVisitor<T>
{
  JsonObjectDeserializationVisitor(JsonElement paramJsonElement, Type paramType, ObjectNavigator paramObjectNavigator, FieldNamingStrategy2 paramFieldNamingStrategy2, ObjectConstructor paramObjectConstructor, ParameterizedTypeHandlerMap<JsonDeserializer<?>> paramParameterizedTypeHandlerMap, JsonDeserializationContext paramJsonDeserializationContext)
  {
    super(paramJsonElement, paramType, paramObjectNavigator, paramFieldNamingStrategy2, paramObjectConstructor, paramParameterizedTypeHandlerMap, paramJsonDeserializationContext);
  }

  private String getFieldName(FieldAttributes paramFieldAttributes)
  {
    return this.fieldNamingPolicy.translateName(paramFieldAttributes);
  }

  protected T constructTarget()
  {
    ObjectConstructor localObjectConstructor = this.objectConstructor;
    Type localType = this.targetType;
    return localObjectConstructor.construct(localType);
  }

  public void startVisitingObject(Object paramObject)
  {
  }

  public void visitArray(Object paramObject, Type paramType)
  {
    String str = "Expecting object but found array: " + paramObject;
    throw new JsonParseException(str);
  }

  public void visitArrayField(FieldAttributes paramFieldAttributes, Type paramType, Object paramObject)
  {
    try
    {
      if (!this.json.isJsonObject())
      {
        StringBuilder localStringBuilder = new StringBuilder().append("Expecting object found: ");
        JsonElement localJsonElement = this.json;
        String str1 = localJsonElement;
        throw new JsonParseException(str1);
      }
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new RuntimeException(localIllegalAccessException);
    }
    JsonObject localJsonObject = this.json.getAsJsonObject();
    String str2 = getFieldName(paramFieldAttributes);
    JsonArray localJsonArray = (JsonArray)localJsonObject.get(str2);
    if (localJsonArray != null)
    {
      Object localObject = visitChildAsArray(paramType, localJsonArray);
      paramFieldAttributes.set(paramObject, localObject);
    }
    while (true)
    {
      return;
      paramFieldAttributes.set(paramObject, null);
    }
  }

  public boolean visitFieldUsingCustomHandler(FieldAttributes paramFieldAttributes, Type paramType, Object paramObject)
  {
    int i = 1;
    String str1;
    try
    {
      str1 = getFieldName(paramFieldAttributes);
      if (!this.json.isJsonObject())
      {
        StringBuilder localStringBuilder = new StringBuilder().append("Expecting object found: ");
        JsonElement localJsonElement1 = this.json;
        String str2 = localJsonElement1;
        throw new JsonParseException(str2);
      }
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new RuntimeException();
    }
    JsonElement localJsonElement2 = this.json.getAsJsonObject().get(str1);
    boolean bool = Primitives.isPrimitive(paramType);
    if (localJsonElement2 == null);
    while (true)
    {
      return i;
      if (localJsonElement2.isJsonNull())
      {
        if (bool)
          continue;
        paramFieldAttributes.set(paramObject, null);
        continue;
      }
      ObjectTypePair localObjectTypePair = new ObjectTypePair(null, paramType, 0);
      ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap = this.deserializers;
      Pair localPair = localObjectTypePair.getMatchingHandler(localParameterizedTypeHandlerMap);
      if (localPair == null)
      {
        i = 0;
        continue;
      }
      Object localObject = invokeCustomDeserializer(localJsonElement2, localPair);
      if ((localObject == null) && (bool))
        continue;
      paramFieldAttributes.set(paramObject, localObject);
    }
  }

  public void visitObjectField(FieldAttributes paramFieldAttributes, Type paramType, Object paramObject)
  {
    try
    {
      if (!this.json.isJsonObject())
      {
        StringBuilder localStringBuilder = new StringBuilder().append("Expecting object found: ");
        JsonElement localJsonElement1 = this.json;
        String str1 = localJsonElement1;
        throw new JsonParseException(str1);
      }
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new RuntimeException(localIllegalAccessException);
    }
    JsonObject localJsonObject = this.json.getAsJsonObject();
    String str2 = getFieldName(paramFieldAttributes);
    JsonElement localJsonElement2 = localJsonObject.get(str2);
    if (localJsonElement2 != null)
    {
      Object localObject = visitChildAsObject(paramType, localJsonElement2);
      paramFieldAttributes.set(paramObject, localObject);
    }
    while (true)
    {
      return;
      paramFieldAttributes.set(paramObject, null);
    }
  }

  public void visitPrimitive(Object paramObject)
  {
    if (!this.json.isJsonPrimitive())
    {
      StringBuilder localStringBuilder = new StringBuilder().append("Type information is unavailable, and the target object is not a primitive: ");
      JsonElement localJsonElement = this.json;
      String str = localJsonElement;
      throw new JsonParseException(str);
    }
    Object localObject = this.json.getAsJsonPrimitive().getAsObject();
    this.target = localObject;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.JsonObjectDeserializationVisitor
 * JD-Core Version:    0.6.0
 */