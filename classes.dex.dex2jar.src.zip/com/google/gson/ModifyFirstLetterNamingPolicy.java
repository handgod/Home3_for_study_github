package com.google.gson;

import com.google.gson.internal..Gson.Preconditions;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.Collection;

final class ModifyFirstLetterNamingPolicy extends RecursiveFieldNamingPolicy
{
  private final LetterModifier letterModifier;

  ModifyFirstLetterNamingPolicy(LetterModifier paramLetterModifier)
  {
    LetterModifier localLetterModifier = (LetterModifier).Gson.Preconditions.checkNotNull(paramLetterModifier);
    this.letterModifier = localLetterModifier;
  }

  private String modifyString(char paramChar, String paramString, int paramInt)
  {
    int i = paramString.length();
    StringBuilder localStringBuilder;
    String str1;
    if (paramInt < i)
    {
      localStringBuilder = new StringBuilder().append(paramChar);
      str1 = paramString.substring(paramInt);
    }
    for (String str2 = str1; ; str2 = String.valueOf(paramChar))
      return str2;
  }

  protected String translateName(String paramString, Type paramType, Collection<Annotation> paramCollection)
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    int i = 0;
    char c1 = paramString.charAt(i);
    int j = paramString.length() + -1;
    if ((i >= j) || (Character.isLetter(c1)))
    {
      int k = paramString.length();
      if (i != k)
        break label91;
      paramString = localStringBuilder1.toString();
    }
    while (true)
    {
      return paramString;
      StringBuilder localStringBuilder2 = localStringBuilder1.append(c1);
      i += 1;
      c1 = paramString.charAt(i);
      break;
      label91: LetterModifier localLetterModifier1 = this.letterModifier;
      LetterModifier localLetterModifier2 = LetterModifier.UPPER;
      if (localLetterModifier1 == localLetterModifier2);
      for (int m = 1; ; m = 0)
      {
        if ((m == 0) || (Character.isUpperCase(c1)))
          break label169;
        char c2 = Character.toUpperCase(c1);
        int n = i + 1;
        String str1 = modifyString(c2, paramString, n);
        paramString = str1;
        break;
      }
      label169: if ((m != 0) || (!Character.isUpperCase(c1)))
        continue;
      char c3 = Character.toLowerCase(c1);
      int i1 = i + 1;
      String str2 = modifyString(c3, paramString, i1);
      paramString = str2;
    }
  }

  public enum LetterModifier
  {
    static
    {
      LOWER = new LetterModifier("LOWER", 1);
      LetterModifier[] arrayOfLetterModifier = new LetterModifier[2];
      LetterModifier localLetterModifier1 = UPPER;
      arrayOfLetterModifier[0] = localLetterModifier1;
      LetterModifier localLetterModifier2 = LOWER;
      arrayOfLetterModifier[1] = localLetterModifier2;
      $VALUES = arrayOfLetterModifier;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.ModifyFirstLetterNamingPolicy
 * JD-Core Version:    0.6.0
 */