package com.google.gson;

final class InnerClassExclusionStrategy
  implements ExclusionStrategy
{
  private boolean isInnerClass(Class<?> paramClass)
  {
    if ((paramClass.isMemberClass()) && (!isStatic(paramClass)));
    for (int i = 1; ; i = 0)
      return i;
  }

  private boolean isStatic(Class<?> paramClass)
  {
    if ((paramClass.getModifiers() & 0x8) != 0);
    for (int i = 1; ; i = 0)
      return i;
  }

  public boolean shouldSkipClass(Class<?> paramClass)
  {
    return isInnerClass(paramClass);
  }

  public boolean shouldSkipField(FieldAttributes paramFieldAttributes)
  {
    Class localClass = paramFieldAttributes.getDeclaredClass();
    return isInnerClass(localClass);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.InnerClassExclusionStrategy
 * JD-Core Version:    0.6.0
 */