package com.google.gson;

import com.google.gson.internal..Gson.Types;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

final class MapTypeAdapter extends BaseMapTypeAdapter
{
  public Map deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
    throws JsonParseException
  {
    Map localMap = constructMapType(paramType, paramJsonDeserializationContext);
    Class localClass = .Gson.Types.getRawType(paramType);
    Type[] arrayOfType = .Gson.Types.getMapKeyAndValueTypes(paramType, localClass);
    Iterator localIterator = paramJsonElement.getAsJsonObject().entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      String str = (String)localEntry.getKey();
      JsonPrimitive localJsonPrimitive = new JsonPrimitive(str);
      Type localType1 = arrayOfType[0];
      Object localObject1 = paramJsonDeserializationContext.deserialize(localJsonPrimitive, localType1);
      JsonElement localJsonElement = (JsonElement)localEntry.getValue();
      Type localType2 = arrayOfType[1];
      Object localObject2 = paramJsonDeserializationContext.deserialize(localJsonElement, localType2);
      Object localObject3 = localMap.put(localObject1, localObject2);
    }
    return localMap;
  }

  public JsonElement serialize(Map paramMap, Type paramType, JsonSerializationContext paramJsonSerializationContext)
  {
    JsonObject localJsonObject = new JsonObject();
    Type localType = null;
    if ((paramType instanceof ParameterizedType))
    {
      Class localClass = .Gson.Types.getRawType(paramType);
      localType = .Gson.Types.getMapKeyAndValueTypes(paramType, localClass)[1];
    }
    Iterator localIterator = paramMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      Object localObject1 = localEntry.getValue();
      Object localObject2;
      if (localObject1 == null)
      {
        localObject2 = JsonNull.createJsonNull();
        String str = String.valueOf(localEntry.getKey());
        localJsonObject.add(str, (JsonElement)localObject2);
        continue;
      }
      if (localType == null);
      for (Object localObject3 = localObject1.getClass(); ; localObject3 = localType)
      {
        localObject2 = serialize(paramJsonSerializationContext, localObject1, (Type)localObject3);
        break;
      }
    }
    return (JsonElement)(JsonElement)localJsonObject;
  }

  public String toString()
  {
    return MapTypeAdapter.class.getSimpleName();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.MapTypeAdapter
 * JD-Core Version:    0.6.0
 */