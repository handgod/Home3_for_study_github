package com.google.gson;

import com.google.gson.internal..Gson.Types;
import java.lang.reflect.Type;

final class ObjectNavigator
{
  private final ExclusionStrategy exclusionStrategy;
  private final ReflectingFieldNavigator reflectingFieldNavigator;

  ObjectNavigator(ExclusionStrategy paramExclusionStrategy)
  {
    if (paramExclusionStrategy == null)
      paramExclusionStrategy = new NullExclusionStrategy();
    this.exclusionStrategy = paramExclusionStrategy;
    ExclusionStrategy localExclusionStrategy = this.exclusionStrategy;
    ReflectingFieldNavigator localReflectingFieldNavigator = new ReflectingFieldNavigator(localExclusionStrategy);
    this.reflectingFieldNavigator = localReflectingFieldNavigator;
  }

  private static boolean isPrimitiveOrString(Object paramObject)
  {
    Class localClass = paramObject.getClass();
    if ((localClass == Object.class) || (localClass == String.class) || (Primitives.unwrap(localClass).isPrimitive()));
    for (int i = 1; ; i = 0)
      return i;
  }

  public void accept(ObjectTypePair paramObjectTypePair, Visitor paramVisitor)
  {
    ExclusionStrategy localExclusionStrategy = this.exclusionStrategy;
    Class localClass = .Gson.Types.getRawType(paramObjectTypePair.type);
    if (localExclusionStrategy.shouldSkipClass(localClass));
    Object localObject1;
    Object localObject2;
    while (true)
    {
      do
        return;
      while (paramVisitor.visitUsingCustomHandler(paramObjectTypePair));
      localObject1 = paramObjectTypePair.getObject();
      if (localObject1 != null)
        break;
      localObject2 = paramVisitor.getTarget();
      label55: if (localObject2 == null)
        continue;
      paramObjectTypePair.setObject(localObject2);
      paramVisitor.start(paramObjectTypePair);
    }
    while (true)
    {
      try
      {
        if (!.Gson.Types.isArray(paramObjectTypePair.type))
          continue;
        Type localType = paramObjectTypePair.type;
        paramVisitor.visitArray(localObject2, localType);
        paramVisitor.end(paramObjectTypePair);
        break;
        localObject2 = localObject1;
        break label55;
        if ((paramObjectTypePair.type == Object.class) && (isPrimitiveOrString(localObject2)))
        {
          paramVisitor.visitPrimitive(localObject2);
          Object localObject3 = paramVisitor.getTarget();
          continue;
        }
      }
      finally
      {
        paramVisitor.end(paramObjectTypePair);
      }
      paramVisitor.startVisitingObject(localObject2);
      this.reflectingFieldNavigator.visitFieldsReflectively(paramObjectTypePair, paramVisitor);
    }
  }

  public abstract interface Visitor
  {
    public abstract void end(ObjectTypePair paramObjectTypePair);

    public abstract Object getTarget();

    public abstract void start(ObjectTypePair paramObjectTypePair);

    public abstract void startVisitingObject(Object paramObject);

    public abstract void visitArray(Object paramObject, Type paramType);

    public abstract void visitArrayField(FieldAttributes paramFieldAttributes, Type paramType, Object paramObject);

    public abstract boolean visitFieldUsingCustomHandler(FieldAttributes paramFieldAttributes, Type paramType, Object paramObject);

    public abstract void visitObjectField(FieldAttributes paramFieldAttributes, Type paramType, Object paramObject);

    public abstract void visitPrimitive(Object paramObject);

    public abstract boolean visitUsingCustomHandler(ObjectTypePair paramObjectTypePair);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.ObjectNavigator
 * JD-Core Version:    0.6.0
 */