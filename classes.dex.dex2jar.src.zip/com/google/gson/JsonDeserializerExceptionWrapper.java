package com.google.gson;

import com.google.gson.internal..Gson.Preconditions;
import java.lang.reflect.Type;

final class JsonDeserializerExceptionWrapper<T>
  implements JsonDeserializer<T>
{
  private final JsonDeserializer<T> delegate;

  JsonDeserializerExceptionWrapper(JsonDeserializer<T> paramJsonDeserializer)
  {
    JsonDeserializer localJsonDeserializer = (JsonDeserializer).Gson.Preconditions.checkNotNull(paramJsonDeserializer);
    this.delegate = localJsonDeserializer;
  }

  public T deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
    throws JsonParseException
  {
    String str;
    try
    {
      Object localObject = this.delegate.deserialize(paramJsonElement, paramType, paramJsonDeserializationContext);
      return localObject;
    }
    catch (JsonParseException localJsonParseException)
    {
      throw localJsonParseException;
    }
    catch (Exception localException)
    {
      StringBuilder localStringBuilder = new StringBuilder().append("The JsonDeserializer ");
      JsonDeserializer localJsonDeserializer = this.delegate;
      str = localJsonDeserializer + " failed to deserialize json object " + paramJsonElement + " given the type " + paramType;
    }
    throw new JsonParseException(str, localException);
  }

  public String toString()
  {
    return this.delegate.toString();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.JsonDeserializerExceptionWrapper
 * JD-Core Version:    0.6.0
 */