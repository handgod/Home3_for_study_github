package com.google.gson;

import java.util.LinkedHashMap;
import java.util.Map.Entry;

final class LruCache<K, V> extends LinkedHashMap<K, V>
  implements Cache<K, V>
{
  private static final long serialVersionUID = 1L;
  private final int maxCapacity;

  public LruCache(int paramInt)
  {
    super(paramInt, 0.7F, 1);
    this.maxCapacity = paramInt;
  }

  /** @deprecated */
  public void addElement(K paramK, V paramV)
  {
    monitorenter;
    try
    {
      Object localObject1 = put(paramK, paramV);
      monitorexit;
      return;
    }
    finally
    {
      localObject2 = finally;
      monitorexit;
    }
    throw localObject2;
  }

  /** @deprecated */
  public V getElement(K paramK)
  {
    monitorenter;
    try
    {
      Object localObject1 = get(paramK);
      Object localObject2 = localObject1;
      monitorexit;
      return localObject2;
    }
    finally
    {
      localObject3 = finally;
      monitorexit;
    }
    throw localObject3;
  }

  protected boolean removeEldestEntry(Map.Entry<K, V> paramEntry)
  {
    int i = size();
    int j = this.maxCapacity;
    if (i > j);
    for (int k = 1; ; k = 0)
      return k;
  }

  /** @deprecated */
  public V removeElement(K paramK)
  {
    monitorenter;
    try
    {
      Object localObject1 = remove(paramK);
      Object localObject2 = localObject1;
      monitorexit;
      return localObject2;
    }
    finally
    {
      localObject3 = finally;
      monitorexit;
    }
    throw localObject3;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.LruCache
 * JD-Core Version:    0.6.0
 */