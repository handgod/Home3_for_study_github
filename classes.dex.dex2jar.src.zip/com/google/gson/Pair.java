package com.google.gson;

final class Pair<FIRST, SECOND>
{
  public final FIRST first;
  public final SECOND second;

  public Pair(FIRST paramFIRST, SECOND paramSECOND)
  {
    this.first = paramFIRST;
    this.second = paramSECOND;
  }

  private static boolean equal(Object paramObject1, Object paramObject2)
  {
    if ((paramObject1 == paramObject2) || ((paramObject1 != null) && (paramObject1.equals(paramObject2))));
    for (int i = 1; ; i = 0)
      return i;
  }

  public boolean equals(Object paramObject)
  {
    int i = 0;
    if (!(paramObject instanceof Pair));
    while (true)
    {
      return i;
      Pair localPair = (Pair)paramObject;
      Object localObject1 = this.first;
      Object localObject2 = localPair.first;
      if (!equal(localObject1, localObject2))
        continue;
      Object localObject3 = this.second;
      Object localObject4 = localPair.second;
      if (!equal(localObject3, localObject4))
        continue;
      i = 1;
    }
  }

  public int hashCode()
  {
    int i = 0;
    if (this.first != null);
    for (int j = this.first.hashCode(); ; j = 0)
    {
      j *= 17;
      if (this.second != null)
        i = this.second.hashCode();
      int k = i * 17;
      return j + k;
    }
  }

  public String toString()
  {
    Object[] arrayOfObject = new Object[2];
    Object localObject1 = this.first;
    arrayOfObject[0] = localObject1;
    Object localObject2 = this.second;
    arrayOfObject[1] = localObject2;
    return String.format("{%s,%s}", arrayOfObject);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.Pair
 * JD-Core Version:    0.6.0
 */