package com.google.gson;

import com.google.gson.internal..Gson.Preconditions;
import java.lang.reflect.Type;

abstract class JsonDeserializationVisitor<T>
  implements ObjectNavigator.Visitor
{
  protected boolean constructed;
  protected final JsonDeserializationContext context;
  protected final ParameterizedTypeHandlerMap<JsonDeserializer<?>> deserializers;
  protected final FieldNamingStrategy2 fieldNamingPolicy;
  protected final JsonElement json;
  protected final ObjectConstructor objectConstructor;
  protected final ObjectNavigator objectNavigator;
  protected T target;
  protected final Type targetType;

  JsonDeserializationVisitor(JsonElement paramJsonElement, Type paramType, ObjectNavigator paramObjectNavigator, FieldNamingStrategy2 paramFieldNamingStrategy2, ObjectConstructor paramObjectConstructor, ParameterizedTypeHandlerMap<JsonDeserializer<?>> paramParameterizedTypeHandlerMap, JsonDeserializationContext paramJsonDeserializationContext)
  {
    this.targetType = paramType;
    this.objectNavigator = paramObjectNavigator;
    this.fieldNamingPolicy = paramFieldNamingStrategy2;
    this.objectConstructor = paramObjectConstructor;
    this.deserializers = paramParameterizedTypeHandlerMap;
    JsonElement localJsonElement = (JsonElement).Gson.Preconditions.checkNotNull(paramJsonElement);
    this.json = localJsonElement;
    this.context = paramJsonDeserializationContext;
    this.constructed = 0;
  }

  private Object visitChild(Type paramType, JsonDeserializationVisitor<?> paramJsonDeserializationVisitor)
  {
    ObjectNavigator localObjectNavigator = this.objectNavigator;
    ObjectTypePair localObjectTypePair = new ObjectTypePair(null, paramType, 0);
    localObjectNavigator.accept(localObjectTypePair, paramJsonDeserializationVisitor);
    return paramJsonDeserializationVisitor.getTarget();
  }

  protected abstract T constructTarget();

  public void end(ObjectTypePair paramObjectTypePair)
  {
  }

  public T getTarget()
  {
    if (!this.constructed)
    {
      Object localObject = constructTarget();
      this.target = localObject;
      this.constructed = 1;
    }
    return this.target;
  }

  protected Object invokeCustomDeserializer(JsonElement paramJsonElement, Pair<JsonDeserializer<?>, ObjectTypePair> paramPair)
  {
    if ((paramJsonElement == null) || (paramJsonElement.isJsonNull()));
    Type localType;
    JsonDeserializer localJsonDeserializer;
    JsonDeserializationContext localJsonDeserializationContext;
    for (Object localObject = null; ; localObject = localJsonDeserializer.deserialize(paramJsonElement, localType, localJsonDeserializationContext))
    {
      return localObject;
      localType = ((ObjectTypePair)paramPair.second).type;
      localJsonDeserializer = (JsonDeserializer)paramPair.first;
      localJsonDeserializationContext = this.context;
    }
  }

  public void start(ObjectTypePair paramObjectTypePair)
  {
  }

  final Object visitChildAsArray(Type paramType, JsonArray paramJsonArray)
  {
    JsonArray localJsonArray = paramJsonArray.getAsJsonArray();
    ObjectNavigator localObjectNavigator = this.objectNavigator;
    FieldNamingStrategy2 localFieldNamingStrategy2 = this.fieldNamingPolicy;
    ObjectConstructor localObjectConstructor = this.objectConstructor;
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap = this.deserializers;
    JsonDeserializationContext localJsonDeserializationContext = this.context;
    Type localType = paramType;
    JsonArrayDeserializationVisitor localJsonArrayDeserializationVisitor = new JsonArrayDeserializationVisitor(localJsonArray, localType, localObjectNavigator, localFieldNamingStrategy2, localObjectConstructor, localParameterizedTypeHandlerMap, localJsonDeserializationContext);
    return visitChild(paramType, localJsonArrayDeserializationVisitor);
  }

  final Object visitChildAsObject(Type paramType, JsonElement paramJsonElement)
  {
    ObjectNavigator localObjectNavigator = this.objectNavigator;
    FieldNamingStrategy2 localFieldNamingStrategy2 = this.fieldNamingPolicy;
    ObjectConstructor localObjectConstructor = this.objectConstructor;
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap = this.deserializers;
    JsonDeserializationContext localJsonDeserializationContext = this.context;
    JsonElement localJsonElement = paramJsonElement;
    Type localType = paramType;
    JsonObjectDeserializationVisitor localJsonObjectDeserializationVisitor = new JsonObjectDeserializationVisitor(localJsonElement, localType, localObjectNavigator, localFieldNamingStrategy2, localObjectConstructor, localParameterizedTypeHandlerMap, localJsonDeserializationContext);
    return visitChild(paramType, localJsonObjectDeserializationVisitor);
  }

  public final boolean visitUsingCustomHandler(ObjectTypePair paramObjectTypePair)
  {
    int i = 1;
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap = this.deserializers;
    Pair localPair = paramObjectTypePair.getMatchingHandler(localParameterizedTypeHandlerMap);
    if (localPair == null)
      i = 0;
    while (true)
    {
      return i;
      JsonElement localJsonElement = this.json;
      Object localObject = invokeCustomDeserializer(localJsonElement, localPair);
      this.target = localObject;
      this.constructed = 1;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.JsonDeserializationVisitor
 * JD-Core Version:    0.6.0
 */