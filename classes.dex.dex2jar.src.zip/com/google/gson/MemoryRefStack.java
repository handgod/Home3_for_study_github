package com.google.gson;

import com.google.gson.internal..Gson.Preconditions;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.Stack;

final class MemoryRefStack
{
  private final Stack<ObjectTypePair> stack;

  MemoryRefStack()
  {
    Stack localStack = new Stack();
    this.stack = localStack;
  }

  public boolean contains(ObjectTypePair paramObjectTypePair)
  {
    int i = 0;
    if (paramObjectTypePair == null)
      break label16;
    while (true)
    {
      return i;
      Iterator localIterator = this.stack.iterator();
      label16: if (!localIterator.hasNext())
        continue;
      ObjectTypePair localObjectTypePair = (ObjectTypePair)localIterator.next();
      Object localObject1 = localObjectTypePair.getObject();
      Object localObject2 = paramObjectTypePair.getObject();
      if (localObject1 != localObject2)
        break;
      Type localType1 = localObjectTypePair.type;
      Type localType2 = paramObjectTypePair.type;
      if (!localType1.equals(localType2))
        break;
      i = 1;
    }
  }

  public boolean isEmpty()
  {
    return this.stack.isEmpty();
  }

  public ObjectTypePair peek()
  {
    return (ObjectTypePair)this.stack.peek();
  }

  public ObjectTypePair pop()
  {
    return (ObjectTypePair)this.stack.pop();
  }

  public ObjectTypePair push(ObjectTypePair paramObjectTypePair)
  {
    Object localObject = .Gson.Preconditions.checkNotNull(paramObjectTypePair);
    return (ObjectTypePair)this.stack.push(paramObjectTypePair);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.MemoryRefStack
 * JD-Core Version:    0.6.0
 */