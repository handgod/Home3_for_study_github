package com.google.gson;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

final class JsonTreeNavigator
{
  private final boolean visitNulls;
  private final JsonElementVisitor visitor;

  JsonTreeNavigator(JsonElementVisitor paramJsonElementVisitor, boolean paramBoolean)
  {
    this.visitor = paramJsonElementVisitor;
    this.visitNulls = paramBoolean;
  }

  private void visitChild(JsonArray paramJsonArray, JsonElement paramJsonElement, boolean paramBoolean)
    throws IOException
  {
    if (paramJsonElement.isJsonNull())
    {
      this.visitor.visitNullArrayMember(paramJsonArray, paramBoolean);
      navigate(paramJsonElement);
    }
    while (true)
    {
      return;
      if (paramJsonElement.isJsonArray())
      {
        JsonArray localJsonArray = paramJsonElement.getAsJsonArray();
        this.visitor.visitArrayMember(paramJsonArray, localJsonArray, paramBoolean);
        navigate(localJsonArray);
        continue;
      }
      if (paramJsonElement.isJsonObject())
      {
        JsonObject localJsonObject = paramJsonElement.getAsJsonObject();
        this.visitor.visitArrayMember(paramJsonArray, localJsonObject, paramBoolean);
        navigate(localJsonObject);
        continue;
      }
      JsonElementVisitor localJsonElementVisitor = this.visitor;
      JsonPrimitive localJsonPrimitive = paramJsonElement.getAsJsonPrimitive();
      localJsonElementVisitor.visitArrayMember(paramJsonArray, localJsonPrimitive, paramBoolean);
    }
  }

  private boolean visitChild(JsonObject paramJsonObject, String paramString, JsonElement paramJsonElement, boolean paramBoolean)
    throws IOException
  {
    if (paramJsonElement.isJsonNull())
      if (this.visitNulls)
      {
        this.visitor.visitNullObjectMember(paramJsonObject, paramString, paramBoolean);
        JsonNull localJsonNull = paramJsonElement.getAsJsonNull();
        navigate(localJsonNull);
      }
    while (true)
    {
      for (int i = 1; ; i = 0)
        return i;
      if (paramJsonElement.isJsonArray())
      {
        JsonArray localJsonArray = paramJsonElement.getAsJsonArray();
        this.visitor.visitObjectMember(paramJsonObject, paramString, localJsonArray, paramBoolean);
        navigate(localJsonArray);
        continue;
      }
      if (paramJsonElement.isJsonObject())
      {
        JsonObject localJsonObject = paramJsonElement.getAsJsonObject();
        this.visitor.visitObjectMember(paramJsonObject, paramString, localJsonObject, paramBoolean);
        navigate(localJsonObject);
        continue;
      }
      JsonElementVisitor localJsonElementVisitor = this.visitor;
      JsonPrimitive localJsonPrimitive = paramJsonElement.getAsJsonPrimitive();
      localJsonElementVisitor.visitObjectMember(paramJsonObject, paramString, localJsonPrimitive, paramBoolean);
    }
  }

  public void navigate(JsonElement paramJsonElement)
    throws IOException
  {
    if (paramJsonElement.isJsonNull())
      this.visitor.visitNull();
    while (true)
    {
      return;
      Iterator localIterator;
      int j;
      if (paramJsonElement.isJsonArray())
      {
        JsonArray localJsonArray = paramJsonElement.getAsJsonArray();
        this.visitor.startArray(localJsonArray);
        int i = 1;
        localIterator = localJsonArray.iterator();
        while (localIterator.hasNext())
        {
          JsonElement localJsonElement1 = (JsonElement)localIterator.next();
          visitChild(localJsonArray, localJsonElement1, i);
          if (i == 0)
            continue;
          j = 0;
        }
        this.visitor.endArray(localJsonArray);
        continue;
      }
      if (paramJsonElement.isJsonObject())
      {
        JsonObject localJsonObject = paramJsonElement.getAsJsonObject();
        this.visitor.startObject(localJsonObject);
        j = 1;
        localIterator = localJsonObject.entrySet().iterator();
        while (localIterator.hasNext())
        {
          Map.Entry localEntry = (Map.Entry)localIterator.next();
          String str = (String)localEntry.getKey();
          JsonElement localJsonElement2 = (JsonElement)localEntry.getValue();
          if ((!visitChild(localJsonObject, str, localJsonElement2, j)) || (j == 0))
            continue;
          int k = 0;
        }
        this.visitor.endObject(localJsonObject);
        continue;
      }
      JsonElementVisitor localJsonElementVisitor = this.visitor;
      JsonPrimitive localJsonPrimitive = paramJsonElement.getAsJsonPrimitive();
      localJsonElementVisitor.visitPrimitive(localJsonPrimitive);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.JsonTreeNavigator
 * JD-Core Version:    0.6.0
 */