package com.google.gson;

import com.google.gson.internal..Gson.Preconditions;
import com.google.gson.internal..Gson.Types;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.List<Lcom.google.gson.FieldAttributes;>;

final class ReflectingFieldNavigator
{
  private static final Cache<Type, List<FieldAttributes>> fieldsCache = new LruCache(500);
  private final ExclusionStrategy exclusionStrategy;

  ReflectingFieldNavigator(ExclusionStrategy paramExclusionStrategy)
  {
    ExclusionStrategy localExclusionStrategy = (ExclusionStrategy).Gson.Preconditions.checkNotNull(paramExclusionStrategy);
    this.exclusionStrategy = localExclusionStrategy;
  }

  private List<FieldAttributes> getAllFields(Type paramType1, Type paramType2)
  {
    Object localObject = (List)fieldsCache.getElement(paramType1);
    if (localObject == null)
    {
      localObject = new ArrayList();
      Iterator localIterator = getInheritanceHierarchy(paramType1).iterator();
      while (localIterator.hasNext())
      {
        Class localClass = (Class)localIterator.next();
        Field[] arrayOfField1 = localClass.getDeclaredFields();
        AccessibleObject.setAccessible(arrayOfField1, 1);
        Field[] arrayOfField2 = arrayOfField1;
        int i = arrayOfField2.length;
        int j = 0;
        while (j < i)
        {
          Field localField = arrayOfField2[j];
          FieldAttributes localFieldAttributes = new FieldAttributes(localClass, localField, paramType2);
          boolean bool = ((List)localObject).add(localFieldAttributes);
          j += 1;
        }
      }
      fieldsCache.addElement(paramType1, localObject);
    }
    return (List<FieldAttributes>)localObject;
  }

  private List<Class<?>> getInheritanceHierarchy(Type paramType)
  {
    ArrayList localArrayList = new ArrayList();
    for (Class localClass = .Gson.Types.getRawType(paramType); (localClass != null) && (!localClass.equals(Object.class)); localClass = localClass.getSuperclass())
    {
      if (localClass.isSynthetic())
        continue;
      boolean bool = localArrayList.add(localClass);
    }
    return localArrayList;
  }

  void visitFieldsReflectively(ObjectTypePair paramObjectTypePair, ObjectNavigator.Visitor paramVisitor)
  {
    Type localType1 = paramObjectTypePair.getMoreSpecificType();
    Object localObject = paramObjectTypePair.getObject();
    Type localType2 = paramObjectTypePair.getType();
    Iterator localIterator = getAllFields(localType1, localType2).iterator();
    while (localIterator.hasNext())
    {
      FieldAttributes localFieldAttributes = (FieldAttributes)localIterator.next();
      if (this.exclusionStrategy.shouldSkipField(localFieldAttributes))
        continue;
      ExclusionStrategy localExclusionStrategy = this.exclusionStrategy;
      Class localClass = localFieldAttributes.getDeclaredClass();
      if (localExclusionStrategy.shouldSkipClass(localClass))
        continue;
      Type localType3 = localFieldAttributes.getResolvedType();
      if (paramVisitor.visitFieldUsingCustomHandler(localFieldAttributes, localType3, localObject))
        continue;
      if (.Gson.Types.isArray(localType3))
      {
        paramVisitor.visitArrayField(localFieldAttributes, localType3, localObject);
        continue;
      }
      paramVisitor.visitObjectField(localFieldAttributes, localType3, localObject);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.ReflectingFieldNavigator
 * JD-Core Version:    0.6.0
 */