package com.google.gson;

import java.lang.reflect.Type;

final class JsonSerializationContextDefault
  implements JsonSerializationContext
{
  private final MemoryRefStack ancestors;
  private final FieldNamingStrategy2 fieldNamingPolicy;
  private final ObjectNavigator objectNavigator;
  private final boolean serializeNulls;
  private final ParameterizedTypeHandlerMap<JsonSerializer<?>> serializers;

  JsonSerializationContextDefault(ObjectNavigator paramObjectNavigator, FieldNamingStrategy2 paramFieldNamingStrategy2, boolean paramBoolean, ParameterizedTypeHandlerMap<JsonSerializer<?>> paramParameterizedTypeHandlerMap)
  {
    this.objectNavigator = paramObjectNavigator;
    this.fieldNamingPolicy = paramFieldNamingStrategy2;
    this.serializeNulls = paramBoolean;
    this.serializers = paramParameterizedTypeHandlerMap;
    MemoryRefStack localMemoryRefStack = new MemoryRefStack();
    this.ancestors = localMemoryRefStack;
  }

  public JsonElement serialize(Object paramObject)
  {
    if (paramObject == null);
    Class localClass;
    for (Object localObject = JsonNull.createJsonNull(); ; localObject = serialize(paramObject, localClass, 0))
    {
      return localObject;
      localClass = paramObject.getClass();
    }
  }

  public JsonElement serialize(Object paramObject, Type paramType)
  {
    return serialize(paramObject, paramType, 1);
  }

  JsonElement serialize(Object paramObject, Type paramType, boolean paramBoolean)
  {
    if (paramObject == null);
    JsonSerializationVisitor localJsonSerializationVisitor;
    for (Object localObject = JsonNull.createJsonNull(); ; localObject = localJsonSerializationVisitor.getJsonElement())
    {
      return localObject;
      ObjectNavigator localObjectNavigator1 = this.objectNavigator;
      FieldNamingStrategy2 localFieldNamingStrategy2 = this.fieldNamingPolicy;
      boolean bool = this.serializeNulls;
      ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap = this.serializers;
      MemoryRefStack localMemoryRefStack = this.ancestors;
      JsonSerializationContextDefault localJsonSerializationContextDefault = this;
      localJsonSerializationVisitor = new JsonSerializationVisitor(localObjectNavigator1, localFieldNamingStrategy2, bool, localParameterizedTypeHandlerMap, localJsonSerializationContextDefault, localMemoryRefStack);
      ObjectNavigator localObjectNavigator2 = this.objectNavigator;
      ObjectTypePair localObjectTypePair = new ObjectTypePair(paramObject, paramType, paramBoolean);
      localObjectNavigator2.accept(localObjectTypePair, localJsonSerializationVisitor);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.JsonSerializationContextDefault
 * JD-Core Version:    0.6.0
 */