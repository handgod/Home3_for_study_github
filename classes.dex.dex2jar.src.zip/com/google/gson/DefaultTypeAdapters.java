package com.google.gson;

import com.google.gson.internal..Gson.Types;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.UnknownHostException;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.SortedSet;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.TreeSet;
import java.util.UUID;

final class DefaultTypeAdapters
{
  private static final BigDecimalTypeAdapter BIG_DECIMAL_TYPE_ADAPTER;
  private static final BigIntegerTypeAdapter BIG_INTEGER_TYPE_ADAPTER;
  private static final BooleanTypeAdapter BOOLEAN_TYPE_ADAPTER;
  private static final ByteTypeAdapter BYTE_TYPE_ADAPTER;
  private static final CharacterTypeAdapter CHARACTER_TYPE_ADAPTER;
  private static final CollectionTypeAdapter COLLECTION_TYPE_ADAPTER;
  private static final DefaultDateTypeAdapter DATE_TYPE_ADAPTER = new DefaultDateTypeAdapter();
  private static final ParameterizedTypeHandlerMap<JsonDeserializer<?>> DEFAULT_DESERIALIZERS;
  static final ParameterizedTypeHandlerMap<JsonDeserializer<?>> DEFAULT_HIERARCHY_DESERIALIZERS;
  static final ParameterizedTypeHandlerMap<JsonSerializer<?>> DEFAULT_HIERARCHY_SERIALIZERS;
  private static final ParameterizedTypeHandlerMap<InstanceCreator<?>> DEFAULT_INSTANCE_CREATORS;
  private static final ParameterizedTypeHandlerMap<JsonSerializer<?>> DEFAULT_SERIALIZERS;
  private static final DoubleDeserializer DOUBLE_TYPE_ADAPTER;
  private static final EnumTypeAdapter ENUM_TYPE_ADAPTER;
  private static final FloatDeserializer FLOAT_TYPE_ADAPTER;
  private static final GregorianCalendarTypeAdapter GREGORIAN_CALENDAR_TYPE_ADAPTER;
  private static final DefaultInetAddressAdapter INET_ADDRESS_ADAPTER;
  private static final IntegerTypeAdapter INTEGER_TYPE_ADAPTER;
  private static final DefaultJavaSqlDateTypeAdapter JAVA_SQL_DATE_TYPE_ADAPTER = new DefaultJavaSqlDateTypeAdapter();
  private static final LocaleTypeAdapter LOCALE_TYPE_ADAPTER;
  private static final LongDeserializer LONG_DESERIALIZER;
  private static final MapTypeAdapter MAP_TYPE_ADAPTER;
  private static final NumberTypeAdapter NUMBER_TYPE_ADAPTER;
  private static final ShortTypeAdapter SHORT_TYPE_ADAPTER;
  private static final StringBufferTypeAdapter STRING_BUFFER_TYPE_ADAPTER;
  private static final StringBuilderTypeAdapter STRING_BUILDER_TYPE_ADAPTER;
  private static final StringTypeAdapter STRING_TYPE_ADAPTER;
  private static final DefaultTimestampDeserializer TIMESTAMP_DESERIALIZER;
  private static final DefaultTimeTypeAdapter TIME_TYPE_ADAPTER = new DefaultTimeTypeAdapter();
  private static final UriTypeAdapter URI_TYPE_ADAPTER;
  private static final UrlTypeAdapter URL_TYPE_ADAPTER;
  private static final UuidTypeAdapter UUUID_TYPE_ADAPTER;

  static
  {
    TIMESTAMP_DESERIALIZER = new DefaultTimestampDeserializer();
    ENUM_TYPE_ADAPTER = new EnumTypeAdapter();
    URL_TYPE_ADAPTER = new UrlTypeAdapter();
    URI_TYPE_ADAPTER = new UriTypeAdapter();
    UUUID_TYPE_ADAPTER = new UuidTypeAdapter();
    LOCALE_TYPE_ADAPTER = new LocaleTypeAdapter();
    INET_ADDRESS_ADAPTER = new DefaultInetAddressAdapter();
    COLLECTION_TYPE_ADAPTER = new CollectionTypeAdapter();
    MAP_TYPE_ADAPTER = new MapTypeAdapter();
    BIG_DECIMAL_TYPE_ADAPTER = new BigDecimalTypeAdapter();
    BIG_INTEGER_TYPE_ADAPTER = new BigIntegerTypeAdapter();
    BOOLEAN_TYPE_ADAPTER = new BooleanTypeAdapter();
    BYTE_TYPE_ADAPTER = new ByteTypeAdapter();
    CHARACTER_TYPE_ADAPTER = new CharacterTypeAdapter();
    DOUBLE_TYPE_ADAPTER = new DoubleDeserializer();
    FLOAT_TYPE_ADAPTER = new FloatDeserializer();
    INTEGER_TYPE_ADAPTER = new IntegerTypeAdapter();
    LONG_DESERIALIZER = new LongDeserializer();
    NUMBER_TYPE_ADAPTER = new NumberTypeAdapter();
    SHORT_TYPE_ADAPTER = new ShortTypeAdapter();
    STRING_TYPE_ADAPTER = new StringTypeAdapter();
    STRING_BUILDER_TYPE_ADAPTER = new StringBuilderTypeAdapter();
    STRING_BUFFER_TYPE_ADAPTER = new StringBufferTypeAdapter();
    GREGORIAN_CALENDAR_TYPE_ADAPTER = new GregorianCalendarTypeAdapter();
    DEFAULT_SERIALIZERS = createDefaultSerializers();
    DEFAULT_HIERARCHY_SERIALIZERS = createDefaultHierarchySerializers();
    DEFAULT_DESERIALIZERS = createDefaultDeserializers();
    DEFAULT_HIERARCHY_DESERIALIZERS = createDefaultHierarchyDeserializers();
    DEFAULT_INSTANCE_CREATORS = createDefaultInstanceCreators();
  }

  private static ParameterizedTypeHandlerMap<JsonDeserializer<?>> createDefaultDeserializers()
  {
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap = new ParameterizedTypeHandlerMap();
    JsonDeserializer localJsonDeserializer1 = wrapDeserializer(URL_TYPE_ADAPTER);
    localParameterizedTypeHandlerMap.register(URL.class, localJsonDeserializer1);
    JsonDeserializer localJsonDeserializer2 = wrapDeserializer(URI_TYPE_ADAPTER);
    localParameterizedTypeHandlerMap.register(URI.class, localJsonDeserializer2);
    JsonDeserializer localJsonDeserializer3 = wrapDeserializer(UUUID_TYPE_ADAPTER);
    localParameterizedTypeHandlerMap.register(UUID.class, localJsonDeserializer3);
    JsonDeserializer localJsonDeserializer4 = wrapDeserializer(LOCALE_TYPE_ADAPTER);
    localParameterizedTypeHandlerMap.register(Locale.class, localJsonDeserializer4);
    JsonDeserializer localJsonDeserializer5 = wrapDeserializer(DATE_TYPE_ADAPTER);
    localParameterizedTypeHandlerMap.register(java.util.Date.class, localJsonDeserializer5);
    JsonDeserializer localJsonDeserializer6 = wrapDeserializer(JAVA_SQL_DATE_TYPE_ADAPTER);
    localParameterizedTypeHandlerMap.register(java.sql.Date.class, localJsonDeserializer6);
    JsonDeserializer localJsonDeserializer7 = wrapDeserializer(TIMESTAMP_DESERIALIZER);
    localParameterizedTypeHandlerMap.register(Timestamp.class, localJsonDeserializer7);
    JsonDeserializer localJsonDeserializer8 = wrapDeserializer(TIME_TYPE_ADAPTER);
    localParameterizedTypeHandlerMap.register(Time.class, localJsonDeserializer8);
    GregorianCalendarTypeAdapter localGregorianCalendarTypeAdapter1 = GREGORIAN_CALENDAR_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(Calendar.class, localGregorianCalendarTypeAdapter1);
    GregorianCalendarTypeAdapter localGregorianCalendarTypeAdapter2 = GREGORIAN_CALENDAR_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(GregorianCalendar.class, localGregorianCalendarTypeAdapter2);
    BigDecimalTypeAdapter localBigDecimalTypeAdapter = BIG_DECIMAL_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(BigDecimal.class, localBigDecimalTypeAdapter);
    BigIntegerTypeAdapter localBigIntegerTypeAdapter = BIG_INTEGER_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(BigInteger.class, localBigIntegerTypeAdapter);
    BooleanTypeAdapter localBooleanTypeAdapter1 = BOOLEAN_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(Boolean.class, localBooleanTypeAdapter1);
    Class localClass1 = Boolean.TYPE;
    BooleanTypeAdapter localBooleanTypeAdapter2 = BOOLEAN_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(localClass1, localBooleanTypeAdapter2);
    ByteTypeAdapter localByteTypeAdapter1 = BYTE_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(Byte.class, localByteTypeAdapter1);
    Class localClass2 = Byte.TYPE;
    ByteTypeAdapter localByteTypeAdapter2 = BYTE_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(localClass2, localByteTypeAdapter2);
    JsonDeserializer localJsonDeserializer9 = wrapDeserializer(CHARACTER_TYPE_ADAPTER);
    localParameterizedTypeHandlerMap.register(Character.class, localJsonDeserializer9);
    Class localClass3 = Character.TYPE;
    JsonDeserializer localJsonDeserializer10 = wrapDeserializer(CHARACTER_TYPE_ADAPTER);
    localParameterizedTypeHandlerMap.register(localClass3, localJsonDeserializer10);
    DoubleDeserializer localDoubleDeserializer1 = DOUBLE_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(Double.class, localDoubleDeserializer1);
    Class localClass4 = Double.TYPE;
    DoubleDeserializer localDoubleDeserializer2 = DOUBLE_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(localClass4, localDoubleDeserializer2);
    FloatDeserializer localFloatDeserializer1 = FLOAT_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(Float.class, localFloatDeserializer1);
    Class localClass5 = Float.TYPE;
    FloatDeserializer localFloatDeserializer2 = FLOAT_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(localClass5, localFloatDeserializer2);
    IntegerTypeAdapter localIntegerTypeAdapter1 = INTEGER_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(Integer.class, localIntegerTypeAdapter1);
    Class localClass6 = Integer.TYPE;
    IntegerTypeAdapter localIntegerTypeAdapter2 = INTEGER_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(localClass6, localIntegerTypeAdapter2);
    LongDeserializer localLongDeserializer1 = LONG_DESERIALIZER;
    localParameterizedTypeHandlerMap.register(Long.class, localLongDeserializer1);
    Class localClass7 = Long.TYPE;
    LongDeserializer localLongDeserializer2 = LONG_DESERIALIZER;
    localParameterizedTypeHandlerMap.register(localClass7, localLongDeserializer2);
    NumberTypeAdapter localNumberTypeAdapter = NUMBER_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(Number.class, localNumberTypeAdapter);
    ShortTypeAdapter localShortTypeAdapter1 = SHORT_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(Short.class, localShortTypeAdapter1);
    Class localClass8 = Short.TYPE;
    ShortTypeAdapter localShortTypeAdapter2 = SHORT_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(localClass8, localShortTypeAdapter2);
    JsonDeserializer localJsonDeserializer11 = wrapDeserializer(STRING_TYPE_ADAPTER);
    localParameterizedTypeHandlerMap.register(String.class, localJsonDeserializer11);
    JsonDeserializer localJsonDeserializer12 = wrapDeserializer(STRING_BUILDER_TYPE_ADAPTER);
    localParameterizedTypeHandlerMap.register(StringBuilder.class, localJsonDeserializer12);
    JsonDeserializer localJsonDeserializer13 = wrapDeserializer(STRING_BUFFER_TYPE_ADAPTER);
    localParameterizedTypeHandlerMap.register(StringBuffer.class, localJsonDeserializer13);
    localParameterizedTypeHandlerMap.makeUnmodifiable();
    return localParameterizedTypeHandlerMap;
  }

  private static ParameterizedTypeHandlerMap<JsonDeserializer<?>> createDefaultHierarchyDeserializers()
  {
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap = new ParameterizedTypeHandlerMap();
    JsonDeserializer localJsonDeserializer1 = wrapDeserializer(ENUM_TYPE_ADAPTER);
    localParameterizedTypeHandlerMap.registerForTypeHierarchy(Enum.class, localJsonDeserializer1);
    JsonDeserializer localJsonDeserializer2 = wrapDeserializer(INET_ADDRESS_ADAPTER);
    localParameterizedTypeHandlerMap.registerForTypeHierarchy(InetAddress.class, localJsonDeserializer2);
    JsonDeserializer localJsonDeserializer3 = wrapDeserializer(COLLECTION_TYPE_ADAPTER);
    localParameterizedTypeHandlerMap.registerForTypeHierarchy(Collection.class, localJsonDeserializer3);
    JsonDeserializer localJsonDeserializer4 = wrapDeserializer(MAP_TYPE_ADAPTER);
    localParameterizedTypeHandlerMap.registerForTypeHierarchy(Map.class, localJsonDeserializer4);
    localParameterizedTypeHandlerMap.makeUnmodifiable();
    return localParameterizedTypeHandlerMap;
  }

  private static ParameterizedTypeHandlerMap<JsonSerializer<?>> createDefaultHierarchySerializers()
  {
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap = new ParameterizedTypeHandlerMap();
    EnumTypeAdapter localEnumTypeAdapter = ENUM_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.registerForTypeHierarchy(Enum.class, localEnumTypeAdapter);
    DefaultInetAddressAdapter localDefaultInetAddressAdapter = INET_ADDRESS_ADAPTER;
    localParameterizedTypeHandlerMap.registerForTypeHierarchy(InetAddress.class, localDefaultInetAddressAdapter);
    CollectionTypeAdapter localCollectionTypeAdapter = COLLECTION_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.registerForTypeHierarchy(Collection.class, localCollectionTypeAdapter);
    MapTypeAdapter localMapTypeAdapter = MAP_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.registerForTypeHierarchy(Map.class, localMapTypeAdapter);
    localParameterizedTypeHandlerMap.makeUnmodifiable();
    return localParameterizedTypeHandlerMap;
  }

  private static ParameterizedTypeHandlerMap<InstanceCreator<?>> createDefaultInstanceCreators()
  {
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap = new ParameterizedTypeHandlerMap();
    DefaultConstructorAllocator localDefaultConstructorAllocator = new DefaultConstructorAllocator(50);
    DefaultConstructorCreator localDefaultConstructorCreator1 = new DefaultConstructorCreator(localDefaultConstructorAllocator);
    localParameterizedTypeHandlerMap.registerForTypeHierarchy(Map.class, localDefaultConstructorCreator1);
    DefaultConstructorCreator localDefaultConstructorCreator2 = new DefaultConstructorCreator(localDefaultConstructorAllocator);
    DefaultConstructorCreator localDefaultConstructorCreator3 = new DefaultConstructorCreator(localDefaultConstructorAllocator);
    DefaultConstructorCreator localDefaultConstructorCreator4 = new DefaultConstructorCreator(localDefaultConstructorAllocator);
    DefaultConstructorCreator localDefaultConstructorCreator5 = new DefaultConstructorCreator(localDefaultConstructorAllocator);
    localParameterizedTypeHandlerMap.registerForTypeHierarchy(Collection.class, localDefaultConstructorCreator2);
    localParameterizedTypeHandlerMap.registerForTypeHierarchy(Queue.class, localDefaultConstructorCreator3);
    localParameterizedTypeHandlerMap.registerForTypeHierarchy(Set.class, localDefaultConstructorCreator4);
    localParameterizedTypeHandlerMap.registerForTypeHierarchy(SortedSet.class, localDefaultConstructorCreator5);
    localParameterizedTypeHandlerMap.makeUnmodifiable();
    return localParameterizedTypeHandlerMap;
  }

  private static ParameterizedTypeHandlerMap<JsonSerializer<?>> createDefaultSerializers()
  {
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap = new ParameterizedTypeHandlerMap();
    UrlTypeAdapter localUrlTypeAdapter = URL_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(URL.class, localUrlTypeAdapter);
    UriTypeAdapter localUriTypeAdapter = URI_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(URI.class, localUriTypeAdapter);
    UuidTypeAdapter localUuidTypeAdapter = UUUID_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(UUID.class, localUuidTypeAdapter);
    LocaleTypeAdapter localLocaleTypeAdapter = LOCALE_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(Locale.class, localLocaleTypeAdapter);
    DefaultDateTypeAdapter localDefaultDateTypeAdapter1 = DATE_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(java.util.Date.class, localDefaultDateTypeAdapter1);
    DefaultJavaSqlDateTypeAdapter localDefaultJavaSqlDateTypeAdapter = JAVA_SQL_DATE_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(java.sql.Date.class, localDefaultJavaSqlDateTypeAdapter);
    DefaultDateTypeAdapter localDefaultDateTypeAdapter2 = DATE_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(Timestamp.class, localDefaultDateTypeAdapter2);
    DefaultTimeTypeAdapter localDefaultTimeTypeAdapter = TIME_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(Time.class, localDefaultTimeTypeAdapter);
    GregorianCalendarTypeAdapter localGregorianCalendarTypeAdapter1 = GREGORIAN_CALENDAR_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(Calendar.class, localGregorianCalendarTypeAdapter1);
    GregorianCalendarTypeAdapter localGregorianCalendarTypeAdapter2 = GREGORIAN_CALENDAR_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(GregorianCalendar.class, localGregorianCalendarTypeAdapter2);
    BigDecimalTypeAdapter localBigDecimalTypeAdapter = BIG_DECIMAL_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(BigDecimal.class, localBigDecimalTypeAdapter);
    BigIntegerTypeAdapter localBigIntegerTypeAdapter = BIG_INTEGER_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(BigInteger.class, localBigIntegerTypeAdapter);
    BooleanTypeAdapter localBooleanTypeAdapter1 = BOOLEAN_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(Boolean.class, localBooleanTypeAdapter1);
    Class localClass1 = Boolean.TYPE;
    BooleanTypeAdapter localBooleanTypeAdapter2 = BOOLEAN_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(localClass1, localBooleanTypeAdapter2);
    ByteTypeAdapter localByteTypeAdapter1 = BYTE_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(Byte.class, localByteTypeAdapter1);
    Class localClass2 = Byte.TYPE;
    ByteTypeAdapter localByteTypeAdapter2 = BYTE_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(localClass2, localByteTypeAdapter2);
    CharacterTypeAdapter localCharacterTypeAdapter1 = CHARACTER_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(Character.class, localCharacterTypeAdapter1);
    Class localClass3 = Character.TYPE;
    CharacterTypeAdapter localCharacterTypeAdapter2 = CHARACTER_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(localClass3, localCharacterTypeAdapter2);
    IntegerTypeAdapter localIntegerTypeAdapter1 = INTEGER_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(Integer.class, localIntegerTypeAdapter1);
    Class localClass4 = Integer.TYPE;
    IntegerTypeAdapter localIntegerTypeAdapter2 = INTEGER_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(localClass4, localIntegerTypeAdapter2);
    NumberTypeAdapter localNumberTypeAdapter = NUMBER_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(Number.class, localNumberTypeAdapter);
    ShortTypeAdapter localShortTypeAdapter1 = SHORT_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(Short.class, localShortTypeAdapter1);
    Class localClass5 = Short.TYPE;
    ShortTypeAdapter localShortTypeAdapter2 = SHORT_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(localClass5, localShortTypeAdapter2);
    StringTypeAdapter localStringTypeAdapter = STRING_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(String.class, localStringTypeAdapter);
    StringBuilderTypeAdapter localStringBuilderTypeAdapter = STRING_BUILDER_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(StringBuilder.class, localStringBuilderTypeAdapter);
    StringBufferTypeAdapter localStringBufferTypeAdapter = STRING_BUFFER_TYPE_ADAPTER;
    localParameterizedTypeHandlerMap.register(StringBuffer.class, localStringBufferTypeAdapter);
    localParameterizedTypeHandlerMap.makeUnmodifiable();
    return localParameterizedTypeHandlerMap;
  }

  static ParameterizedTypeHandlerMap<JsonDeserializer<?>> getAllDefaultDeserializers()
  {
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap1 = getDefaultDeserializers().copyOf();
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap2 = DEFAULT_HIERARCHY_DESERIALIZERS;
    localParameterizedTypeHandlerMap1.register(localParameterizedTypeHandlerMap2);
    return localParameterizedTypeHandlerMap1;
  }

  static ParameterizedTypeHandlerMap<JsonSerializer<?>> getAllDefaultSerializers()
  {
    LongSerializationPolicy localLongSerializationPolicy = LongSerializationPolicy.DEFAULT;
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap1 = getDefaultSerializers(0, localLongSerializationPolicy);
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap2 = DEFAULT_HIERARCHY_SERIALIZERS;
    localParameterizedTypeHandlerMap1.register(localParameterizedTypeHandlerMap2);
    return localParameterizedTypeHandlerMap1;
  }

  static ParameterizedTypeHandlerMap<JsonDeserializer<?>> getDefaultDeserializers()
  {
    return DEFAULT_DESERIALIZERS;
  }

  static ParameterizedTypeHandlerMap<InstanceCreator<?>> getDefaultInstanceCreators()
  {
    return DEFAULT_INSTANCE_CREATORS;
  }

  static ParameterizedTypeHandlerMap<JsonSerializer<?>> getDefaultSerializers()
  {
    LongSerializationPolicy localLongSerializationPolicy = LongSerializationPolicy.DEFAULT;
    return getDefaultSerializers(0, localLongSerializationPolicy);
  }

  static ParameterizedTypeHandlerMap<JsonSerializer<?>> getDefaultSerializers(boolean paramBoolean, LongSerializationPolicy paramLongSerializationPolicy)
  {
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap1 = new ParameterizedTypeHandlerMap();
    DoubleSerializer localDoubleSerializer = new DoubleSerializer();
    localParameterizedTypeHandlerMap1.registerIfAbsent(Double.class, localDoubleSerializer);
    Class localClass1 = Double.TYPE;
    localParameterizedTypeHandlerMap1.registerIfAbsent(localClass1, localDoubleSerializer);
    FloatSerializer localFloatSerializer = new FloatSerializer();
    localParameterizedTypeHandlerMap1.registerIfAbsent(Float.class, localFloatSerializer);
    Class localClass2 = Float.TYPE;
    localParameterizedTypeHandlerMap1.registerIfAbsent(localClass2, localFloatSerializer);
    LongSerializer localLongSerializer = new LongSerializer(null);
    localParameterizedTypeHandlerMap1.registerIfAbsent(Long.class, localLongSerializer);
    Class localClass3 = Long.TYPE;
    localParameterizedTypeHandlerMap1.registerIfAbsent(localClass3, localLongSerializer);
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap2 = DEFAULT_SERIALIZERS;
    localParameterizedTypeHandlerMap1.registerIfAbsent(localParameterizedTypeHandlerMap2);
    return localParameterizedTypeHandlerMap1;
  }

  private static JsonDeserializer<?> wrapDeserializer(JsonDeserializer<?> paramJsonDeserializer)
  {
    return new JsonDeserializerExceptionWrapper(paramJsonDeserializer);
  }

  final class DefaultConstructorCreator<T>
    implements InstanceCreator<T>
  {
    private final DefaultConstructorAllocator allocator;

    public DefaultConstructorCreator(DefaultConstructorAllocator arg2)
    {
      Object localObject;
      this.allocator = localObject;
    }

    public T createInstance(Type paramType)
    {
      Class localClass1 = .Gson.Types.getRawType(paramType);
      try
      {
        Object localObject1 = this.allocator.newInstance(localClass1);
        if (localObject1 == null)
        {
          DefaultConstructorAllocator localDefaultConstructorAllocator = this.allocator;
          Class localClass2 = DefaultTypeAdapters.this;
          Object localObject2 = localDefaultConstructorAllocator.newInstance(localClass2);
          localObject1 = localObject2;
        }
        return localObject1;
      }
      catch (Exception localException)
      {
      }
      throw new JsonIOException(localException);
    }

    public String toString()
    {
      return DefaultConstructorCreator.class.getSimpleName();
    }
  }

  final class BooleanTypeAdapter
    implements JsonSerializer<Boolean>, JsonDeserializer<Boolean>
  {
    public Boolean deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      try
      {
        Boolean localBoolean = Boolean.valueOf(paramJsonElement.getAsBoolean());
        return localBoolean;
      }
      catch (UnsupportedOperationException localUnsupportedOperationException)
      {
        throw new JsonSyntaxException(localUnsupportedOperationException);
      }
      catch (IllegalStateException localIllegalStateException)
      {
      }
      throw new JsonSyntaxException(localIllegalStateException);
    }

    public JsonElement serialize(Boolean paramBoolean, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      return new JsonPrimitive(paramBoolean);
    }

    public String toString()
    {
      return BooleanTypeAdapter.class.getSimpleName();
    }
  }

  final class StringBufferTypeAdapter
    implements JsonSerializer<StringBuffer>, JsonDeserializer<StringBuffer>
  {
    public StringBuffer deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      String str = paramJsonElement.getAsString();
      return new StringBuffer(str);
    }

    public JsonElement serialize(StringBuffer paramStringBuffer, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      String str = paramStringBuffer.toString();
      return new JsonPrimitive(str);
    }

    public String toString()
    {
      return StringBufferTypeAdapter.class.getSimpleName();
    }
  }

  final class StringBuilderTypeAdapter
    implements JsonSerializer<StringBuilder>, JsonDeserializer<StringBuilder>
  {
    public StringBuilder deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      String str = paramJsonElement.getAsString();
      return new StringBuilder(str);
    }

    public JsonElement serialize(StringBuilder paramStringBuilder, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      String str = paramStringBuilder.toString();
      return new JsonPrimitive(str);
    }

    public String toString()
    {
      return StringBuilderTypeAdapter.class.getSimpleName();
    }
  }

  final class StringTypeAdapter
    implements JsonSerializer<String>, JsonDeserializer<String>
  {
    public String deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      return paramJsonElement.getAsString();
    }

    public JsonElement serialize(String paramString, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      return new JsonPrimitive(paramString);
    }

    public String toString()
    {
      return StringTypeAdapter.class.getSimpleName();
    }
  }

  final class CharacterTypeAdapter
    implements JsonSerializer<Character>, JsonDeserializer<Character>
  {
    public Character deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      return Character.valueOf(paramJsonElement.getAsCharacter());
    }

    public JsonElement serialize(Character paramCharacter, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      return new JsonPrimitive(paramCharacter);
    }

    public String toString()
    {
      return CharacterTypeAdapter.class.getSimpleName();
    }
  }

  final class DoubleDeserializer
    implements JsonDeserializer<Double>
  {
    public Double deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      try
      {
        Double localDouble = Double.valueOf(paramJsonElement.getAsDouble());
        return localDouble;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        throw new JsonSyntaxException(localNumberFormatException);
      }
      catch (UnsupportedOperationException localUnsupportedOperationException)
      {
        throw new JsonSyntaxException(localUnsupportedOperationException);
      }
      catch (IllegalStateException localIllegalStateException)
      {
      }
      throw new JsonSyntaxException(localIllegalStateException);
    }

    public String toString()
    {
      return DoubleDeserializer.class.getSimpleName();
    }
  }

  final class DoubleSerializer
    implements JsonSerializer<Double>
  {
    private final boolean serializeSpecialFloatingPointValues;

    DoubleSerializer()
    {
      this.serializeSpecialFloatingPointValues = this$1;
    }

    public JsonElement serialize(Double paramDouble, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      if ((!this.serializeSpecialFloatingPointValues) && ((Double.isNaN(paramDouble.doubleValue())) || (Double.isInfinite(paramDouble.doubleValue()))))
      {
        String str = paramDouble + " is not a valid double value as per JSON specification. To override this" + " behavior, use GsonBuilder.serializeSpecialDoubleValues() method.";
        throw new IllegalArgumentException(str);
      }
      return new JsonPrimitive(paramDouble);
    }
  }

  final class FloatDeserializer
    implements JsonDeserializer<Float>
  {
    public Float deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      try
      {
        Float localFloat = Float.valueOf(paramJsonElement.getAsFloat());
        return localFloat;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        throw new JsonSyntaxException(localNumberFormatException);
      }
      catch (UnsupportedOperationException localUnsupportedOperationException)
      {
        throw new JsonSyntaxException(localUnsupportedOperationException);
      }
      catch (IllegalStateException localIllegalStateException)
      {
      }
      throw new JsonSyntaxException(localIllegalStateException);
    }

    public String toString()
    {
      return FloatDeserializer.class.getSimpleName();
    }
  }

  final class FloatSerializer
    implements JsonSerializer<Float>
  {
    private final boolean serializeSpecialFloatingPointValues;

    FloatSerializer()
    {
      this.serializeSpecialFloatingPointValues = this$1;
    }

    public JsonElement serialize(Float paramFloat, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      if ((!this.serializeSpecialFloatingPointValues) && ((Float.isNaN(paramFloat.floatValue())) || (Float.isInfinite(paramFloat.floatValue()))))
      {
        String str = paramFloat + " is not a valid float value as per JSON specification. To override this" + " behavior, use GsonBuilder.serializeSpecialFloatingPointValues() method.";
        throw new IllegalArgumentException(str);
      }
      return new JsonPrimitive(paramFloat);
    }
  }

  final class ByteTypeAdapter
    implements JsonSerializer<Byte>, JsonDeserializer<Byte>
  {
    public Byte deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      try
      {
        Byte localByte = Byte.valueOf(paramJsonElement.getAsByte());
        return localByte;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        throw new JsonSyntaxException(localNumberFormatException);
      }
      catch (UnsupportedOperationException localUnsupportedOperationException)
      {
        throw new JsonSyntaxException(localUnsupportedOperationException);
      }
      catch (IllegalStateException localIllegalStateException)
      {
      }
      throw new JsonSyntaxException(localIllegalStateException);
    }

    public JsonElement serialize(Byte paramByte, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      return new JsonPrimitive(paramByte);
    }

    public String toString()
    {
      return ByteTypeAdapter.class.getSimpleName();
    }
  }

  final class ShortTypeAdapter
    implements JsonSerializer<Short>, JsonDeserializer<Short>
  {
    public Short deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      try
      {
        Short localShort = Short.valueOf(paramJsonElement.getAsShort());
        return localShort;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        throw new JsonSyntaxException(localNumberFormatException);
      }
      catch (UnsupportedOperationException localUnsupportedOperationException)
      {
        throw new JsonSyntaxException(localUnsupportedOperationException);
      }
      catch (IllegalStateException localIllegalStateException)
      {
      }
      throw new JsonSyntaxException(localIllegalStateException);
    }

    public JsonElement serialize(Short paramShort, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      return new JsonPrimitive(paramShort);
    }

    public String toString()
    {
      return ShortTypeAdapter.class.getSimpleName();
    }
  }

  final class IntegerTypeAdapter
    implements JsonSerializer<Integer>, JsonDeserializer<Integer>
  {
    public Integer deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      try
      {
        Integer localInteger = Integer.valueOf(paramJsonElement.getAsInt());
        return localInteger;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        throw new JsonSyntaxException(localNumberFormatException);
      }
      catch (UnsupportedOperationException localUnsupportedOperationException)
      {
        throw new JsonSyntaxException(localUnsupportedOperationException);
      }
      catch (IllegalStateException localIllegalStateException)
      {
      }
      throw new JsonSyntaxException(localIllegalStateException);
    }

    public JsonElement serialize(Integer paramInteger, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      return new JsonPrimitive(paramInteger);
    }

    public String toString()
    {
      return IntegerTypeAdapter.class.getSimpleName();
    }
  }

  final class LongDeserializer
    implements JsonDeserializer<Long>
  {
    public Long deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      try
      {
        Long localLong = Long.valueOf(paramJsonElement.getAsLong());
        return localLong;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        throw new JsonSyntaxException(localNumberFormatException);
      }
      catch (UnsupportedOperationException localUnsupportedOperationException)
      {
        throw new JsonSyntaxException(localUnsupportedOperationException);
      }
      catch (IllegalStateException localIllegalStateException)
      {
      }
      throw new JsonSyntaxException(localIllegalStateException);
    }

    public String toString()
    {
      return LongDeserializer.class.getSimpleName();
    }
  }

  final class LongSerializer
    implements JsonSerializer<Long>
  {
    private LongSerializer()
    {
    }

    public JsonElement serialize(Long paramLong, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      return DefaultTypeAdapters.this.serialize(paramLong);
    }

    public String toString()
    {
      return LongSerializer.class.getSimpleName();
    }
  }

  final class NumberTypeAdapter
    implements JsonSerializer<Number>, JsonDeserializer<Number>
  {
    public Number deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      try
      {
        Number localNumber = paramJsonElement.getAsNumber();
        return localNumber;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        throw new JsonSyntaxException(localNumberFormatException);
      }
      catch (UnsupportedOperationException localUnsupportedOperationException)
      {
        throw new JsonSyntaxException(localUnsupportedOperationException);
      }
      catch (IllegalStateException localIllegalStateException)
      {
      }
      throw new JsonSyntaxException(localIllegalStateException);
    }

    public JsonElement serialize(Number paramNumber, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      return new JsonPrimitive(paramNumber);
    }

    public String toString()
    {
      return NumberTypeAdapter.class.getSimpleName();
    }
  }

  final class BigIntegerTypeAdapter
    implements JsonSerializer<BigInteger>, JsonDeserializer<BigInteger>
  {
    public BigInteger deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      try
      {
        BigInteger localBigInteger = paramJsonElement.getAsBigInteger();
        return localBigInteger;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        throw new JsonSyntaxException(localNumberFormatException);
      }
      catch (UnsupportedOperationException localUnsupportedOperationException)
      {
        throw new JsonSyntaxException(localUnsupportedOperationException);
      }
      catch (IllegalStateException localIllegalStateException)
      {
      }
      throw new JsonSyntaxException(localIllegalStateException);
    }

    public JsonElement serialize(BigInteger paramBigInteger, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      return new JsonPrimitive(paramBigInteger);
    }

    public String toString()
    {
      return BigIntegerTypeAdapter.class.getSimpleName();
    }
  }

  final class BigDecimalTypeAdapter
    implements JsonSerializer<BigDecimal>, JsonDeserializer<BigDecimal>
  {
    public BigDecimal deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      try
      {
        BigDecimal localBigDecimal = paramJsonElement.getAsBigDecimal();
        return localBigDecimal;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        throw new JsonSyntaxException(localNumberFormatException);
      }
      catch (UnsupportedOperationException localUnsupportedOperationException)
      {
        throw new JsonSyntaxException(localUnsupportedOperationException);
      }
      catch (IllegalStateException localIllegalStateException)
      {
      }
      throw new JsonSyntaxException(localIllegalStateException);
    }

    public JsonElement serialize(BigDecimal paramBigDecimal, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      return new JsonPrimitive(paramBigDecimal);
    }

    public String toString()
    {
      return BigDecimalTypeAdapter.class.getSimpleName();
    }
  }

  final class CollectionTypeAdapter
    implements JsonSerializer<Collection>, JsonDeserializer<Collection>
  {
    private Collection constructCollectionType(Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
    {
      return (Collection)((JsonDeserializationContextDefault)paramJsonDeserializationContext).getObjectConstructor().construct(paramType);
    }

    public Collection deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      Collection localCollection;
      if (paramJsonElement.isJsonNull())
        localCollection = null;
      while (true)
      {
        return localCollection;
        localCollection = constructCollectionType(paramType, paramJsonDeserializationContext);
        Class localClass = .Gson.Types.getRawType(paramType);
        Type localType = .Gson.Types.getCollectionElementType(paramType, localClass);
        Iterator localIterator = paramJsonElement.getAsJsonArray().iterator();
        while (localIterator.hasNext())
        {
          JsonElement localJsonElement = (JsonElement)localIterator.next();
          if ((localJsonElement == null) || (localJsonElement.isJsonNull()))
          {
            boolean bool1 = localCollection.add(null);
            continue;
          }
          Object localObject = paramJsonDeserializationContext.deserialize(localJsonElement, localType);
          boolean bool2 = localCollection.add(localObject);
        }
      }
    }

    public JsonElement serialize(Collection paramCollection, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      if (paramCollection == null)
      {
        localObject1 = JsonNull.createJsonNull();
        return localObject1;
      }
      Object localObject1 = new JsonArray();
      Type localType = null;
      if ((paramType instanceof ParameterizedType))
      {
        Class localClass = .Gson.Types.getRawType(paramType);
        localType = .Gson.Types.getCollectionElementType(paramType, localClass);
      }
      Iterator localIterator = paramCollection.iterator();
      label53: Object localObject2;
      while (localIterator.hasNext())
      {
        localObject2 = localIterator.next();
        if (localObject2 == null)
        {
          JsonNull localJsonNull = JsonNull.createJsonNull();
          ((JsonArray)localObject1).add(localJsonNull);
          continue;
        }
        if ((localType != null) && (localType != Object.class))
          break label133;
      }
      label133: for (Object localObject3 = localObject2.getClass(); ; localObject3 = localType)
      {
        JsonElement localJsonElement = paramJsonSerializationContext.serialize(localObject2, (Type)localObject3);
        ((JsonArray)localObject1).add(localJsonElement);
        break label53;
        break;
      }
    }
  }

  final class LocaleTypeAdapter
    implements JsonSerializer<Locale>, JsonDeserializer<Locale>
  {
    public Locale deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      String str1 = paramJsonElement.getAsString();
      StringTokenizer localStringTokenizer = new StringTokenizer(str1, "_");
      String str2 = null;
      String str3 = null;
      String str4 = null;
      if (localStringTokenizer.hasMoreElements())
        str2 = localStringTokenizer.nextToken();
      if (localStringTokenizer.hasMoreElements())
        str3 = localStringTokenizer.nextToken();
      if (localStringTokenizer.hasMoreElements())
        str4 = localStringTokenizer.nextToken();
      Locale localLocale;
      if ((str3 == null) && (str4 == null))
        localLocale = new Locale(str2);
      while (true)
      {
        return localLocale;
        if (str4 == null)
        {
          localLocale = new Locale(str2, str3);
          continue;
        }
        localLocale = new Locale(str2, str3, str4);
      }
    }

    public JsonElement serialize(Locale paramLocale, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      String str = paramLocale.toString();
      return new JsonPrimitive(str);
    }

    public String toString()
    {
      return LocaleTypeAdapter.class.getSimpleName();
    }
  }

  final class UuidTypeAdapter
    implements JsonSerializer<UUID>, JsonDeserializer<UUID>
  {
    public UUID deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      return UUID.fromString(paramJsonElement.getAsString());
    }

    public JsonElement serialize(UUID paramUUID, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      String str = paramUUID.toString();
      return new JsonPrimitive(str);
    }

    public String toString()
    {
      return UuidTypeAdapter.class.getSimpleName();
    }
  }

  final class UriTypeAdapter
    implements JsonSerializer<URI>, JsonDeserializer<URI>
  {
    public URI deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      try
      {
        String str = paramJsonElement.getAsString();
        URI localURI = new URI(str);
        return localURI;
      }
      catch (URISyntaxException localURISyntaxException)
      {
      }
      throw new JsonSyntaxException(localURISyntaxException);
    }

    public JsonElement serialize(URI paramURI, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      String str = paramURI.toASCIIString();
      return new JsonPrimitive(str);
    }

    public String toString()
    {
      return UriTypeAdapter.class.getSimpleName();
    }
  }

  final class UrlTypeAdapter
    implements JsonSerializer<URL>, JsonDeserializer<URL>
  {
    public URL deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      try
      {
        String str = paramJsonElement.getAsString();
        URL localURL = new URL(str);
        return localURL;
      }
      catch (MalformedURLException localMalformedURLException)
      {
      }
      throw new JsonSyntaxException(localMalformedURLException);
    }

    public JsonElement serialize(URL paramURL, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      String str = paramURL.toExternalForm();
      return new JsonPrimitive(str);
    }

    public String toString()
    {
      return UrlTypeAdapter.class.getSimpleName();
    }
  }

  final class EnumTypeAdapter<T extends Enum<T>>
    implements JsonSerializer<T>, JsonDeserializer<T>
  {
    public T deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      Class localClass = (Class)paramType;
      String str = paramJsonElement.getAsString();
      return Enum.valueOf(localClass, str);
    }

    public JsonElement serialize(T paramT, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      String str = paramT.name();
      return new JsonPrimitive(str);
    }

    public String toString()
    {
      return EnumTypeAdapter.class.getSimpleName();
    }
  }

  final class DefaultInetAddressAdapter
    implements JsonDeserializer<InetAddress>, JsonSerializer<InetAddress>
  {
    public InetAddress deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      try
      {
        InetAddress localInetAddress = InetAddress.getByName(paramJsonElement.getAsString());
        return localInetAddress;
      }
      catch (UnknownHostException localUnknownHostException)
      {
      }
      throw new JsonParseException(localUnknownHostException);
    }

    public JsonElement serialize(InetAddress paramInetAddress, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      String str = paramInetAddress.getHostAddress();
      return new JsonPrimitive(str);
    }
  }

  final class GregorianCalendarTypeAdapter
    implements JsonSerializer<GregorianCalendar>, JsonDeserializer<GregorianCalendar>
  {
    private static final String DAY_OF_MONTH = "dayOfMonth";
    private static final String HOUR_OF_DAY = "hourOfDay";
    private static final String MINUTE = "minute";
    private static final String MONTH = "month";
    private static final String SECOND = "second";
    private static final String YEAR = "year";

    public GregorianCalendar deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      JsonObject localJsonObject = paramJsonElement.getAsJsonObject();
      int i = localJsonObject.get("year").getAsInt();
      int j = localJsonObject.get("month").getAsInt();
      int k = localJsonObject.get("dayOfMonth").getAsInt();
      int m = localJsonObject.get("hourOfDay").getAsInt();
      int n = localJsonObject.get("minute").getAsInt();
      int i1 = localJsonObject.get("second").getAsInt();
      return new GregorianCalendar(i, j, k, m, n, i1);
    }

    public JsonElement serialize(GregorianCalendar paramGregorianCalendar, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      JsonObject localJsonObject = new JsonObject();
      Integer localInteger1 = Integer.valueOf(paramGregorianCalendar.get(1));
      localJsonObject.addProperty("year", localInteger1);
      Integer localInteger2 = Integer.valueOf(paramGregorianCalendar.get(2));
      localJsonObject.addProperty("month", localInteger2);
      Integer localInteger3 = Integer.valueOf(paramGregorianCalendar.get(5));
      localJsonObject.addProperty("dayOfMonth", localInteger3);
      Integer localInteger4 = Integer.valueOf(paramGregorianCalendar.get(11));
      localJsonObject.addProperty("hourOfDay", localInteger4);
      Integer localInteger5 = Integer.valueOf(paramGregorianCalendar.get(12));
      localJsonObject.addProperty("minute", localInteger5);
      Integer localInteger6 = Integer.valueOf(paramGregorianCalendar.get(13));
      localJsonObject.addProperty("second", localInteger6);
      return localJsonObject;
    }

    public String toString()
    {
      return GregorianCalendarTypeAdapter.class.getSimpleName();
    }
  }

  final class DefaultTimeTypeAdapter
    implements JsonSerializer<Time>, JsonDeserializer<Time>
  {
    private final DateFormat format;

    DefaultTimeTypeAdapter()
    {
      this$1 = new SimpleDateFormat("hh:mm:ss a");
      this.format = this$1;
    }

    public Time deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      if (!(paramJsonElement instanceof JsonPrimitive))
        throw new JsonParseException("The date should be a string value");
      try
      {
        synchronized (this.format)
        {
          DateFormat localDateFormat2 = this.format;
          String str = paramJsonElement.getAsString();
          long l = localDateFormat2.parse(str).getTime();
          Time localTime = new Time(l);
          return localTime;
        }
      }
      catch (ParseException localParseException)
      {
      }
      throw new JsonSyntaxException(localParseException);
    }

    public JsonElement serialize(Time paramTime, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      synchronized (this.format)
      {
        String str = this.format.format(paramTime);
        JsonPrimitive localJsonPrimitive = new JsonPrimitive(str);
        return localJsonPrimitive;
      }
    }
  }

  final class DefaultTimestampDeserializer
    implements JsonDeserializer<Timestamp>
  {
    public Timestamp deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      long l = ((java.util.Date)paramJsonDeserializationContext.deserialize(paramJsonElement, java.util.Date.class)).getTime();
      return new Timestamp(l);
    }
  }

  final class DefaultJavaSqlDateTypeAdapter
    implements JsonSerializer<java.sql.Date>, JsonDeserializer<java.sql.Date>
  {
    private final DateFormat format;

    DefaultJavaSqlDateTypeAdapter()
    {
      this$1 = new SimpleDateFormat("MMM d, yyyy");
      this.format = this$1;
    }

    public java.sql.Date deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      if (!(paramJsonElement instanceof JsonPrimitive))
        throw new JsonParseException("The date should be a string value");
      try
      {
        synchronized (this.format)
        {
          DateFormat localDateFormat2 = this.format;
          String str = paramJsonElement.getAsString();
          long l = localDateFormat2.parse(str).getTime();
          java.sql.Date localDate = new java.sql.Date(l);
          return localDate;
        }
      }
      catch (ParseException localParseException)
      {
      }
      throw new JsonSyntaxException(localParseException);
    }

    public JsonElement serialize(java.sql.Date paramDate, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      synchronized (this.format)
      {
        String str = this.format.format(paramDate);
        JsonPrimitive localJsonPrimitive = new JsonPrimitive(str);
        return localJsonPrimitive;
      }
    }
  }

  final class DefaultDateTypeAdapter
    implements JsonSerializer<java.util.Date>, JsonDeserializer<java.util.Date>
  {
    private final DateFormat iso8601Format;
    private final DateFormat localFormat;

    DefaultDateTypeAdapter()
    {
      this(localDateFormat2);
    }

    DefaultDateTypeAdapter()
    {
      this(localDateFormat2);
    }

    public DefaultDateTypeAdapter(int arg2)
    {
      this(localDateFormat2);
    }

    DefaultDateTypeAdapter()
    {
      this(localSimpleDateFormat2);
    }

    DefaultDateTypeAdapter(DateFormat arg2)
    {
      Object localObject;
      this.localFormat = localObject;
      Locale localLocale = Locale.US;
      SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", localLocale);
      this.iso8601Format = localSimpleDateFormat;
      DateFormat localDateFormat = this.iso8601Format;
      TimeZone localTimeZone = TimeZone.getTimeZone("UTC");
      localDateFormat.setTimeZone(localTimeZone);
    }

    private java.util.Date deserializeToDate(JsonElement paramJsonElement)
    {
      String str4;
      while (true)
      {
        java.util.Date localDate1;
        java.util.Date localDate2;
        synchronized (this.localFormat)
        {
          try
          {
            DateFormat localDateFormat2 = this.localFormat;
            String str1 = paramJsonElement.getAsString();
            localDate1 = localDateFormat2.parse(str1);
            localDate2 = localDate1;
            return localDate2;
          }
          catch (ParseException localParseException1)
          {
          }
        }
        try
        {
          DateFormat localDateFormat3 = DefaultTypeAdapters.this;
          String str2 = paramJsonElement.getAsString();
          localDate1 = localDateFormat3.parse(str2);
          localDate2 = localDate1;
          monitorexit;
          continue;
          localObject = finally;
          monitorexit;
          throw localObject;
        }
        catch (ParseException localParseException2)
        {
          try
          {
            DateFormat localDateFormat4 = this.iso8601Format;
            String str3 = paramJsonElement.getAsString();
            localDate1 = localDateFormat4.parse(str3);
            localDate2 = localDate1;
            monitorexit;
          }
          catch (ParseException localParseException3)
          {
            str4 = paramJsonElement.getAsString();
          }
        }
      }
      throw new JsonSyntaxException(str4, localParseException3);
    }

    public java.util.Date deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
      throws JsonParseException
    {
      if (!(paramJsonElement instanceof JsonPrimitive))
        throw new JsonParseException("The date should be a string value");
      Object localObject = deserializeToDate(paramJsonElement);
      if (paramType == java.util.Date.class);
      while (true)
      {
        return localObject;
        if (paramType == Timestamp.class)
        {
          long l1 = ((java.util.Date)localObject).getTime();
          localObject = new Timestamp(l1);
          continue;
        }
        if (paramType != java.sql.Date.class)
          break;
        long l2 = ((java.util.Date)localObject).getTime();
        localObject = new java.sql.Date(l2);
      }
      StringBuilder localStringBuilder = new StringBuilder();
      Class localClass = getClass();
      String str = localClass + " cannot deserialize to " + paramType;
      throw new IllegalArgumentException(str);
    }

    public JsonElement serialize(java.util.Date paramDate, Type paramType, JsonSerializationContext paramJsonSerializationContext)
    {
      synchronized (this.localFormat)
      {
        String str = DefaultTypeAdapters.this.format(paramDate);
        JsonPrimitive localJsonPrimitive = new JsonPrimitive(str);
        return localJsonPrimitive;
      }
    }

    public String toString()
    {
      StringBuilder localStringBuilder1 = new StringBuilder();
      String str1 = DefaultDateTypeAdapter.class.getSimpleName();
      StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
      StringBuilder localStringBuilder3 = localStringBuilder1.append(40);
      String str2 = this.localFormat.getClass().getSimpleName();
      StringBuilder localStringBuilder4 = localStringBuilder3.append(str2).append(41);
      return localStringBuilder1.toString();
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.DefaultTypeAdapters
 * JD-Core Version:    0.6.0
 */