package com.google.gson;

public enum FieldNamingPolicy
{
  private final FieldNamingStrategy2 namingPolicy;

  static
  {
    ModifyFirstLetterNamingPolicy.LetterModifier localLetterModifier = ModifyFirstLetterNamingPolicy.LetterModifier.UPPER;
    ModifyFirstLetterNamingPolicy localModifyFirstLetterNamingPolicy = new ModifyFirstLetterNamingPolicy(localLetterModifier);
    UPPER_CAMEL_CASE = new FieldNamingPolicy("UPPER_CAMEL_CASE", 0, localModifyFirstLetterNamingPolicy);
    UpperCamelCaseSeparatorNamingPolicy localUpperCamelCaseSeparatorNamingPolicy = new UpperCamelCaseSeparatorNamingPolicy(" ");
    UPPER_CAMEL_CASE_WITH_SPACES = new FieldNamingPolicy("UPPER_CAMEL_CASE_WITH_SPACES", 1, localUpperCamelCaseSeparatorNamingPolicy);
    LowerCamelCaseSeparatorNamingPolicy localLowerCamelCaseSeparatorNamingPolicy1 = new LowerCamelCaseSeparatorNamingPolicy("_");
    LOWER_CASE_WITH_UNDERSCORES = new FieldNamingPolicy("LOWER_CASE_WITH_UNDERSCORES", 2, localLowerCamelCaseSeparatorNamingPolicy1);
    LowerCamelCaseSeparatorNamingPolicy localLowerCamelCaseSeparatorNamingPolicy2 = new LowerCamelCaseSeparatorNamingPolicy("-");
    LOWER_CASE_WITH_DASHES = new FieldNamingPolicy("LOWER_CASE_WITH_DASHES", 3, localLowerCamelCaseSeparatorNamingPolicy2);
    FieldNamingPolicy[] arrayOfFieldNamingPolicy = new FieldNamingPolicy[4];
    FieldNamingPolicy localFieldNamingPolicy1 = UPPER_CAMEL_CASE;
    arrayOfFieldNamingPolicy[0] = localFieldNamingPolicy1;
    FieldNamingPolicy localFieldNamingPolicy2 = UPPER_CAMEL_CASE_WITH_SPACES;
    arrayOfFieldNamingPolicy[1] = localFieldNamingPolicy2;
    FieldNamingPolicy localFieldNamingPolicy3 = LOWER_CASE_WITH_UNDERSCORES;
    arrayOfFieldNamingPolicy[2] = localFieldNamingPolicy3;
    FieldNamingPolicy localFieldNamingPolicy4 = LOWER_CASE_WITH_DASHES;
    arrayOfFieldNamingPolicy[3] = localFieldNamingPolicy4;
    $VALUES = arrayOfFieldNamingPolicy;
  }

  private FieldNamingPolicy(FieldNamingStrategy2 paramFieldNamingStrategy2)
  {
    this.namingPolicy = paramFieldNamingStrategy2;
  }

  FieldNamingStrategy2 getFieldNamingPolicy()
  {
    return this.namingPolicy;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.FieldNamingPolicy
 * JD-Core Version:    0.6.0
 */