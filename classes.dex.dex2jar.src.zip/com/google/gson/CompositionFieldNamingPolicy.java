package com.google.gson;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.Collection;

abstract class CompositionFieldNamingPolicy extends RecursiveFieldNamingPolicy
{
  private final RecursiveFieldNamingPolicy[] fieldPolicies;

  public CompositionFieldNamingPolicy(RecursiveFieldNamingPolicy[] paramArrayOfRecursiveFieldNamingPolicy)
  {
    if (paramArrayOfRecursiveFieldNamingPolicy == null)
      throw new NullPointerException("naming policies can not be null.");
    this.fieldPolicies = paramArrayOfRecursiveFieldNamingPolicy;
  }

  protected String translateName(String paramString, Type paramType, Collection<Annotation> paramCollection)
  {
    RecursiveFieldNamingPolicy[] arrayOfRecursiveFieldNamingPolicy = this.fieldPolicies;
    int i = arrayOfRecursiveFieldNamingPolicy.length;
    int j = 0;
    while (j < i)
    {
      paramString = arrayOfRecursiveFieldNamingPolicy[j].translateName(paramString, paramType, paramCollection);
      j += 1;
    }
    return paramString;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.CompositionFieldNamingPolicy
 * JD-Core Version:    0.6.0
 */