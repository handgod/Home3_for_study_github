package com.google.gson;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

final class ModifierBasedExclusionStrategy
  implements ExclusionStrategy
{
  private final Collection<Integer> modifiers;

  public ModifierBasedExclusionStrategy(int[] paramArrayOfInt)
  {
    HashSet localHashSet = new HashSet();
    this.modifiers = localHashSet;
    if (paramArrayOfInt != null)
    {
      int[] arrayOfInt = paramArrayOfInt;
      int i = arrayOfInt.length;
      int j = 0;
      while (j < i)
      {
        int k = arrayOfInt[j];
        Collection localCollection = this.modifiers;
        Integer localInteger = Integer.valueOf(k);
        boolean bool = localCollection.add(localInteger);
        j += 1;
      }
    }
  }

  public boolean shouldSkipClass(Class<?> paramClass)
  {
    return false;
  }

  public boolean shouldSkipField(FieldAttributes paramFieldAttributes)
  {
    Iterator localIterator = this.modifiers.iterator();
    int i;
    do
    {
      if (!localIterator.hasNext())
        break;
      i = ((Integer)localIterator.next()).intValue();
    }
    while (!paramFieldAttributes.hasModifier(i));
    for (int j = 1; ; j = 0)
      return j;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.ModifierBasedExclusionStrategy
 * JD-Core Version:    0.6.0
 */