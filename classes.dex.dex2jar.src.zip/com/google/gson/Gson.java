package com.google.gson;

import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import com.google.gson.stream.MalformedJsonException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Type;
import java.util.LinkedList;
import java.util.List;

public final class Gson
{
  static final AnonymousAndLocalClassExclusionStrategy DEFAULT_ANON_LOCAL_CLASS_EXCLUSION_STRATEGY = ;
  private static final ExclusionStrategy DEFAULT_EXCLUSION_STRATEGY = ;
  static final boolean DEFAULT_JSON_NON_EXECUTABLE = false;
  static final ModifierBasedExclusionStrategy DEFAULT_MODIFIER_BASED_EXCLUSION_STRATEGY = ;
  static final FieldNamingStrategy2 DEFAULT_NAMING_POLICY = ;
  static final SyntheticFieldExclusionStrategy DEFAULT_SYNTHETIC_FIELD_EXCLUSION_STRATEGY = ;
  private static final String JSON_NON_EXECUTABLE_PREFIX = ")]}'\n";
  private final ExclusionStrategy deserializationExclusionStrategy;
  private final ParameterizedTypeHandlerMap<JsonDeserializer<?>> deserializers;
  private final FieldNamingStrategy2 fieldNamingPolicy;
  private final boolean generateNonExecutableJson;
  private final boolean htmlSafe;
  private final MappedObjectConstructor objectConstructor;
  private final boolean prettyPrinting;
  private final ExclusionStrategy serializationExclusionStrategy;
  private final boolean serializeNulls;
  private final ParameterizedTypeHandlerMap<JsonSerializer<?>> serializers;

  static
  {
    int[] arrayOfInt = { 128, 8 };
    DEFAULT_MODIFIER_BASED_EXCLUSION_STRATEGY = new ModifierBasedExclusionStrategy(arrayOfInt);
    JavaFieldNamingPolicy localJavaFieldNamingPolicy = new JavaFieldNamingPolicy();
    DEFAULT_NAMING_POLICY = new SerializedNameAnnotationInterceptingNamingPolicy(localJavaFieldNamingPolicy);
    DEFAULT_EXCLUSION_STRATEGY = createExclusionStrategy();
  }

  public Gson()
  {
  }

  Gson(ExclusionStrategy paramExclusionStrategy1, ExclusionStrategy paramExclusionStrategy2, FieldNamingStrategy2 paramFieldNamingStrategy2, MappedObjectConstructor paramMappedObjectConstructor, boolean paramBoolean1, ParameterizedTypeHandlerMap<JsonSerializer<?>> paramParameterizedTypeHandlerMap, ParameterizedTypeHandlerMap<JsonDeserializer<?>> paramParameterizedTypeHandlerMap1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
  {
    this.deserializationExclusionStrategy = paramExclusionStrategy1;
    this.serializationExclusionStrategy = paramExclusionStrategy2;
    this.fieldNamingPolicy = paramFieldNamingStrategy2;
    this.objectConstructor = paramMappedObjectConstructor;
    this.serializeNulls = paramBoolean1;
    this.serializers = paramParameterizedTypeHandlerMap;
    this.deserializers = paramParameterizedTypeHandlerMap1;
    this.generateNonExecutableJson = paramBoolean2;
    this.htmlSafe = paramBoolean3;
    this.prettyPrinting = paramBoolean4;
  }

  private static void assertFullConsumption(Object paramObject, JsonReader paramJsonReader)
  {
    if (paramObject != null)
      try
      {
        JsonToken localJsonToken1 = paramJsonReader.peek();
        JsonToken localJsonToken2 = JsonToken.END_DOCUMENT;
        if (localJsonToken1 != localJsonToken2)
          throw new JsonIOException("JSON document was not fully consumed.");
      }
      catch (MalformedJsonException localMalformedJsonException)
      {
        throw new JsonSyntaxException(localMalformedJsonException);
      }
      catch (IOException localIOException)
      {
        throw new JsonIOException(localIOException);
      }
  }

  private static ExclusionStrategy createExclusionStrategy()
  {
    LinkedList localLinkedList = new LinkedList();
    AnonymousAndLocalClassExclusionStrategy localAnonymousAndLocalClassExclusionStrategy = DEFAULT_ANON_LOCAL_CLASS_EXCLUSION_STRATEGY;
    boolean bool1 = localLinkedList.add(localAnonymousAndLocalClassExclusionStrategy);
    SyntheticFieldExclusionStrategy localSyntheticFieldExclusionStrategy = DEFAULT_SYNTHETIC_FIELD_EXCLUSION_STRATEGY;
    boolean bool2 = localLinkedList.add(localSyntheticFieldExclusionStrategy);
    ModifierBasedExclusionStrategy localModifierBasedExclusionStrategy = DEFAULT_MODIFIER_BASED_EXCLUSION_STRATEGY;
    boolean bool3 = localLinkedList.add(localModifierBasedExclusionStrategy);
    return new DisjunctionExclusionStrategy(localLinkedList);
  }

  public <T> T fromJson(JsonElement paramJsonElement, Class<T> paramClass)
    throws JsonSyntaxException
  {
    Object localObject = fromJson(paramJsonElement, paramClass);
    return Primitives.wrap(paramClass).cast(localObject);
  }

  public <T> T fromJson(JsonElement paramJsonElement, Type paramType)
    throws JsonSyntaxException
  {
    if (paramJsonElement == null);
    ObjectNavigator localObjectNavigator;
    FieldNamingStrategy2 localFieldNamingStrategy2;
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap;
    MappedObjectConstructor localMappedObjectConstructor;
    for (Object localObject = null; ; localObject = new JsonDeserializationContextDefault(localObjectNavigator, localFieldNamingStrategy2, localParameterizedTypeHandlerMap, localMappedObjectConstructor).deserialize(paramJsonElement, paramType))
    {
      return localObject;
      ExclusionStrategy localExclusionStrategy = this.deserializationExclusionStrategy;
      localObjectNavigator = new ObjectNavigator(localExclusionStrategy);
      localFieldNamingStrategy2 = this.fieldNamingPolicy;
      localParameterizedTypeHandlerMap = this.deserializers;
      localMappedObjectConstructor = this.objectConstructor;
    }
  }

  public <T> T fromJson(JsonReader paramJsonReader, Type paramType)
    throws JsonIOException, JsonSyntaxException
  {
    boolean bool = paramJsonReader.isLenient();
    paramJsonReader.setLenient(1);
    try
    {
      JsonElement localJsonElement = Streams.parse(paramJsonReader);
      Object localObject1 = fromJson(localJsonElement, paramType);
      Object localObject2 = localObject1;
      return localObject2;
    }
    finally
    {
      paramJsonReader.setLenient(bool);
    }
    throw localObject3;
  }

  public <T> T fromJson(Reader paramReader, Class<T> paramClass)
    throws JsonSyntaxException, JsonIOException
  {
    JsonReader localJsonReader = new JsonReader(paramReader);
    Object localObject = fromJson(localJsonReader, paramClass);
    assertFullConsumption(localObject, localJsonReader);
    return Primitives.wrap(paramClass).cast(localObject);
  }

  public <T> T fromJson(Reader paramReader, Type paramType)
    throws JsonIOException, JsonSyntaxException
  {
    JsonReader localJsonReader = new JsonReader(paramReader);
    Object localObject = fromJson(localJsonReader, paramType);
    assertFullConsumption(localObject, localJsonReader);
    return localObject;
  }

  public <T> T fromJson(String paramString, Class<T> paramClass)
    throws JsonSyntaxException
  {
    Object localObject = fromJson(paramString, paramClass);
    return Primitives.wrap(paramClass).cast(localObject);
  }

  public <T> T fromJson(String paramString, Type paramType)
    throws JsonSyntaxException
  {
    if (paramString == null);
    StringReader localStringReader;
    for (Object localObject = null; ; localObject = fromJson(localStringReader, paramType))
    {
      return localObject;
      localStringReader = new StringReader(paramString);
    }
  }

  public String toJson(JsonElement paramJsonElement)
  {
    StringWriter localStringWriter = new StringWriter();
    toJson(paramJsonElement, localStringWriter);
    return localStringWriter.toString();
  }

  public String toJson(Object paramObject)
  {
    JsonNull localJsonNull;
    if (paramObject == null)
      localJsonNull = JsonNull.createJsonNull();
    Class localClass;
    for (String str = toJson(localJsonNull); ; str = toJson(paramObject, localClass))
    {
      return str;
      localClass = paramObject.getClass();
    }
  }

  public String toJson(Object paramObject, Type paramType)
  {
    StringWriter localStringWriter = new StringWriter();
    JsonElement localJsonElement = toJsonTree(paramObject, paramType);
    toJson(localJsonElement, localStringWriter);
    return localStringWriter.toString();
  }

  public void toJson(JsonElement paramJsonElement, JsonWriter paramJsonWriter)
    throws JsonIOException
  {
    boolean bool1 = paramJsonWriter.isLenient();
    paramJsonWriter.setLenient(1);
    boolean bool2 = paramJsonWriter.isHtmlSafe();
    boolean bool3 = this.htmlSafe;
    paramJsonWriter.setHtmlSafe(bool3);
    try
    {
      boolean bool4 = this.serializeNulls;
      Streams.write(paramJsonElement, bool4, paramJsonWriter);
      return;
    }
    catch (IOException localIOException)
    {
      throw new JsonIOException(localIOException);
    }
    finally
    {
      paramJsonWriter.setLenient(bool1);
      paramJsonWriter.setHtmlSafe(bool2);
    }
    throw localObject;
  }

  public void toJson(JsonElement paramJsonElement, Appendable paramAppendable)
    throws JsonIOException
  {
    try
    {
      if (this.generateNonExecutableJson)
        Appendable localAppendable = paramAppendable.append(")]}'\n");
      Writer localWriter = Streams.writerForAppendable(paramAppendable);
      JsonWriter localJsonWriter = new JsonWriter(localWriter);
      if (this.prettyPrinting)
        localJsonWriter.setIndent("  ");
      toJson(paramJsonElement, localJsonWriter);
      return;
    }
    catch (IOException localIOException)
    {
    }
    throw new RuntimeException(localIOException);
  }

  public void toJson(Object paramObject, Appendable paramAppendable)
    throws JsonIOException
  {
    if (paramObject != null)
    {
      Class localClass = paramObject.getClass();
      toJson(paramObject, localClass, paramAppendable);
    }
    while (true)
    {
      return;
      JsonNull localJsonNull = JsonNull.createJsonNull();
      toJson(localJsonNull, paramAppendable);
    }
  }

  public void toJson(Object paramObject, Type paramType, JsonWriter paramJsonWriter)
    throws JsonIOException
  {
    JsonElement localJsonElement = toJsonTree(paramObject, paramType);
    toJson(localJsonElement, paramJsonWriter);
  }

  public void toJson(Object paramObject, Type paramType, Appendable paramAppendable)
    throws JsonIOException
  {
    JsonElement localJsonElement = toJsonTree(paramObject, paramType);
    toJson(localJsonElement, paramAppendable);
  }

  public JsonElement toJsonTree(Object paramObject)
  {
    if (paramObject == null);
    Class localClass;
    for (Object localObject = JsonNull.createJsonNull(); ; localObject = toJsonTree(paramObject, localClass))
    {
      return localObject;
      localClass = paramObject.getClass();
    }
  }

  public JsonElement toJsonTree(Object paramObject, Type paramType)
  {
    ExclusionStrategy localExclusionStrategy = this.serializationExclusionStrategy;
    ObjectNavigator localObjectNavigator = new ObjectNavigator(localExclusionStrategy);
    FieldNamingStrategy2 localFieldNamingStrategy2 = this.fieldNamingPolicy;
    boolean bool = this.serializeNulls;
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap = this.serializers;
    return new JsonSerializationContextDefault(localObjectNavigator, localFieldNamingStrategy2, bool, localParameterizedTypeHandlerMap).serialize(paramObject, paramType);
  }

  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder("{").append("serializeNulls:");
    boolean bool = this.serializeNulls;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(bool).append(",serializers:");
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap1 = this.serializers;
    StringBuilder localStringBuilder3 = localStringBuilder2.append(localParameterizedTypeHandlerMap1).append(",deserializers:");
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap2 = this.deserializers;
    StringBuilder localStringBuilder4 = localStringBuilder3.append(localParameterizedTypeHandlerMap2).append(",instanceCreators:");
    MappedObjectConstructor localMappedObjectConstructor = this.objectConstructor;
    return localMappedObjectConstructor + "}";
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.Gson
 * JD-Core Version:    0.6.0
 */