package com.google.gson;

import com.google.gson.internal..Gson.Types;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

final class ParameterizedTypeHandlerMap<T>
{
  private static final Logger logger = Logger.getLogger(ParameterizedTypeHandlerMap.class.getName());
  private final Map<Type, T> map;
  private boolean modifiable;
  private final List<Pair<Class<?>, T>> typeHierarchyList;

  ParameterizedTypeHandlerMap()
  {
    HashMap localHashMap = new HashMap();
    this.map = localHashMap;
    ArrayList localArrayList = new ArrayList();
    this.typeHierarchyList = localArrayList;
    this.modifiable = 1;
  }

  private T getHandlerForTypeHierarchy(Class<?> paramClass)
  {
    Iterator localIterator = this.typeHierarchyList.iterator();
    Pair localPair;
    do
    {
      if (!localIterator.hasNext())
        break;
      localPair = (Pair)localIterator.next();
    }
    while (!((Class)localPair.first).isAssignableFrom(paramClass));
    for (Object localObject = localPair.second; ; localObject = null)
      return localObject;
  }

  private int getIndexOfAnOverriddenHandler(Class<?> paramClass)
  {
    int i = this.typeHierarchyList.size() + -1;
    if (i >= 0)
    {
      Class localClass = (Class)((Pair)this.typeHierarchyList.get(i)).first;
      if (!paramClass.isAssignableFrom(localClass));
    }
    while (true)
    {
      return i;
      i += -1;
      break;
      i = -1;
    }
  }

  /** @deprecated */
  private int getIndexOfSpecificHandlerForTypeHierarchy(Class<?> paramClass)
  {
    monitorenter;
    try
    {
      int i = this.typeHierarchyList.size() + -1;
      while (i >= 0)
      {
        Object localObject1 = ((Pair)this.typeHierarchyList.get(i)).first;
        boolean bool = paramClass.equals(localObject1);
        if (bool)
          return i;
        i += -1;
      }
      i = -1;
    }
    finally
    {
      monitorexit;
    }
  }

  private String typeToString(Type paramType)
  {
    return .Gson.Types.getRawType(paramType).getSimpleName();
  }

  /** @deprecated */
  public ParameterizedTypeHandlerMap<T> copyOf()
  {
    monitorenter;
    try
    {
      ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap = new ParameterizedTypeHandlerMap();
      Map localMap1 = localParameterizedTypeHandlerMap.map;
      Map localMap2 = this.map;
      localMap1.putAll(localMap2);
      List localList1 = localParameterizedTypeHandlerMap.typeHierarchyList;
      List localList2 = this.typeHierarchyList;
      boolean bool = localList1.addAll(localList2);
      monitorexit;
      return localParameterizedTypeHandlerMap;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  /** @deprecated */
  public T getHandlerFor(Type paramType)
  {
    monitorenter;
    try
    {
      Object localObject1 = this.map.get(paramType);
      if (localObject1 == null)
      {
        Class localClass = .Gson.Types.getRawType(paramType);
        if (localClass != paramType)
          localObject1 = getHandlerFor(localClass);
        if (localObject1 == null)
        {
          Object localObject2 = getHandlerForTypeHierarchy(localClass);
          localObject1 = localObject2;
        }
      }
      monitorexit;
      return localObject1;
    }
    finally
    {
      localObject3 = finally;
      monitorexit;
    }
    throw localObject3;
  }

  /** @deprecated */
  public boolean hasSpecificHandlerFor(Type paramType)
  {
    monitorenter;
    try
    {
      boolean bool1 = this.map.containsKey(paramType);
      boolean bool2 = bool1;
      monitorexit;
      return bool2;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  /** @deprecated */
  public void makeUnmodifiable()
  {
    monitorenter;
    try
    {
      this.modifiable = 0;
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  /** @deprecated */
  public void register(ParameterizedTypeHandlerMap<T> paramParameterizedTypeHandlerMap)
  {
    monitorenter;
    try
    {
      if (!this.modifiable)
        throw new IllegalStateException("Attempted to modify an unmodifiable map.");
    }
    finally
    {
      monitorexit;
    }
    Iterator localIterator = paramParameterizedTypeHandlerMap.map.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      Type localType = (Type)localEntry.getKey();
      Object localObject2 = localEntry.getValue();
      register(localType, localObject2);
    }
    int i = paramParameterizedTypeHandlerMap.typeHierarchyList.size() + -1;
    while (i >= 0)
    {
      Pair localPair = (Pair)paramParameterizedTypeHandlerMap.typeHierarchyList.get(i);
      registerForTypeHierarchy(localPair);
      i += -1;
    }
    monitorexit;
  }

  /** @deprecated */
  public void register(Type paramType, T paramT)
  {
    monitorenter;
    try
    {
      if (!this.modifiable)
        throw new IllegalStateException("Attempted to modify an unmodifiable map.");
    }
    finally
    {
      monitorexit;
    }
    if (hasSpecificHandlerFor(paramType))
    {
      Logger localLogger = logger;
      Level localLevel = Level.WARNING;
      localLogger.log(localLevel, "Overriding the existing type handler for {0}", paramType);
    }
    Object localObject2 = this.map.put(paramType, paramT);
    monitorexit;
  }

  /** @deprecated */
  public void registerForTypeHierarchy(Pair<Class<?>, T> paramPair)
  {
    monitorenter;
    try
    {
      if (!this.modifiable)
        throw new IllegalStateException("Attempted to modify an unmodifiable map.");
    }
    finally
    {
      monitorexit;
    }
    Class localClass1 = (Class)paramPair.first;
    int i = getIndexOfSpecificHandlerForTypeHierarchy(localClass1);
    if (i >= 0)
    {
      Logger localLogger = logger;
      Level localLevel = Level.WARNING;
      Object localObject2 = paramPair.first;
      localLogger.log(localLevel, "Overriding the existing type handler for {0}", localObject2);
      Object localObject3 = this.typeHierarchyList.remove(i);
    }
    Class localClass2 = (Class)paramPair.first;
    i = getIndexOfAnOverriddenHandler(localClass2);
    if (i >= 0)
    {
      StringBuilder localStringBuilder1 = new StringBuilder().append("The specified type handler for type ");
      Object localObject4 = paramPair.first;
      StringBuilder localStringBuilder2 = localStringBuilder1.append(localObject4).append(" hides the previously registered type hierarchy handler for ");
      Object localObject5 = ((Pair)this.typeHierarchyList.get(i)).first;
      String str = localObject5 + ". Gson does not allow this.";
      throw new IllegalArgumentException(str);
    }
    this.typeHierarchyList.add(0, paramPair);
    monitorexit;
  }

  /** @deprecated */
  public void registerForTypeHierarchy(Class<?> paramClass, T paramT)
  {
    monitorenter;
    try
    {
      Pair localPair = new Pair(paramClass, paramT);
      registerForTypeHierarchy(localPair);
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  /** @deprecated */
  public void registerIfAbsent(ParameterizedTypeHandlerMap<T> paramParameterizedTypeHandlerMap)
  {
    monitorenter;
    try
    {
      if (!this.modifiable)
        throw new IllegalStateException("Attempted to modify an unmodifiable map.");
    }
    finally
    {
      monitorexit;
    }
    Iterator localIterator = paramParameterizedTypeHandlerMap.map.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      Map localMap = this.map;
      Object localObject2 = localEntry.getKey();
      if (localMap.containsKey(localObject2))
        continue;
      Type localType = (Type)localEntry.getKey();
      Object localObject3 = localEntry.getValue();
      register(localType, localObject3);
    }
    int i = paramParameterizedTypeHandlerMap.typeHierarchyList.size() + -1;
    while (i >= 0)
    {
      Pair localPair = (Pair)paramParameterizedTypeHandlerMap.typeHierarchyList.get(i);
      Class localClass = (Class)localPair.first;
      if (getIndexOfSpecificHandlerForTypeHierarchy(localClass) < 0)
        registerForTypeHierarchy(localPair);
      i += -1;
    }
    monitorexit;
  }

  /** @deprecated */
  public void registerIfAbsent(Type paramType, T paramT)
  {
    monitorenter;
    try
    {
      if (!this.modifiable)
        throw new IllegalStateException("Attempted to modify an unmodifiable map.");
    }
    finally
    {
      monitorexit;
    }
    if (!this.map.containsKey(paramType))
      register(paramType, paramT);
    monitorexit;
  }

  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder("{mapForTypeHierarchy:{");
    int i = 1;
    Iterator localIterator = this.typeHierarchyList.iterator();
    if (localIterator.hasNext())
    {
      Pair localPair = (Pair)localIterator.next();
      if (i != 0)
        i = 0;
      while (true)
      {
        Type localType1 = (Type)localPair.first;
        String str1 = typeToString(localType1);
        StringBuilder localStringBuilder2 = localStringBuilder1.append(str1).append(58);
        Object localObject1 = localPair.second;
        StringBuilder localStringBuilder3 = localStringBuilder1.append(localObject1);
        break;
        StringBuilder localStringBuilder4 = localStringBuilder1.append(44);
      }
    }
    StringBuilder localStringBuilder5 = localStringBuilder1.append("},map:{");
    i = 1;
    localIterator = this.map.entrySet().iterator();
    if (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      if (i != 0)
        i = 0;
      while (true)
      {
        Type localType2 = (Type)localEntry.getKey();
        String str2 = typeToString(localType2);
        StringBuilder localStringBuilder6 = localStringBuilder1.append(str2).append(58);
        Object localObject2 = localEntry.getValue();
        StringBuilder localStringBuilder7 = localStringBuilder1.append(localObject2);
        break;
        StringBuilder localStringBuilder8 = localStringBuilder1.append(44);
      }
    }
    StringBuilder localStringBuilder9 = localStringBuilder1.append("}");
    return localStringBuilder1.toString();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.ParameterizedTypeHandlerMap
 * JD-Core Version:    0.6.0
 */