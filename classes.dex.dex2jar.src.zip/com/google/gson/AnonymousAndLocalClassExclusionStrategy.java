package com.google.gson;

final class AnonymousAndLocalClassExclusionStrategy
  implements ExclusionStrategy
{
  private boolean isAnonymousOrLocal(Class<?> paramClass)
  {
    if ((!Enum.class.isAssignableFrom(paramClass)) && ((paramClass.isAnonymousClass()) || (paramClass.isLocalClass())));
    for (int i = 1; ; i = 0)
      return i;
  }

  public boolean shouldSkipClass(Class<?> paramClass)
  {
    return isAnonymousOrLocal(paramClass);
  }

  public boolean shouldSkipField(FieldAttributes paramFieldAttributes)
  {
    Class localClass = paramFieldAttributes.getDeclaredClass();
    return isAnonymousOrLocal(localClass);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.AnonymousAndLocalClassExclusionStrategy
 * JD-Core Version:    0.6.0
 */