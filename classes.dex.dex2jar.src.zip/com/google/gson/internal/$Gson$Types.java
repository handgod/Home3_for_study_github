package com.google.gson.internal;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Arrays;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Properties;

public final class $Gson$Types
{
  static final Type[] EMPTY_TYPE_ARRAY = new Type[0];

  public static GenericArrayType arrayOf(Type paramType)
  {
    return new GenericArrayTypeImpl();
  }

  public static Type canonicalize(Type paramType)
  {
    Object localObject;
    if ((paramType instanceof Class))
    {
      localObject = (Class)paramType;
      if (((Class)localObject).isArray())
      {
        Type localType1 = canonicalize(((Class)localObject).getComponentType());
        localObject = new GenericArrayTypeImpl();
      }
    }
    while (true)
    {
      return localObject;
      if ((paramType instanceof ParameterizedType))
      {
        ParameterizedType localParameterizedType = (ParameterizedType)paramType;
        Type localType2 = localParameterizedType.getOwnerType();
        Type localType3 = localParameterizedType.getRawType();
        Type[] arrayOfType1 = localParameterizedType.getActualTypeArguments();
        localObject = new ParameterizedTypeImpl(localType3, arrayOfType1);
        continue;
      }
      if ((paramType instanceof GenericArrayType))
      {
        Type localType4 = ((GenericArrayType)paramType).getGenericComponentType();
        localObject = new GenericArrayTypeImpl();
        continue;
      }
      if ((paramType instanceof WildcardType))
      {
        WildcardType localWildcardType = (WildcardType)paramType;
        Type[] arrayOfType2 = localWildcardType.getUpperBounds();
        Type[] arrayOfType3 = localWildcardType.getLowerBounds();
        localObject = new WildcardTypeImpl(arrayOfType3);
        continue;
      }
      localObject = paramType;
    }
  }

  private static void checkNotPrimitive(Type paramType)
  {
    if ((!(paramType instanceof Class)) || (!((Class)paramType).isPrimitive()));
    int j;
    for (int i = 1; ; j = 0)
    {
      .Gson.Preconditions.checkArgument(i);
      return;
    }
  }

  private static Class<?> declaringClassOf(TypeVariable paramTypeVariable)
  {
    Object localObject = paramTypeVariable.getGenericDeclaration();
    if ((localObject instanceof Class));
    for (localObject = (Class)localObject; ; localObject = null)
      return localObject;
  }

  static boolean equal(Object paramObject1, Object paramObject2)
  {
    if ((paramObject1 == paramObject2) || ((paramObject1 != null) && (paramObject1.equals(paramObject2))));
    for (int i = 1; ; i = 0)
      return i;
  }

  public static boolean equals(Type paramType1, Type paramType2)
  {
    boolean bool1 = true;
    boolean bool2 = false;
    if (paramType1 == paramType2)
      bool2 = true;
    do
      while (true)
      {
        return bool2;
        if ((paramType1 instanceof Class))
        {
          bool2 = paramType1.equals(paramType2);
          continue;
        }
        if ((paramType1 instanceof ParameterizedType))
        {
          if (!(paramType2 instanceof ParameterizedType))
            continue;
          ParameterizedType localParameterizedType1 = (ParameterizedType)paramType1;
          ParameterizedType localParameterizedType2 = (ParameterizedType)paramType2;
          Type localType1 = localParameterizedType1.getOwnerType();
          Type localType2 = localParameterizedType2.getOwnerType();
          if (equal(localType1, localType2))
          {
            Type localType3 = localParameterizedType1.getRawType();
            Type localType4 = localParameterizedType2.getRawType();
            if (localType3.equals(localType4))
            {
              Type[] arrayOfType1 = localParameterizedType1.getActualTypeArguments();
              Type[] arrayOfType2 = localParameterizedType2.getActualTypeArguments();
              if (!Arrays.equals(arrayOfType1, arrayOfType2));
            }
          }
          while (true)
          {
            bool2 = bool1;
            break;
            bool1 = false;
          }
        }
        if ((paramType1 instanceof GenericArrayType))
        {
          if (!(paramType2 instanceof GenericArrayType))
            continue;
          GenericArrayType localGenericArrayType1 = (GenericArrayType)paramType1;
          GenericArrayType localGenericArrayType2 = (GenericArrayType)paramType2;
          Type localType5 = localGenericArrayType1.getGenericComponentType();
          Type localType6 = localGenericArrayType2.getGenericComponentType();
          bool2 = equals(localType5, localType6);
          continue;
        }
        if (!(paramType1 instanceof WildcardType))
          break;
        if (!(paramType2 instanceof WildcardType))
          continue;
        WildcardType localWildcardType1 = (WildcardType)paramType1;
        WildcardType localWildcardType2 = (WildcardType)paramType2;
        Type[] arrayOfType3 = localWildcardType1.getUpperBounds();
        Type[] arrayOfType4 = localWildcardType2.getUpperBounds();
        if (Arrays.equals(arrayOfType3, arrayOfType4))
        {
          Type[] arrayOfType5 = localWildcardType1.getLowerBounds();
          Type[] arrayOfType6 = localWildcardType2.getLowerBounds();
          if (!Arrays.equals(arrayOfType5, arrayOfType6));
        }
        while (true)
        {
          bool2 = bool1;
          break;
          bool1 = false;
        }
      }
    while ((!(paramType1 instanceof TypeVariable)) || (!(paramType2 instanceof TypeVariable)));
    TypeVariable localTypeVariable1 = (TypeVariable)paramType1;
    TypeVariable localTypeVariable2 = (TypeVariable)paramType2;
    GenericDeclaration localGenericDeclaration1 = localTypeVariable1.getGenericDeclaration();
    GenericDeclaration localGenericDeclaration2 = localTypeVariable2.getGenericDeclaration();
    if (localGenericDeclaration1 == localGenericDeclaration2)
    {
      String str1 = localTypeVariable1.getName();
      String str2 = localTypeVariable2.getName();
      if (!str1.equals(str2));
    }
    while (true)
    {
      bool2 = bool1;
      break;
      bool1 = false;
    }
  }

  public static Type getArrayComponentType(Type paramType)
  {
    if ((paramType instanceof GenericArrayType));
    for (Object localObject = ((GenericArrayType)paramType).getGenericComponentType(); ; localObject = ((Class)paramType).getComponentType())
      return localObject;
  }

  public static Type getCollectionElementType(Type paramType, Class<?> paramClass)
  {
    return ((ParameterizedType)getSupertype(paramType, paramClass, java.util.Collection.class)).getActualTypeArguments()[0];
  }

  static Type getGenericSupertype(Type paramType, Class<?> paramClass1, Class<?> paramClass2)
  {
    if (paramClass2 == paramClass1);
    while (true)
    {
      return paramType;
      if (paramClass2.isInterface())
      {
        Class[] arrayOfClass = paramClass1.getInterfaces();
        int i = 0;
        int j = arrayOfClass.length;
        while (true)
        {
          if (i >= j)
            break label103;
          if (arrayOfClass[i] == paramClass2)
          {
            paramType = paramClass1.getGenericInterfaces()[i];
            break;
          }
          Class localClass1 = arrayOfClass[i];
          if (paramClass2.isAssignableFrom(localClass1))
          {
            Type localType = paramClass1.getGenericInterfaces()[i];
            Class localClass2 = arrayOfClass[i];
            paramType = getGenericSupertype(localType, localClass2, paramClass2);
            break;
          }
          i += 1;
        }
      }
      label103: if (!paramClass1.isInterface())
        while (true)
        {
          if (paramClass1 == Object.class)
            break label165;
          Class localClass3 = paramClass1.getSuperclass();
          if (localClass3 == paramClass2)
          {
            paramType = paramClass1.getGenericSuperclass();
            break;
          }
          if (paramClass2.isAssignableFrom(localClass3))
          {
            paramType = getGenericSupertype(paramClass1.getGenericSuperclass(), localClass3, paramClass2);
            break;
          }
          paramClass1 = localClass3;
        }
      label165: paramType = paramClass2;
    }
  }

  public static Type[] getMapKeyAndValueTypes(Type paramType, Class<?> paramClass)
  {
    Type[] arrayOfType;
    if (paramType == Properties.class)
    {
      arrayOfType = new Type[2];
      arrayOfType[0] = String.class;
      arrayOfType[1] = String.class;
    }
    while (true)
    {
      return arrayOfType;
      arrayOfType = ((ParameterizedType)getSupertype(paramType, paramClass, Map.class)).getActualTypeArguments();
    }
  }

  public static Class<?> getRawType(Type paramType)
  {
    if ((paramType instanceof Class))
      paramType = (Class)paramType;
    while (true)
    {
      return paramType;
      if ((paramType instanceof ParameterizedType))
      {
        Type localType = ((ParameterizedType)paramType).getRawType();
        .Gson.Preconditions.checkArgument(localType instanceof Class);
        paramType = (Class)localType;
        continue;
      }
      if ((paramType instanceof GenericArrayType))
      {
        paramType = Array.newInstance(getRawType(((GenericArrayType)paramType).getGenericComponentType()), 0).getClass();
        continue;
      }
      if ((paramType instanceof TypeVariable))
      {
        paramType = Object.class;
        continue;
      }
      if (!(paramType instanceof WildcardType))
        break;
      paramType = getRawType(((WildcardType)paramType).getUpperBounds()[0]);
    }
    if (paramType == null);
    for (String str1 = "null"; ; str1 = paramType.getClass().getName())
    {
      String str2 = "Expected a Class, ParameterizedType, or GenericArrayType, but <" + paramType + "> is of type " + str1;
      throw new IllegalArgumentException(str2);
    }
  }

  static Type getSupertype(Type paramType, Class<?> paramClass1, Class<?> paramClass2)
  {
    .Gson.Preconditions.checkArgument(paramClass2.isAssignableFrom(paramClass1));
    Type localType = getGenericSupertype(paramType, paramClass1, paramClass2);
    return resolve(paramType, paramClass1, localType);
  }

  private static int hashCodeOrZero(Object paramObject)
  {
    if (paramObject != null);
    for (int i = paramObject.hashCode(); ; i = 0)
      return i;
  }

  private static int indexOf(Object[] paramArrayOfObject, Object paramObject)
  {
    int i = 0;
    while (true)
    {
      int j = paramArrayOfObject.length;
      if (i >= j)
        break;
      Object localObject = paramArrayOfObject[i];
      if (paramObject.equals(localObject))
        return i;
      i += 1;
    }
    throw new NoSuchElementException();
  }

  public static boolean isArray(Type paramType)
  {
    if (((paramType instanceof GenericArrayType)) || (((paramType instanceof Class)) && (((Class)paramType).isArray())));
    for (int i = 1; ; i = 0)
      return i;
  }

  public static ParameterizedType newParameterizedTypeWithOwner(Type paramType1, Type paramType2, Type[] paramArrayOfType)
  {
    return new ParameterizedTypeImpl(paramType2, paramArrayOfType);
  }

  public static Type resolve(Type paramType1, Class<?> paramClass, Type paramType2)
  {
    Object localObject1;
    while ((paramType2 instanceof TypeVariable))
    {
      TypeVariable localTypeVariable1 = (TypeVariable)paramType2;
      Type localType1 = paramType1;
      Class<?> localClass1 = paramClass;
      TypeVariable localTypeVariable2 = localTypeVariable1;
      paramType2 = resolveTypeVariable(localType1, localClass1, localTypeVariable2);
      Type localType2 = paramType2;
      TypeVariable localTypeVariable3 = localTypeVariable1;
      if (localType2 != localTypeVariable3)
        continue;
      localObject1 = paramType2;
    }
    while (true)
    {
      return localObject1;
      Type localType4;
      if (((paramType2 instanceof Class)) && (((Class)paramType2).isArray()))
      {
        Object localObject2 = (Class)paramType2;
        Class localClass = ((Class)localObject2).getComponentType();
        Type localType3 = paramType1;
        Class<?> localClass2 = paramClass;
        localType4 = resolve(localType3, localClass2, localClass);
        if (localClass == localType4);
        while (true)
        {
          localObject1 = localObject2;
          break;
          localObject2 = arrayOf(localType4);
        }
      }
      if ((paramType2 instanceof GenericArrayType))
      {
        localObject1 = (GenericArrayType)paramType2;
        Type localType5 = ((GenericArrayType)localObject1).getGenericComponentType();
        Type localType6 = paramType1;
        Class<?> localClass3 = paramClass;
        localType4 = resolve(localType6, localClass3, localType5);
        if (localType5 == localType4)
          continue;
        localObject1 = arrayOf(localType4);
        continue;
      }
      if ((paramType2 instanceof ParameterizedType))
      {
        localObject1 = (ParameterizedType)paramType2;
        Type localType7 = ((ParameterizedType)localObject1).getOwnerType();
        Type localType8 = paramType1;
        Class<?> localClass4 = paramClass;
        Type localType9 = resolve(localType8, localClass4, localType7);
        if (localType9 != localType7);
        Type[] arrayOfType1;
        for (int i = 1; ; i = 0)
        {
          arrayOfType1 = ((ParameterizedType)localObject1).getActualTypeArguments();
          int j = 0;
          int k = arrayOfType1.length;
          while (j < k)
          {
            Type localType10 = arrayOfType1[j];
            Type localType11 = paramType1;
            Class<?> localClass5 = paramClass;
            Type localType12 = localType10;
            Type localType13 = resolve(localType11, localClass5, localType12);
            Type localType14 = arrayOfType1[j];
            if (localType13 != localType14)
            {
              if (i == 0)
              {
                arrayOfType1 = (Type[])arrayOfType1.clone();
                i = 1;
              }
              arrayOfType1[j] = localType13;
            }
            j += 1;
          }
        }
        if (i == 0)
          continue;
        Type localType15 = ((ParameterizedType)localObject1).getRawType();
        localObject1 = newParameterizedTypeWithOwner(localType9, localType15, arrayOfType1);
        continue;
      }
      if ((paramType2 instanceof WildcardType))
      {
        localObject1 = (WildcardType)paramType2;
        Type[] arrayOfType2 = ((WildcardType)localObject1).getLowerBounds();
        Type[] arrayOfType3 = ((WildcardType)localObject1).getUpperBounds();
        int m = arrayOfType2.length;
        int n = 1;
        if (m == n)
        {
          Type localType16 = arrayOfType2[0];
          Type localType17 = paramType1;
          Class<?> localClass6 = paramClass;
          Type localType18 = localType16;
          Type localType19 = resolve(localType17, localClass6, localType18);
          Type localType20 = arrayOfType2[0];
          if (localType19 == localType20)
            continue;
          localObject1 = supertypeOf(localType19);
          continue;
        }
        int i1 = arrayOfType3.length;
        int i2 = 1;
        if (i1 != i2)
          continue;
        Type localType21 = arrayOfType3[0];
        Type localType22 = paramType1;
        Class<?> localClass7 = paramClass;
        Type localType23 = localType21;
        Type localType24 = resolve(localType22, localClass7, localType23);
        Type localType25 = arrayOfType3[0];
        Type localType26 = localType24;
        Type localType27 = localType25;
        if (localType26 == localType27)
          continue;
        localObject1 = subtypeOf(localType24);
        continue;
      }
      localObject1 = paramType2;
    }
  }

  static Type resolveTypeVariable(Type paramType, Class<?> paramClass, TypeVariable paramTypeVariable)
  {
    Class localClass = declaringClassOf(paramTypeVariable);
    if (localClass == null);
    while (true)
    {
      return paramTypeVariable;
      Type localType = getGenericSupertype(paramType, paramClass, localClass);
      if (!(localType instanceof ParameterizedType))
        continue;
      int i = indexOf(localClass.getTypeParameters(), paramTypeVariable);
      paramTypeVariable = ((ParameterizedType)localType).getActualTypeArguments()[i];
    }
  }

  public static WildcardType subtypeOf(Type paramType)
  {
    Type[] arrayOfType1 = new Type[1];
    arrayOfType1[0] = paramType;
    Type[] arrayOfType2 = EMPTY_TYPE_ARRAY;
    return new WildcardTypeImpl(arrayOfType2);
  }

  public static WildcardType supertypeOf(Type paramType)
  {
    Type[] arrayOfType1 = new Type[1];
    arrayOfType1[0] = Object.class;
    Type[] arrayOfType2 = new Type[1];
    arrayOfType2[0] = paramType;
    return new WildcardTypeImpl(arrayOfType2);
  }

  public static String typeToString(Type paramType)
  {
    if ((paramType instanceof Class));
    for (String str = ((Class)paramType).getName(); ; str = paramType.toString())
      return str;
  }

  final class WildcardTypeImpl
    implements WildcardType, Serializable
  {
    private static final long serialVersionUID;
    private final Type lowerBound;
    private final Type upperBound;

    public WildcardTypeImpl(Type[] arg2)
    {
      Object localObject1;
      if (localObject1.length <= i)
      {
        int k = 1;
        .Gson.Preconditions.checkArgument(k);
        if (this$1.length != 1)
          break label96;
        int m = 1;
        label31: .Gson.Preconditions.checkArgument(m);
        if (localObject1.length != 1)
          break label108;
        Object localObject2 = .Gson.Preconditions.checkNotNull(localObject1[0]);
        .Gson.Types.access$000(localObject1[0]);
        if (this$1[0] != Object.class)
          break label103;
        label64: .Gson.Preconditions.checkArgument(i);
        Type localType1 = .Gson.Types.canonicalize(localObject1[0]);
        this.lowerBound = localType1;
      }
      label96: label103: label108: Type localType2;
      for (this.upperBound = Object.class; ; this.upperBound = localType2)
      {
        return;
        int n = 0;
        break;
        n = 0;
        break label31;
        int j = 0;
        break label64;
        Object localObject3 = .Gson.Preconditions.checkNotNull(this$1[0]);
        .Gson.Types.access$000(this$1[0]);
        this.lowerBound = null;
        localType2 = .Gson.Types.canonicalize(this$1[0]);
      }
    }

    public boolean equals(Object paramObject)
    {
      if ((paramObject instanceof Serializable))
      {
        WildcardType localWildcardType = (Serializable)paramObject;
        if (!.Gson.Types.equals(this, localWildcardType));
      }
      for (int i = 1; ; i = 0)
        return i;
    }

    public Type[] getLowerBounds()
    {
      Type[] arrayOfType;
      if (this.lowerBound != null)
      {
        arrayOfType = new Type[1];
        Type localType = this.lowerBound;
        arrayOfType[0] = localType;
      }
      while (true)
      {
        return arrayOfType;
        arrayOfType = .Gson.Types.EMPTY_TYPE_ARRAY;
      }
    }

    public Type[] getUpperBounds()
    {
      Type[] arrayOfType = new Type[1];
      Type localType = this.upperBound;
      arrayOfType[0] = localType;
      return arrayOfType;
    }

    public int hashCode()
    {
      if (this.lowerBound != null);
      for (int i = this.lowerBound.hashCode() + 31; ; i = 1)
      {
        int j = this.upperBound.hashCode() + 31;
        return i ^ j;
      }
    }

    public String toString()
    {
      String str2;
      if (this.lowerBound != null)
      {
        StringBuilder localStringBuilder1 = new StringBuilder().append("? super ");
        String str1 = .Gson.Types.typeToString(this.lowerBound);
        str2 = str1;
      }
      while (true)
      {
        return str2;
        if (this.upperBound == Object.class)
        {
          str2 = "?";
          continue;
        }
        StringBuilder localStringBuilder2 = new StringBuilder().append("? extends ");
        String str3 = .Gson.Types.typeToString(this.upperBound);
        str2 = str3;
      }
    }
  }

  final class GenericArrayTypeImpl
    implements GenericArrayType, Serializable
  {
    private static final long serialVersionUID;
    private final Type componentType;

    public GenericArrayTypeImpl()
    {
      Type localType = .Gson.Types.canonicalize(this$1);
      this.componentType = localType;
    }

    public boolean equals(Object paramObject)
    {
      if ((paramObject instanceof Serializable))
      {
        GenericArrayType localGenericArrayType = (Serializable)paramObject;
        if (!.Gson.Types.equals(this, localGenericArrayType));
      }
      for (int i = 1; ; i = 0)
        return i;
    }

    public Type getGenericComponentType()
    {
      return this.componentType;
    }

    public int hashCode()
    {
      return this.componentType.hashCode();
    }

    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      String str = .Gson.Types.typeToString(this.componentType);
      return str + "[]";
    }
  }

  final class ParameterizedTypeImpl
    implements ParameterizedType, Serializable
  {
    private static final long serialVersionUID;
    private final Type ownerType;
    private final Type rawType;
    private final Type[] typeArguments;

    public ParameterizedTypeImpl(Type paramArrayOfType, Type[] arg3)
    {
      if ((paramArrayOfType instanceof Class))
      {
        Class localClass = (Class)paramArrayOfType;
        if ((this$1 != null) || (localClass.getEnclosingClass() == null))
        {
          int j = 1;
          .Gson.Preconditions.checkArgument(j);
          if ((this$1 == null) || (localClass.getEnclosingClass() != null))
            i = 1;
          .Gson.Preconditions.checkArgument(i);
        }
      }
      else
      {
        if (this$1 != null)
          break label183;
      }
      label183: Type localType1;
      for (Object localObject2 = null; ; localType1 = .Gson.Types.canonicalize(this$1))
      {
        this.ownerType = localObject2;
        Type localType2 = .Gson.Types.canonicalize(paramArrayOfType);
        this.rawType = localType2;
        Object localObject1;
        Type[] arrayOfType1 = (Type[])localObject1.clone();
        this.typeArguments = arrayOfType1;
        int m = 0;
        while (true)
        {
          int n = this.typeArguments.length;
          if (m >= n)
            break;
          Object localObject3 = .Gson.Preconditions.checkNotNull(this.typeArguments[m]);
          .Gson.Types.access$000(this.typeArguments[m]);
          Type[] arrayOfType2 = this.typeArguments;
          Type localType3 = .Gson.Types.canonicalize(this.typeArguments[m]);
          arrayOfType2[m] = localType3;
          m += 1;
        }
        int k = 0;
        break;
      }
    }

    public boolean equals(Object paramObject)
    {
      if ((paramObject instanceof Serializable))
      {
        ParameterizedType localParameterizedType = (Serializable)paramObject;
        if (!.Gson.Types.equals(this, localParameterizedType));
      }
      for (int i = 1; ; i = 0)
        return i;
    }

    public Type[] getActualTypeArguments()
    {
      return (Type[])this.typeArguments.clone();
    }

    public Type getOwnerType()
    {
      return this.ownerType;
    }

    public Type getRawType()
    {
      return this.rawType;
    }

    public int hashCode()
    {
      int i = Arrays.hashCode(this.typeArguments);
      int j = this.rawType.hashCode();
      int k = i ^ j;
      int m = .Gson.Types.access$100(this.ownerType);
      return k ^ m;
    }

    public String toString()
    {
      int i = (this.typeArguments.length + 1) * 30;
      StringBuilder localStringBuilder1 = new StringBuilder(i);
      String str1 = .Gson.Types.typeToString(this.rawType);
      StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
      if (this.typeArguments.length == 0);
      for (String str2 = localStringBuilder1.toString(); ; str2 = ">")
      {
        return str2;
        StringBuilder localStringBuilder3 = localStringBuilder1.append("<");
        String str3 = .Gson.Types.typeToString(this.typeArguments[0]);
        StringBuilder localStringBuilder4 = localStringBuilder3.append(str3);
        int j = 1;
        while (true)
        {
          int k = this.typeArguments.length;
          if (j >= k)
            break;
          StringBuilder localStringBuilder5 = localStringBuilder1.append(", ");
          String str4 = .Gson.Types.typeToString(this.typeArguments[j]);
          StringBuilder localStringBuilder6 = localStringBuilder5.append(str4);
          j += 1;
        }
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.internal..Gson.Types
 * JD-Core Version:    0.6.0
 */