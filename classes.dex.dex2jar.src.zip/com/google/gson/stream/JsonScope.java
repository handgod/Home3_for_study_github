package com.google.gson.stream;

 enum JsonScope
{
  static
  {
    EMPTY_OBJECT = new JsonScope("EMPTY_OBJECT", 2);
    DANGLING_NAME = new JsonScope("DANGLING_NAME", 3);
    NONEMPTY_OBJECT = new JsonScope("NONEMPTY_OBJECT", 4);
    EMPTY_DOCUMENT = new JsonScope("EMPTY_DOCUMENT", 5);
    NONEMPTY_DOCUMENT = new JsonScope("NONEMPTY_DOCUMENT", 6);
    CLOSED = new JsonScope("CLOSED", 7);
    JsonScope[] arrayOfJsonScope = new JsonScope[8];
    JsonScope localJsonScope1 = EMPTY_ARRAY;
    arrayOfJsonScope[0] = localJsonScope1;
    JsonScope localJsonScope2 = NONEMPTY_ARRAY;
    arrayOfJsonScope[1] = localJsonScope2;
    JsonScope localJsonScope3 = EMPTY_OBJECT;
    arrayOfJsonScope[2] = localJsonScope3;
    JsonScope localJsonScope4 = DANGLING_NAME;
    arrayOfJsonScope[3] = localJsonScope4;
    JsonScope localJsonScope5 = NONEMPTY_OBJECT;
    arrayOfJsonScope[4] = localJsonScope5;
    JsonScope localJsonScope6 = EMPTY_DOCUMENT;
    arrayOfJsonScope[5] = localJsonScope6;
    JsonScope localJsonScope7 = NONEMPTY_DOCUMENT;
    arrayOfJsonScope[6] = localJsonScope7;
    JsonScope localJsonScope8 = CLOSED;
    arrayOfJsonScope[7] = localJsonScope8;
    $VALUES = arrayOfJsonScope;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.stream.JsonScope
 * JD-Core Version:    0.6.0
 */