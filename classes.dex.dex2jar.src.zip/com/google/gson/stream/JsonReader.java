package com.google.gson.stream;

import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

public final class JsonReader
  implements Closeable
{
  private static final char[] NON_EXECUTE_PREFIX = ")]}'\n".toCharArray();
  private final char[] buffer;
  private boolean hasToken;
  private final Reader in;
  private boolean lenient = 0;
  private int limit;
  private String name;
  private int pos;
  private boolean skipping;
  private final List<JsonScope> stack;
  private JsonToken token;
  private String value;

  public JsonReader(Reader paramReader)
  {
    char[] arrayOfChar = new char[1024];
    this.buffer = arrayOfChar;
    this.pos = 0;
    this.limit = 0;
    ArrayList localArrayList = new ArrayList();
    this.stack = localArrayList;
    JsonScope localJsonScope = JsonScope.EMPTY_DOCUMENT;
    push(localJsonScope);
    this.skipping = 0;
    if (paramReader == null)
      throw new NullPointerException("in == null");
    this.in = paramReader;
  }

  private JsonToken advance()
    throws IOException
  {
    JsonToken localJsonToken1 = quickPeek();
    JsonToken localJsonToken2 = this.token;
    this.hasToken = 0;
    this.token = null;
    this.value = null;
    this.name = null;
    return localJsonToken2;
  }

  private void checkLenient()
    throws IOException
  {
    if (!this.lenient)
      throw syntaxError("Use JsonReader.setLenient(true) to accept malformed JSON");
  }

  private void consumeNonExecutePrefix()
    throws IOException
  {
    int i = nextNonWhitespace();
    int j = this.pos + -1;
    this.pos = j;
    int k = this.pos;
    int m = NON_EXECUTE_PREFIX.length;
    int n = k + m;
    int i1 = this.limit;
    if (n > i1)
    {
      int i2 = NON_EXECUTE_PREFIX.length;
      if (fillBuffer(i2));
    }
    while (true)
    {
      return;
      int i3 = 0;
      while (true)
      {
        int i4 = NON_EXECUTE_PREFIX.length;
        if (i3 >= i4)
          break label126;
        char[] arrayOfChar = this.buffer;
        int i5 = this.pos + i3;
        int i6 = arrayOfChar[i5];
        int i7 = NON_EXECUTE_PREFIX[i3];
        if (i6 != i7)
          break;
        i3 += 1;
      }
      label126: int i8 = this.pos;
      int i9 = NON_EXECUTE_PREFIX.length;
      int i10 = i8 + i9;
      this.pos = i10;
    }
  }

  private void decodeLiteral()
    throws IOException
  {
    if (this.value.equalsIgnoreCase("null"))
    {
      JsonToken localJsonToken1 = JsonToken.NULL;
      this.token = localJsonToken1;
    }
    while (true)
    {
      return;
      if ((this.value.equalsIgnoreCase("true")) || (this.value.equalsIgnoreCase("false")))
      {
        JsonToken localJsonToken2 = JsonToken.BOOLEAN;
        this.token = localJsonToken2;
        continue;
      }
      try
      {
        double d = Double.parseDouble(this.value);
        JsonToken localJsonToken3 = JsonToken.NUMBER;
        this.token = localJsonToken3;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        checkLenient();
        JsonToken localJsonToken4 = JsonToken.STRING;
        this.token = localJsonToken4;
      }
    }
  }

  private void expect(JsonToken paramJsonToken)
    throws IOException
  {
    JsonToken localJsonToken1 = quickPeek();
    if (this.token != paramJsonToken)
    {
      StringBuilder localStringBuilder = new StringBuilder().append("Expected ").append(paramJsonToken).append(" but was ");
      JsonToken localJsonToken2 = peek();
      String str = localJsonToken2;
      throw new IllegalStateException(str);
    }
    JsonToken localJsonToken3 = advance();
  }

  private boolean fillBuffer(int paramInt)
    throws IOException
  {
    int i = 0;
    int j = this.limit;
    int k = this.pos;
    if (j != k)
    {
      int m = this.limit;
      int n = this.pos;
      int i1 = m - n;
      this.limit = i1;
      char[] arrayOfChar1 = this.buffer;
      int i2 = this.pos;
      char[] arrayOfChar2 = this.buffer;
      int i3 = this.limit;
      System.arraycopy(arrayOfChar1, i2, arrayOfChar2, 0, i3);
    }
    while (true)
    {
      this.pos = 0;
      while (true)
      {
        Reader localReader = this.in;
        char[] arrayOfChar3 = this.buffer;
        int i4 = this.limit;
        int i5 = this.buffer.length;
        int i6 = this.limit;
        int i7 = i5 - i6;
        int i8 = localReader.read(arrayOfChar3, i4, i7);
        if (i8 == -1)
          break;
        int i9 = this.limit + i8;
        this.limit = i9;
        if (this.limit < paramInt)
          continue;
        i = 1;
      }
      return i;
      this.limit = 0;
    }
  }

  private CharSequence getSnippet()
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    int i = Math.min(this.pos, 20);
    char[] arrayOfChar1 = this.buffer;
    int j = this.pos - i;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(arrayOfChar1, j, i);
    int k = this.limit;
    int m = this.pos;
    int n = Math.min(k - m, 20);
    char[] arrayOfChar2 = this.buffer;
    int i1 = this.pos;
    StringBuilder localStringBuilder3 = localStringBuilder1.append(arrayOfChar2, i1, n);
    return localStringBuilder1;
  }

  private JsonToken nextInArray(boolean paramBoolean)
    throws IOException
  {
    label13: JsonToken localJsonToken;
    if (paramBoolean)
    {
      JsonScope localJsonScope1 = JsonScope.NONEMPTY_ARRAY;
      replaceTop(localJsonScope1);
      switch (nextNonWhitespace())
      {
      default:
        int i = this.pos + -1;
        this.pos = i;
        localJsonToken = nextValue();
      case 93:
      case 44:
      case 59:
      }
    }
    while (true)
    {
      return localJsonToken;
      switch (nextNonWhitespace())
      {
      case 44:
      default:
        throw syntaxError("Unterminated array");
      case 93:
        JsonScope localJsonScope2 = pop();
        this.hasToken = 1;
        localJsonToken = JsonToken.END_ARRAY;
        this.token = localJsonToken;
        break;
      case 59:
        checkLenient();
        break label13;
        if (paramBoolean)
        {
          JsonScope localJsonScope3 = pop();
          this.hasToken = 1;
          localJsonToken = JsonToken.END_ARRAY;
          this.token = localJsonToken;
          continue;
        }
        checkLenient();
        int j = this.pos + -1;
        this.pos = j;
        this.hasToken = 1;
        this.value = "null";
        localJsonToken = JsonToken.NULL;
        this.token = localJsonToken;
      }
    }
  }

  private JsonToken nextInObject(boolean paramBoolean)
    throws IOException
  {
    int j;
    JsonToken localJsonToken;
    if (paramBoolean)
      switch (nextNonWhitespace())
      {
      default:
        int i = this.pos + -1;
        this.pos = i;
        j = nextNonWhitespace();
        switch (j)
        {
        default:
          checkLenient();
          int k = this.pos + -1;
          this.pos = k;
          String str1 = nextLiteral();
          this.name = str1;
          if (this.name.length() == 0)
            throw syntaxError("Expected name");
        case 39:
        case 34:
        }
      case 125:
        JsonScope localJsonScope1 = pop();
        this.hasToken = 1;
        localJsonToken = JsonToken.END_OBJECT;
        this.token = localJsonToken;
      }
    while (true)
    {
      return localJsonToken;
      switch (nextNonWhitespace())
      {
      case 44:
      case 59:
      default:
        throw syntaxError("Unterminated object");
      case 125:
      }
      JsonScope localJsonScope2 = pop();
      this.hasToken = 1;
      localJsonToken = JsonToken.END_OBJECT;
      this.token = localJsonToken;
      continue;
      checkLenient();
      char c = (char)j;
      String str2 = nextString(c);
      this.name = str2;
      JsonScope localJsonScope3 = JsonScope.DANGLING_NAME;
      replaceTop(localJsonScope3);
      this.hasToken = 1;
      localJsonToken = JsonToken.NAME;
      this.token = localJsonToken;
    }
  }

  private String nextLiteral()
    throws IOException
  {
    StringBuilder localStringBuilder1 = null;
    int i = this.pos;
    label195: String str;
    while (true)
    {
      int j = this.pos;
      int k = this.limit;
      if (j < k)
      {
        char[] arrayOfChar1 = this.buffer;
        int m = this.pos;
        int n = m + 1;
        this.pos = n;
        switch (arrayOfChar1[m])
        {
        default:
          break;
        case '\t':
        case '\n':
        case '\f':
        case '\r':
        case ' ':
        case ',':
        case ':':
        case '[':
        case ']':
        case '{':
        case '}':
          int i1 = this.pos + -1;
          this.pos = i1;
          if (this.skipping)
            str = "skipped!";
        case '#':
        case '/':
        case ';':
        case '=':
        case '\\':
        }
      }
    }
    while (true)
    {
      return str;
      checkLenient();
      break label195;
      if (localStringBuilder1 == null)
      {
        char[] arrayOfChar2 = this.buffer;
        int i2 = this.pos - i;
        str = new String(arrayOfChar2, i, i2);
        continue;
      }
      char[] arrayOfChar3 = this.buffer;
      int i3 = this.pos - i;
      StringBuilder localStringBuilder2 = localStringBuilder1.append(arrayOfChar3, i, i3);
      str = localStringBuilder1.toString();
      continue;
      if (localStringBuilder1 == null)
        localStringBuilder1 = new StringBuilder();
      char[] arrayOfChar4 = this.buffer;
      int i4 = this.pos - i;
      StringBuilder localStringBuilder3 = localStringBuilder1.append(arrayOfChar4, i, i4);
      if (fillBuffer(1))
        break;
      str = localStringBuilder1.toString();
    }
  }

  private int nextNonWhitespace()
    throws IOException
  {
    while (true)
    {
      int i = this.pos;
      int j = this.limit;
      if ((i >= j) && (!fillBuffer(1)))
        break;
      char[] arrayOfChar1 = this.buffer;
      int k = this.pos;
      int m = k + 1;
      this.pos = m;
      int n = arrayOfChar1[k];
      switch (n)
      {
      case 9:
      case 10:
      case 13:
      case 32:
      default:
      case 47:
        while (true)
        {
          return n;
          int i1 = this.pos;
          int i2 = this.limit;
          if ((i1 == i2) && (!fillBuffer(1)))
            continue;
          checkLenient();
          char[] arrayOfChar2 = this.buffer;
          int i3 = this.pos;
          switch (arrayOfChar2[i3])
          {
          default:
          case '*':
          case '/':
          }
        }
        int i4 = this.pos + 1;
        this.pos = i4;
        if (!skipTo("*/"))
          throw syntaxError("Unterminated comment");
        int i5 = this.pos + 2;
        this.pos = i5;
        continue;
        int i6 = this.pos + 1;
        this.pos = i6;
        skipToEndOfLine();
        break;
      case 35:
      }
      checkLenient();
      skipToEndOfLine();
    }
    throw new EOFException("End of input");
  }

  private String nextString(char paramChar)
    throws IOException
  {
    StringBuilder localStringBuilder1 = null;
    do
    {
      int i = this.pos;
      while (true)
      {
        int j = this.pos;
        int k = this.limit;
        if (j >= k)
          break;
        char[] arrayOfChar1 = this.buffer;
        int m = this.pos;
        int n = m + 1;
        this.pos = n;
        char c1 = arrayOfChar1[m];
        if (c1 == paramChar)
        {
          String str;
          if (this.skipping)
            str = "skipped!";
          while (true)
          {
            return str;
            if (localStringBuilder1 == null)
            {
              char[] arrayOfChar2 = this.buffer;
              int i1 = this.pos - i + -1;
              str = new String(arrayOfChar2, i, i1);
              continue;
            }
            char[] arrayOfChar3 = this.buffer;
            int i2 = this.pos - i + -1;
            StringBuilder localStringBuilder2 = localStringBuilder1.append(arrayOfChar3, i, i2);
            str = localStringBuilder1.toString();
          }
        }
        if (c1 != '\\')
          continue;
        if (localStringBuilder1 == null)
          localStringBuilder1 = new StringBuilder();
        char[] arrayOfChar4 = this.buffer;
        int i3 = this.pos - i + -1;
        StringBuilder localStringBuilder3 = localStringBuilder1.append(arrayOfChar4, i, i3);
        char c2 = readEscapeCharacter();
        StringBuilder localStringBuilder4 = localStringBuilder1.append(c2);
        i = this.pos;
      }
      if (localStringBuilder1 == null)
        localStringBuilder1 = new StringBuilder();
      char[] arrayOfChar5 = this.buffer;
      int i4 = this.pos - i;
      StringBuilder localStringBuilder5 = localStringBuilder1.append(arrayOfChar5, i, i4);
    }
    while (fillBuffer(1));
    throw syntaxError("Unterminated string");
  }

  private JsonToken nextValue()
    throws IOException
  {
    int i = nextNonWhitespace();
    JsonToken localJsonToken;
    switch (i)
    {
    default:
      int j = this.pos + -1;
      this.pos = j;
      localJsonToken = readLiteral();
    case 123:
    case 91:
    case 39:
    case 34:
    }
    while (true)
    {
      return localJsonToken;
      JsonScope localJsonScope1 = JsonScope.EMPTY_OBJECT;
      push(localJsonScope1);
      this.hasToken = 1;
      localJsonToken = JsonToken.BEGIN_OBJECT;
      this.token = localJsonToken;
      continue;
      JsonScope localJsonScope2 = JsonScope.EMPTY_ARRAY;
      push(localJsonScope2);
      this.hasToken = 1;
      localJsonToken = JsonToken.BEGIN_ARRAY;
      this.token = localJsonToken;
      continue;
      checkLenient();
      char c = (char)i;
      String str = nextString(c);
      this.value = str;
      this.hasToken = 1;
      localJsonToken = JsonToken.STRING;
      this.token = localJsonToken;
    }
  }

  private JsonToken objectValue()
    throws IOException
  {
    switch (nextNonWhitespace())
    {
    case 59:
    case 60:
    default:
      throw syntaxError("Expected ':'");
    case 61:
      checkLenient();
      int i = this.pos;
      int j = this.limit;
      if ((i >= j) && (!fillBuffer(1)))
        break;
      char[] arrayOfChar = this.buffer;
      int k = this.pos;
      if (arrayOfChar[k] != '>')
        break;
      int m = this.pos + 1;
      this.pos = m;
    case 58:
    }
    JsonScope localJsonScope = JsonScope.NONEMPTY_OBJECT;
    replaceTop(localJsonScope);
    return nextValue();
  }

  private JsonScope peekStack()
  {
    List localList = this.stack;
    int i = this.stack.size() + -1;
    return (JsonScope)localList.get(i);
  }

  private JsonScope pop()
  {
    List localList = this.stack;
    int i = this.stack.size() + -1;
    return (JsonScope)localList.remove(i);
  }

  private void push(JsonScope paramJsonScope)
  {
    boolean bool = this.stack.add(paramJsonScope);
  }

  private JsonToken quickPeek()
    throws IOException
  {
    Object localObject;
    if (this.hasToken)
      localObject = this.token;
    while (true)
    {
      return localObject;
      int[] arrayOfInt = 1.$SwitchMap$com$google$gson$stream$JsonScope;
      int i = peekStack().ordinal();
      switch (arrayOfInt[i])
      {
      default:
        throw new AssertionError();
      case 1:
        if (this.lenient)
          consumeNonExecutePrefix();
        JsonScope localJsonScope = JsonScope.NONEMPTY_DOCUMENT;
        replaceTop(localJsonScope);
        localObject = nextValue();
        if (this.lenient)
          continue;
        JsonToken localJsonToken1 = JsonToken.BEGIN_ARRAY;
        if (localObject == localJsonToken1)
          continue;
        JsonToken localJsonToken2 = JsonToken.BEGIN_OBJECT;
        if (localObject == localJsonToken2)
          continue;
        IOException localIOException = syntaxError("Expected JSON document to start with '[' or '{'");
        break;
      case 2:
        localObject = nextInArray(1);
        break;
      case 3:
        localObject = nextInArray(0);
        break;
      case 4:
        localObject = nextInObject(1);
        break;
      case 5:
        localObject = objectValue();
        break;
      case 6:
        localObject = nextInObject(0);
        break;
      case 7:
        try
        {
          JsonToken localJsonToken3 = nextValue();
          if (this.lenient)
          {
            localObject = localJsonToken3;
            continue;
          }
          throw syntaxError("Expected EOF");
        }
        catch (EOFException localEOFException)
        {
          this.hasToken = 1;
          localObject = JsonToken.END_DOCUMENT;
          this.token = ((JsonToken)localObject);
        }
      case 8:
      }
    }
    throw new IllegalStateException("JsonReader is closed");
  }

  private char readEscapeCharacter()
    throws IOException
  {
    int i = this.pos;
    int j = this.limit;
    if ((i == j) && (!fillBuffer(1)))
      throw syntaxError("Unterminated escape sequence");
    char[] arrayOfChar1 = this.buffer;
    int k = this.pos;
    int m = k + 1;
    this.pos = m;
    int n = arrayOfChar1[k];
    switch (n)
    {
    default:
    case 117:
    case 116:
    case 98:
    case 110:
    case 114:
    case 102:
    }
    while (true)
    {
      return n;
      int i1 = this.pos + 4;
      int i2 = this.limit;
      if ((i1 > i2) && (!fillBuffer(4)))
        throw syntaxError("Unterminated escape sequence");
      char[] arrayOfChar2 = this.buffer;
      int i3 = this.pos;
      String str = new String(arrayOfChar2, i3, 4);
      int i4 = this.pos + 4;
      this.pos = i4;
      n = (char)Integer.parseInt(str, 16);
      continue;
      n = 9;
      continue;
      n = 8;
      continue;
      n = 10;
      continue;
      n = 13;
      continue;
      n = 12;
    }
  }

  private JsonToken readLiteral()
    throws IOException
  {
    String str = nextLiteral();
    if (str.length() == 0)
      throw syntaxError("Expected literal value");
    this.value = str;
    this.hasToken = 1;
    this.token = null;
    return null;
  }

  private void replaceTop(JsonScope paramJsonScope)
  {
    List localList = this.stack;
    int i = this.stack.size() + -1;
    Object localObject = localList.set(i, paramJsonScope);
  }

  private boolean skipTo(String paramString)
    throws IOException
  {
    int i = this.pos;
    int j = paramString.length();
    int k = i + j;
    int m = this.limit;
    if (k >= m)
    {
      int n = paramString.length();
      if (!fillBuffer(n));
    }
    else
    {
      int i1 = 0;
      while (true)
      {
        int i2 = paramString.length();
        if (i1 >= i2)
          break label122;
        char[] arrayOfChar = this.buffer;
        int i3 = this.pos + i1;
        int i4 = arrayOfChar[i3];
        int i5 = paramString.charAt(i1);
        if (i4 != i5)
        {
          int i6 = this.pos + 1;
          this.pos = i6;
          break;
        }
        i1 += 1;
      }
    }
    label122: for (int i7 = 1; ; i7 = 0)
      return i7;
  }

  private void skipToEndOfLine()
    throws IOException
  {
    int n;
    do
    {
      int i = this.pos;
      int j = this.limit;
      if ((i >= j) && (!fillBuffer(1)))
        break;
      char[] arrayOfChar = this.buffer;
      int k = this.pos;
      int m = k + 1;
      this.pos = m;
      n = arrayOfChar[k];
    }
    while ((n != 13) && (n != 10));
  }

  private IOException syntaxError(String paramString)
    throws IOException
  {
    StringBuilder localStringBuilder = new StringBuilder().append(paramString).append(" near ");
    CharSequence localCharSequence = getSnippet();
    String str = localCharSequence;
    throw new MalformedJsonException(str);
  }

  public void beginArray()
    throws IOException
  {
    JsonToken localJsonToken = JsonToken.BEGIN_ARRAY;
    expect(localJsonToken);
  }

  public void beginObject()
    throws IOException
  {
    JsonToken localJsonToken = JsonToken.BEGIN_OBJECT;
    expect(localJsonToken);
  }

  public void close()
    throws IOException
  {
    this.hasToken = 0;
    this.value = null;
    this.token = null;
    this.stack.clear();
    List localList = this.stack;
    JsonScope localJsonScope = JsonScope.CLOSED;
    boolean bool = localList.add(localJsonScope);
    this.in.close();
  }

  public void endArray()
    throws IOException
  {
    JsonToken localJsonToken = JsonToken.END_ARRAY;
    expect(localJsonToken);
  }

  public void endObject()
    throws IOException
  {
    JsonToken localJsonToken = JsonToken.END_OBJECT;
    expect(localJsonToken);
  }

  public boolean hasNext()
    throws IOException
  {
    JsonToken localJsonToken1 = quickPeek();
    JsonToken localJsonToken2 = this.token;
    JsonToken localJsonToken3 = JsonToken.END_OBJECT;
    if (localJsonToken2 != localJsonToken3)
    {
      JsonToken localJsonToken4 = this.token;
      JsonToken localJsonToken5 = JsonToken.END_ARRAY;
      if (localJsonToken4 == localJsonToken5);
    }
    for (int i = 1; ; i = 0)
      return i;
  }

  public boolean isLenient()
  {
    return this.lenient;
  }

  public boolean nextBoolean()
    throws IOException
  {
    JsonToken localJsonToken1 = quickPeek();
    if (this.value != null)
    {
      JsonToken localJsonToken2 = this.token;
      JsonToken localJsonToken3 = JsonToken.STRING;
      if (localJsonToken2 != localJsonToken3);
    }
    else
    {
      StringBuilder localStringBuilder1 = new StringBuilder().append("Expected a boolean but was ");
      JsonToken localJsonToken4 = peek();
      String str1 = localJsonToken4;
      throw new IllegalStateException(str1);
    }
    if (this.value.equalsIgnoreCase("true"));
    for (int i = 1; ; i = 0)
    {
      JsonToken localJsonToken5 = advance();
      return i;
      if (!this.value.equalsIgnoreCase("false"))
        break;
    }
    StringBuilder localStringBuilder2 = new StringBuilder().append("Not a boolean: ");
    String str2 = this.value;
    String str3 = str2;
    throw new IllegalStateException(str3);
  }

  public double nextDouble()
    throws IOException
  {
    JsonToken localJsonToken1 = quickPeek();
    if (this.value == null)
    {
      StringBuilder localStringBuilder1 = new StringBuilder().append("Expected a double but was ");
      JsonToken localJsonToken2 = peek();
      String str1 = localJsonToken2;
      throw new IllegalStateException(str1);
    }
    double d = Double.parseDouble(this.value);
    if ((d >= 1.0D) && (this.value.startsWith("0")))
    {
      StringBuilder localStringBuilder2 = new StringBuilder().append("JSON forbids octal prefixes: ");
      String str2 = this.value;
      String str3 = str2;
      throw new NumberFormatException(str3);
    }
    if ((!this.lenient) && ((Double.isNaN(d)) || (Double.isInfinite(d))))
    {
      StringBuilder localStringBuilder3 = new StringBuilder().append("JSON forbids NaN and infinities: ");
      String str4 = this.value;
      String str5 = str4;
      throw new NumberFormatException(str5);
    }
    JsonToken localJsonToken3 = advance();
    return d;
  }

  public int nextInt()
    throws IOException
  {
    JsonToken localJsonToken1 = quickPeek();
    if (this.value == null)
    {
      StringBuilder localStringBuilder1 = new StringBuilder().append("Expected an int but was ");
      JsonToken localJsonToken2 = peek();
      String str1 = localJsonToken2;
      throw new IllegalStateException(str1);
    }
    int j;
    try
    {
      int i = Integer.parseInt(this.value);
      j = i;
      if ((j >= 1L) && (this.value.startsWith("0")))
      {
        StringBuilder localStringBuilder2 = new StringBuilder().append("JSON forbids octal prefixes: ");
        String str2 = this.value;
        String str3 = str2;
        throw new NumberFormatException(str3);
      }
    }
    catch (NumberFormatException localNumberFormatException)
    {
      double d;
      do
      {
        d = Double.parseDouble(this.value);
        j = (int)d;
      }
      while (j == d);
      String str4 = this.value;
      throw new NumberFormatException(str4);
    }
    JsonToken localJsonToken3 = advance();
    return j;
  }

  public long nextLong()
    throws IOException
  {
    JsonToken localJsonToken1 = quickPeek();
    if (this.value == null)
    {
      StringBuilder localStringBuilder1 = new StringBuilder().append("Expected a long but was ");
      JsonToken localJsonToken2 = peek();
      String str1 = localJsonToken2;
      throw new IllegalStateException(str1);
    }
    long l2;
    try
    {
      long l1 = Long.parseLong(this.value);
      l2 = l1;
      if ((l2 >= 1L) && (this.value.startsWith("0")))
      {
        StringBuilder localStringBuilder2 = new StringBuilder().append("JSON forbids octal prefixes: ");
        String str2 = this.value;
        String str3 = str2;
        throw new NumberFormatException(str3);
      }
    }
    catch (NumberFormatException localNumberFormatException)
    {
      double d;
      do
      {
        d = Double.parseDouble(this.value);
        l2 = ()d;
      }
      while (l2 == d);
      String str4 = this.value;
      throw new NumberFormatException(str4);
    }
    JsonToken localJsonToken3 = advance();
    return l2;
  }

  public String nextName()
    throws IOException
  {
    JsonToken localJsonToken1 = quickPeek();
    JsonToken localJsonToken2 = this.token;
    JsonToken localJsonToken3 = JsonToken.NAME;
    if (localJsonToken2 != localJsonToken3)
    {
      StringBuilder localStringBuilder = new StringBuilder().append("Expected a name but was ");
      JsonToken localJsonToken4 = peek();
      String str1 = localJsonToken4;
      throw new IllegalStateException(str1);
    }
    String str2 = this.name;
    JsonToken localJsonToken5 = advance();
    return str2;
  }

  public void nextNull()
    throws IOException
  {
    JsonToken localJsonToken1 = quickPeek();
    if (this.value != null)
    {
      JsonToken localJsonToken2 = this.token;
      JsonToken localJsonToken3 = JsonToken.STRING;
      if (localJsonToken2 != localJsonToken3);
    }
    else
    {
      StringBuilder localStringBuilder1 = new StringBuilder().append("Expected null but was ");
      JsonToken localJsonToken4 = peek();
      String str1 = localJsonToken4;
      throw new IllegalStateException(str1);
    }
    if (!this.value.equalsIgnoreCase("null"))
    {
      StringBuilder localStringBuilder2 = new StringBuilder().append("Not a null: ");
      String str2 = this.value;
      String str3 = str2;
      throw new IllegalStateException(str3);
    }
    JsonToken localJsonToken5 = advance();
  }

  public String nextString()
    throws IOException
  {
    JsonToken localJsonToken1 = peek();
    if (this.value != null)
    {
      JsonToken localJsonToken2 = this.token;
      JsonToken localJsonToken3 = JsonToken.STRING;
      if (localJsonToken2 != localJsonToken3)
      {
        JsonToken localJsonToken4 = this.token;
        JsonToken localJsonToken5 = JsonToken.NUMBER;
        if (localJsonToken4 == localJsonToken5);
      }
    }
    else
    {
      StringBuilder localStringBuilder = new StringBuilder().append("Expected a string but was ");
      JsonToken localJsonToken6 = peek();
      String str1 = localJsonToken6;
      throw new IllegalStateException(str1);
    }
    String str2 = this.value;
    JsonToken localJsonToken7 = advance();
    return str2;
  }

  public JsonToken peek()
    throws IOException
  {
    JsonToken localJsonToken = quickPeek();
    if (this.token == null)
      decodeLiteral();
    return this.token;
  }

  public void setLenient(boolean paramBoolean)
  {
    this.lenient = paramBoolean;
  }

  public void skipValue()
    throws IOException
  {
    this.skipping = 1;
    int i = 0;
    try
    {
      JsonToken localJsonToken1 = advance();
      JsonToken localJsonToken2 = JsonToken.BEGIN_ARRAY;
      JsonToken localJsonToken3;
      if (localJsonToken1 != localJsonToken2)
      {
        localJsonToken3 = JsonToken.BEGIN_OBJECT;
        if (localJsonToken1 != localJsonToken3);
      }
      else
      {
        i += 1;
      }
      while (i == 0)
      {
        return;
        JsonToken localJsonToken4 = JsonToken.END_ARRAY;
        if (localJsonToken1 != localJsonToken4)
        {
          localJsonToken3 = JsonToken.END_OBJECT;
          if (localJsonToken1 != localJsonToken3)
            continue;
        }
        i += -1;
      }
    }
    finally
    {
      this.skipping = 0;
    }
    throw localObject;
  }

  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str = getClass().getSimpleName();
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str).append(" near ");
    CharSequence localCharSequence = getSnippet();
    return localCharSequence;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.stream.JsonReader
 * JD-Core Version:    0.6.0
 */