package com.google.gson.stream;

public enum JsonToken
{
  static
  {
    BEGIN_OBJECT = new JsonToken("BEGIN_OBJECT", 2);
    END_OBJECT = new JsonToken("END_OBJECT", 3);
    NAME = new JsonToken("NAME", 4);
    STRING = new JsonToken("STRING", 5);
    NUMBER = new JsonToken("NUMBER", 6);
    BOOLEAN = new JsonToken("BOOLEAN", 7);
    NULL = new JsonToken("NULL", 8);
    END_DOCUMENT = new JsonToken("END_DOCUMENT", 9);
    JsonToken[] arrayOfJsonToken = new JsonToken[10];
    JsonToken localJsonToken1 = BEGIN_ARRAY;
    arrayOfJsonToken[0] = localJsonToken1;
    JsonToken localJsonToken2 = END_ARRAY;
    arrayOfJsonToken[1] = localJsonToken2;
    JsonToken localJsonToken3 = BEGIN_OBJECT;
    arrayOfJsonToken[2] = localJsonToken3;
    JsonToken localJsonToken4 = END_OBJECT;
    arrayOfJsonToken[3] = localJsonToken4;
    JsonToken localJsonToken5 = NAME;
    arrayOfJsonToken[4] = localJsonToken5;
    JsonToken localJsonToken6 = STRING;
    arrayOfJsonToken[5] = localJsonToken6;
    JsonToken localJsonToken7 = NUMBER;
    arrayOfJsonToken[6] = localJsonToken7;
    JsonToken localJsonToken8 = BOOLEAN;
    arrayOfJsonToken[7] = localJsonToken8;
    JsonToken localJsonToken9 = NULL;
    arrayOfJsonToken[8] = localJsonToken9;
    JsonToken localJsonToken10 = END_DOCUMENT;
    arrayOfJsonToken[9] = localJsonToken10;
    $VALUES = arrayOfJsonToken;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.stream.JsonToken
 * JD-Core Version:    0.6.0
 */