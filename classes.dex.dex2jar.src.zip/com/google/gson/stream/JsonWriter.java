package com.google.gson.stream;

import java.io.Closeable;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

public final class JsonWriter
  implements Closeable
{
  private boolean htmlSafe;
  private String indent;
  private boolean lenient;
  private final Writer out;
  private String separator;
  private final List<JsonScope> stack;

  public JsonWriter(Writer paramWriter)
  {
    ArrayList localArrayList = new ArrayList();
    this.stack = localArrayList;
    List localList = this.stack;
    JsonScope localJsonScope = JsonScope.EMPTY_DOCUMENT;
    boolean bool = localList.add(localJsonScope);
    this.separator = ":";
    if (paramWriter == null)
      throw new NullPointerException("out == null");
    this.out = paramWriter;
  }

  private void beforeName()
    throws IOException
  {
    JsonScope localJsonScope1 = peek();
    JsonScope localJsonScope2 = JsonScope.NONEMPTY_OBJECT;
    if (localJsonScope1 == localJsonScope2)
      this.out.write(44);
    JsonScope localJsonScope4;
    do
    {
      newline();
      JsonScope localJsonScope3 = JsonScope.DANGLING_NAME;
      replaceTop(localJsonScope3);
      return;
      localJsonScope4 = JsonScope.EMPTY_OBJECT;
    }
    while (localJsonScope1 == localJsonScope4);
    StringBuilder localStringBuilder = new StringBuilder().append("Nesting problem: ");
    List localList = this.stack;
    String str = localList;
    throw new IllegalStateException(str);
  }

  private void beforeValue(boolean paramBoolean)
    throws IOException
  {
    int[] arrayOfInt = 1.$SwitchMap$com$google$gson$stream$JsonScope;
    int i = peek().ordinal();
    switch (arrayOfInt[i])
    {
    default:
      StringBuilder localStringBuilder = new StringBuilder().append("Nesting problem: ");
      List localList = this.stack;
      String str1 = localList;
      throw new IllegalStateException(str1);
    case 1:
      if ((!this.lenient) && (!paramBoolean))
        throw new IllegalStateException("JSON must start with an array or an object.");
      JsonScope localJsonScope1 = JsonScope.NONEMPTY_DOCUMENT;
      replaceTop(localJsonScope1);
    case 2:
    case 3:
    case 4:
      while (true)
      {
        return;
        JsonScope localJsonScope2 = JsonScope.NONEMPTY_ARRAY;
        replaceTop(localJsonScope2);
        newline();
        continue;
        Writer localWriter1 = this.out.append(44);
        newline();
        continue;
        Writer localWriter2 = this.out;
        String str2 = this.separator;
        Writer localWriter3 = localWriter2.append(str2);
        JsonScope localJsonScope3 = JsonScope.NONEMPTY_OBJECT;
        replaceTop(localJsonScope3);
      }
    case 5:
    }
    throw new IllegalStateException("JSON must have only one top-level value.");
  }

  private JsonWriter close(JsonScope paramJsonScope1, JsonScope paramJsonScope2, String paramString)
    throws IOException
  {
    JsonScope localJsonScope = peek();
    if ((localJsonScope != paramJsonScope2) && (localJsonScope != paramJsonScope1))
    {
      StringBuilder localStringBuilder = new StringBuilder().append("Nesting problem: ");
      List localList1 = this.stack;
      String str = localList1;
      throw new IllegalStateException(str);
    }
    List localList2 = this.stack;
    int i = this.stack.size() + -1;
    Object localObject = localList2.remove(i);
    if (localJsonScope == paramJsonScope2)
      newline();
    this.out.write(paramString);
    return this;
  }

  private void newline()
    throws IOException
  {
    if (this.indent == null)
      return;
    this.out.write("\n");
    int i = 1;
    while (true)
    {
      int j = this.stack.size();
      if (i >= j)
        break;
      Writer localWriter = this.out;
      String str = this.indent;
      localWriter.write(str);
      i += 1;
    }
  }

  private JsonWriter open(JsonScope paramJsonScope, String paramString)
    throws IOException
  {
    beforeValue(1);
    boolean bool = this.stack.add(paramJsonScope);
    this.out.write(paramString);
    return this;
  }

  private JsonScope peek()
  {
    List localList = this.stack;
    int i = this.stack.size() + -1;
    return (JsonScope)localList.get(i);
  }

  private void replaceTop(JsonScope paramJsonScope)
  {
    List localList = this.stack;
    int i = this.stack.size() + -1;
    Object localObject = localList.set(i, paramJsonScope);
  }

  private void string(String paramString)
    throws IOException
  {
    this.out.write("\"");
    int i = 0;
    int j = paramString.length();
    if (i < j)
    {
      int k = paramString.charAt(i);
      switch (k)
      {
      default:
        if (k > 31)
          break;
        Writer localWriter1 = this.out;
        Object[] arrayOfObject1 = new Object[1];
        Integer localInteger1 = Integer.valueOf(k);
        arrayOfObject1[0] = localInteger1;
        String str1 = String.format("\\u%04x", arrayOfObject1);
        localWriter1.write(str1);
      case 34:
      case 92:
      case 9:
      case 8:
      case 10:
      case 13:
      case 12:
      case 38:
      case 39:
      case 60:
      case 61:
      case 62:
      }
      while (true)
      {
        i += 1;
        break;
        this.out.write(92);
        this.out.write(k);
        continue;
        this.out.write("\\t");
        continue;
        this.out.write("\\b");
        continue;
        this.out.write("\\n");
        continue;
        this.out.write("\\r");
        continue;
        this.out.write("\\f");
        continue;
        if (this.htmlSafe)
        {
          Writer localWriter2 = this.out;
          Object[] arrayOfObject2 = new Object[1];
          Integer localInteger2 = Integer.valueOf(k);
          arrayOfObject2[0] = localInteger2;
          String str2 = String.format("\\u%04x", arrayOfObject2);
          localWriter2.write(str2);
          continue;
        }
        this.out.write(k);
        continue;
        this.out.write(k);
      }
    }
    this.out.write("\"");
  }

  public JsonWriter beginArray()
    throws IOException
  {
    JsonScope localJsonScope = JsonScope.EMPTY_ARRAY;
    return open(localJsonScope, "[");
  }

  public JsonWriter beginObject()
    throws IOException
  {
    JsonScope localJsonScope = JsonScope.EMPTY_OBJECT;
    return open(localJsonScope, "{");
  }

  public void close()
    throws IOException
  {
    this.out.close();
    JsonScope localJsonScope1 = peek();
    JsonScope localJsonScope2 = JsonScope.NONEMPTY_DOCUMENT;
    if (localJsonScope1 != localJsonScope2)
      throw new IOException("Incomplete document");
  }

  public JsonWriter endArray()
    throws IOException
  {
    JsonScope localJsonScope1 = JsonScope.EMPTY_ARRAY;
    JsonScope localJsonScope2 = JsonScope.NONEMPTY_ARRAY;
    return close(localJsonScope1, localJsonScope2, "]");
  }

  public JsonWriter endObject()
    throws IOException
  {
    JsonScope localJsonScope1 = JsonScope.EMPTY_OBJECT;
    JsonScope localJsonScope2 = JsonScope.NONEMPTY_OBJECT;
    return close(localJsonScope1, localJsonScope2, "}");
  }

  public void flush()
    throws IOException
  {
    this.out.flush();
  }

  public boolean isHtmlSafe()
  {
    return this.htmlSafe;
  }

  public boolean isLenient()
  {
    return this.lenient;
  }

  public JsonWriter name(String paramString)
    throws IOException
  {
    if (paramString == null)
      throw new NullPointerException("name == null");
    beforeName();
    string(paramString);
    return this;
  }

  public JsonWriter nullValue()
    throws IOException
  {
    beforeValue(0);
    this.out.write("null");
    return this;
  }

  public void setHtmlSafe(boolean paramBoolean)
  {
    this.htmlSafe = paramBoolean;
  }

  public void setIndent(String paramString)
  {
    if (paramString.length() == 0)
      this.indent = null;
    for (this.separator = ":"; ; this.separator = ": ")
    {
      return;
      this.indent = paramString;
    }
  }

  public void setLenient(boolean paramBoolean)
  {
    this.lenient = paramBoolean;
  }

  public JsonWriter value(double paramDouble)
    throws IOException
  {
    if ((Double.isNaN(paramDouble)) || (Double.isInfinite(paramDouble)))
    {
      String str1 = "Numeric values must be finite, but was " + paramDouble;
      throw new IllegalArgumentException(str1);
    }
    beforeValue(0);
    Writer localWriter1 = this.out;
    String str2 = Double.toString(paramDouble);
    Writer localWriter2 = localWriter1.append(str2);
    return this;
  }

  public JsonWriter value(long paramLong)
    throws IOException
  {
    beforeValue(0);
    Writer localWriter = this.out;
    String str = Long.toString(paramLong);
    localWriter.write(str);
    return this;
  }

  public JsonWriter value(Number paramNumber)
    throws IOException
  {
    if (paramNumber == null)
      this = nullValue();
    while (true)
    {
      return this;
      String str1 = paramNumber.toString();
      if ((!this.lenient) && ((str1.equals("-Infinity")) || (str1.equals("Infinity")) || (str1.equals("NaN"))))
      {
        String str2 = "Numeric values must be finite, but was " + paramNumber;
        throw new IllegalArgumentException(str2);
      }
      beforeValue(0);
      Writer localWriter = this.out.append(str1);
    }
  }

  public JsonWriter value(String paramString)
    throws IOException
  {
    if (paramString == null)
      this = nullValue();
    while (true)
    {
      return this;
      beforeValue(0);
      string(paramString);
    }
  }

  public JsonWriter value(boolean paramBoolean)
    throws IOException
  {
    beforeValue(0);
    Writer localWriter = this.out;
    if (paramBoolean);
    for (String str = "true"; ; str = "false")
    {
      localWriter.write(str);
      return this;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.stream.JsonWriter
 * JD-Core Version:    0.6.0
 */