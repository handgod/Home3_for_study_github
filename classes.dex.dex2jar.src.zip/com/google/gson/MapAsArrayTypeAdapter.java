package com.google.gson;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

final class MapAsArrayTypeAdapter extends BaseMapTypeAdapter
  implements JsonSerializer<Map<?, ?>>, JsonDeserializer<Map<?, ?>>
{
  private void checkSize(Object paramObject1, int paramInt1, Object paramObject2, int paramInt2)
  {
    if (paramInt1 != paramInt2)
    {
      String str = "Input size " + paramInt1 + " != output size " + paramInt2 + " for input " + paramObject1 + " and output " + paramObject2;
      throw new JsonSyntaxException(str);
    }
  }

  private Type[] typeToTypeArguments(Type paramType)
  {
    Type[] arrayOfType;
    if ((paramType instanceof ParameterizedType))
    {
      arrayOfType = ((ParameterizedType)paramType).getActualTypeArguments();
      if (arrayOfType.length != 2)
      {
        String str = "MapAsArrayTypeAdapter cannot handle " + paramType;
        throw new IllegalArgumentException(str);
      }
    }
    else
    {
      arrayOfType = new Type[2];
      arrayOfType[0] = Object.class;
      arrayOfType[1] = Object.class;
    }
    return arrayOfType;
  }

  public Map<?, ?> deserialize(JsonElement paramJsonElement, Type paramType, JsonDeserializationContext paramJsonDeserializationContext)
    throws JsonParseException
  {
    Map localMap = constructMapType(paramType, paramJsonDeserializationContext);
    Type[] arrayOfType = typeToTypeArguments(paramType);
    if (paramJsonElement.isJsonArray())
    {
      JsonArray localJsonArray1 = paramJsonElement.getAsJsonArray();
      int i = 0;
      while (true)
      {
        int j = localJsonArray1.size();
        if (i >= j)
          break;
        JsonArray localJsonArray2 = localJsonArray1.get(i).getAsJsonArray();
        JsonElement localJsonElement1 = localJsonArray2.get(0);
        Type localType1 = arrayOfType[0];
        Object localObject1 = paramJsonDeserializationContext.deserialize(localJsonElement1, localType1);
        JsonElement localJsonElement2 = localJsonArray2.get(1);
        Type localType2 = arrayOfType[1];
        Object localObject2 = paramJsonDeserializationContext.deserialize(localJsonElement2, localType2);
        Object localObject3 = localMap.put(localObject1, localObject2);
        i += 1;
      }
      int k = localJsonArray1.size();
      int m = localMap.size();
      checkSize(localJsonArray1, k, localMap, m);
    }
    while (true)
    {
      return localMap;
      JsonObject localJsonObject = paramJsonElement.getAsJsonObject();
      Iterator localIterator = localJsonObject.entrySet().iterator();
      while (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        String str = (String)localEntry.getKey();
        JsonPrimitive localJsonPrimitive = new JsonPrimitive(str);
        Type localType3 = arrayOfType[0];
        Object localObject4 = paramJsonDeserializationContext.deserialize(localJsonPrimitive, localType3);
        JsonElement localJsonElement3 = (JsonElement)localEntry.getValue();
        Type localType4 = arrayOfType[1];
        Object localObject5 = paramJsonDeserializationContext.deserialize(localJsonElement3, localType4);
        Object localObject6 = localMap.put(localObject4, localObject5);
      }
      int n = localJsonObject.entrySet().size();
      int i1 = localMap.size();
      checkSize(localJsonObject, n, localMap, i1);
    }
  }

  public JsonElement serialize(Map<?, ?> paramMap, Type paramType, JsonSerializationContext paramJsonSerializationContext)
  {
    Type[] arrayOfType = typeToTypeArguments(paramType);
    int i = 0;
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramMap.entrySet().iterator();
    if (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      Object localObject1 = localEntry.getKey();
      Type localType1 = arrayOfType[0];
      JsonElement localJsonElement1 = serialize(paramJsonSerializationContext, localObject1, localType1);
      if ((localJsonElement1.isJsonObject()) || (localJsonElement1.isJsonArray()));
      for (int j = 1; ; j = 0)
      {
        i |= j;
        boolean bool1 = localArrayList.add(localJsonElement1);
        Object localObject2 = localEntry.getValue();
        Type localType2 = arrayOfType[1];
        JsonElement localJsonElement2 = serialize(paramJsonSerializationContext, localObject2, localType2);
        boolean bool2 = localArrayList.add(localJsonElement2);
        break;
      }
    }
    if (i != 0)
    {
      localObject3 = new JsonArray();
      k = 0;
      while (true)
      {
        int m = localArrayList.size();
        if (k >= m)
          break;
        JsonArray localJsonArray = new JsonArray();
        JsonElement localJsonElement3 = (JsonElement)localArrayList.get(k);
        localJsonArray.add(localJsonElement3);
        int n = k + 1;
        JsonElement localJsonElement4 = (JsonElement)localArrayList.get(n);
        localJsonArray.add(localJsonElement4);
        ((JsonArray)localObject3).add(localJsonArray);
        k += 2;
      }
    }
    Object localObject3 = new JsonObject();
    int k = 0;
    while (true)
    {
      int i1 = localArrayList.size();
      if (k >= i1)
        break;
      String str = ((JsonElement)localArrayList.get(k)).getAsString();
      int i2 = k + 1;
      JsonElement localJsonElement5 = (JsonElement)localArrayList.get(i2);
      ((JsonObject)localObject3).add(str, localJsonElement5);
      k += 2;
    }
    int i3 = paramMap.size();
    int i4 = ((JsonObject)localObject3).entrySet().size();
    checkSize(paramMap, i3, localObject3, i4);
    return (JsonElement)localObject3;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.MapAsArrayTypeAdapter
 * JD-Core Version:    0.6.0
 */