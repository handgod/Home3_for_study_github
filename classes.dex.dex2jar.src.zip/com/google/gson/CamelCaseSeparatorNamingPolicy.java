package com.google.gson;

import com.google.gson.internal..Gson.Preconditions;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.Collection;

final class CamelCaseSeparatorNamingPolicy extends RecursiveFieldNamingPolicy
{
  private final String separatorString;

  public CamelCaseSeparatorNamingPolicy(String paramString)
  {
    Object localObject = .Gson.Preconditions.checkNotNull(paramString);
    if (!"".equals(paramString));
    int j;
    for (int i = 1; ; j = 0)
    {
      .Gson.Preconditions.checkArgument(i);
      this.separatorString = paramString;
      return;
    }
  }

  protected String translateName(String paramString, Type paramType, Collection<Annotation> paramCollection)
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    int i = 0;
    while (true)
    {
      int j = paramString.length();
      if (i >= j)
        break;
      char c = paramString.charAt(i);
      if ((Character.isUpperCase(c)) && (localStringBuilder1.length() != 0))
      {
        String str = this.separatorString;
        StringBuilder localStringBuilder2 = localStringBuilder1.append(str);
      }
      StringBuilder localStringBuilder3 = localStringBuilder1.append(c);
      i += 1;
    }
    return localStringBuilder1.toString();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.CamelCaseSeparatorNamingPolicy
 * JD-Core Version:    0.6.0
 */