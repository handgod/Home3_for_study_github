package com.google.gson;

import com.google.gson.internal..Gson.Preconditions;
import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class GsonBuilder
{
  private static final MapAsArrayTypeAdapter COMPLEX_KEY_MAP_TYPE_ADAPTER = new MapAsArrayTypeAdapter();
  private static final ExposeAnnotationDeserializationExclusionStrategy exposeAnnotationDeserializationExclusionStrategy;
  private static final ExposeAnnotationSerializationExclusionStrategy exposeAnnotationSerializationExclusionStrategy;
  private static final InnerClassExclusionStrategy innerClassExclusionStrategy = new InnerClassExclusionStrategy();
  private String datePattern;
  private int dateStyle;
  private final Set<ExclusionStrategy> deserializeExclusionStrategies;
  private final ParameterizedTypeHandlerMap<JsonDeserializer<?>> deserializers;
  private boolean escapeHtmlChars;
  private boolean excludeFieldsWithoutExposeAnnotation;
  private FieldNamingStrategy2 fieldNamingPolicy;
  private boolean generateNonExecutableJson;
  private double ignoreVersionsAfter;
  private final ParameterizedTypeHandlerMap<InstanceCreator<?>> instanceCreators;
  private LongSerializationPolicy longSerializationPolicy;
  private ModifierBasedExclusionStrategy modifierBasedExclusionStrategy;
  private boolean prettyPrinting;
  private final Set<ExclusionStrategy> serializeExclusionStrategies;
  private boolean serializeInnerClasses;
  private boolean serializeNulls;
  private boolean serializeSpecialFloatingPointValues;
  private final ParameterizedTypeHandlerMap<JsonSerializer<?>> serializers;
  private int timeStyle;

  static
  {
    exposeAnnotationDeserializationExclusionStrategy = new ExposeAnnotationDeserializationExclusionStrategy();
    exposeAnnotationSerializationExclusionStrategy = new ExposeAnnotationSerializationExclusionStrategy();
  }

  public GsonBuilder()
  {
    HashSet localHashSet1 = new HashSet();
    this.serializeExclusionStrategies = localHashSet1;
    HashSet localHashSet2 = new HashSet();
    this.deserializeExclusionStrategies = localHashSet2;
    Set localSet1 = this.deserializeExclusionStrategies;
    AnonymousAndLocalClassExclusionStrategy localAnonymousAndLocalClassExclusionStrategy1 = Gson.DEFAULT_ANON_LOCAL_CLASS_EXCLUSION_STRATEGY;
    boolean bool1 = localSet1.add(localAnonymousAndLocalClassExclusionStrategy1);
    Set localSet2 = this.deserializeExclusionStrategies;
    SyntheticFieldExclusionStrategy localSyntheticFieldExclusionStrategy1 = Gson.DEFAULT_SYNTHETIC_FIELD_EXCLUSION_STRATEGY;
    boolean bool2 = localSet2.add(localSyntheticFieldExclusionStrategy1);
    Set localSet3 = this.serializeExclusionStrategies;
    AnonymousAndLocalClassExclusionStrategy localAnonymousAndLocalClassExclusionStrategy2 = Gson.DEFAULT_ANON_LOCAL_CLASS_EXCLUSION_STRATEGY;
    boolean bool3 = localSet3.add(localAnonymousAndLocalClassExclusionStrategy2);
    Set localSet4 = this.serializeExclusionStrategies;
    SyntheticFieldExclusionStrategy localSyntheticFieldExclusionStrategy2 = Gson.DEFAULT_SYNTHETIC_FIELD_EXCLUSION_STRATEGY;
    boolean bool4 = localSet4.add(localSyntheticFieldExclusionStrategy2);
    this.ignoreVersionsAfter = -1.0D;
    this.serializeInnerClasses = 1;
    this.prettyPrinting = 0;
    this.escapeHtmlChars = 1;
    ModifierBasedExclusionStrategy localModifierBasedExclusionStrategy = Gson.DEFAULT_MODIFIER_BASED_EXCLUSION_STRATEGY;
    this.modifierBasedExclusionStrategy = localModifierBasedExclusionStrategy;
    this.excludeFieldsWithoutExposeAnnotation = 0;
    LongSerializationPolicy localLongSerializationPolicy = LongSerializationPolicy.DEFAULT;
    this.longSerializationPolicy = localLongSerializationPolicy;
    FieldNamingStrategy2 localFieldNamingStrategy2 = Gson.DEFAULT_NAMING_POLICY;
    this.fieldNamingPolicy = localFieldNamingStrategy2;
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap1 = new ParameterizedTypeHandlerMap();
    this.instanceCreators = localParameterizedTypeHandlerMap1;
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap2 = new ParameterizedTypeHandlerMap();
    this.serializers = localParameterizedTypeHandlerMap2;
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap3 = new ParameterizedTypeHandlerMap();
    this.deserializers = localParameterizedTypeHandlerMap3;
    this.serializeNulls = 0;
    this.dateStyle = 2;
    this.timeStyle = 2;
    this.serializeSpecialFloatingPointValues = 0;
    this.generateNonExecutableJson = 0;
  }

  private static void addTypeAdaptersForDate(String paramString, int paramInt1, int paramInt2, ParameterizedTypeHandlerMap<JsonSerializer<?>> paramParameterizedTypeHandlerMap, ParameterizedTypeHandlerMap<JsonDeserializer<?>> paramParameterizedTypeHandlerMap1)
  {
    DefaultTypeAdapters.DefaultDateTypeAdapter localDefaultDateTypeAdapter = null;
    if (paramString != null)
    {
      String str = paramString.trim();
      if ("".equals(str));
    }
    for (localDefaultDateTypeAdapter = new DefaultTypeAdapters.DefaultDateTypeAdapter(paramString); ; localDefaultDateTypeAdapter = new DefaultTypeAdapters.DefaultDateTypeAdapter(paramInt1, paramInt2))
      do
      {
        if (localDefaultDateTypeAdapter != null)
        {
          registerIfAbsent(java.util.Date.class, paramParameterizedTypeHandlerMap, localDefaultDateTypeAdapter);
          registerIfAbsent(java.util.Date.class, paramParameterizedTypeHandlerMap1, localDefaultDateTypeAdapter);
          registerIfAbsent(Timestamp.class, paramParameterizedTypeHandlerMap, localDefaultDateTypeAdapter);
          registerIfAbsent(Timestamp.class, paramParameterizedTypeHandlerMap1, localDefaultDateTypeAdapter);
          registerIfAbsent(java.sql.Date.class, paramParameterizedTypeHandlerMap, localDefaultDateTypeAdapter);
          registerIfAbsent(java.sql.Date.class, paramParameterizedTypeHandlerMap1, localDefaultDateTypeAdapter);
        }
        return;
      }
      while ((paramInt1 == 2) || (paramInt2 == 2));
  }

  private <T> GsonBuilder registerDeserializer(Type paramType, JsonDeserializer<T> paramJsonDeserializer)
  {
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap = this.deserializers;
    JsonDeserializerExceptionWrapper localJsonDeserializerExceptionWrapper = new JsonDeserializerExceptionWrapper(paramJsonDeserializer);
    localParameterizedTypeHandlerMap.register(paramType, localJsonDeserializerExceptionWrapper);
    return this;
  }

  private <T> GsonBuilder registerDeserializerForTypeHierarchy(Class<?> paramClass, JsonDeserializer<T> paramJsonDeserializer)
  {
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap = this.deserializers;
    JsonDeserializerExceptionWrapper localJsonDeserializerExceptionWrapper = new JsonDeserializerExceptionWrapper(paramJsonDeserializer);
    localParameterizedTypeHandlerMap.registerForTypeHierarchy(paramClass, localJsonDeserializerExceptionWrapper);
    return this;
  }

  private static <T> void registerIfAbsent(Class<?> paramClass, ParameterizedTypeHandlerMap<T> paramParameterizedTypeHandlerMap, T paramT)
  {
    if (!paramParameterizedTypeHandlerMap.hasSpecificHandlerFor(paramClass))
      paramParameterizedTypeHandlerMap.register(paramClass, paramT);
  }

  private <T> GsonBuilder registerInstanceCreator(Type paramType, InstanceCreator<? extends T> paramInstanceCreator)
  {
    this.instanceCreators.register(paramType, paramInstanceCreator);
    return this;
  }

  private <T> GsonBuilder registerInstanceCreatorForTypeHierarchy(Class<?> paramClass, InstanceCreator<? extends T> paramInstanceCreator)
  {
    this.instanceCreators.registerForTypeHierarchy(paramClass, paramInstanceCreator);
    return this;
  }

  private <T> GsonBuilder registerSerializer(Type paramType, JsonSerializer<T> paramJsonSerializer)
  {
    this.serializers.register(paramType, paramJsonSerializer);
    return this;
  }

  private <T> GsonBuilder registerSerializerForTypeHierarchy(Class<?> paramClass, JsonSerializer<T> paramJsonSerializer)
  {
    this.serializers.registerForTypeHierarchy(paramClass, paramJsonSerializer);
    return this;
  }

  public GsonBuilder addDeserializationExclusionStrategy(ExclusionStrategy paramExclusionStrategy)
  {
    boolean bool = this.deserializeExclusionStrategies.add(paramExclusionStrategy);
    return this;
  }

  public GsonBuilder addSerializationExclusionStrategy(ExclusionStrategy paramExclusionStrategy)
  {
    boolean bool = this.serializeExclusionStrategies.add(paramExclusionStrategy);
    return this;
  }

  public Gson create()
  {
    Set localSet1 = this.deserializeExclusionStrategies;
    LinkedList localLinkedList1 = new LinkedList(localSet1);
    Set localSet2 = this.serializeExclusionStrategies;
    LinkedList localLinkedList2 = new LinkedList(localSet2);
    ModifierBasedExclusionStrategy localModifierBasedExclusionStrategy1 = this.modifierBasedExclusionStrategy;
    boolean bool1 = localLinkedList1.add(localModifierBasedExclusionStrategy1);
    ModifierBasedExclusionStrategy localModifierBasedExclusionStrategy2 = this.modifierBasedExclusionStrategy;
    boolean bool2 = localLinkedList2.add(localModifierBasedExclusionStrategy2);
    if (!this.serializeInnerClasses)
    {
      InnerClassExclusionStrategy localInnerClassExclusionStrategy1 = innerClassExclusionStrategy;
      boolean bool3 = localLinkedList1.add(localInnerClassExclusionStrategy1);
      InnerClassExclusionStrategy localInnerClassExclusionStrategy2 = innerClassExclusionStrategy;
      boolean bool4 = localLinkedList2.add(localInnerClassExclusionStrategy2);
    }
    if (this.ignoreVersionsAfter != -1.0D)
    {
      double d = this.ignoreVersionsAfter;
      VersionExclusionStrategy localVersionExclusionStrategy = new VersionExclusionStrategy(d);
      boolean bool5 = localLinkedList1.add(localVersionExclusionStrategy);
      boolean bool6 = localLinkedList2.add(localVersionExclusionStrategy);
    }
    if (this.excludeFieldsWithoutExposeAnnotation)
    {
      ExposeAnnotationDeserializationExclusionStrategy localExposeAnnotationDeserializationExclusionStrategy = exposeAnnotationDeserializationExclusionStrategy;
      boolean bool7 = localLinkedList1.add(localExposeAnnotationDeserializationExclusionStrategy);
      ExposeAnnotationSerializationExclusionStrategy localExposeAnnotationSerializationExclusionStrategy = exposeAnnotationSerializationExclusionStrategy;
      boolean bool8 = localLinkedList2.add(localExposeAnnotationSerializationExclusionStrategy);
    }
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap1 = DefaultTypeAdapters.DEFAULT_HIERARCHY_SERIALIZERS.copyOf();
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap2 = this.serializers.copyOf();
    localParameterizedTypeHandlerMap1.register(localParameterizedTypeHandlerMap2);
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap3 = DefaultTypeAdapters.DEFAULT_HIERARCHY_DESERIALIZERS.copyOf();
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap4 = this.deserializers.copyOf();
    localParameterizedTypeHandlerMap3.register(localParameterizedTypeHandlerMap4);
    String str = this.datePattern;
    int i = this.dateStyle;
    int j = this.timeStyle;
    addTypeAdaptersForDate(str, i, j, localParameterizedTypeHandlerMap1, localParameterizedTypeHandlerMap3);
    boolean bool9 = this.serializeSpecialFloatingPointValues;
    LongSerializationPolicy localLongSerializationPolicy = this.longSerializationPolicy;
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap5 = DefaultTypeAdapters.getDefaultSerializers(bool9, localLongSerializationPolicy);
    localParameterizedTypeHandlerMap1.registerIfAbsent(localParameterizedTypeHandlerMap5);
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap6 = DefaultTypeAdapters.getDefaultDeserializers();
    localParameterizedTypeHandlerMap3.registerIfAbsent(localParameterizedTypeHandlerMap6);
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap7 = this.instanceCreators.copyOf();
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap8 = DefaultTypeAdapters.getDefaultInstanceCreators();
    localParameterizedTypeHandlerMap7.registerIfAbsent(localParameterizedTypeHandlerMap8);
    localParameterizedTypeHandlerMap1.makeUnmodifiable();
    localParameterizedTypeHandlerMap3.makeUnmodifiable();
    this.instanceCreators.makeUnmodifiable();
    MappedObjectConstructor localMappedObjectConstructor = new MappedObjectConstructor(localParameterizedTypeHandlerMap7);
    DisjunctionExclusionStrategy localDisjunctionExclusionStrategy1 = new DisjunctionExclusionStrategy(localLinkedList1);
    DisjunctionExclusionStrategy localDisjunctionExclusionStrategy2 = new DisjunctionExclusionStrategy(localLinkedList2);
    FieldNamingStrategy2 localFieldNamingStrategy2 = this.fieldNamingPolicy;
    boolean bool10 = this.serializeNulls;
    boolean bool11 = this.generateNonExecutableJson;
    boolean bool12 = this.escapeHtmlChars;
    boolean bool13 = this.prettyPrinting;
    return new Gson(localDisjunctionExclusionStrategy1, localDisjunctionExclusionStrategy2, localFieldNamingStrategy2, localMappedObjectConstructor, bool10, localParameterizedTypeHandlerMap1, localParameterizedTypeHandlerMap3, bool11, bool12, bool13);
  }

  public GsonBuilder disableHtmlEscaping()
  {
    this.escapeHtmlChars = 0;
    return this;
  }

  public GsonBuilder disableInnerClassSerialization()
  {
    this.serializeInnerClasses = 0;
    return this;
  }

  public GsonBuilder enableComplexMapKeySerialization()
  {
    MapAsArrayTypeAdapter localMapAsArrayTypeAdapter = COMPLEX_KEY_MAP_TYPE_ADAPTER;
    GsonBuilder localGsonBuilder = registerTypeHierarchyAdapter(Map.class, localMapAsArrayTypeAdapter);
    return this;
  }

  public GsonBuilder excludeFieldsWithModifiers(int[] paramArrayOfInt)
  {
    ModifierBasedExclusionStrategy localModifierBasedExclusionStrategy = new ModifierBasedExclusionStrategy(paramArrayOfInt);
    this.modifierBasedExclusionStrategy = localModifierBasedExclusionStrategy;
    return this;
  }

  public GsonBuilder excludeFieldsWithoutExposeAnnotation()
  {
    this.excludeFieldsWithoutExposeAnnotation = 1;
    return this;
  }

  public GsonBuilder generateNonExecutableJson()
  {
    this.generateNonExecutableJson = 1;
    return this;
  }

  public GsonBuilder registerTypeAdapter(Type paramType, Object paramObject)
  {
    if (((paramObject instanceof JsonSerializer)) || ((paramObject instanceof JsonDeserializer)) || ((paramObject instanceof InstanceCreator)));
    int j;
    for (int i = 1; ; j = 0)
    {
      .Gson.Preconditions.checkArgument(i);
      if ((paramObject instanceof InstanceCreator))
      {
        InstanceCreator localInstanceCreator = (InstanceCreator)paramObject;
        GsonBuilder localGsonBuilder1 = registerInstanceCreator(paramType, localInstanceCreator);
      }
      if ((paramObject instanceof JsonSerializer))
      {
        JsonSerializer localJsonSerializer = (JsonSerializer)paramObject;
        GsonBuilder localGsonBuilder2 = registerSerializer(paramType, localJsonSerializer);
      }
      if ((paramObject instanceof JsonDeserializer))
      {
        JsonDeserializer localJsonDeserializer = (JsonDeserializer)paramObject;
        GsonBuilder localGsonBuilder3 = registerDeserializer(paramType, localJsonDeserializer);
      }
      return this;
    }
  }

  public GsonBuilder registerTypeHierarchyAdapter(Class<?> paramClass, Object paramObject)
  {
    if (((paramObject instanceof JsonSerializer)) || ((paramObject instanceof JsonDeserializer)) || ((paramObject instanceof InstanceCreator)));
    int j;
    for (int i = 1; ; j = 0)
    {
      .Gson.Preconditions.checkArgument(i);
      if ((paramObject instanceof InstanceCreator))
      {
        InstanceCreator localInstanceCreator = (InstanceCreator)paramObject;
        GsonBuilder localGsonBuilder1 = registerInstanceCreatorForTypeHierarchy(paramClass, localInstanceCreator);
      }
      if ((paramObject instanceof JsonSerializer))
      {
        JsonSerializer localJsonSerializer = (JsonSerializer)paramObject;
        GsonBuilder localGsonBuilder2 = registerSerializerForTypeHierarchy(paramClass, localJsonSerializer);
      }
      if ((paramObject instanceof JsonDeserializer))
      {
        JsonDeserializer localJsonDeserializer = (JsonDeserializer)paramObject;
        GsonBuilder localGsonBuilder3 = registerDeserializerForTypeHierarchy(paramClass, localJsonDeserializer);
      }
      return this;
    }
  }

  public GsonBuilder serializeNulls()
  {
    this.serializeNulls = 1;
    return this;
  }

  public GsonBuilder serializeSpecialFloatingPointValues()
  {
    this.serializeSpecialFloatingPointValues = 1;
    return this;
  }

  public GsonBuilder setDateFormat(int paramInt)
  {
    this.dateStyle = paramInt;
    this.datePattern = null;
    return this;
  }

  public GsonBuilder setDateFormat(int paramInt1, int paramInt2)
  {
    this.dateStyle = paramInt1;
    this.timeStyle = paramInt2;
    this.datePattern = null;
    return this;
  }

  public GsonBuilder setDateFormat(String paramString)
  {
    this.datePattern = paramString;
    return this;
  }

  public GsonBuilder setExclusionStrategies(ExclusionStrategy[] paramArrayOfExclusionStrategy)
  {
    List localList = Arrays.asList(paramArrayOfExclusionStrategy);
    boolean bool1 = this.serializeExclusionStrategies.addAll(localList);
    boolean bool2 = this.deserializeExclusionStrategies.addAll(localList);
    return this;
  }

  public GsonBuilder setFieldNamingPolicy(FieldNamingPolicy paramFieldNamingPolicy)
  {
    FieldNamingStrategy2 localFieldNamingStrategy2 = paramFieldNamingPolicy.getFieldNamingPolicy();
    return setFieldNamingStrategy(localFieldNamingStrategy2);
  }

  GsonBuilder setFieldNamingStrategy(FieldNamingStrategy2 paramFieldNamingStrategy2)
  {
    SerializedNameAnnotationInterceptingNamingPolicy localSerializedNameAnnotationInterceptingNamingPolicy = new SerializedNameAnnotationInterceptingNamingPolicy(paramFieldNamingStrategy2);
    this.fieldNamingPolicy = localSerializedNameAnnotationInterceptingNamingPolicy;
    return this;
  }

  public GsonBuilder setFieldNamingStrategy(FieldNamingStrategy paramFieldNamingStrategy)
  {
    FieldNamingStrategy2Adapter localFieldNamingStrategy2Adapter = new FieldNamingStrategy2Adapter(paramFieldNamingStrategy);
    return setFieldNamingStrategy(localFieldNamingStrategy2Adapter);
  }

  public GsonBuilder setLongSerializationPolicy(LongSerializationPolicy paramLongSerializationPolicy)
  {
    this.longSerializationPolicy = paramLongSerializationPolicy;
    return this;
  }

  public GsonBuilder setPrettyPrinting()
  {
    this.prettyPrinting = 1;
    return this;
  }

  public GsonBuilder setVersion(double paramDouble)
  {
    this.ignoreVersionsAfter = paramDouble;
    return this;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.GsonBuilder
 * JD-Core Version:    0.6.0
 */