package com.google.gson;

final class UnsafeAllocator$4 extends UnsafeAllocator
{
  public <T> T newInstance(Class<T> paramClass)
  {
    String str = "Cannot allocate " + paramClass;
    throw new UnsupportedOperationException(str);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.UnsafeAllocator.4
 * JD-Core Version:    0.6.0
 */