package com.google.gson;

import com.google.gson.annotations.Since;
import com.google.gson.annotations.Until;
import com.google.gson.internal..Gson.Preconditions;

final class VersionExclusionStrategy
  implements ExclusionStrategy
{
  private final double version;

  VersionExclusionStrategy(double paramDouble)
  {
    if (paramDouble >= 0.0D);
    int j;
    for (int i = 1; ; j = 0)
    {
      .Gson.Preconditions.checkArgument(i);
      this.version = paramDouble;
      return;
    }
  }

  private boolean isValidSince(Since paramSince)
  {
    if (paramSince != null)
    {
      double d1 = paramSince.value();
      double d2 = this.version;
      if (d1 <= d2);
    }
    for (int i = 0; ; i = 1)
      return i;
  }

  private boolean isValidUntil(Until paramUntil)
  {
    if (paramUntil != null)
    {
      double d1 = paramUntil.value();
      double d2 = this.version;
      if (d1 > d2);
    }
    for (int i = 0; ; i = 1)
      return i;
  }

  private boolean isValidVersion(Since paramSince, Until paramUntil)
  {
    if ((isValidSince(paramSince)) && (isValidUntil(paramUntil)));
    for (int i = 1; ; i = 0)
      return i;
  }

  public boolean shouldSkipClass(Class<?> paramClass)
  {
    Since localSince = (Since)paramClass.getAnnotation(Since.class);
    Until localUntil = (Until)paramClass.getAnnotation(Until.class);
    if (!isValidVersion(localSince, localUntil));
    for (int i = 1; ; i = 0)
      return i;
  }

  public boolean shouldSkipField(FieldAttributes paramFieldAttributes)
  {
    Since localSince = (Since)paramFieldAttributes.getAnnotation(Since.class);
    Until localUntil = (Until)paramFieldAttributes.getAnnotation(Until.class);
    if (!isValidVersion(localSince, localUntil));
    for (int i = 1; ; i = 0)
      return i;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.VersionExclusionStrategy
 * JD-Core Version:    0.6.0
 */