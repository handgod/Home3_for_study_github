package com.google.gson;

final class SyntheticFieldExclusionStrategy
  implements ExclusionStrategy
{
  private final boolean skipSyntheticFields;

  SyntheticFieldExclusionStrategy(boolean paramBoolean)
  {
    this.skipSyntheticFields = paramBoolean;
  }

  public boolean shouldSkipClass(Class<?> paramClass)
  {
    return false;
  }

  public boolean shouldSkipField(FieldAttributes paramFieldAttributes)
  {
    if ((this.skipSyntheticFields) && (paramFieldAttributes.isSynthetic()));
    for (int i = 1; ; i = 0)
      return i;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.SyntheticFieldExclusionStrategy
 * JD-Core Version:    0.6.0
 */