package com.google.gson;

import java.lang.reflect.Type;

final class JsonDeserializationContextDefault
  implements JsonDeserializationContext
{
  private final ParameterizedTypeHandlerMap<JsonDeserializer<?>> deserializers;
  private final FieldNamingStrategy2 fieldNamingPolicy;
  private final MappedObjectConstructor objectConstructor;
  private final ObjectNavigator objectNavigator;

  JsonDeserializationContextDefault(ObjectNavigator paramObjectNavigator, FieldNamingStrategy2 paramFieldNamingStrategy2, ParameterizedTypeHandlerMap<JsonDeserializer<?>> paramParameterizedTypeHandlerMap, MappedObjectConstructor paramMappedObjectConstructor)
  {
    this.objectNavigator = paramObjectNavigator;
    this.fieldNamingPolicy = paramFieldNamingStrategy2;
    this.deserializers = paramParameterizedTypeHandlerMap;
    this.objectConstructor = paramMappedObjectConstructor;
  }

  private <T> T fromJsonArray(Type paramType, JsonArray paramJsonArray, JsonDeserializationContext paramJsonDeserializationContext)
    throws JsonParseException
  {
    ObjectNavigator localObjectNavigator1 = this.objectNavigator;
    FieldNamingStrategy2 localFieldNamingStrategy2 = this.fieldNamingPolicy;
    MappedObjectConstructor localMappedObjectConstructor = this.objectConstructor;
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap = this.deserializers;
    JsonArray localJsonArray = paramJsonArray;
    Type localType = paramType;
    JsonDeserializationContext localJsonDeserializationContext = paramJsonDeserializationContext;
    JsonArrayDeserializationVisitor localJsonArrayDeserializationVisitor = new JsonArrayDeserializationVisitor(localJsonArray, localType, localObjectNavigator1, localFieldNamingStrategy2, localMappedObjectConstructor, localParameterizedTypeHandlerMap, localJsonDeserializationContext);
    ObjectNavigator localObjectNavigator2 = this.objectNavigator;
    ObjectTypePair localObjectTypePair = new ObjectTypePair(null, paramType, 1);
    localObjectNavigator2.accept(localObjectTypePair, localJsonArrayDeserializationVisitor);
    return localJsonArrayDeserializationVisitor.getTarget();
  }

  private <T> T fromJsonObject(Type paramType, JsonObject paramJsonObject, JsonDeserializationContext paramJsonDeserializationContext)
    throws JsonParseException
  {
    ObjectNavigator localObjectNavigator1 = this.objectNavigator;
    FieldNamingStrategy2 localFieldNamingStrategy2 = this.fieldNamingPolicy;
    MappedObjectConstructor localMappedObjectConstructor = this.objectConstructor;
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap = this.deserializers;
    JsonObject localJsonObject = paramJsonObject;
    Type localType = paramType;
    JsonDeserializationContext localJsonDeserializationContext = paramJsonDeserializationContext;
    JsonObjectDeserializationVisitor localJsonObjectDeserializationVisitor = new JsonObjectDeserializationVisitor(localJsonObject, localType, localObjectNavigator1, localFieldNamingStrategy2, localMappedObjectConstructor, localParameterizedTypeHandlerMap, localJsonDeserializationContext);
    ObjectNavigator localObjectNavigator2 = this.objectNavigator;
    ObjectTypePair localObjectTypePair = new ObjectTypePair(null, paramType, 1);
    localObjectNavigator2.accept(localObjectTypePair, localJsonObjectDeserializationVisitor);
    return localJsonObjectDeserializationVisitor.getTarget();
  }

  private <T> T fromJsonPrimitive(Type paramType, JsonPrimitive paramJsonPrimitive, JsonDeserializationContext paramJsonDeserializationContext)
    throws JsonParseException
  {
    ObjectNavigator localObjectNavigator1 = this.objectNavigator;
    FieldNamingStrategy2 localFieldNamingStrategy2 = this.fieldNamingPolicy;
    MappedObjectConstructor localMappedObjectConstructor = this.objectConstructor;
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap = this.deserializers;
    JsonPrimitive localJsonPrimitive = paramJsonPrimitive;
    Type localType = paramType;
    JsonDeserializationContext localJsonDeserializationContext = paramJsonDeserializationContext;
    JsonObjectDeserializationVisitor localJsonObjectDeserializationVisitor = new JsonObjectDeserializationVisitor(localJsonPrimitive, localType, localObjectNavigator1, localFieldNamingStrategy2, localMappedObjectConstructor, localParameterizedTypeHandlerMap, localJsonDeserializationContext);
    ObjectNavigator localObjectNavigator2 = this.objectNavigator;
    Object localObject = paramJsonPrimitive.getAsObject();
    ObjectTypePair localObjectTypePair = new ObjectTypePair(localObject, paramType, 1);
    localObjectNavigator2.accept(localObjectTypePair, localJsonObjectDeserializationVisitor);
    return localJsonObjectDeserializationVisitor.getTarget();
  }

  public <T> T deserialize(JsonElement paramJsonElement, Type paramType)
    throws JsonParseException
  {
    Object localObject;
    if ((paramJsonElement == null) || (paramJsonElement.isJsonNull()))
      localObject = null;
    while (true)
    {
      return localObject;
      if (paramJsonElement.isJsonArray())
      {
        JsonArray localJsonArray = paramJsonElement.getAsJsonArray();
        localObject = fromJsonArray(paramType, localJsonArray, this);
        continue;
      }
      if (paramJsonElement.isJsonObject())
      {
        JsonObject localJsonObject = paramJsonElement.getAsJsonObject();
        localObject = fromJsonObject(paramType, localJsonObject, this);
        continue;
      }
      if (!paramJsonElement.isJsonPrimitive())
        break;
      JsonPrimitive localJsonPrimitive = paramJsonElement.getAsJsonPrimitive();
      localObject = fromJsonPrimitive(paramType, localJsonPrimitive, this);
    }
    String str = "Failed parsing JSON source: " + paramJsonElement + " to Json";
    throw new JsonParseException(str);
  }

  ObjectConstructor getObjectConstructor()
  {
    return this.objectConstructor;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.JsonDeserializationContextDefault
 * JD-Core Version:    0.6.0
 */