package com.google.gson;

final class UpperCamelCaseSeparatorNamingPolicy extends CompositionFieldNamingPolicy
{
  public UpperCamelCaseSeparatorNamingPolicy(String paramString)
  {
    super(arrayOfRecursiveFieldNamingPolicy);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.UpperCamelCaseSeparatorNamingPolicy
 * JD-Core Version:    0.6.0
 */