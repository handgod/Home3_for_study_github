package com.google.gson;

import com.google.gson.internal..Gson.Preconditions;
import java.lang.reflect.Field;

final class FieldNamingStrategy2Adapter
  implements FieldNamingStrategy2
{
  private final FieldNamingStrategy adaptee;

  FieldNamingStrategy2Adapter(FieldNamingStrategy paramFieldNamingStrategy)
  {
    FieldNamingStrategy localFieldNamingStrategy = (FieldNamingStrategy).Gson.Preconditions.checkNotNull(paramFieldNamingStrategy);
    this.adaptee = localFieldNamingStrategy;
  }

  public String translateName(FieldAttributes paramFieldAttributes)
  {
    FieldNamingStrategy localFieldNamingStrategy = this.adaptee;
    Field localField = paramFieldAttributes.getFieldObject();
    return localFieldNamingStrategy.translateName(localField);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.FieldNamingStrategy2Adapter
 * JD-Core Version:    0.6.0
 */