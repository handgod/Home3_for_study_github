package com.google.gson;

final class CircularReferenceException extends RuntimeException
{
  private static final long serialVersionUID = 7444343294106513081L;
  private final Object offendingNode;

  CircularReferenceException(Object paramObject)
  {
    super("circular reference error");
    this.offendingNode = paramObject;
  }

  public IllegalStateException createDetailedException(FieldAttributes paramFieldAttributes)
  {
    String str1 = getMessage();
    StringBuilder localStringBuilder1 = new StringBuilder(str1);
    if (paramFieldAttributes != null)
    {
      StringBuilder localStringBuilder2 = localStringBuilder1.append("\n  ").append("Offending field: ");
      StringBuilder localStringBuilder3 = new StringBuilder();
      String str2 = paramFieldAttributes.getName();
      String str3 = str2 + "\n";
      StringBuilder localStringBuilder4 = localStringBuilder2.append(str3);
    }
    if (this.offendingNode != null)
    {
      StringBuilder localStringBuilder5 = localStringBuilder1.append("\n  ").append("Offending object: ");
      Object localObject = this.offendingNode;
      StringBuilder localStringBuilder6 = localStringBuilder5.append(localObject);
    }
    String str4 = localStringBuilder1.toString();
    return new IllegalStateException(str4, this);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.CircularReferenceException
 * JD-Core Version:    0.6.0
 */