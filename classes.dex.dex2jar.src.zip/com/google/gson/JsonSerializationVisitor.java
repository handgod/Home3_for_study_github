package com.google.gson;

import com.google.gson.internal..Gson.Preconditions;
import com.google.gson.internal..Gson.Types;
import java.lang.reflect.Array;
import java.lang.reflect.Type;

final class JsonSerializationVisitor
  implements ObjectNavigator.Visitor
{
  private final MemoryRefStack ancestors;
  private final JsonSerializationContext context;
  private final FieldNamingStrategy2 fieldNamingPolicy;
  private final ObjectNavigator objectNavigator;
  private JsonElement root;
  private final boolean serializeNulls;
  private final ParameterizedTypeHandlerMap<JsonSerializer<?>> serializers;

  JsonSerializationVisitor(ObjectNavigator paramObjectNavigator, FieldNamingStrategy2 paramFieldNamingStrategy2, boolean paramBoolean, ParameterizedTypeHandlerMap<JsonSerializer<?>> paramParameterizedTypeHandlerMap, JsonSerializationContext paramJsonSerializationContext, MemoryRefStack paramMemoryRefStack)
  {
    this.objectNavigator = paramObjectNavigator;
    this.fieldNamingPolicy = paramFieldNamingStrategy2;
    this.serializeNulls = paramBoolean;
    this.serializers = paramParameterizedTypeHandlerMap;
    this.context = paramJsonSerializationContext;
    this.ancestors = paramMemoryRefStack;
  }

  private void addAsArrayElement(ObjectTypePair paramObjectTypePair)
  {
    if (paramObjectTypePair.getObject() == null)
    {
      JsonArray localJsonArray = this.root.getAsJsonArray();
      JsonNull localJsonNull = JsonNull.createJsonNull();
      localJsonArray.add(localJsonNull);
    }
    while (true)
    {
      return;
      JsonElement localJsonElement = getJsonElementForChild(paramObjectTypePair);
      this.root.getAsJsonArray().add(localJsonElement);
    }
  }

  private void addAsChildOfObject(FieldAttributes paramFieldAttributes, ObjectTypePair paramObjectTypePair)
  {
    JsonElement localJsonElement = getJsonElementForChild(paramObjectTypePair);
    addChildAsElement(paramFieldAttributes, localJsonElement);
  }

  private void addChildAsElement(FieldAttributes paramFieldAttributes, JsonElement paramJsonElement)
  {
    JsonObject localJsonObject = this.root.getAsJsonObject();
    String str = this.fieldNamingPolicy.translateName(paramFieldAttributes);
    localJsonObject.add(str, paramJsonElement);
  }

  private void assignToRoot(JsonElement paramJsonElement)
  {
    JsonElement localJsonElement = (JsonElement).Gson.Preconditions.checkNotNull(paramJsonElement);
    this.root = localJsonElement;
  }

  private JsonElement findAndInvokeCustomSerializer(ObjectTypePair paramObjectTypePair)
  {
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap = this.serializers;
    Pair localPair = paramObjectTypePair.getMatchingHandler(localParameterizedTypeHandlerMap);
    Object localObject1;
    if (localPair == null)
      localObject1 = null;
    while (true)
    {
      return localObject1;
      JsonSerializer localJsonSerializer = (JsonSerializer)localPair.first;
      paramObjectTypePair = (ObjectTypePair)localPair.second;
      start(paramObjectTypePair);
      try
      {
        Object localObject2 = paramObjectTypePair.getObject();
        Type localType = paramObjectTypePair.getType();
        JsonSerializationContext localJsonSerializationContext = this.context;
        localObject1 = localJsonSerializer.serialize(localObject2, localType, localJsonSerializationContext);
        if (localObject1 == null)
        {
          JsonNull localJsonNull = JsonNull.createJsonNull();
          localObject1 = localJsonNull;
        }
        end(paramObjectTypePair);
      }
      finally
      {
        end(paramObjectTypePair);
      }
    }
  }

  private Object getFieldValue(FieldAttributes paramFieldAttributes, Object paramObject)
  {
    try
    {
      Object localObject = paramFieldAttributes.get(paramObject);
      return localObject;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
    }
    throw new RuntimeException(localIllegalAccessException);
  }

  private JsonElement getJsonElementForChild(ObjectTypePair paramObjectTypePair)
  {
    ObjectNavigator localObjectNavigator = this.objectNavigator;
    FieldNamingStrategy2 localFieldNamingStrategy2 = this.fieldNamingPolicy;
    boolean bool = this.serializeNulls;
    ParameterizedTypeHandlerMap localParameterizedTypeHandlerMap = this.serializers;
    JsonSerializationContext localJsonSerializationContext = this.context;
    MemoryRefStack localMemoryRefStack = this.ancestors;
    JsonSerializationVisitor localJsonSerializationVisitor = new JsonSerializationVisitor(localObjectNavigator, localFieldNamingStrategy2, bool, localParameterizedTypeHandlerMap, localJsonSerializationContext, localMemoryRefStack);
    this.objectNavigator.accept(paramObjectTypePair, localJsonSerializationVisitor);
    return localJsonSerializationVisitor.getJsonElement();
  }

  private boolean isFieldNull(FieldAttributes paramFieldAttributes, Object paramObject)
  {
    if (getFieldValue(paramFieldAttributes, paramObject) == null);
    for (int i = 1; ; i = 0)
      return i;
  }

  public void end(ObjectTypePair paramObjectTypePair)
  {
    if (paramObjectTypePair != null)
      ObjectTypePair localObjectTypePair = this.ancestors.pop();
  }

  public JsonElement getJsonElement()
  {
    return this.root;
  }

  public Object getTarget()
  {
    return null;
  }

  public void start(ObjectTypePair paramObjectTypePair)
  {
    if (paramObjectTypePair == null);
    while (true)
    {
      return;
      if (this.ancestors.contains(paramObjectTypePair))
        throw new CircularReferenceException(paramObjectTypePair);
      ObjectTypePair localObjectTypePair = this.ancestors.push(paramObjectTypePair);
    }
  }

  public void startVisitingObject(Object paramObject)
  {
    JsonObject localJsonObject = new JsonObject();
    assignToRoot(localJsonObject);
  }

  public void visitArray(Object paramObject, Type paramType)
  {
    JsonArray localJsonArray = new JsonArray();
    assignToRoot(localJsonArray);
    int i = Array.getLength(paramObject);
    Type localType = .Gson.Types.getArrayComponentType(paramType);
    int j = 0;
    while (j < i)
    {
      Object localObject = Array.get(paramObject, j);
      ObjectTypePair localObjectTypePair = new ObjectTypePair(localObject, localType, 0);
      addAsArrayElement(localObjectTypePair);
      j += 1;
    }
  }

  // ERROR //
  public void visitArrayField(FieldAttributes paramFieldAttributes, Type paramType, Object paramObject)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_3
    //   3: invokespecial 211	com/google/gson/JsonSerializationVisitor:isFieldNull	(Lcom/google/gson/FieldAttributes;Ljava/lang/Object;)Z
    //   6: ifeq +23 -> 29
    //   9: aload_0
    //   10: getfield 33	com/google/gson/JsonSerializationVisitor:serializeNulls	Z
    //   13: ifeq +15 -> 28
    //   16: invokestatic 61	com/google/gson/JsonNull:createJsonNull	()Lcom/google/gson/JsonNull;
    //   19: astore 4
    //   21: aload_0
    //   22: aload_1
    //   23: aload 4
    //   25: invokespecial 77	com/google/gson/JsonSerializationVisitor:addChildAsElement	(Lcom/google/gson/FieldAttributes;Lcom/google/gson/JsonElement;)V
    //   28: return
    //   29: aload_0
    //   30: aload_1
    //   31: aload_3
    //   32: invokespecial 159	com/google/gson/JsonSerializationVisitor:getFieldValue	(Lcom/google/gson/FieldAttributes;Ljava/lang/Object;)Ljava/lang/Object;
    //   35: astore 5
    //   37: new 43	com/google/gson/ObjectTypePair
    //   40: dup
    //   41: aload 5
    //   43: aload_2
    //   44: ldc 202
    //   46: invokespecial 205	com/google/gson/ObjectTypePair:<init>	(Ljava/lang/Object;Ljava/lang/reflect/Type;Z)V
    //   49: astore 6
    //   51: aload_0
    //   52: aload_1
    //   53: aload 6
    //   55: invokespecial 213	com/google/gson/JsonSerializationVisitor:addAsChildOfObject	(Lcom/google/gson/FieldAttributes;Lcom/google/gson/ObjectTypePair;)V
    //   58: goto -30 -> 28
    //   61: aload_1
    //   62: invokevirtual 217	com/google/gson/CircularReferenceException:createDetailedException	(Lcom/google/gson/FieldAttributes;)Ljava/lang/IllegalStateException;
    //   65: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   0	58	61	com/google/gson/CircularReferenceException
  }

  // ERROR //
  public boolean visitFieldUsingCustomHandler(FieldAttributes paramFieldAttributes, Type paramType, Object paramObject)
  {
    // Byte code:
    //   0: iconst_1
    //   1: istore 4
    //   3: aload_0
    //   4: getfield 49	com/google/gson/JsonSerializationVisitor:root	Lcom/google/gson/JsonElement;
    //   7: invokevirtual 223	com/google/gson/JsonElement:isJsonObject	()Z
    //   10: invokestatic 227	com/google/gson/internal/$Gson$Preconditions:checkState	(Z)V
    //   13: aload_1
    //   14: aload_3
    //   15: invokevirtual 138	com/google/gson/FieldAttributes:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   18: astore 5
    //   20: aload 5
    //   22: ifnonnull +25 -> 47
    //   25: aload_0
    //   26: getfield 33	com/google/gson/JsonSerializationVisitor:serializeNulls	Z
    //   29: ifeq +15 -> 44
    //   32: invokestatic 61	com/google/gson/JsonNull:createJsonNull	()Lcom/google/gson/JsonNull;
    //   35: astore 6
    //   37: aload_0
    //   38: aload_1
    //   39: aload 6
    //   41: invokespecial 77	com/google/gson/JsonSerializationVisitor:addChildAsElement	(Lcom/google/gson/FieldAttributes;Lcom/google/gson/JsonElement;)V
    //   44: iload 4
    //   46: ireturn
    //   47: new 43	com/google/gson/ObjectTypePair
    //   50: dup
    //   51: aload 5
    //   53: aload_2
    //   54: ldc 202
    //   56: invokespecial 205	com/google/gson/ObjectTypePair:<init>	(Ljava/lang/Object;Ljava/lang/reflect/Type;Z)V
    //   59: astore 7
    //   61: aload_0
    //   62: aload 7
    //   64: invokespecial 229	com/google/gson/JsonSerializationVisitor:findAndInvokeCustomSerializer	(Lcom/google/gson/ObjectTypePair;)Lcom/google/gson/JsonElement;
    //   67: astore 8
    //   69: aload 8
    //   71: ifnull +23 -> 94
    //   74: aload_0
    //   75: aload_1
    //   76: aload 8
    //   78: invokespecial 77	com/google/gson/JsonSerializationVisitor:addChildAsElement	(Lcom/google/gson/FieldAttributes;Lcom/google/gson/JsonElement;)V
    //   81: goto -37 -> 44
    //   84: astore 9
    //   86: new 140	java/lang/RuntimeException
    //   89: dup
    //   90: invokespecial 230	java/lang/RuntimeException:<init>	()V
    //   93: athrow
    //   94: iconst_0
    //   95: istore 4
    //   97: goto -53 -> 44
    //   100: aload_1
    //   101: invokevirtual 217	com/google/gson/CircularReferenceException:createDetailedException	(Lcom/google/gson/FieldAttributes;)Ljava/lang/IllegalStateException;
    //   104: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   3	81	84	java/lang/IllegalAccessException
    //   3	81	100	com/google/gson/CircularReferenceException
  }

  // ERROR //
  public void visitObjectField(FieldAttributes paramFieldAttributes, Type paramType, Object paramObject)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_3
    //   3: invokespecial 211	com/google/gson/JsonSerializationVisitor:isFieldNull	(Lcom/google/gson/FieldAttributes;Ljava/lang/Object;)Z
    //   6: ifeq +23 -> 29
    //   9: aload_0
    //   10: getfield 33	com/google/gson/JsonSerializationVisitor:serializeNulls	Z
    //   13: ifeq +15 -> 28
    //   16: invokestatic 61	com/google/gson/JsonNull:createJsonNull	()Lcom/google/gson/JsonNull;
    //   19: astore 4
    //   21: aload_0
    //   22: aload_1
    //   23: aload 4
    //   25: invokespecial 77	com/google/gson/JsonSerializationVisitor:addChildAsElement	(Lcom/google/gson/FieldAttributes;Lcom/google/gson/JsonElement;)V
    //   28: return
    //   29: aload_0
    //   30: aload_1
    //   31: aload_3
    //   32: invokespecial 159	com/google/gson/JsonSerializationVisitor:getFieldValue	(Lcom/google/gson/FieldAttributes;Ljava/lang/Object;)Ljava/lang/Object;
    //   35: astore 5
    //   37: new 43	com/google/gson/ObjectTypePair
    //   40: dup
    //   41: aload 5
    //   43: aload_2
    //   44: ldc 202
    //   46: invokespecial 205	com/google/gson/ObjectTypePair:<init>	(Ljava/lang/Object;Ljava/lang/reflect/Type;Z)V
    //   49: astore 6
    //   51: aload_0
    //   52: aload_1
    //   53: aload 6
    //   55: invokespecial 213	com/google/gson/JsonSerializationVisitor:addAsChildOfObject	(Lcom/google/gson/FieldAttributes;Lcom/google/gson/ObjectTypePair;)V
    //   58: goto -30 -> 28
    //   61: aload_1
    //   62: invokevirtual 217	com/google/gson/CircularReferenceException:createDetailedException	(Lcom/google/gson/FieldAttributes;)Ljava/lang/IllegalStateException;
    //   65: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   0	58	61	com/google/gson/CircularReferenceException
  }

  public void visitPrimitive(Object paramObject)
  {
    if (paramObject == null);
    for (Object localObject = JsonNull.createJsonNull(); ; localObject = new JsonPrimitive(paramObject))
    {
      assignToRoot((JsonElement)localObject);
      return;
    }
  }

  public boolean visitUsingCustomHandler(ObjectTypePair paramObjectTypePair)
  {
    for (int i = 1; ; i = 0)
      try
      {
        if (paramObjectTypePair.getObject() == null)
          if (this.serializeNulls)
          {
            JsonNull localJsonNull = JsonNull.createJsonNull();
            assignToRoot(localJsonNull);
          }
        while (true)
        {
          return i;
          JsonElement localJsonElement = findAndInvokeCustomSerializer(paramObjectTypePair);
          if (localJsonElement == null)
            break;
          assignToRoot(localJsonElement);
        }
      }
      catch (CircularReferenceException localCircularReferenceException)
      {
        throw localCircularReferenceException.createDetailedException(null);
      }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.JsonSerializationVisitor
 * JD-Core Version:    0.6.0
 */