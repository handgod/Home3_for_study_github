package com.google.gson;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.Collection;

abstract class RecursiveFieldNamingPolicy
  implements FieldNamingStrategy2
{
  public final String translateName(FieldAttributes paramFieldAttributes)
  {
    String str = paramFieldAttributes.getName();
    Type localType = paramFieldAttributes.getDeclaredType();
    Collection localCollection = paramFieldAttributes.getAnnotations();
    return translateName(str, localType, localCollection);
  }

  protected abstract String translateName(String paramString, Type paramType, Collection<Annotation> paramCollection);
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.RecursiveFieldNamingPolicy
 * JD-Core Version:    0.6.0
 */