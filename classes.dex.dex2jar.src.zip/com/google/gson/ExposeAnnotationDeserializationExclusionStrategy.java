package com.google.gson;

import com.google.gson.annotations.Expose;

final class ExposeAnnotationDeserializationExclusionStrategy
  implements ExclusionStrategy
{
  public boolean shouldSkipClass(Class<?> paramClass)
  {
    return false;
  }

  public boolean shouldSkipField(FieldAttributes paramFieldAttributes)
  {
    int i = 1;
    Expose localExpose = (Expose)paramFieldAttributes.getAnnotation(Expose.class);
    if (localExpose == null);
    while (true)
    {
      return i;
      if (!localExpose.deserialize())
        continue;
      i = 0;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.ExposeAnnotationDeserializationExclusionStrategy
 * JD-Core Version:    0.6.0
 */