package com.google.gson;

import com.google.gson.internal..Gson.Preconditions;
import com.google.gson.internal..Gson.Types;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

public final class FieldAttributes
{
  private static final Cache<Pair<Class<?>, String>, Collection<Annotation>> ANNOTATION_CACHE = ;
  private static final String MAX_CACHE_PROPERTY_NAME = "com.google.gson.annotation_cache_size_hint";
  private Collection<Annotation> annotations;
  private final Class<?> declaredType;
  private final Class<?> declaringClazz;
  private final Field field;
  private Type genericType;
  private final boolean isSynthetic;
  private final int modifiers;
  private final String name;
  private final Type resolvedType;

  static
  {
    int i = getMaxCacheSize();
    ANNOTATION_CACHE = new LruCache(i);
  }

  FieldAttributes(Class<?> paramClass, Field paramField, Type paramType)
  {
    Class localClass1 = (Class).Gson.Preconditions.checkNotNull(paramClass);
    this.declaringClazz = localClass1;
    String str = paramField.getName();
    this.name = str;
    Class localClass2 = paramField.getType();
    this.declaredType = localClass2;
    boolean bool = paramField.isSynthetic();
    this.isSynthetic = bool;
    int i = paramField.getModifiers();
    this.modifiers = i;
    this.field = paramField;
    Type localType = getTypeInfoForField(paramField, paramType);
    this.resolvedType = localType;
  }

  private static <T extends Annotation> T getAnnotationFromArray(Collection<Annotation> paramCollection, Class<T> paramClass)
  {
    Iterator localIterator = paramCollection.iterator();
    Annotation localAnnotation;
    do
    {
      if (!localIterator.hasNext())
        break;
      localAnnotation = (Annotation)localIterator.next();
    }
    while (localAnnotation.annotationType() != paramClass);
    while (true)
    {
      return localAnnotation;
      localAnnotation = null;
    }
  }

  private static int getMaxCacheSize()
  {
    int i = 2000;
    try
    {
      String str = String.valueOf(2000);
      int j = Integer.parseInt(System.getProperty("com.google.gson.annotation_cache_size_hint", str));
      i = j;
      label23: return i;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      break label23;
    }
  }

  static Type getTypeInfoForField(Field paramField, Type paramType)
  {
    Class localClass = .Gson.Types.getRawType(paramType);
    if (!paramField.getDeclaringClass().isAssignableFrom(localClass));
    Type localType2;
    for (Type localType1 = paramField.getGenericType(); ; localType1 = .Gson.Types.resolve(paramType, localClass, localType2))
    {
      return localType1;
      localType2 = paramField.getGenericType();
    }
  }

  Object get(Object paramObject)
    throws IllegalAccessException
  {
    return this.field.get(paramObject);
  }

  public <T extends Annotation> T getAnnotation(Class<T> paramClass)
  {
    return getAnnotationFromArray(getAnnotations(), paramClass);
  }

  public Collection<Annotation> getAnnotations()
  {
    if (this.annotations == null)
    {
      Class localClass = this.declaringClazz;
      String str = this.name;
      Pair localPair = new Pair(localClass, str);
      Collection localCollection1 = (Collection)ANNOTATION_CACHE.getElement(localPair);
      this.annotations = localCollection1;
      if (this.annotations == null)
      {
        Collection localCollection2 = Collections.unmodifiableCollection(Arrays.asList(this.field.getAnnotations()));
        this.annotations = localCollection2;
        Cache localCache = ANNOTATION_CACHE;
        Collection localCollection3 = this.annotations;
        localCache.addElement(localPair, localCollection3);
      }
    }
    return this.annotations;
  }

  public Class<?> getDeclaredClass()
  {
    return this.declaredType;
  }

  public Type getDeclaredType()
  {
    if (this.genericType == null)
    {
      Type localType = this.field.getGenericType();
      this.genericType = localType;
    }
    return this.genericType;
  }

  public Class<?> getDeclaringClass()
  {
    return this.declaringClazz;
  }

  @Deprecated
  Field getFieldObject()
  {
    return this.field;
  }

  public String getName()
  {
    return this.name;
  }

  Type getResolvedType()
  {
    return this.resolvedType;
  }

  public boolean hasModifier(int paramInt)
  {
    if ((this.modifiers & paramInt) != 0);
    for (int i = 1; ; i = 0)
      return i;
  }

  boolean isSynthetic()
  {
    return this.isSynthetic;
  }

  void set(Object paramObject1, Object paramObject2)
    throws IllegalAccessException
  {
    this.field.set(paramObject1, paramObject2);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.FieldAttributes
 * JD-Core Version:    0.6.0
 */