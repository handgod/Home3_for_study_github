package com.google.gson;

import com.google.gson.internal..Gson.Preconditions;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;

public final class JsonPrimitive extends JsonElement
{
  private static final BigInteger INTEGER_MAX;
  private static final BigInteger LONG_MAX;
  private static final Class<?>[] PRIMITIVE_TYPES;
  private Object value;

  static
  {
    Class[] arrayOfClass = new Class[16];
    Class localClass1 = Integer.TYPE;
    arrayOfClass[0] = localClass1;
    Class localClass2 = Long.TYPE;
    arrayOfClass[1] = localClass2;
    Class localClass3 = Short.TYPE;
    arrayOfClass[2] = localClass3;
    Class localClass4 = Float.TYPE;
    arrayOfClass[3] = localClass4;
    Class localClass5 = Double.TYPE;
    arrayOfClass[4] = localClass5;
    Class localClass6 = Byte.TYPE;
    arrayOfClass[5] = localClass6;
    Class localClass7 = Boolean.TYPE;
    arrayOfClass[6] = localClass7;
    Class localClass8 = Character.TYPE;
    arrayOfClass[7] = localClass8;
    arrayOfClass[8] = Integer.class;
    arrayOfClass[9] = Long.class;
    arrayOfClass[10] = Short.class;
    arrayOfClass[11] = Float.class;
    arrayOfClass[12] = Double.class;
    arrayOfClass[13] = Byte.class;
    arrayOfClass[14] = Boolean.class;
    arrayOfClass[15] = Character.class;
    PRIMITIVE_TYPES = arrayOfClass;
    INTEGER_MAX = BigInteger.valueOf(2147483647L);
    LONG_MAX = BigInteger.valueOf(9223372036854775807L);
  }

  public JsonPrimitive(Boolean paramBoolean)
  {
    setValue(paramBoolean);
  }

  public JsonPrimitive(Character paramCharacter)
  {
    setValue(paramCharacter);
  }

  public JsonPrimitive(Number paramNumber)
  {
    setValue(paramNumber);
  }

  JsonPrimitive(Object paramObject)
  {
    setValue(paramObject);
  }

  public JsonPrimitive(String paramString)
  {
    setValue(paramString);
  }

  private static boolean isFloatingPoint(JsonPrimitive paramJsonPrimitive)
  {
    int i = 0;
    if ((paramJsonPrimitive.value instanceof Number))
    {
      Number localNumber = (Number)paramJsonPrimitive.value;
      if (((localNumber instanceof BigDecimal)) || ((localNumber instanceof Double)) || ((localNumber instanceof Float)))
        i = 1;
    }
    return i;
  }

  private static boolean isIntegral(JsonPrimitive paramJsonPrimitive)
  {
    int i = 0;
    if ((paramJsonPrimitive.value instanceof Number))
    {
      Number localNumber = (Number)paramJsonPrimitive.value;
      if (((localNumber instanceof BigInteger)) || ((localNumber instanceof Long)) || ((localNumber instanceof Integer)) || ((localNumber instanceof Short)) || ((localNumber instanceof Byte)))
        i = 1;
    }
    return i;
  }

  private static boolean isPrimitiveOrString(Object paramObject)
  {
    int i = 1;
    if ((paramObject instanceof String));
    while (true)
    {
      return i;
      Class localClass = paramObject.getClass();
      Class[] arrayOfClass = PRIMITIVE_TYPES;
      int j = arrayOfClass.length;
      int k = 0;
      while (true)
      {
        if (k >= j)
          break label54;
        if (arrayOfClass[k].isAssignableFrom(localClass))
          break;
        k += 1;
      }
      label54: i = 0;
    }
  }

  static Number stringToNumber(String paramString)
  {
    try
    {
      long l = Long.parseLong(paramString);
      if ((l >= -2147483648L) && (l <= 2147483647L));
      Long localLong;
      for (localObject = Integer.valueOf((int)l); ; localObject = localLong)
      {
        return localObject;
        localLong = Long.valueOf(l);
      }
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      while (true)
        try
        {
          localObject = new BigDecimal(paramString);
        }
        catch (NumberFormatException localNumberFormatException2)
        {
          Object localObject = Double.valueOf(Double.parseDouble(paramString));
        }
    }
  }

  public boolean equals(Object paramObject)
  {
    int i = 1;
    int j = 0;
    if (this == paramObject);
    while (true)
    {
      return i;
      if (paramObject != null)
      {
        Class localClass1 = getClass();
        Class localClass2 = paramObject.getClass();
        if (localClass1 == localClass2);
      }
      else
      {
        i = 0;
        continue;
      }
      JsonPrimitive localJsonPrimitive = (JsonPrimitive)paramObject;
      if (this.value == null)
      {
        if (localJsonPrimitive.value == null)
          continue;
        i = 0;
        continue;
      }
      if ((isIntegral(this)) && (isIntegral(localJsonPrimitive)))
      {
        long l1 = getAsNumber().longValue();
        long l2 = localJsonPrimitive.getAsNumber().longValue();
        if (l1 == l2)
          continue;
        i = 0;
        continue;
      }
      if ((isFloatingPoint(this)) && (isFloatingPoint(localJsonPrimitive)))
      {
        double d1 = getAsNumber().doubleValue();
        double d2 = localJsonPrimitive.getAsNumber().doubleValue();
        if ((d1 == d2) || ((Double.isNaN(d1)) && (Double.isNaN(d2))))
          j = 1;
        i = j;
        continue;
      }
      Object localObject1 = this.value;
      Object localObject2 = localJsonPrimitive.value;
      boolean bool = localObject1.equals(localObject2);
    }
  }

  public BigDecimal getAsBigDecimal()
  {
    if ((this.value instanceof BigDecimal));
    String str;
    for (BigDecimal localBigDecimal = (BigDecimal)this.value; ; localBigDecimal = new BigDecimal(str))
    {
      return localBigDecimal;
      str = this.value.toString();
    }
  }

  public BigInteger getAsBigInteger()
  {
    if ((this.value instanceof BigInteger));
    String str;
    for (BigInteger localBigInteger = (BigInteger)this.value; ; localBigInteger = new BigInteger(str))
    {
      return localBigInteger;
      str = this.value.toString();
    }
  }

  public boolean getAsBoolean()
  {
    if (isBoolean());
    for (boolean bool = getAsBooleanWrapper().booleanValue(); ; bool = Boolean.parseBoolean(getAsString()))
      return bool;
  }

  Boolean getAsBooleanWrapper()
  {
    return (Boolean)this.value;
  }

  public byte getAsByte()
  {
    if (isNumber());
    for (int i = getAsNumber().byteValue(); ; i = Byte.parseByte(getAsString()))
      return i;
  }

  public char getAsCharacter()
  {
    return getAsString().charAt(0);
  }

  public double getAsDouble()
  {
    double d;
    if (isNumber())
      d = getAsNumber().doubleValue();
    while (true)
    {
      return d;
      d = Double.parseDouble(getAsString());
    }
  }

  public float getAsFloat()
  {
    float f;
    if (isNumber())
      f = getAsNumber().floatValue();
    while (true)
    {
      return f;
      f = Float.parseFloat(getAsString());
    }
  }

  public int getAsInt()
  {
    if (isNumber());
    for (int i = getAsNumber().intValue(); ; i = Integer.parseInt(getAsString()))
      return i;
  }

  public long getAsLong()
  {
    long l;
    if (isNumber())
      l = getAsNumber().longValue();
    while (true)
    {
      return l;
      l = Long.parseLong(getAsString());
    }
  }

  public Number getAsNumber()
  {
    if ((this.value instanceof String));
    for (Number localNumber = stringToNumber((String)this.value); ; localNumber = (Number)this.value)
      return localNumber;
  }

  Object getAsObject()
  {
    BigInteger localBigInteger1;
    Object localObject;
    if ((this.value instanceof BigInteger))
    {
      localBigInteger1 = (BigInteger)this.value;
      BigInteger localBigInteger2 = INTEGER_MAX;
      if (localBigInteger1.compareTo(localBigInteger2) < 0)
        localObject = Integer.valueOf(localBigInteger1.intValue());
    }
    while (true)
    {
      return localObject;
      BigInteger localBigInteger3 = LONG_MAX;
      if (localBigInteger1.compareTo(localBigInteger3) < 0)
      {
        localObject = Long.valueOf(localBigInteger1.longValue());
        continue;
      }
      localObject = this.value;
    }
  }

  public short getAsShort()
  {
    if (isNumber());
    for (int i = getAsNumber().shortValue(); ; i = Short.parseShort(getAsString()))
      return i;
  }

  public String getAsString()
  {
    String str;
    if (isNumber())
      str = getAsNumber().toString();
    while (true)
    {
      return str;
      if (isBoolean())
      {
        str = getAsBooleanWrapper().toString();
        continue;
      }
      str = (String)this.value;
    }
  }

  public int hashCode()
  {
    int i;
    if (this.value == null)
      i = 31;
    while (true)
    {
      return i;
      if (isIntegral(this))
      {
        long l1 = getAsNumber().longValue();
        i = (int)(l1 >>> 32 ^ l1);
        continue;
      }
      if (isFloatingPoint(this))
      {
        long l2 = Double.doubleToLongBits(getAsNumber().doubleValue());
        i = (int)(l2 >>> 32 ^ l2);
        continue;
      }
      i = this.value.hashCode();
    }
  }

  public boolean isBoolean()
  {
    return this.value instanceof Boolean;
  }

  public boolean isNumber()
  {
    return this.value instanceof Number;
  }

  public boolean isString()
  {
    return this.value instanceof String;
  }

  void setValue(Object paramObject)
  {
    if ((paramObject instanceof Character))
    {
      String str = String.valueOf(((Character)paramObject).charValue());
      this.value = str;
      return;
    }
    if (((paramObject instanceof Number)) || (isPrimitiveOrString(paramObject)));
    int j;
    for (int i = 1; ; j = 0)
    {
      .Gson.Preconditions.checkArgument(i);
      this.value = paramObject;
      break;
    }
  }

  protected void toString(Appendable paramAppendable, Escaper paramEscaper)
    throws IOException
  {
    if (isString())
    {
      Appendable localAppendable1 = paramAppendable.append(34);
      String str1 = this.value.toString();
      String str2 = paramEscaper.escapeJsonString(str1);
      Appendable localAppendable2 = paramAppendable.append(str2);
      Appendable localAppendable3 = paramAppendable.append(34);
    }
    while (true)
    {
      return;
      String str3 = this.value.toString();
      Appendable localAppendable4 = paramAppendable.append(str3);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.JsonPrimitive
 * JD-Core Version:    0.6.0
 */