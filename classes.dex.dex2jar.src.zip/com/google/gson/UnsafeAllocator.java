package com.google.gson;

import java.io.ObjectInputStream;
import java.io.ObjectStreamClass;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

abstract class UnsafeAllocator
{
  public static UnsafeAllocator create()
  {
    try
    {
      Class localClass1 = Class.forName("sun.misc.Unsafe");
      Field localField = localClass1.getDeclaredField("theUnsafe");
      localField.setAccessible(1);
      Object localObject1 = localField.get(null);
      Class[] arrayOfClass1 = new Class[1];
      arrayOfClass1[0] = Class.class;
      Method localMethod1 = localClass1.getMethod("allocateInstance", arrayOfClass1);
      localObject2 = new UnsafeAllocator.1(localMethod1, localObject1);
      return localObject2;
    }
    catch (Exception localException1)
    {
      while (true)
        try
        {
          Class[] arrayOfClass2 = new Class[2];
          arrayOfClass2[0] = Class.class;
          arrayOfClass2[1] = Class.class;
          Method localMethod2 = ObjectInputStream.class.getDeclaredMethod("newInstance", arrayOfClass2);
          localMethod2.setAccessible(1);
          localObject2 = new UnsafeAllocator.2(localMethod2);
        }
        catch (Exception localException2)
        {
          try
          {
            Class[] arrayOfClass3 = new Class[1];
            arrayOfClass3[0] = Class.class;
            Method localMethod3 = ObjectStreamClass.class.getDeclaredMethod("getConstructorId", arrayOfClass3);
            localMethod3.setAccessible(1);
            Object[] arrayOfObject = new Object[1];
            arrayOfObject[0] = Object.class;
            int i = ((Integer)localMethod3.invoke(null, arrayOfObject)).intValue();
            Class[] arrayOfClass4 = new Class[2];
            arrayOfClass4[0] = Class.class;
            Class localClass2 = Integer.TYPE;
            arrayOfClass4[1] = localClass2;
            Method localMethod4 = ObjectStreamClass.class.getDeclaredMethod("newInstance", arrayOfClass4);
            localMethod4.setAccessible(1);
            localObject2 = new UnsafeAllocator.3(localMethod4, i);
          }
          catch (Exception localException3)
          {
            Object localObject2 = new UnsafeAllocator.4();
          }
        }
    }
  }

  public abstract <T> T newInstance(Class<T> paramClass)
    throws Exception;
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.UnsafeAllocator
 * JD-Core Version:    0.6.0
 */