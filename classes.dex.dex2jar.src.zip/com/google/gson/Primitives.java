package com.google.gson;

import com.google.gson.internal..Gson.Preconditions;
import java.lang.reflect.Type;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

final class Primitives
{
  private static final Map<Class<?>, Class<?>> PRIMITIVE_TO_WRAPPER_TYPE;
  private static final Map<Class<?>, Class<?>> WRAPPER_TO_PRIMITIVE_TYPE;

  static
  {
    HashMap localHashMap1 = new HashMap(16);
    HashMap localHashMap2 = new HashMap(16);
    Class localClass1 = Boolean.TYPE;
    add(localHashMap1, localHashMap2, localClass1, Boolean.class);
    Class localClass2 = Byte.TYPE;
    add(localHashMap1, localHashMap2, localClass2, Byte.class);
    Class localClass3 = Character.TYPE;
    add(localHashMap1, localHashMap2, localClass3, Character.class);
    Class localClass4 = Double.TYPE;
    add(localHashMap1, localHashMap2, localClass4, Double.class);
    Class localClass5 = Float.TYPE;
    add(localHashMap1, localHashMap2, localClass5, Float.class);
    Class localClass6 = Integer.TYPE;
    add(localHashMap1, localHashMap2, localClass6, Integer.class);
    Class localClass7 = Long.TYPE;
    add(localHashMap1, localHashMap2, localClass7, Long.class);
    Class localClass8 = Short.TYPE;
    add(localHashMap1, localHashMap2, localClass8, Short.class);
    Class localClass9 = Void.TYPE;
    add(localHashMap1, localHashMap2, localClass9, Void.class);
    PRIMITIVE_TO_WRAPPER_TYPE = Collections.unmodifiableMap(localHashMap1);
    WRAPPER_TO_PRIMITIVE_TYPE = Collections.unmodifiableMap(localHashMap2);
  }

  private static void add(Map<Class<?>, Class<?>> paramMap1, Map<Class<?>, Class<?>> paramMap2, Class<?> paramClass1, Class<?> paramClass2)
  {
    Object localObject1 = paramMap1.put(paramClass1, paramClass2);
    Object localObject2 = paramMap2.put(paramClass2, paramClass1);
  }

  public static boolean isPrimitive(Type paramType)
  {
    return PRIMITIVE_TO_WRAPPER_TYPE.containsKey(paramType);
  }

  public static boolean isWrapperType(Class<?> paramClass)
  {
    Map localMap = WRAPPER_TO_PRIMITIVE_TYPE;
    Object localObject = .Gson.Preconditions.checkNotNull(paramClass);
    return localMap.containsKey(localObject);
  }

  public static <T> Class<T> unwrap(Class<T> paramClass)
  {
    Map localMap = WRAPPER_TO_PRIMITIVE_TYPE;
    Object localObject = .Gson.Preconditions.checkNotNull(paramClass);
    Class localClass = (Class)localMap.get(localObject);
    if (localClass == null);
    while (true)
    {
      return paramClass;
      paramClass = localClass;
    }
  }

  public static <T> Class<T> wrap(Class<T> paramClass)
  {
    Map localMap = PRIMITIVE_TO_WRAPPER_TYPE;
    Object localObject = .Gson.Preconditions.checkNotNull(paramClass);
    Class localClass = (Class)localMap.get(localObject);
    if (localClass == null);
    while (true)
    {
      return paramClass;
      paramClass = localClass;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.Primitives
 * JD-Core Version:    0.6.0
 */