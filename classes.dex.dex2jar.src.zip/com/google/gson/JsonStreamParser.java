package com.google.gson;

import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.MalformedJsonException;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.Iterator;
import java.util.NoSuchElementException;

public final class JsonStreamParser
  implements Iterator<JsonElement>
{
  private final Object lock;
  private final JsonReader parser;

  public JsonStreamParser(Reader paramReader)
  {
    JsonReader localJsonReader = new JsonReader(paramReader);
    this.parser = localJsonReader;
    this.parser.setLenient(1);
    Object localObject = new Object();
    this.lock = localObject;
  }

  public JsonStreamParser(String paramString)
  {
    this(localStringReader);
  }

  public boolean hasNext()
  {
    try
    {
      synchronized (this.lock)
      {
        try
        {
          JsonToken localJsonToken1 = this.parser.peek();
          JsonToken localJsonToken2 = JsonToken.END_DOCUMENT;
          if (localJsonToken1 != localJsonToken2);
          for (localJsonToken1 = null; ; localJsonToken1 = null)
            return localJsonToken1;
        }
        catch (MalformedJsonException localMalformedJsonException)
        {
          throw new JsonSyntaxException(localMalformedJsonException);
        }
      }
    }
    catch (IOException localIOException)
    {
    }
    throw new JsonIOException(localIOException);
  }

  public JsonElement next()
    throws JsonParseException
  {
    if (!hasNext())
      throw new NoSuchElementException();
    NoSuchElementException localNoSuchElementException;
    try
    {
      JsonElement localJsonElement = Streams.parse(this.parser);
      return localJsonElement;
    }
    catch (StackOverflowError localStackOverflowError)
    {
      throw new JsonParseException("Failed parsing JSON source to Json", localStackOverflowError);
    }
    catch (OutOfMemoryError localOutOfMemoryError)
    {
      throw new JsonParseException("Failed parsing JSON source to Json", localOutOfMemoryError);
    }
    catch (JsonParseException localNoSuchElementException)
    {
      if ((localJsonParseException.getCause() instanceof EOFException))
        localNoSuchElementException = new NoSuchElementException();
    }
    throw localNoSuchElementException;
  }

  public void remove()
  {
    throw new UnsupportedOperationException();
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.JsonStreamParser
 * JD-Core Version:    0.6.0
 */