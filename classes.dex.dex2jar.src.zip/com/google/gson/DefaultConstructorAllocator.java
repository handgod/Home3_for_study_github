package com.google.gson;

import java.lang.reflect.Constructor;

final class DefaultConstructorAllocator
{
  private static final Constructor<Null> NULL_CONSTRUCTOR = createNullConstructor();
  private final Cache<Class<?>, Constructor<?>> constructorCache;

  public DefaultConstructorAllocator()
  {
    this(200);
  }

  public DefaultConstructorAllocator(int paramInt)
  {
    LruCache localLruCache = new LruCache(paramInt);
    this.constructorCache = localLruCache;
  }

  private static final Constructor<Null> createNullConstructor()
  {
    try
    {
      Constructor localConstructor1 = getNoArgsConstructor(Null.class);
      localConstructor2 = localConstructor1;
      return localConstructor2;
    }
    catch (Exception localException)
    {
      while (true)
        Constructor localConstructor2 = null;
    }
  }

  private <T> Constructor<T> findConstructor(Class<T> paramClass)
  {
    Object localObject = (Constructor)this.constructorCache.getElement(paramClass);
    if (localObject != null)
    {
      Constructor localConstructor1 = NULL_CONSTRUCTOR;
      if (localObject == localConstructor1)
        localObject = null;
      return localObject;
    }
    Constructor localConstructor2 = getNoArgsConstructor(paramClass);
    if (localConstructor2 != null)
      this.constructorCache.addElement(paramClass, localConstructor2);
    while (true)
    {
      localObject = localConstructor2;
      break;
      Cache localCache = this.constructorCache;
      Constructor localConstructor3 = NULL_CONSTRUCTOR;
      localCache.addElement(paramClass, localConstructor3);
    }
  }

  private static <T> Constructor<T> getNoArgsConstructor(Class<T> paramClass)
  {
    try
    {
      Class[] arrayOfClass = new Class[0];
      localConstructor = paramClass.getDeclaredConstructor(arrayOfClass);
      localConstructor.setAccessible(1);
      return localConstructor;
    }
    catch (Exception localException)
    {
      while (true)
        Constructor localConstructor = null;
    }
  }

  final boolean isInCache(Class<?> paramClass)
  {
    if (this.constructorCache.getElement(paramClass) != null);
    for (int i = 1; ; i = 0)
      return i;
  }

  public <T> T newInstance(Class<T> paramClass)
    throws Exception
  {
    Constructor localConstructor = findConstructor(paramClass);
    Object[] arrayOfObject;
    if (localConstructor != null)
      arrayOfObject = new Object[0];
    for (Object localObject = localConstructor.newInstance(arrayOfObject); ; localObject = null)
      return localObject;
  }

  final class Null
  {
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.gson.DefaultConstructorAllocator
 * JD-Core Version:    0.6.0
 */