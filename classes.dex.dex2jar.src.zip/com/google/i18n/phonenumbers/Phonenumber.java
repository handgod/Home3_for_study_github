package com.google.i18n.phonenumbers;

import java.io.Serializable;

public final class Phonenumber
{
  public class PhoneNumber
    implements Serializable
  {
    private static final long serialVersionUID = 1L;
    private CountryCodeSource countryCodeSource_;
    private int countryCode_ = 0;
    private String extension_ = "";
    private boolean hasCountryCode;
    private boolean hasCountryCodeSource;
    private boolean hasExtension;
    private boolean hasItalianLeadingZero;
    private boolean hasNationalNumber;
    private boolean hasPreferredDomesticCarrierCode;
    private boolean hasRawInput;
    private boolean italianLeadingZero_ = 0;
    private long nationalNumber_ = 0L;
    private String preferredDomesticCarrierCode_ = "";
    private String rawInput_ = "";

    public PhoneNumber()
    {
      this$1 = CountryCodeSource.FROM_NUMBER_WITH_PLUS_SIGN;
      this.countryCodeSource_ = this$1;
    }

    public final PhoneNumber clear()
    {
      PhoneNumber localPhoneNumber1 = clearCountryCode();
      PhoneNumber localPhoneNumber2 = clearNationalNumber();
      PhoneNumber localPhoneNumber3 = clearExtension();
      PhoneNumber localPhoneNumber4 = clearItalianLeadingZero();
      PhoneNumber localPhoneNumber5 = clearRawInput();
      PhoneNumber localPhoneNumber6 = clearCountryCodeSource();
      PhoneNumber localPhoneNumber7 = clearPreferredDomesticCarrierCode();
      return this;
    }

    public PhoneNumber clearCountryCode()
    {
      this.hasCountryCode = 0;
      this.countryCode_ = 0;
      return this;
    }

    public PhoneNumber clearCountryCodeSource()
    {
      this.hasCountryCodeSource = 0;
      CountryCodeSource localCountryCodeSource = CountryCodeSource.FROM_NUMBER_WITH_PLUS_SIGN;
      this.countryCodeSource_ = localCountryCodeSource;
      return this;
    }

    public PhoneNumber clearExtension()
    {
      this.hasExtension = 0;
      this.extension_ = "";
      return this;
    }

    public PhoneNumber clearItalianLeadingZero()
    {
      this.hasItalianLeadingZero = 0;
      this.italianLeadingZero_ = 0;
      return this;
    }

    public PhoneNumber clearNationalNumber()
    {
      this.hasNationalNumber = 0;
      this.nationalNumber_ = 0L;
      return this;
    }

    public PhoneNumber clearPreferredDomesticCarrierCode()
    {
      this.hasPreferredDomesticCarrierCode = 0;
      this.preferredDomesticCarrierCode_ = "";
      return this;
    }

    public PhoneNumber clearRawInput()
    {
      this.hasRawInput = 0;
      this.rawInput_ = "";
      return this;
    }

    public boolean equals(Object paramObject)
    {
      if ((paramObject instanceof PhoneNumber))
      {
        PhoneNumber localPhoneNumber = (PhoneNumber)paramObject;
        if (!exactlySameAs(localPhoneNumber));
      }
      for (int i = 1; ; i = 0)
        return i;
    }

    public boolean exactlySameAs(PhoneNumber paramPhoneNumber)
    {
      int i = 1;
      if (paramPhoneNumber == null)
        i = 0;
      while (true)
      {
        return i;
        if (this == paramPhoneNumber)
          continue;
        int j = this.countryCode_;
        int k = paramPhoneNumber.countryCode_;
        if (j == k)
        {
          long l1 = this.nationalNumber_;
          long l2 = paramPhoneNumber.nationalNumber_;
          if (l1 == l2)
          {
            String str1 = this.extension_;
            String str2 = paramPhoneNumber.extension_;
            if (str1.equals(str2))
            {
              boolean bool1 = this.italianLeadingZero_;
              boolean bool2 = paramPhoneNumber.italianLeadingZero_;
              if (bool1 == bool2)
              {
                String str3 = this.rawInput_;
                String str4 = paramPhoneNumber.rawInput_;
                if (str3.equals(str4))
                {
                  CountryCodeSource localCountryCodeSource1 = this.countryCodeSource_;
                  CountryCodeSource localCountryCodeSource2 = paramPhoneNumber.countryCodeSource_;
                  if (localCountryCodeSource1 == localCountryCodeSource2)
                  {
                    String str5 = this.preferredDomesticCarrierCode_;
                    String str6 = paramPhoneNumber.preferredDomesticCarrierCode_;
                    if (str5.equals(str6))
                    {
                      boolean bool3 = hasPreferredDomesticCarrierCode();
                      boolean bool4 = paramPhoneNumber.hasPreferredDomesticCarrierCode();
                      if (bool3 == bool4)
                        continue;
                    }
                  }
                }
              }
            }
          }
        }
        i = 0;
      }
    }

    public int getCountryCode()
    {
      return this.countryCode_;
    }

    public CountryCodeSource getCountryCodeSource()
    {
      return this.countryCodeSource_;
    }

    public String getExtension()
    {
      return this.extension_;
    }

    public long getNationalNumber()
    {
      return this.nationalNumber_;
    }

    public String getPreferredDomesticCarrierCode()
    {
      return this.preferredDomesticCarrierCode_;
    }

    public String getRawInput()
    {
      return this.rawInput_;
    }

    public boolean hasCountryCode()
    {
      return this.hasCountryCode;
    }

    public boolean hasCountryCodeSource()
    {
      return this.hasCountryCodeSource;
    }

    public boolean hasExtension()
    {
      return this.hasExtension;
    }

    public boolean hasItalianLeadingZero()
    {
      return this.hasItalianLeadingZero;
    }

    public boolean hasNationalNumber()
    {
      return this.hasNationalNumber;
    }

    public boolean hasPreferredDomesticCarrierCode()
    {
      return this.hasPreferredDomesticCarrierCode;
    }

    public boolean hasRawInput()
    {
      return this.hasRawInput;
    }

    public int hashCode()
    {
      int i = 1231;
      int j = (getCountryCode() + 2173) * 53;
      int k = Long.valueOf(getNationalNumber()).hashCode();
      int m = (j + k) * 53;
      int n = getExtension().hashCode();
      int i1 = (m + n) * 53;
      int i2;
      if (isItalianLeadingZero())
      {
        i2 = 1231;
        int i3 = (i2 + i1) * 53;
        int i4 = getRawInput().hashCode();
        int i5 = (i3 + i4) * 53;
        int i6 = getCountryCodeSource().hashCode();
        int i7 = (i5 + i6) * 53;
        int i8 = getPreferredDomesticCarrierCode().hashCode();
        i2 = (i7 + i8) * 53;
        if (!hasPreferredDomesticCarrierCode())
          break label153;
      }
      while (true)
      {
        return i2 + i;
        i2 = 1237;
        break;
        label153: i = 1237;
      }
    }

    public boolean isItalianLeadingZero()
    {
      return this.italianLeadingZero_;
    }

    public PhoneNumber mergeFrom(PhoneNumber paramPhoneNumber)
    {
      if (paramPhoneNumber.hasCountryCode())
      {
        int i = paramPhoneNumber.getCountryCode();
        PhoneNumber localPhoneNumber1 = setCountryCode(i);
      }
      if (paramPhoneNumber.hasNationalNumber())
      {
        long l = paramPhoneNumber.getNationalNumber();
        PhoneNumber localPhoneNumber2 = setNationalNumber(l);
      }
      if (paramPhoneNumber.hasExtension())
      {
        String str1 = paramPhoneNumber.getExtension();
        PhoneNumber localPhoneNumber3 = setExtension(str1);
      }
      if (paramPhoneNumber.hasItalianLeadingZero())
      {
        boolean bool = paramPhoneNumber.isItalianLeadingZero();
        PhoneNumber localPhoneNumber4 = setItalianLeadingZero(bool);
      }
      if (paramPhoneNumber.hasRawInput())
      {
        String str2 = paramPhoneNumber.getRawInput();
        PhoneNumber localPhoneNumber5 = setRawInput(str2);
      }
      if (paramPhoneNumber.hasCountryCodeSource())
      {
        CountryCodeSource localCountryCodeSource = paramPhoneNumber.getCountryCodeSource();
        PhoneNumber localPhoneNumber6 = setCountryCodeSource(localCountryCodeSource);
      }
      if (paramPhoneNumber.hasPreferredDomesticCarrierCode())
      {
        String str3 = paramPhoneNumber.getPreferredDomesticCarrierCode();
        PhoneNumber localPhoneNumber7 = setPreferredDomesticCarrierCode(str3);
      }
      return this;
    }

    public PhoneNumber setCountryCode(int paramInt)
    {
      this.hasCountryCode = 1;
      this.countryCode_ = paramInt;
      return this;
    }

    public PhoneNumber setCountryCodeSource(CountryCodeSource paramCountryCodeSource)
    {
      if (paramCountryCodeSource == null)
        throw new NullPointerException();
      this.hasCountryCodeSource = 1;
      this.countryCodeSource_ = paramCountryCodeSource;
      return this;
    }

    public PhoneNumber setExtension(String paramString)
    {
      if (paramString == null)
        throw new NullPointerException();
      this.hasExtension = 1;
      this.extension_ = paramString;
      return this;
    }

    public PhoneNumber setItalianLeadingZero(boolean paramBoolean)
    {
      this.hasItalianLeadingZero = 1;
      this.italianLeadingZero_ = paramBoolean;
      return this;
    }

    public PhoneNumber setNationalNumber(long paramLong)
    {
      this.hasNationalNumber = 1;
      this.nationalNumber_ = paramLong;
      return this;
    }

    public PhoneNumber setPreferredDomesticCarrierCode(String paramString)
    {
      if (paramString == null)
        throw new NullPointerException();
      this.hasPreferredDomesticCarrierCode = 1;
      this.preferredDomesticCarrierCode_ = paramString;
      return this;
    }

    public PhoneNumber setRawInput(String paramString)
    {
      if (paramString == null)
        throw new NullPointerException();
      this.hasRawInput = 1;
      this.rawInput_ = paramString;
      return this;
    }

    public String toString()
    {
      StringBuilder localStringBuilder1 = new StringBuilder();
      StringBuilder localStringBuilder2 = localStringBuilder1.append("Country Code: ");
      int i = this.countryCode_;
      StringBuilder localStringBuilder3 = localStringBuilder2.append(i);
      StringBuilder localStringBuilder4 = localStringBuilder1.append(" National Number: ");
      long l = this.nationalNumber_;
      StringBuilder localStringBuilder5 = localStringBuilder4.append(l);
      if ((hasItalianLeadingZero()) && (isItalianLeadingZero()))
        StringBuilder localStringBuilder6 = localStringBuilder1.append(" Leading Zero: true");
      if (hasExtension())
      {
        StringBuilder localStringBuilder7 = localStringBuilder1.append(" Extension: ");
        String str1 = this.extension_;
        StringBuilder localStringBuilder8 = localStringBuilder7.append(str1);
      }
      if (hasCountryCodeSource())
      {
        StringBuilder localStringBuilder9 = localStringBuilder1.append(" Country Code Source: ");
        CountryCodeSource localCountryCodeSource = this.countryCodeSource_;
        StringBuilder localStringBuilder10 = localStringBuilder9.append(localCountryCodeSource);
      }
      if (hasPreferredDomesticCarrierCode())
      {
        StringBuilder localStringBuilder11 = localStringBuilder1.append(" Preferred Domestic Carrier Code: ");
        String str2 = this.preferredDomesticCarrierCode_;
        StringBuilder localStringBuilder12 = localStringBuilder11.append(str2);
      }
      return localStringBuilder1.toString();
    }

    public enum CountryCodeSource
    {
      static
      {
        FROM_NUMBER_WITH_IDD = new CountryCodeSource("FROM_NUMBER_WITH_IDD", 1);
        FROM_NUMBER_WITHOUT_PLUS_SIGN = new CountryCodeSource("FROM_NUMBER_WITHOUT_PLUS_SIGN", 2);
        FROM_DEFAULT_COUNTRY = new CountryCodeSource("FROM_DEFAULT_COUNTRY", 3);
        CountryCodeSource[] arrayOfCountryCodeSource = new CountryCodeSource[4];
        CountryCodeSource localCountryCodeSource1 = FROM_NUMBER_WITH_PLUS_SIGN;
        arrayOfCountryCodeSource[0] = localCountryCodeSource1;
        CountryCodeSource localCountryCodeSource2 = FROM_NUMBER_WITH_IDD;
        arrayOfCountryCodeSource[1] = localCountryCodeSource2;
        CountryCodeSource localCountryCodeSource3 = FROM_NUMBER_WITHOUT_PLUS_SIGN;
        arrayOfCountryCodeSource[2] = localCountryCodeSource3;
        CountryCodeSource localCountryCodeSource4 = FROM_DEFAULT_COUNTRY;
        arrayOfCountryCodeSource[3] = localCountryCodeSource4;
        $VALUES = arrayOfCountryCodeSource;
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.i18n.phonenumbers.Phonenumber
 * JD-Core Version:    0.6.0
 */