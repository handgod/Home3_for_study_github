package com.google.i18n.phonenumbers;

 enum PhoneNumberUtil$Leniency$1
{
  boolean verify(Phonenumber.PhoneNumber paramPhoneNumber, String paramString, PhoneNumberUtil paramPhoneNumberUtil)
  {
    return paramPhoneNumberUtil.isPossibleNumber(paramPhoneNumber);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.i18n.phonenumbers.PhoneNumberUtil.Leniency.1
 * JD-Core Version:    0.6.0
 */