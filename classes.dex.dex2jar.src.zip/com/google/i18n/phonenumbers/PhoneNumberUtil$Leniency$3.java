package com.google.i18n.phonenumbers;

 enum PhoneNumberUtil$Leniency$3
{
  boolean verify(Phonenumber.PhoneNumber paramPhoneNumber, String paramString, PhoneNumberUtil paramPhoneNumberUtil)
  {
    boolean bool = false;
    if ((!paramPhoneNumberUtil.isValidNumber(paramPhoneNumber)) || (!PhoneNumberUtil.Leniency.access$100(paramPhoneNumber, paramString, paramPhoneNumberUtil)) || (PhoneNumberUtil.Leniency.access$200(paramString)));
    while (true)
    {
      return bool;
      String[] arrayOfString = PhoneNumberUtil.Leniency.access$300(paramPhoneNumberUtil, paramPhoneNumber);
      StringBuilder localStringBuilder = PhoneNumberUtil.access$400(paramString, 1);
      int i = 0;
      int j = 0;
      while (true)
      {
        int k = arrayOfString.length;
        if (i >= k)
          break label185;
        String str1 = arrayOfString[i];
        j = localStringBuilder.indexOf(str1, j);
        if (j < 0)
          break;
        int m = arrayOfString[i].length();
        j += m;
        if (i == 0)
        {
          int n = localStringBuilder.length();
          if ((j < n) && (Character.isDigit(localStringBuilder.charAt(j))))
          {
            String str2 = paramPhoneNumberUtil.getNationalSignificantNumber(paramPhoneNumber);
            int i1 = arrayOfString[i].length();
            int i2 = j - i1;
            bool = localStringBuilder.substring(i2).startsWith(str2);
            break;
          }
        }
        i += 1;
      }
      label185: String str3 = localStringBuilder.substring(j);
      String str4 = paramPhoneNumber.getExtension();
      bool = str3.contains(str4);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.i18n.phonenumbers.PhoneNumberUtil.Leniency.3
 * JD-Core Version:    0.6.0
 */