package com.google.i18n.phonenumbers;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.ArrayList;
import java.util.List;

public final class Phonemetadata
{
  public class PhoneMetadataCollection
    implements Externalizable
  {
    private static final long serialVersionUID = 1L;
    private List<Phonemetadata.PhoneMetadata> metadata_;

    public PhoneMetadataCollection()
    {
      this$1 = new ArrayList();
      this.metadata_ = this$1;
    }

    public static Builder newBuilder()
    {
      return new Builder();
    }

    public PhoneMetadataCollection addMetadata(Phonemetadata.PhoneMetadata paramPhoneMetadata)
    {
      if (paramPhoneMetadata == null)
        throw new NullPointerException();
      boolean bool = this.metadata_.add(paramPhoneMetadata);
      return this;
    }

    public PhoneMetadataCollection clear()
    {
      this.metadata_.clear();
      return this;
    }

    public int getMetadataCount()
    {
      return this.metadata_.size();
    }

    public List<Phonemetadata.PhoneMetadata> getMetadataList()
    {
      return this.metadata_;
    }

    public void readExternal(ObjectInput paramObjectInput)
      throws IOException
    {
      int i = paramObjectInput.readInt();
      int j = 0;
      while (j < i)
      {
        Phonemetadata.PhoneMetadata localPhoneMetadata = new Phonemetadata.PhoneMetadata();
        localPhoneMetadata.readExternal(paramObjectInput);
        boolean bool = this.metadata_.add(localPhoneMetadata);
        j += 1;
      }
    }

    public void writeExternal(ObjectOutput paramObjectOutput)
      throws IOException
    {
      int i = getMetadataCount();
      paramObjectOutput.writeInt(i);
      int j = 0;
      while (j < i)
      {
        ((Phonemetadata.PhoneMetadata)this.metadata_.get(j)).writeExternal(paramObjectOutput);
        j += 1;
      }
    }

    public final class Builder extends Phonemetadata.PhoneMetadataCollection
    {
      public Phonemetadata.PhoneMetadataCollection build()
      {
        return this;
      }
    }
  }

  public class PhoneMetadata
    implements Externalizable
  {
    private static final long serialVersionUID = 1L;
    private int countryCode_ = 0;
    private Phonemetadata.PhoneNumberDesc fixedLine_ = null;
    private Phonemetadata.PhoneNumberDesc generalDesc_ = null;
    private boolean hasCountryCode;
    private boolean hasFixedLine;
    private boolean hasGeneralDesc;
    private boolean hasId;
    private boolean hasInternationalPrefix;
    private boolean hasLeadingDigits;
    private boolean hasLeadingZeroPossible;
    private boolean hasMainCountryForCode;
    private boolean hasMobile;
    private boolean hasNationalPrefix;
    private boolean hasNationalPrefixForParsing;
    private boolean hasNationalPrefixTransformRule;
    private boolean hasNoInternationalDialling;
    private boolean hasPager;
    private boolean hasPersonalNumber;
    private boolean hasPreferredExtnPrefix;
    private boolean hasPreferredInternationalPrefix;
    private boolean hasPremiumRate;
    private boolean hasSameMobileAndFixedLinePattern;
    private boolean hasSharedCost;
    private boolean hasTollFree;
    private boolean hasUan;
    private boolean hasVoip;
    private String id_ = "";
    private String internationalPrefix_ = "";
    private List<Phonemetadata.NumberFormat> intlNumberFormat_;
    private String leadingDigits_;
    private boolean leadingZeroPossible_;
    private boolean mainCountryForCode_;
    private Phonemetadata.PhoneNumberDesc mobile_ = null;
    private String nationalPrefixForParsing_ = "";
    private String nationalPrefixTransformRule_ = "";
    private String nationalPrefix_ = "";
    private Phonemetadata.PhoneNumberDesc noInternationalDialling_ = null;
    private List<Phonemetadata.NumberFormat> numberFormat_;
    private Phonemetadata.PhoneNumberDesc pager_ = null;
    private Phonemetadata.PhoneNumberDesc personalNumber_ = null;
    private String preferredExtnPrefix_ = "";
    private String preferredInternationalPrefix_ = "";
    private Phonemetadata.PhoneNumberDesc premiumRate_ = null;
    private boolean sameMobileAndFixedLinePattern_ = 0;
    private Phonemetadata.PhoneNumberDesc sharedCost_ = null;
    private Phonemetadata.PhoneNumberDesc tollFree_ = null;
    private Phonemetadata.PhoneNumberDesc uan_ = null;
    private Phonemetadata.PhoneNumberDesc voip_ = null;

    public PhoneMetadata()
    {
      this$1 = new ArrayList();
      this.numberFormat_ = this$1;
      ArrayList localArrayList = new ArrayList();
      this.intlNumberFormat_ = localArrayList;
      this.mainCountryForCode_ = 0;
      this.leadingDigits_ = "";
      this.leadingZeroPossible_ = 0;
    }

    public static Builder newBuilder()
    {
      return new Builder();
    }

    public PhoneMetadata addIntlNumberFormat(Phonemetadata.NumberFormat paramNumberFormat)
    {
      if (paramNumberFormat == null)
        throw new NullPointerException();
      boolean bool = this.intlNumberFormat_.add(paramNumberFormat);
      return this;
    }

    public PhoneMetadata addNumberFormat(Phonemetadata.NumberFormat paramNumberFormat)
    {
      if (paramNumberFormat == null)
        throw new NullPointerException();
      boolean bool = this.numberFormat_.add(paramNumberFormat);
      return this;
    }

    public PhoneMetadata clearIntlNumberFormat()
    {
      this.intlNumberFormat_.clear();
      return this;
    }

    public int getCountryCode()
    {
      return this.countryCode_;
    }

    public Phonemetadata.PhoneNumberDesc getFixedLine()
    {
      return this.fixedLine_;
    }

    public Phonemetadata.PhoneNumberDesc getGeneralDesc()
    {
      return this.generalDesc_;
    }

    public String getId()
    {
      return this.id_;
    }

    public String getInternationalPrefix()
    {
      return this.internationalPrefix_;
    }

    public Phonemetadata.NumberFormat getIntlNumberFormat(int paramInt)
    {
      return (Phonemetadata.NumberFormat)this.intlNumberFormat_.get(paramInt);
    }

    public String getLeadingDigits()
    {
      return this.leadingDigits_;
    }

    public boolean getMainCountryForCode()
    {
      return this.mainCountryForCode_;
    }

    public Phonemetadata.PhoneNumberDesc getMobile()
    {
      return this.mobile_;
    }

    public String getNationalPrefix()
    {
      return this.nationalPrefix_;
    }

    public String getNationalPrefixForParsing()
    {
      return this.nationalPrefixForParsing_;
    }

    public String getNationalPrefixTransformRule()
    {
      return this.nationalPrefixTransformRule_;
    }

    public Phonemetadata.PhoneNumberDesc getNoInternationalDialling()
    {
      return this.noInternationalDialling_;
    }

    public Phonemetadata.NumberFormat getNumberFormat(int paramInt)
    {
      return (Phonemetadata.NumberFormat)this.numberFormat_.get(paramInt);
    }

    public Phonemetadata.PhoneNumberDesc getPager()
    {
      return this.pager_;
    }

    public Phonemetadata.PhoneNumberDesc getPersonalNumber()
    {
      return this.personalNumber_;
    }

    public String getPreferredExtnPrefix()
    {
      return this.preferredExtnPrefix_;
    }

    public String getPreferredInternationalPrefix()
    {
      return this.preferredInternationalPrefix_;
    }

    public Phonemetadata.PhoneNumberDesc getPremiumRate()
    {
      return this.premiumRate_;
    }

    public Phonemetadata.PhoneNumberDesc getSharedCost()
    {
      return this.sharedCost_;
    }

    public Phonemetadata.PhoneNumberDesc getTollFree()
    {
      return this.tollFree_;
    }

    public Phonemetadata.PhoneNumberDesc getUan()
    {
      return this.uan_;
    }

    public Phonemetadata.PhoneNumberDesc getVoip()
    {
      return this.voip_;
    }

    public boolean hasCountryCode()
    {
      return this.hasCountryCode;
    }

    public boolean hasFixedLine()
    {
      return this.hasFixedLine;
    }

    public boolean hasGeneralDesc()
    {
      return this.hasGeneralDesc;
    }

    public boolean hasId()
    {
      return this.hasId;
    }

    public boolean hasInternationalPrefix()
    {
      return this.hasInternationalPrefix;
    }

    public boolean hasLeadingDigits()
    {
      return this.hasLeadingDigits;
    }

    public boolean hasLeadingZeroPossible()
    {
      return this.hasLeadingZeroPossible;
    }

    public boolean hasMainCountryForCode()
    {
      return this.hasMainCountryForCode;
    }

    public boolean hasMobile()
    {
      return this.hasMobile;
    }

    public boolean hasNationalPrefix()
    {
      return this.hasNationalPrefix;
    }

    public boolean hasNationalPrefixForParsing()
    {
      return this.hasNationalPrefixForParsing;
    }

    public boolean hasNationalPrefixTransformRule()
    {
      return this.hasNationalPrefixTransformRule;
    }

    public boolean hasNoInternationalDialling()
    {
      return this.hasNoInternationalDialling;
    }

    public boolean hasPager()
    {
      return this.hasPager;
    }

    public boolean hasPersonalNumber()
    {
      return this.hasPersonalNumber;
    }

    public boolean hasPreferredExtnPrefix()
    {
      return this.hasPreferredExtnPrefix;
    }

    public boolean hasPreferredInternationalPrefix()
    {
      return this.hasPreferredInternationalPrefix;
    }

    public boolean hasPremiumRate()
    {
      return this.hasPremiumRate;
    }

    public boolean hasSameMobileAndFixedLinePattern()
    {
      return this.hasSameMobileAndFixedLinePattern;
    }

    public boolean hasSharedCost()
    {
      return this.hasSharedCost;
    }

    public boolean hasTollFree()
    {
      return this.hasTollFree;
    }

    public boolean hasUan()
    {
      return this.hasUan;
    }

    public boolean hasVoip()
    {
      return this.hasVoip;
    }

    public int intlNumberFormatSize()
    {
      return this.intlNumberFormat_.size();
    }

    public List<Phonemetadata.NumberFormat> intlNumberFormats()
    {
      return this.intlNumberFormat_;
    }

    public boolean isLeadingZeroPossible()
    {
      return this.leadingZeroPossible_;
    }

    public boolean isMainCountryForCode()
    {
      return this.mainCountryForCode_;
    }

    public boolean isSameMobileAndFixedLinePattern()
    {
      return this.sameMobileAndFixedLinePattern_;
    }

    public int numberFormatSize()
    {
      return this.numberFormat_.size();
    }

    public List<Phonemetadata.NumberFormat> numberFormats()
    {
      return this.numberFormat_;
    }

    public void readExternal(ObjectInput paramObjectInput)
      throws IOException
    {
      int i = 0;
      if (paramObjectInput.readBoolean())
      {
        Phonemetadata.PhoneNumberDesc localPhoneNumberDesc1 = new Phonemetadata.PhoneNumberDesc();
        localPhoneNumberDesc1.readExternal(paramObjectInput);
        PhoneMetadata localPhoneMetadata1 = setGeneralDesc(localPhoneNumberDesc1);
      }
      if (paramObjectInput.readBoolean())
      {
        Phonemetadata.PhoneNumberDesc localPhoneNumberDesc2 = new Phonemetadata.PhoneNumberDesc();
        localPhoneNumberDesc2.readExternal(paramObjectInput);
        PhoneMetadata localPhoneMetadata2 = setFixedLine(localPhoneNumberDesc2);
      }
      if (paramObjectInput.readBoolean())
      {
        Phonemetadata.PhoneNumberDesc localPhoneNumberDesc3 = new Phonemetadata.PhoneNumberDesc();
        localPhoneNumberDesc3.readExternal(paramObjectInput);
        PhoneMetadata localPhoneMetadata3 = setMobile(localPhoneNumberDesc3);
      }
      if (paramObjectInput.readBoolean())
      {
        Phonemetadata.PhoneNumberDesc localPhoneNumberDesc4 = new Phonemetadata.PhoneNumberDesc();
        localPhoneNumberDesc4.readExternal(paramObjectInput);
        PhoneMetadata localPhoneMetadata4 = setTollFree(localPhoneNumberDesc4);
      }
      if (paramObjectInput.readBoolean())
      {
        Phonemetadata.PhoneNumberDesc localPhoneNumberDesc5 = new Phonemetadata.PhoneNumberDesc();
        localPhoneNumberDesc5.readExternal(paramObjectInput);
        PhoneMetadata localPhoneMetadata5 = setPremiumRate(localPhoneNumberDesc5);
      }
      if (paramObjectInput.readBoolean())
      {
        Phonemetadata.PhoneNumberDesc localPhoneNumberDesc6 = new Phonemetadata.PhoneNumberDesc();
        localPhoneNumberDesc6.readExternal(paramObjectInput);
        PhoneMetadata localPhoneMetadata6 = setSharedCost(localPhoneNumberDesc6);
      }
      if (paramObjectInput.readBoolean())
      {
        Phonemetadata.PhoneNumberDesc localPhoneNumberDesc7 = new Phonemetadata.PhoneNumberDesc();
        localPhoneNumberDesc7.readExternal(paramObjectInput);
        PhoneMetadata localPhoneMetadata7 = setPersonalNumber(localPhoneNumberDesc7);
      }
      if (paramObjectInput.readBoolean())
      {
        Phonemetadata.PhoneNumberDesc localPhoneNumberDesc8 = new Phonemetadata.PhoneNumberDesc();
        localPhoneNumberDesc8.readExternal(paramObjectInput);
        PhoneMetadata localPhoneMetadata8 = setVoip(localPhoneNumberDesc8);
      }
      if (paramObjectInput.readBoolean())
      {
        Phonemetadata.PhoneNumberDesc localPhoneNumberDesc9 = new Phonemetadata.PhoneNumberDesc();
        localPhoneNumberDesc9.readExternal(paramObjectInput);
        PhoneMetadata localPhoneMetadata9 = setPager(localPhoneNumberDesc9);
      }
      if (paramObjectInput.readBoolean())
      {
        Phonemetadata.PhoneNumberDesc localPhoneNumberDesc10 = new Phonemetadata.PhoneNumberDesc();
        localPhoneNumberDesc10.readExternal(paramObjectInput);
        PhoneMetadata localPhoneMetadata10 = setUan(localPhoneNumberDesc10);
      }
      if (paramObjectInput.readBoolean())
      {
        Phonemetadata.PhoneNumberDesc localPhoneNumberDesc11 = new Phonemetadata.PhoneNumberDesc();
        localPhoneNumberDesc11.readExternal(paramObjectInput);
        PhoneMetadata localPhoneMetadata11 = setNoInternationalDialling(localPhoneNumberDesc11);
      }
      String str1 = paramObjectInput.readUTF();
      PhoneMetadata localPhoneMetadata12 = setId(str1);
      int j = paramObjectInput.readInt();
      PhoneMetadata localPhoneMetadata13 = setCountryCode(j);
      String str2 = paramObjectInput.readUTF();
      PhoneMetadata localPhoneMetadata14 = setInternationalPrefix(str2);
      if (paramObjectInput.readBoolean())
      {
        String str3 = paramObjectInput.readUTF();
        PhoneMetadata localPhoneMetadata15 = setPreferredInternationalPrefix(str3);
      }
      if (paramObjectInput.readBoolean())
      {
        String str4 = paramObjectInput.readUTF();
        PhoneMetadata localPhoneMetadata16 = setNationalPrefix(str4);
      }
      if (paramObjectInput.readBoolean())
      {
        String str5 = paramObjectInput.readUTF();
        PhoneMetadata localPhoneMetadata17 = setPreferredExtnPrefix(str5);
      }
      if (paramObjectInput.readBoolean())
      {
        String str6 = paramObjectInput.readUTF();
        PhoneMetadata localPhoneMetadata18 = setNationalPrefixForParsing(str6);
      }
      if (paramObjectInput.readBoolean())
      {
        String str7 = paramObjectInput.readUTF();
        PhoneMetadata localPhoneMetadata19 = setNationalPrefixTransformRule(str7);
      }
      boolean bool1 = paramObjectInput.readBoolean();
      PhoneMetadata localPhoneMetadata20 = setSameMobileAndFixedLinePattern(bool1);
      int k = paramObjectInput.readInt();
      int m = 0;
      while (m < k)
      {
        Phonemetadata.NumberFormat localNumberFormat1 = new Phonemetadata.NumberFormat();
        localNumberFormat1.readExternal(paramObjectInput);
        boolean bool2 = this.numberFormat_.add(localNumberFormat1);
        m += 1;
      }
      m = paramObjectInput.readInt();
      while (i < m)
      {
        Phonemetadata.NumberFormat localNumberFormat2 = new Phonemetadata.NumberFormat();
        localNumberFormat2.readExternal(paramObjectInput);
        boolean bool3 = this.intlNumberFormat_.add(localNumberFormat2);
        i += 1;
      }
      boolean bool4 = paramObjectInput.readBoolean();
      PhoneMetadata localPhoneMetadata21 = setMainCountryForCode(bool4);
      if (paramObjectInput.readBoolean())
      {
        String str8 = paramObjectInput.readUTF();
        PhoneMetadata localPhoneMetadata22 = setLeadingDigits(str8);
      }
      boolean bool5 = paramObjectInput.readBoolean();
      PhoneMetadata localPhoneMetadata23 = setLeadingZeroPossible(bool5);
    }

    public PhoneMetadata setCountryCode(int paramInt)
    {
      this.hasCountryCode = 1;
      this.countryCode_ = paramInt;
      return this;
    }

    public PhoneMetadata setFixedLine(Phonemetadata.PhoneNumberDesc paramPhoneNumberDesc)
    {
      if (paramPhoneNumberDesc == null)
        throw new NullPointerException();
      this.hasFixedLine = 1;
      this.fixedLine_ = paramPhoneNumberDesc;
      return this;
    }

    public PhoneMetadata setGeneralDesc(Phonemetadata.PhoneNumberDesc paramPhoneNumberDesc)
    {
      if (paramPhoneNumberDesc == null)
        throw new NullPointerException();
      this.hasGeneralDesc = 1;
      this.generalDesc_ = paramPhoneNumberDesc;
      return this;
    }

    public PhoneMetadata setId(String paramString)
    {
      this.hasId = 1;
      this.id_ = paramString;
      return this;
    }

    public PhoneMetadata setInternationalPrefix(String paramString)
    {
      this.hasInternationalPrefix = 1;
      this.internationalPrefix_ = paramString;
      return this;
    }

    public PhoneMetadata setLeadingDigits(String paramString)
    {
      this.hasLeadingDigits = 1;
      this.leadingDigits_ = paramString;
      return this;
    }

    public PhoneMetadata setLeadingZeroPossible(boolean paramBoolean)
    {
      this.hasLeadingZeroPossible = 1;
      this.leadingZeroPossible_ = paramBoolean;
      return this;
    }

    public PhoneMetadata setMainCountryForCode(boolean paramBoolean)
    {
      this.hasMainCountryForCode = 1;
      this.mainCountryForCode_ = paramBoolean;
      return this;
    }

    public PhoneMetadata setMobile(Phonemetadata.PhoneNumberDesc paramPhoneNumberDesc)
    {
      if (paramPhoneNumberDesc == null)
        throw new NullPointerException();
      this.hasMobile = 1;
      this.mobile_ = paramPhoneNumberDesc;
      return this;
    }

    public PhoneMetadata setNationalPrefix(String paramString)
    {
      this.hasNationalPrefix = 1;
      this.nationalPrefix_ = paramString;
      return this;
    }

    public PhoneMetadata setNationalPrefixForParsing(String paramString)
    {
      this.hasNationalPrefixForParsing = 1;
      this.nationalPrefixForParsing_ = paramString;
      return this;
    }

    public PhoneMetadata setNationalPrefixTransformRule(String paramString)
    {
      this.hasNationalPrefixTransformRule = 1;
      this.nationalPrefixTransformRule_ = paramString;
      return this;
    }

    public PhoneMetadata setNoInternationalDialling(Phonemetadata.PhoneNumberDesc paramPhoneNumberDesc)
    {
      if (paramPhoneNumberDesc == null)
        throw new NullPointerException();
      this.hasNoInternationalDialling = 1;
      this.noInternationalDialling_ = paramPhoneNumberDesc;
      return this;
    }

    public PhoneMetadata setPager(Phonemetadata.PhoneNumberDesc paramPhoneNumberDesc)
    {
      if (paramPhoneNumberDesc == null)
        throw new NullPointerException();
      this.hasPager = 1;
      this.pager_ = paramPhoneNumberDesc;
      return this;
    }

    public PhoneMetadata setPersonalNumber(Phonemetadata.PhoneNumberDesc paramPhoneNumberDesc)
    {
      if (paramPhoneNumberDesc == null)
        throw new NullPointerException();
      this.hasPersonalNumber = 1;
      this.personalNumber_ = paramPhoneNumberDesc;
      return this;
    }

    public PhoneMetadata setPreferredExtnPrefix(String paramString)
    {
      this.hasPreferredExtnPrefix = 1;
      this.preferredExtnPrefix_ = paramString;
      return this;
    }

    public PhoneMetadata setPreferredInternationalPrefix(String paramString)
    {
      this.hasPreferredInternationalPrefix = 1;
      this.preferredInternationalPrefix_ = paramString;
      return this;
    }

    public PhoneMetadata setPremiumRate(Phonemetadata.PhoneNumberDesc paramPhoneNumberDesc)
    {
      if (paramPhoneNumberDesc == null)
        throw new NullPointerException();
      this.hasPremiumRate = 1;
      this.premiumRate_ = paramPhoneNumberDesc;
      return this;
    }

    public PhoneMetadata setSameMobileAndFixedLinePattern(boolean paramBoolean)
    {
      this.hasSameMobileAndFixedLinePattern = 1;
      this.sameMobileAndFixedLinePattern_ = paramBoolean;
      return this;
    }

    public PhoneMetadata setSharedCost(Phonemetadata.PhoneNumberDesc paramPhoneNumberDesc)
    {
      if (paramPhoneNumberDesc == null)
        throw new NullPointerException();
      this.hasSharedCost = 1;
      this.sharedCost_ = paramPhoneNumberDesc;
      return this;
    }

    public PhoneMetadata setTollFree(Phonemetadata.PhoneNumberDesc paramPhoneNumberDesc)
    {
      if (paramPhoneNumberDesc == null)
        throw new NullPointerException();
      this.hasTollFree = 1;
      this.tollFree_ = paramPhoneNumberDesc;
      return this;
    }

    public PhoneMetadata setUan(Phonemetadata.PhoneNumberDesc paramPhoneNumberDesc)
    {
      if (paramPhoneNumberDesc == null)
        throw new NullPointerException();
      this.hasUan = 1;
      this.uan_ = paramPhoneNumberDesc;
      return this;
    }

    public PhoneMetadata setVoip(Phonemetadata.PhoneNumberDesc paramPhoneNumberDesc)
    {
      if (paramPhoneNumberDesc == null)
        throw new NullPointerException();
      this.hasVoip = 1;
      this.voip_ = paramPhoneNumberDesc;
      return this;
    }

    public void writeExternal(ObjectOutput paramObjectOutput)
      throws IOException
    {
      int i = 0;
      boolean bool1 = this.hasGeneralDesc;
      paramObjectOutput.writeBoolean(bool1);
      if (this.hasGeneralDesc)
        this.generalDesc_.writeExternal(paramObjectOutput);
      boolean bool2 = this.hasFixedLine;
      paramObjectOutput.writeBoolean(bool2);
      if (this.hasFixedLine)
        this.fixedLine_.writeExternal(paramObjectOutput);
      boolean bool3 = this.hasMobile;
      paramObjectOutput.writeBoolean(bool3);
      if (this.hasMobile)
        this.mobile_.writeExternal(paramObjectOutput);
      boolean bool4 = this.hasTollFree;
      paramObjectOutput.writeBoolean(bool4);
      if (this.hasTollFree)
        this.tollFree_.writeExternal(paramObjectOutput);
      boolean bool5 = this.hasPremiumRate;
      paramObjectOutput.writeBoolean(bool5);
      if (this.hasPremiumRate)
        this.premiumRate_.writeExternal(paramObjectOutput);
      boolean bool6 = this.hasSharedCost;
      paramObjectOutput.writeBoolean(bool6);
      if (this.hasSharedCost)
        this.sharedCost_.writeExternal(paramObjectOutput);
      boolean bool7 = this.hasPersonalNumber;
      paramObjectOutput.writeBoolean(bool7);
      if (this.hasPersonalNumber)
        this.personalNumber_.writeExternal(paramObjectOutput);
      boolean bool8 = this.hasVoip;
      paramObjectOutput.writeBoolean(bool8);
      if (this.hasVoip)
        this.voip_.writeExternal(paramObjectOutput);
      boolean bool9 = this.hasPager;
      paramObjectOutput.writeBoolean(bool9);
      if (this.hasPager)
        this.pager_.writeExternal(paramObjectOutput);
      boolean bool10 = this.hasUan;
      paramObjectOutput.writeBoolean(bool10);
      if (this.hasUan)
        this.uan_.writeExternal(paramObjectOutput);
      boolean bool11 = this.hasNoInternationalDialling;
      paramObjectOutput.writeBoolean(bool11);
      if (this.hasNoInternationalDialling)
        this.noInternationalDialling_.writeExternal(paramObjectOutput);
      String str1 = this.id_;
      paramObjectOutput.writeUTF(str1);
      int j = this.countryCode_;
      paramObjectOutput.writeInt(j);
      String str2 = this.internationalPrefix_;
      paramObjectOutput.writeUTF(str2);
      boolean bool12 = this.hasPreferredInternationalPrefix;
      paramObjectOutput.writeBoolean(bool12);
      if (this.hasPreferredInternationalPrefix)
      {
        String str3 = this.preferredInternationalPrefix_;
        paramObjectOutput.writeUTF(str3);
      }
      boolean bool13 = this.hasNationalPrefix;
      paramObjectOutput.writeBoolean(bool13);
      if (this.hasNationalPrefix)
      {
        String str4 = this.nationalPrefix_;
        paramObjectOutput.writeUTF(str4);
      }
      boolean bool14 = this.hasPreferredExtnPrefix;
      paramObjectOutput.writeBoolean(bool14);
      if (this.hasPreferredExtnPrefix)
      {
        String str5 = this.preferredExtnPrefix_;
        paramObjectOutput.writeUTF(str5);
      }
      boolean bool15 = this.hasNationalPrefixForParsing;
      paramObjectOutput.writeBoolean(bool15);
      if (this.hasNationalPrefixForParsing)
      {
        String str6 = this.nationalPrefixForParsing_;
        paramObjectOutput.writeUTF(str6);
      }
      boolean bool16 = this.hasNationalPrefixTransformRule;
      paramObjectOutput.writeBoolean(bool16);
      if (this.hasNationalPrefixTransformRule)
      {
        String str7 = this.nationalPrefixTransformRule_;
        paramObjectOutput.writeUTF(str7);
      }
      boolean bool17 = this.sameMobileAndFixedLinePattern_;
      paramObjectOutput.writeBoolean(bool17);
      int k = numberFormatSize();
      paramObjectOutput.writeInt(k);
      int m = 0;
      while (m < k)
      {
        ((Phonemetadata.NumberFormat)this.numberFormat_.get(m)).writeExternal(paramObjectOutput);
        m += 1;
      }
      m = intlNumberFormatSize();
      paramObjectOutput.writeInt(m);
      while (i < m)
      {
        ((Phonemetadata.NumberFormat)this.intlNumberFormat_.get(i)).writeExternal(paramObjectOutput);
        i += 1;
      }
      boolean bool18 = this.mainCountryForCode_;
      paramObjectOutput.writeBoolean(bool18);
      boolean bool19 = this.hasLeadingDigits;
      paramObjectOutput.writeBoolean(bool19);
      if (this.hasLeadingDigits)
      {
        String str8 = this.leadingDigits_;
        paramObjectOutput.writeUTF(str8);
      }
      boolean bool20 = this.leadingZeroPossible_;
      paramObjectOutput.writeBoolean(bool20);
    }

    public final class Builder extends Phonemetadata.PhoneMetadata
    {
      public Phonemetadata.PhoneMetadata build()
      {
        return this;
      }
    }
  }

  public class PhoneNumberDesc
    implements Externalizable
  {
    private static final long serialVersionUID = 1L;
    private String exampleNumber_ = "";
    private boolean hasExampleNumber;
    private boolean hasNationalNumberPattern;
    private boolean hasPossibleNumberPattern;
    private String nationalNumberPattern_ = "";
    private String possibleNumberPattern_ = "";

    public static Builder newBuilder()
    {
      return new Builder();
    }

    public boolean exactlySameAs(PhoneNumberDesc paramPhoneNumberDesc)
    {
      String str1 = this.nationalNumberPattern_;
      String str2 = paramPhoneNumberDesc.nationalNumberPattern_;
      if (str1.equals(str2))
      {
        String str3 = this.possibleNumberPattern_;
        String str4 = paramPhoneNumberDesc.possibleNumberPattern_;
        if (str3.equals(str4))
        {
          String str5 = this.exampleNumber_;
          String str6 = paramPhoneNumberDesc.exampleNumber_;
          if (!str5.equals(str6));
        }
      }
      for (int i = 1; ; i = 0)
        return i;
    }

    public String getExampleNumber()
    {
      return this.exampleNumber_;
    }

    public String getNationalNumberPattern()
    {
      return this.nationalNumberPattern_;
    }

    public String getPossibleNumberPattern()
    {
      return this.possibleNumberPattern_;
    }

    public boolean hasExampleNumber()
    {
      return this.hasExampleNumber;
    }

    public boolean hasNationalNumberPattern()
    {
      return this.hasNationalNumberPattern;
    }

    public boolean hasPossibleNumberPattern()
    {
      return this.hasPossibleNumberPattern;
    }

    public PhoneNumberDesc mergeFrom(PhoneNumberDesc paramPhoneNumberDesc)
    {
      if (paramPhoneNumberDesc.hasNationalNumberPattern())
      {
        String str1 = paramPhoneNumberDesc.getNationalNumberPattern();
        PhoneNumberDesc localPhoneNumberDesc1 = setNationalNumberPattern(str1);
      }
      if (paramPhoneNumberDesc.hasPossibleNumberPattern())
      {
        String str2 = paramPhoneNumberDesc.getPossibleNumberPattern();
        PhoneNumberDesc localPhoneNumberDesc2 = setPossibleNumberPattern(str2);
      }
      if (paramPhoneNumberDesc.hasExampleNumber())
      {
        String str3 = paramPhoneNumberDesc.getExampleNumber();
        PhoneNumberDesc localPhoneNumberDesc3 = setExampleNumber(str3);
      }
      return this;
    }

    public void readExternal(ObjectInput paramObjectInput)
      throws IOException
    {
      if (paramObjectInput.readBoolean())
      {
        String str1 = paramObjectInput.readUTF();
        PhoneNumberDesc localPhoneNumberDesc1 = setNationalNumberPattern(str1);
      }
      if (paramObjectInput.readBoolean())
      {
        String str2 = paramObjectInput.readUTF();
        PhoneNumberDesc localPhoneNumberDesc2 = setPossibleNumberPattern(str2);
      }
      if (paramObjectInput.readBoolean())
      {
        String str3 = paramObjectInput.readUTF();
        PhoneNumberDesc localPhoneNumberDesc3 = setExampleNumber(str3);
      }
    }

    public PhoneNumberDesc setExampleNumber(String paramString)
    {
      this.hasExampleNumber = 1;
      this.exampleNumber_ = paramString;
      return this;
    }

    public PhoneNumberDesc setNationalNumberPattern(String paramString)
    {
      this.hasNationalNumberPattern = 1;
      this.nationalNumberPattern_ = paramString;
      return this;
    }

    public PhoneNumberDesc setPossibleNumberPattern(String paramString)
    {
      this.hasPossibleNumberPattern = 1;
      this.possibleNumberPattern_ = paramString;
      return this;
    }

    public void writeExternal(ObjectOutput paramObjectOutput)
      throws IOException
    {
      boolean bool1 = this.hasNationalNumberPattern;
      paramObjectOutput.writeBoolean(bool1);
      if (this.hasNationalNumberPattern)
      {
        String str1 = this.nationalNumberPattern_;
        paramObjectOutput.writeUTF(str1);
      }
      boolean bool2 = this.hasPossibleNumberPattern;
      paramObjectOutput.writeBoolean(bool2);
      if (this.hasPossibleNumberPattern)
      {
        String str2 = this.possibleNumberPattern_;
        paramObjectOutput.writeUTF(str2);
      }
      boolean bool3 = this.hasExampleNumber;
      paramObjectOutput.writeBoolean(bool3);
      if (this.hasExampleNumber)
      {
        String str3 = this.exampleNumber_;
        paramObjectOutput.writeUTF(str3);
      }
    }

    public final class Builder extends Phonemetadata.PhoneNumberDesc
    {
      public Phonemetadata.PhoneNumberDesc build()
      {
        return this;
      }
    }
  }

  public class NumberFormat
    implements Externalizable
  {
    private static final long serialVersionUID = 1L;
    private String domesticCarrierCodeFormattingRule_;
    private String format_ = "";
    private boolean hasDomesticCarrierCodeFormattingRule;
    private boolean hasFormat;
    private boolean hasNationalPrefixFormattingRule;
    private boolean hasPattern;
    private List<String> leadingDigitsPattern_;
    private String nationalPrefixFormattingRule_;
    private String pattern_ = "";

    public NumberFormat()
    {
      this$1 = new ArrayList();
      this.leadingDigitsPattern_ = this$1;
      this.nationalPrefixFormattingRule_ = "";
      this.domesticCarrierCodeFormattingRule_ = "";
    }

    public static Builder newBuilder()
    {
      return new Builder();
    }

    public NumberFormat addLeadingDigitsPattern(String paramString)
    {
      if (paramString == null)
        throw new NullPointerException();
      boolean bool = this.leadingDigitsPattern_.add(paramString);
      return this;
    }

    public NumberFormat clearNationalPrefixFormattingRule()
    {
      this.hasNationalPrefixFormattingRule = 0;
      this.nationalPrefixFormattingRule_ = "";
      return this;
    }

    public String getDomesticCarrierCodeFormattingRule()
    {
      return this.domesticCarrierCodeFormattingRule_;
    }

    public String getFormat()
    {
      return this.format_;
    }

    public String getLeadingDigitsPattern(int paramInt)
    {
      return (String)this.leadingDigitsPattern_.get(paramInt);
    }

    public String getNationalPrefixFormattingRule()
    {
      return this.nationalPrefixFormattingRule_;
    }

    public String getPattern()
    {
      return this.pattern_;
    }

    public boolean hasDomesticCarrierCodeFormattingRule()
    {
      return this.hasDomesticCarrierCodeFormattingRule;
    }

    public boolean hasFormat()
    {
      return this.hasFormat;
    }

    public boolean hasNationalPrefixFormattingRule()
    {
      return this.hasNationalPrefixFormattingRule;
    }

    public boolean hasPattern()
    {
      return this.hasPattern;
    }

    public List<String> leadingDigitPatterns()
    {
      return this.leadingDigitsPattern_;
    }

    public int leadingDigitsPatternSize()
    {
      return this.leadingDigitsPattern_.size();
    }

    public NumberFormat mergeFrom(NumberFormat paramNumberFormat)
    {
      if (paramNumberFormat.hasPattern())
      {
        String str1 = paramNumberFormat.getPattern();
        NumberFormat localNumberFormat1 = setPattern(str1);
      }
      if (paramNumberFormat.hasFormat())
      {
        String str2 = paramNumberFormat.getFormat();
        NumberFormat localNumberFormat2 = setFormat(str2);
      }
      int i = paramNumberFormat.leadingDigitsPatternSize();
      int j = 0;
      while (j < i)
      {
        String str3 = paramNumberFormat.getLeadingDigitsPattern(j);
        NumberFormat localNumberFormat3 = addLeadingDigitsPattern(str3);
        j += 1;
      }
      if (paramNumberFormat.hasNationalPrefixFormattingRule())
      {
        String str4 = paramNumberFormat.getNationalPrefixFormattingRule();
        NumberFormat localNumberFormat4 = setNationalPrefixFormattingRule(str4);
      }
      if (paramNumberFormat.hasDomesticCarrierCodeFormattingRule())
      {
        String str5 = paramNumberFormat.getDomesticCarrierCodeFormattingRule();
        NumberFormat localNumberFormat5 = setDomesticCarrierCodeFormattingRule(str5);
      }
      return this;
    }

    public void readExternal(ObjectInput paramObjectInput)
      throws IOException
    {
      String str1 = paramObjectInput.readUTF();
      NumberFormat localNumberFormat1 = setPattern(str1);
      String str2 = paramObjectInput.readUTF();
      NumberFormat localNumberFormat2 = setFormat(str2);
      int i = paramObjectInput.readInt();
      int j = 0;
      while (j < i)
      {
        List localList = this.leadingDigitsPattern_;
        String str3 = paramObjectInput.readUTF();
        boolean bool = localList.add(str3);
        j += 1;
      }
      if (paramObjectInput.readBoolean())
      {
        String str4 = paramObjectInput.readUTF();
        NumberFormat localNumberFormat3 = setNationalPrefixFormattingRule(str4);
      }
      if (paramObjectInput.readBoolean())
      {
        String str5 = paramObjectInput.readUTF();
        NumberFormat localNumberFormat4 = setDomesticCarrierCodeFormattingRule(str5);
      }
    }

    public NumberFormat setDomesticCarrierCodeFormattingRule(String paramString)
    {
      this.hasDomesticCarrierCodeFormattingRule = 1;
      this.domesticCarrierCodeFormattingRule_ = paramString;
      return this;
    }

    public NumberFormat setFormat(String paramString)
    {
      this.hasFormat = 1;
      this.format_ = paramString;
      return this;
    }

    public NumberFormat setNationalPrefixFormattingRule(String paramString)
    {
      this.hasNationalPrefixFormattingRule = 1;
      this.nationalPrefixFormattingRule_ = paramString;
      return this;
    }

    public NumberFormat setPattern(String paramString)
    {
      this.hasPattern = 1;
      this.pattern_ = paramString;
      return this;
    }

    public void writeExternal(ObjectOutput paramObjectOutput)
      throws IOException
    {
      String str1 = this.pattern_;
      paramObjectOutput.writeUTF(str1);
      String str2 = this.format_;
      paramObjectOutput.writeUTF(str2);
      int i = leadingDigitsPatternSize();
      paramObjectOutput.writeInt(i);
      int j = 0;
      while (j < i)
      {
        String str3 = (String)this.leadingDigitsPattern_.get(j);
        paramObjectOutput.writeUTF(str3);
        j += 1;
      }
      boolean bool1 = this.hasNationalPrefixFormattingRule;
      paramObjectOutput.writeBoolean(bool1);
      if (this.hasNationalPrefixFormattingRule)
      {
        String str4 = this.nationalPrefixFormattingRule_;
        paramObjectOutput.writeUTF(str4);
      }
      boolean bool2 = this.hasDomesticCarrierCodeFormattingRule;
      paramObjectOutput.writeBoolean(bool2);
      if (this.hasDomesticCarrierCodeFormattingRule)
      {
        String str5 = this.domesticCarrierCodeFormattingRule_;
        paramObjectOutput.writeUTF(str5);
      }
    }

    public final class Builder extends Phonemetadata.NumberFormat
    {
      public Phonemetadata.NumberFormat build()
      {
        return this;
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.i18n.phonenumbers.Phonemetadata
 * JD-Core Version:    0.6.0
 */