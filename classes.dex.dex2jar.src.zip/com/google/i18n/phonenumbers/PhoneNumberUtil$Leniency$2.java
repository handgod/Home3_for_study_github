package com.google.i18n.phonenumbers;

 enum PhoneNumberUtil$Leniency$2
{
  boolean verify(Phonenumber.PhoneNumber paramPhoneNumber, String paramString, PhoneNumberUtil paramPhoneNumberUtil)
  {
    if (!paramPhoneNumberUtil.isValidNumber(paramPhoneNumber));
    boolean bool;
    for (int i = 0; ; bool = PhoneNumberUtil.Leniency.access$100(paramPhoneNumber, paramString, paramPhoneNumberUtil))
      return i;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.i18n.phonenumbers.PhoneNumberUtil.Leniency.2
 * JD-Core Version:    0.6.0
 */