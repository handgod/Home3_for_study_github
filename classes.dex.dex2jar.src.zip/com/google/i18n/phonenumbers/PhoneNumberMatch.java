package com.google.i18n.phonenumbers;

import java.util.Arrays;

public final class PhoneNumberMatch
{
  private final Phonenumber.PhoneNumber number;
  private final String rawString;
  private final int start;

  PhoneNumberMatch(int paramInt, String paramString, Phonenumber.PhoneNumber paramPhoneNumber)
  {
    if (paramInt < 0)
      throw new IllegalArgumentException("Start index must be >= 0.");
    if ((paramString == null) || (paramPhoneNumber == null))
      throw new NullPointerException();
    this.start = paramInt;
    this.rawString = paramString;
    this.number = paramPhoneNumber;
  }

  public int end()
  {
    int i = this.start;
    int j = this.rawString.length();
    return i + j;
  }

  public boolean equals(Object paramObject)
  {
    int i = 1;
    if (this == paramObject);
    while (true)
    {
      return i;
      if (!(paramObject instanceof PhoneNumberMatch))
      {
        i = 0;
        continue;
      }
      paramObject = (PhoneNumberMatch)paramObject;
      String str1 = this.rawString;
      String str2 = paramObject.rawString;
      if (str1.equals(str2))
      {
        int j = this.start;
        int k = paramObject.start;
        if (j == k)
        {
          Phonenumber.PhoneNumber localPhoneNumber1 = this.number;
          Phonenumber.PhoneNumber localPhoneNumber2 = paramObject.number;
          if (localPhoneNumber1.equals(localPhoneNumber2))
            continue;
        }
      }
      i = 0;
    }
  }

  public int hashCode()
  {
    Object[] arrayOfObject = new Object[3];
    Integer localInteger = Integer.valueOf(this.start);
    arrayOfObject[0] = localInteger;
    String str = this.rawString;
    arrayOfObject[1] = str;
    Phonenumber.PhoneNumber localPhoneNumber = this.number;
    arrayOfObject[2] = localPhoneNumber;
    return Arrays.hashCode(arrayOfObject);
  }

  public Phonenumber.PhoneNumber number()
  {
    return this.number;
  }

  public String rawString()
  {
    return this.rawString;
  }

  public int start()
  {
    return this.start;
  }

  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("PhoneNumberMatch [");
    int i = start();
    StringBuilder localStringBuilder2 = localStringBuilder1.append(i).append(",");
    int j = end();
    StringBuilder localStringBuilder3 = localStringBuilder2.append(j).append(") ");
    String str = this.rawString;
    return str;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.i18n.phonenumbers.PhoneNumberMatch
 * JD-Core Version:    0.6.0
 */