package com.google.i18n.phonenumbers;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PhoneNumberUtil
{
  private static final Map<Character, Character> ALL_PLUS_NUMBER_GROUPING_SYMBOLS = ;
  private static final Map<Character, Character> ALPHA_MAPPINGS = ;
  private static final Map<Character, Character> ALPHA_PHONE_MAPPINGS = ;
  private static final Pattern CAPTURING_DIGIT_PATTERN = ;
  private static final String CAPTURING_EXTN_DIGITS = "(\\p{Nd}{1,7})";
  private static final Pattern CC_PATTERN = ;
  private static final String DEFAULT_EXTN_PREFIX = " ext. ";
  private static final String DIGITS = "\\p{Nd}";
  private static final Pattern EXTN_PATTERN = ;
  static final String EXTN_PATTERNS_FOR_MATCHING = ;
  private static final String EXTN_PATTERNS_FOR_PARSING = ;
  private static final Pattern FG_PATTERN = ;
  private static final Pattern FIRST_GROUP_PATTERN = ;
  private static final Logger LOGGER = ;
  static final int MAX_LENGTH_COUNTRY_CODE = 3;
  static final int MAX_LENGTH_FOR_NSN = 15;
  static final String META_DATA_FILE_PREFIX = "/com/google/i18n/phonenumbers/data/PhoneNumberMetadataProto";
  private static final int MIN_LENGTH_FOR_NSN = 3;
  private static final int NANPA_COUNTRY_CODE = 1;
  private static final Pattern NON_DIGITS_PATTERN = ;
  private static final Pattern NP_PATTERN = ;
  static final String PLUS_CHARS = "+＋";
  static final Pattern PLUS_CHARS_PATTERN = ;
  static final char PLUS_SIGN = '+';
  static final int REGEX_FLAGS = 66;
  private static final String RFC3966_EXTN_PREFIX = ";ext=";
  private static final String SECOND_NUMBER_START = "[\\\\/] *x";
  static final Pattern SECOND_NUMBER_START_PATTERN = ;
  private static final Pattern SEPARATOR_PATTERN = ;
  private static final Pattern UNIQUE_INTERNATIONAL_PREFIX = ;
  private static final String UNKNOWN_REGION = "ZZ";
  private static final String UNWANTED_END_CHARS = "[[\\P{N}&&\\P{L}]&&[^#]]+$";
  static final Pattern UNWANTED_END_CHAR_PATTERN = ;
  private static final String VALID_ALPHA = ;
  private static final Pattern VALID_ALPHA_PHONE_PATTERN = ;
  private static final String VALID_PHONE_NUMBER = ;
  private static final Pattern VALID_PHONE_NUMBER_PATTERN = ;
  static final String VALID_PUNCTUATION = "-x‐-―−ー－-／  ​⁠　()（）［］.\\[\\]/~⁓∼～";
  private static final String VALID_START_CHAR = "[+＋\\p{Nd}]";
  private static final Pattern VALID_START_CHAR_PATTERN;
  private static PhoneNumberUtil instance;
  private Map<Integer, List<String>> countryCallingCodeToRegionCodeMap = null;
  private String currentFilePrefix = "/com/google/i18n/phonenumbers/data/PhoneNumberMetadataProto";
  private final Set<String> nanpaRegions;
  private RegexCache regexCache;
  private Map<String, Phonemetadata.PhoneMetadata> regionToMetadataMap;
  private final Set<String> supportedRegions;

  static
  {
    HashMap localHashMap1 = new HashMap();
    Character localCharacter1 = Character.valueOf(48);
    Character localCharacter2 = Character.valueOf(48);
    Object localObject1 = localHashMap1.put(localCharacter1, localCharacter2);
    Character localCharacter3 = Character.valueOf(49);
    Character localCharacter4 = Character.valueOf(49);
    Object localObject2 = localHashMap1.put(localCharacter3, localCharacter4);
    Character localCharacter5 = Character.valueOf(50);
    Character localCharacter6 = Character.valueOf(50);
    Object localObject3 = localHashMap1.put(localCharacter5, localCharacter6);
    Character localCharacter7 = Character.valueOf(51);
    Character localCharacter8 = Character.valueOf(51);
    Object localObject4 = localHashMap1.put(localCharacter7, localCharacter8);
    Character localCharacter9 = Character.valueOf(52);
    Character localCharacter10 = Character.valueOf(52);
    Object localObject5 = localHashMap1.put(localCharacter9, localCharacter10);
    Character localCharacter11 = Character.valueOf(53);
    Character localCharacter12 = Character.valueOf(53);
    Object localObject6 = localHashMap1.put(localCharacter11, localCharacter12);
    Character localCharacter13 = Character.valueOf(54);
    Character localCharacter14 = Character.valueOf(54);
    Object localObject7 = localHashMap1.put(localCharacter13, localCharacter14);
    Character localCharacter15 = Character.valueOf(55);
    Character localCharacter16 = Character.valueOf(55);
    Object localObject8 = localHashMap1.put(localCharacter15, localCharacter16);
    Character localCharacter17 = Character.valueOf(56);
    Character localCharacter18 = Character.valueOf(56);
    Object localObject9 = localHashMap1.put(localCharacter17, localCharacter18);
    Character localCharacter19 = Character.valueOf(57);
    Character localCharacter20 = Character.valueOf(57);
    Object localObject10 = localHashMap1.put(localCharacter19, localCharacter20);
    HashMap localHashMap2 = new HashMap(40);
    Character localCharacter21 = Character.valueOf(65);
    Character localCharacter22 = Character.valueOf(50);
    Object localObject11 = localHashMap2.put(localCharacter21, localCharacter22);
    Character localCharacter23 = Character.valueOf(66);
    Character localCharacter24 = Character.valueOf(50);
    Object localObject12 = localHashMap2.put(localCharacter23, localCharacter24);
    Character localCharacter25 = Character.valueOf(67);
    Character localCharacter26 = Character.valueOf(50);
    Object localObject13 = localHashMap2.put(localCharacter25, localCharacter26);
    Character localCharacter27 = Character.valueOf(68);
    Character localCharacter28 = Character.valueOf(51);
    Object localObject14 = localHashMap2.put(localCharacter27, localCharacter28);
    Character localCharacter29 = Character.valueOf(69);
    Character localCharacter30 = Character.valueOf(51);
    Object localObject15 = localHashMap2.put(localCharacter29, localCharacter30);
    Character localCharacter31 = Character.valueOf(70);
    Character localCharacter32 = Character.valueOf(51);
    Object localObject16 = localHashMap2.put(localCharacter31, localCharacter32);
    Character localCharacter33 = Character.valueOf(71);
    Character localCharacter34 = Character.valueOf(52);
    Object localObject17 = localHashMap2.put(localCharacter33, localCharacter34);
    Character localCharacter35 = Character.valueOf(72);
    Character localCharacter36 = Character.valueOf(52);
    Object localObject18 = localHashMap2.put(localCharacter35, localCharacter36);
    Character localCharacter37 = Character.valueOf(73);
    Character localCharacter38 = Character.valueOf(52);
    Object localObject19 = localHashMap2.put(localCharacter37, localCharacter38);
    Character localCharacter39 = Character.valueOf(74);
    Character localCharacter40 = Character.valueOf(53);
    Object localObject20 = localHashMap2.put(localCharacter39, localCharacter40);
    Character localCharacter41 = Character.valueOf(75);
    Character localCharacter42 = Character.valueOf(53);
    Object localObject21 = localHashMap2.put(localCharacter41, localCharacter42);
    Character localCharacter43 = Character.valueOf(76);
    Character localCharacter44 = Character.valueOf(53);
    Object localObject22 = localHashMap2.put(localCharacter43, localCharacter44);
    Character localCharacter45 = Character.valueOf(77);
    Character localCharacter46 = Character.valueOf(54);
    Object localObject23 = localHashMap2.put(localCharacter45, localCharacter46);
    Character localCharacter47 = Character.valueOf(78);
    Character localCharacter48 = Character.valueOf(54);
    Object localObject24 = localHashMap2.put(localCharacter47, localCharacter48);
    Character localCharacter49 = Character.valueOf(79);
    Character localCharacter50 = Character.valueOf(54);
    Object localObject25 = localHashMap2.put(localCharacter49, localCharacter50);
    Character localCharacter51 = Character.valueOf(80);
    Character localCharacter52 = Character.valueOf(55);
    Object localObject26 = localHashMap2.put(localCharacter51, localCharacter52);
    Character localCharacter53 = Character.valueOf(81);
    Character localCharacter54 = Character.valueOf(55);
    Object localObject27 = localHashMap2.put(localCharacter53, localCharacter54);
    Character localCharacter55 = Character.valueOf(82);
    Character localCharacter56 = Character.valueOf(55);
    Object localObject28 = localHashMap2.put(localCharacter55, localCharacter56);
    Character localCharacter57 = Character.valueOf(83);
    Character localCharacter58 = Character.valueOf(55);
    Object localObject29 = localHashMap2.put(localCharacter57, localCharacter58);
    Character localCharacter59 = Character.valueOf(84);
    Character localCharacter60 = Character.valueOf(56);
    Object localObject30 = localHashMap2.put(localCharacter59, localCharacter60);
    Character localCharacter61 = Character.valueOf(85);
    Character localCharacter62 = Character.valueOf(56);
    Object localObject31 = localHashMap2.put(localCharacter61, localCharacter62);
    Character localCharacter63 = Character.valueOf(86);
    Character localCharacter64 = Character.valueOf(56);
    Object localObject32 = localHashMap2.put(localCharacter63, localCharacter64);
    Character localCharacter65 = Character.valueOf(87);
    Character localCharacter66 = Character.valueOf(57);
    Object localObject33 = localHashMap2.put(localCharacter65, localCharacter66);
    Character localCharacter67 = Character.valueOf(88);
    Character localCharacter68 = Character.valueOf(57);
    Object localObject34 = localHashMap2.put(localCharacter67, localCharacter68);
    Character localCharacter69 = Character.valueOf(89);
    Character localCharacter70 = Character.valueOf(57);
    Object localObject35 = localHashMap2.put(localCharacter69, localCharacter70);
    Character localCharacter71 = Character.valueOf(90);
    Character localCharacter72 = Character.valueOf(57);
    Object localObject36 = localHashMap2.put(localCharacter71, localCharacter72);
    ALPHA_MAPPINGS = Collections.unmodifiableMap(localHashMap2);
    HashMap localHashMap3 = new HashMap(100);
    Map localMap = ALPHA_MAPPINGS;
    localHashMap3.putAll(localMap);
    localHashMap3.putAll(localHashMap1);
    ALPHA_PHONE_MAPPINGS = Collections.unmodifiableMap(localHashMap3);
    HashMap localHashMap4 = new HashMap();
    Iterator localIterator = ALPHA_MAPPINGS.keySet().iterator();
    while (localIterator.hasNext())
    {
      char c = ((Character)localIterator.next()).charValue();
      Character localCharacter73 = Character.valueOf(Character.toLowerCase(c));
      Character localCharacter74 = Character.valueOf(c);
      Object localObject37 = localHashMap4.put(localCharacter73, localCharacter74);
      Character localCharacter75 = Character.valueOf(c);
      Character localCharacter76 = Character.valueOf(c);
      Object localObject38 = localHashMap4.put(localCharacter75, localCharacter76);
    }
    localHashMap4.putAll(localHashMap1);
    Character localCharacter77 = Character.valueOf(45);
    Character localCharacter78 = Character.valueOf(45);
    Object localObject39 = localHashMap4.put(localCharacter77, localCharacter78);
    Character localCharacter79 = Character.valueOf(65293);
    Character localCharacter80 = Character.valueOf(45);
    Object localObject40 = localHashMap4.put(localCharacter79, localCharacter80);
    Character localCharacter81 = Character.valueOf(8208);
    Character localCharacter82 = Character.valueOf(45);
    Object localObject41 = localHashMap4.put(localCharacter81, localCharacter82);
    Character localCharacter83 = Character.valueOf(8209);
    Character localCharacter84 = Character.valueOf(45);
    Object localObject42 = localHashMap4.put(localCharacter83, localCharacter84);
    Character localCharacter85 = Character.valueOf(8210);
    Character localCharacter86 = Character.valueOf(45);
    Object localObject43 = localHashMap4.put(localCharacter85, localCharacter86);
    Character localCharacter87 = Character.valueOf(8211);
    Character localCharacter88 = Character.valueOf(45);
    Object localObject44 = localHashMap4.put(localCharacter87, localCharacter88);
    Character localCharacter89 = Character.valueOf(8212);
    Character localCharacter90 = Character.valueOf(45);
    Object localObject45 = localHashMap4.put(localCharacter89, localCharacter90);
    Character localCharacter91 = Character.valueOf(8213);
    Character localCharacter92 = Character.valueOf(45);
    Object localObject46 = localHashMap4.put(localCharacter91, localCharacter92);
    Character localCharacter93 = Character.valueOf(8722);
    Character localCharacter94 = Character.valueOf(45);
    Object localObject47 = localHashMap4.put(localCharacter93, localCharacter94);
    Character localCharacter95 = Character.valueOf(47);
    Character localCharacter96 = Character.valueOf(47);
    Object localObject48 = localHashMap4.put(localCharacter95, localCharacter96);
    Character localCharacter97 = Character.valueOf(65295);
    Character localCharacter98 = Character.valueOf(47);
    Object localObject49 = localHashMap4.put(localCharacter97, localCharacter98);
    Character localCharacter99 = Character.valueOf(32);
    Character localCharacter100 = Character.valueOf(32);
    Object localObject50 = localHashMap4.put(localCharacter99, localCharacter100);
    Character localCharacter101 = Character.valueOf(12288);
    Character localCharacter102 = Character.valueOf(32);
    Object localObject51 = localHashMap4.put(localCharacter101, localCharacter102);
    Character localCharacter103 = Character.valueOf(8288);
    Character localCharacter104 = Character.valueOf(32);
    Object localObject52 = localHashMap4.put(localCharacter103, localCharacter104);
    Character localCharacter105 = Character.valueOf(46);
    Character localCharacter106 = Character.valueOf(46);
    Object localObject53 = localHashMap4.put(localCharacter105, localCharacter106);
    Character localCharacter107 = Character.valueOf(65294);
    Character localCharacter108 = Character.valueOf(46);
    Object localObject54 = localHashMap4.put(localCharacter107, localCharacter108);
    ALL_PLUS_NUMBER_GROUPING_SYMBOLS = Collections.unmodifiableMap(localHashMap4);
    UNIQUE_INTERNATIONAL_PREFIX = Pattern.compile("[\\d]+(?:[~⁓∼～][\\d]+)?");
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str1 = Arrays.toString(ALPHA_MAPPINGS.keySet().toArray()).replaceAll("[, \\[\\]]", "");
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
    String str2 = Arrays.toString(ALPHA_MAPPINGS.keySet().toArray()).toLowerCase().replaceAll("[, \\[\\]]", "");
    VALID_ALPHA = str2;
    PLUS_CHARS_PATTERN = Pattern.compile("[+＋]+");
    SEPARATOR_PATTERN = Pattern.compile("[-x‐-―−ー－-／  ​⁠　()（）［］.\\[\\]/~⁓∼～]+");
    CAPTURING_DIGIT_PATTERN = Pattern.compile("(\\p{Nd})");
    VALID_START_CHAR_PATTERN = Pattern.compile("[+＋\\p{Nd}]");
    SECOND_NUMBER_START_PATTERN = Pattern.compile("[\\\\/] *x");
    UNWANTED_END_CHAR_PATTERN = Pattern.compile("[[\\P{N}&&\\P{L}]&&[^#]]+$");
    VALID_ALPHA_PHONE_PATTERN = Pattern.compile("(?:.*?[A-Za-z]){3}.*");
    StringBuilder localStringBuilder3 = new StringBuilder().append("[+＋]*(?:[-x‐-―−ー－-／  ​⁠　()（）［］.\\[\\]/~⁓∼～]*\\p{Nd}){3,}[-x‐-―−ー－-／  ​⁠　()（）［］.\\[\\]/~⁓∼～");
    String str3 = VALID_ALPHA;
    VALID_PHONE_NUMBER = str3 + "\\p{Nd}" + "]*";
    EXTN_PATTERNS_FOR_PARSING = createExtnPattern("," + "xｘ#＃~～");
    EXTN_PATTERNS_FOR_MATCHING = createExtnPattern("xｘ#＃~～");
    StringBuilder localStringBuilder4 = new StringBuilder().append("(?:");
    String str4 = EXTN_PATTERNS_FOR_PARSING;
    EXTN_PATTERN = Pattern.compile(str4 + ")$", 66);
    StringBuilder localStringBuilder5 = new StringBuilder();
    String str5 = VALID_PHONE_NUMBER;
    StringBuilder localStringBuilder6 = localStringBuilder5.append(str5).append("(?:");
    String str6 = EXTN_PATTERNS_FOR_PARSING;
    VALID_PHONE_NUMBER_PATTERN = Pattern.compile(str6 + ")?", 66);
    NON_DIGITS_PATTERN = Pattern.compile("(\\D+)");
    FIRST_GROUP_PATTERN = Pattern.compile("(\\$\\d)");
    NP_PATTERN = Pattern.compile("\\$NP");
    FG_PATTERN = Pattern.compile("\\$FG");
    CC_PATTERN = Pattern.compile("\\$CC");
    instance = null;
  }

  private PhoneNumberUtil()
  {
    HashSet localHashSet1 = new HashSet(300);
    this.supportedRegions = localHashSet1;
    HashSet localHashSet2 = new HashSet(35);
    this.nanpaRegions = localHashSet2;
    HashMap localHashMap = new HashMap();
    this.regionToMetadataMap = localHashMap;
    RegexCache localRegexCache = new RegexCache(100);
    this.regexCache = localRegexCache;
  }

  private boolean checkRegionForParsing(String paramString1, String paramString2)
  {
    if ((!isValidRegionCode(paramString2)) && ((paramString1 == null) || (paramString1.length() == 0) || (!PLUS_CHARS_PATTERN.matcher(paramString1).lookingAt())));
    for (int i = 0; ; i = 1)
      return i;
  }

  public static String convertAlphaCharactersInNumber(String paramString)
  {
    Map localMap = ALPHA_PHONE_MAPPINGS;
    return normalizeHelper(paramString, localMap, 0);
  }

  private static String createExtnPattern(String paramString)
  {
    return ";ext=(\\p{Nd}{1,7})|[  \\t,]*(?:ext(?:ensi(?:ó?|ó))?n?|ｅｘｔｎ?|[" + paramString + "]|int|anexo|ｉｎｔ)" + "[:\\.．]?[  \\t,-]*" + "(\\p{Nd}{1,7})" + "#?|" + "[- ]+(" + "\\p{Nd}" + "{1,5})#";
  }

  static String extractPossibleNumber(String paramString)
  {
    Object localObject = VALID_START_CHAR_PATTERN.matcher(paramString);
    int k;
    if (((Matcher)localObject).find())
    {
      int i = ((Matcher)localObject).start();
      localObject = paramString.substring(i);
      Matcher localMatcher = UNWANTED_END_CHAR_PATTERN.matcher((CharSequence)localObject);
      if (localMatcher.find())
      {
        int j = localMatcher.start();
        localObject = ((String)localObject).substring(0, j);
        Logger localLogger = LOGGER;
        Level localLevel = Level.FINER;
        String str = "Stripped trailing characters: " + (String)localObject;
        localLogger.log(localLevel, str);
      }
      localMatcher = SECOND_NUMBER_START_PATTERN.matcher((CharSequence)localObject);
      if (localMatcher.find())
        k = localMatcher.start();
    }
    for (localObject = ((String)localObject).substring(0, k); ; localObject = "")
      return localObject;
  }

  private String formatAccordingToFormats(String paramString, List<Phonemetadata.NumberFormat> paramList, PhoneNumberFormat paramPhoneNumberFormat)
  {
    return formatAccordingToFormats(paramString, paramList, paramPhoneNumberFormat, null);
  }

  private String formatAccordingToFormats(String paramString1, List<Phonemetadata.NumberFormat> paramList, PhoneNumberFormat paramPhoneNumberFormat, String paramString2)
  {
    Object localObject1 = paramList.iterator();
    Object localObject2;
    Matcher localMatcher;
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (Phonemetadata.NumberFormat)((Iterator)localObject1).next();
      int i = ((Phonemetadata.NumberFormat)localObject2).leadingDigitsPatternSize();
      if (i != 0)
      {
        RegexCache localRegexCache1 = this.regexCache;
        int j = i + -1;
        String str1 = ((Phonemetadata.NumberFormat)localObject2).getLeadingDigitsPattern(j);
        if (!localRegexCache1.getPatternForRegex(str1).matcher(paramString1).lookingAt())
          continue;
      }
      RegexCache localRegexCache2 = this.regexCache;
      String str2 = ((Phonemetadata.NumberFormat)localObject2).getPattern();
      localMatcher = localRegexCache2.getPatternForRegex(str2).matcher(paramString1);
      if (!localMatcher.matches())
        continue;
      localObject1 = ((Phonemetadata.NumberFormat)localObject2).getFormat();
      PhoneNumberFormat localPhoneNumberFormat1 = PhoneNumberFormat.NATIONAL;
      if ((paramPhoneNumberFormat != localPhoneNumberFormat1) || (paramString2 == null) || (paramString2.length() <= 0) || (((Phonemetadata.NumberFormat)localObject2).getDomesticCarrierCodeFormattingRule().length() <= 0))
        break label204;
      String str3 = ((Phonemetadata.NumberFormat)localObject2).getDomesticCarrierCodeFormattingRule();
      String str4 = CC_PATTERN.matcher(str3).replaceFirst(paramString2);
      String str5 = FIRST_GROUP_PATTERN.matcher((CharSequence)localObject1).replaceFirst(str4);
      paramString1 = localMatcher.replaceAll(str5);
    }
    while (true)
    {
      return paramString1;
      label204: localObject2 = ((Phonemetadata.NumberFormat)localObject2).getNationalPrefixFormattingRule();
      PhoneNumberFormat localPhoneNumberFormat2 = PhoneNumberFormat.NATIONAL;
      if ((paramPhoneNumberFormat == localPhoneNumberFormat2) && (localObject2 != null) && (((String)localObject2).length() > 0))
      {
        String str6 = FIRST_GROUP_PATTERN.matcher((CharSequence)localObject1).replaceFirst((String)localObject2);
        paramString1 = localMatcher.replaceAll(str6);
        continue;
      }
      paramString1 = localMatcher.replaceAll((String)localObject1);
    }
  }

  private void formatExtension(String paramString1, String paramString2, StringBuilder paramStringBuilder)
  {
    Phonemetadata.PhoneMetadata localPhoneMetadata = getMetadataForRegion(paramString2);
    if (localPhoneMetadata.hasPreferredExtnPrefix())
    {
      String str = localPhoneMetadata.getPreferredExtnPrefix();
      StringBuilder localStringBuilder1 = paramStringBuilder.append(str).append(paramString1);
    }
    while (true)
    {
      return;
      StringBuilder localStringBuilder2 = paramStringBuilder.append(" ext. ").append(paramString1);
    }
  }

  private String formatNationalNumber(String paramString1, String paramString2, PhoneNumberFormat paramPhoneNumberFormat)
  {
    return formatNationalNumber(paramString1, paramString2, paramPhoneNumberFormat, null);
  }

  private String formatNationalNumber(String paramString1, String paramString2, PhoneNumberFormat paramPhoneNumberFormat, String paramString3)
  {
    Object localObject = getMetadataForRegion(paramString2);
    if (((Phonemetadata.PhoneMetadata)localObject).intlNumberFormats().size() != 0)
    {
      PhoneNumberFormat localPhoneNumberFormat1 = PhoneNumberFormat.NATIONAL;
      if (paramPhoneNumberFormat != localPhoneNumberFormat1)
        break label80;
    }
    label80: for (localObject = ((Phonemetadata.PhoneMetadata)localObject).numberFormats(); ; localObject = ((Phonemetadata.PhoneMetadata)localObject).intlNumberFormats())
    {
      localObject = formatAccordingToFormats(paramString1, (List)localObject, paramPhoneNumberFormat, paramString3);
      PhoneNumberFormat localPhoneNumberFormat2 = PhoneNumberFormat.RFC3966;
      if (paramPhoneNumberFormat == localPhoneNumberFormat2)
        localObject = SEPARATOR_PATTERN.matcher((CharSequence)localObject).replaceAll("-");
      return localObject;
    }
  }

  private void formatNumberByFormat(int paramInt, PhoneNumberFormat paramPhoneNumberFormat, StringBuilder paramStringBuilder)
  {
    int[] arrayOfInt = 2.$SwitchMap$com$google$i18n$phonenumbers$PhoneNumberUtil$PhoneNumberFormat;
    int i = paramPhoneNumberFormat.ordinal();
    switch (arrayOfInt[i])
    {
    default:
    case 1:
    case 2:
    case 3:
    }
    while (true)
    {
      return;
      StringBuilder localStringBuilder1 = paramStringBuilder.insert(0, paramInt).insert(0, 43);
      continue;
      StringBuilder localStringBuilder2 = paramStringBuilder.insert(0, " ").insert(0, paramInt).insert(0, 43);
      continue;
      StringBuilder localStringBuilder3 = paramStringBuilder.insert(0, "-").insert(0, paramInt).insert(0, 43);
    }
  }

  /** @deprecated */
  public static PhoneNumberUtil getInstance()
  {
    monitorenter;
    try
    {
      PhoneNumberUtil localPhoneNumberUtil1;
      if (instance == null)
      {
        Map localMap = CountryCodeToRegionCodeMap.getCountryCodeToRegionCodeMap();
        localPhoneNumberUtil1 = getInstance("/com/google/i18n/phonenumbers/data/PhoneNumberMetadataProto", localMap);
      }
      for (PhoneNumberUtil localPhoneNumberUtil2 = localPhoneNumberUtil1; ; localPhoneNumberUtil2 = instance)
        return localPhoneNumberUtil2;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  /** @deprecated */
  static PhoneNumberUtil getInstance(String paramString, Map<Integer, List<String>> paramMap)
  {
    monitorenter;
    try
    {
      if (instance == null)
      {
        instance = new PhoneNumberUtil();
        instance.countryCallingCodeToRegionCodeMap = paramMap;
        instance.init(paramString);
      }
      PhoneNumberUtil localPhoneNumberUtil = instance;
      monitorexit;
      return localPhoneNumberUtil;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  private PhoneNumberType getNumberTypeHelper(String paramString, Phonemetadata.PhoneMetadata paramPhoneMetadata)
  {
    Object localObject = paramPhoneMetadata.getGeneralDesc();
    if ((!((Phonemetadata.PhoneNumberDesc)localObject).hasNationalNumberPattern()) || (!isNumberMatchingDesc(paramString, (Phonemetadata.PhoneNumberDesc)localObject)))
      localObject = PhoneNumberType.UNKNOWN;
    while (true)
    {
      return localObject;
      Phonemetadata.PhoneNumberDesc localPhoneNumberDesc1 = paramPhoneMetadata.getPremiumRate();
      if (isNumberMatchingDesc(paramString, localPhoneNumberDesc1))
      {
        localObject = PhoneNumberType.PREMIUM_RATE;
        continue;
      }
      Phonemetadata.PhoneNumberDesc localPhoneNumberDesc2 = paramPhoneMetadata.getTollFree();
      if (isNumberMatchingDesc(paramString, localPhoneNumberDesc2))
      {
        localObject = PhoneNumberType.TOLL_FREE;
        continue;
      }
      Phonemetadata.PhoneNumberDesc localPhoneNumberDesc3 = paramPhoneMetadata.getSharedCost();
      if (isNumberMatchingDesc(paramString, localPhoneNumberDesc3))
      {
        localObject = PhoneNumberType.SHARED_COST;
        continue;
      }
      Phonemetadata.PhoneNumberDesc localPhoneNumberDesc4 = paramPhoneMetadata.getVoip();
      if (isNumberMatchingDesc(paramString, localPhoneNumberDesc4))
      {
        localObject = PhoneNumberType.VOIP;
        continue;
      }
      Phonemetadata.PhoneNumberDesc localPhoneNumberDesc5 = paramPhoneMetadata.getPersonalNumber();
      if (isNumberMatchingDesc(paramString, localPhoneNumberDesc5))
      {
        localObject = PhoneNumberType.PERSONAL_NUMBER;
        continue;
      }
      Phonemetadata.PhoneNumberDesc localPhoneNumberDesc6 = paramPhoneMetadata.getPager();
      if (isNumberMatchingDesc(paramString, localPhoneNumberDesc6))
      {
        localObject = PhoneNumberType.PAGER;
        continue;
      }
      Phonemetadata.PhoneNumberDesc localPhoneNumberDesc7 = paramPhoneMetadata.getUan();
      if (isNumberMatchingDesc(paramString, localPhoneNumberDesc7))
      {
        localObject = PhoneNumberType.UAN;
        continue;
      }
      Phonemetadata.PhoneNumberDesc localPhoneNumberDesc8 = paramPhoneMetadata.getFixedLine();
      if (isNumberMatchingDesc(paramString, localPhoneNumberDesc8))
      {
        if (paramPhoneMetadata.isSameMobileAndFixedLinePattern())
        {
          localObject = PhoneNumberType.FIXED_LINE_OR_MOBILE;
          continue;
        }
        Phonemetadata.PhoneNumberDesc localPhoneNumberDesc9 = paramPhoneMetadata.getMobile();
        if (isNumberMatchingDesc(paramString, localPhoneNumberDesc9))
        {
          localObject = PhoneNumberType.FIXED_LINE_OR_MOBILE;
          continue;
        }
        localObject = PhoneNumberType.FIXED_LINE;
        continue;
      }
      if (!paramPhoneMetadata.isSameMobileAndFixedLinePattern())
      {
        Phonemetadata.PhoneNumberDesc localPhoneNumberDesc10 = paramPhoneMetadata.getMobile();
        if (isNumberMatchingDesc(paramString, localPhoneNumberDesc10))
        {
          localObject = PhoneNumberType.MOBILE;
          continue;
        }
      }
      localObject = PhoneNumberType.UNKNOWN;
    }
  }

  private String getRegionCodeForNumberFromRegionList(Phonenumber.PhoneNumber paramPhoneNumber, List<String> paramList)
  {
    String str1 = getNationalSignificantNumber(paramPhoneNumber);
    Iterator localIterator = paramList.iterator();
    String str2;
    Phonemetadata.PhoneMetadata localPhoneMetadata;
    RegexCache localRegexCache;
    String str3;
    do
    {
      if (!localIterator.hasNext())
        break label109;
      str2 = (String)localIterator.next();
      localPhoneMetadata = getMetadataForRegion(str2);
      if (!localPhoneMetadata.hasLeadingDigits())
        break;
      localRegexCache = this.regexCache;
      str3 = localPhoneMetadata.getLeadingDigits();
    }
    while (!localRegexCache.getPatternForRegex(str3).matcher(str1).lookingAt());
    while (true)
    {
      return str2;
      PhoneNumberType localPhoneNumberType1 = getNumberTypeHelper(str1, localPhoneMetadata);
      PhoneNumberType localPhoneNumberType2 = PhoneNumberType.UNKNOWN;
      if (localPhoneNumberType1 == localPhoneNumberType2)
        break;
      continue;
      label109: str2 = null;
    }
  }

  private boolean hasValidRegionCode(String paramString1, int paramInt, String paramString2)
  {
    if (!isValidRegionCode(paramString1))
    {
      Logger localLogger = LOGGER;
      Level localLevel = Level.WARNING;
      String str = "Number " + paramString2 + " has invalid or missing country calling code (" + paramInt + ")";
      localLogger.log(localLevel, str);
    }
    for (int i = 0; ; i = 1)
      return i;
  }

  private void init(String paramString)
  {
    this.currentFilePrefix = paramString;
    Iterator localIterator = this.countryCallingCodeToRegionCodeMap.values().iterator();
    while (localIterator.hasNext())
    {
      List localList = (List)localIterator.next();
      boolean bool1 = this.supportedRegions.addAll(localList);
    }
    Set localSet = this.nanpaRegions;
    Map localMap = this.countryCallingCodeToRegionCodeMap;
    Integer localInteger = Integer.valueOf(1);
    Collection localCollection = (Collection)localMap.get(localInteger);
    boolean bool2 = localSet.addAll(localCollection);
  }

  private boolean isNationalNumberSuffixOfTheOther(Phonenumber.PhoneNumber paramPhoneNumber1, Phonenumber.PhoneNumber paramPhoneNumber2)
  {
    String str1 = String.valueOf(paramPhoneNumber1.getNationalNumber());
    String str2 = String.valueOf(paramPhoneNumber2.getNationalNumber());
    if ((str1.endsWith(str2)) || (str2.endsWith(str1)));
    for (int i = 1; ; i = 0)
      return i;
  }

  private boolean isNumberMatchingDesc(String paramString, Phonemetadata.PhoneNumberDesc paramPhoneNumberDesc)
  {
    RegexCache localRegexCache1 = this.regexCache;
    String str1 = paramPhoneNumberDesc.getPossibleNumberPattern();
    Matcher localMatcher1 = localRegexCache1.getPatternForRegex(str1).matcher(paramString);
    RegexCache localRegexCache2 = this.regexCache;
    String str2 = paramPhoneNumberDesc.getNationalNumberPattern();
    Matcher localMatcher2 = localRegexCache2.getPatternForRegex(str2).matcher(paramString);
    if ((localMatcher1.matches()) && (localMatcher2.matches()));
    for (int i = 1; ; i = 0)
      return i;
  }

  private boolean isValidRegionCode(String paramString)
  {
    if ((paramString != null) && (this.supportedRegions.contains(paramString)));
    for (int i = 1; ; i = 0)
      return i;
  }

  static boolean isViablePhoneNumber(String paramString)
  {
    if (paramString.length() < 3);
    boolean bool;
    for (int i = 0; ; bool = VALID_PHONE_NUMBER_PATTERN.matcher(paramString).matches())
      return i;
  }

  private void loadMetadataForRegionFromFile(String paramString1, String paramString2)
  {
    String str1 = paramString1 + "_" + paramString2;
    InputStream localInputStream = PhoneNumberUtil.class.getResourceAsStream(str1);
    try
    {
      ObjectInputStream localObjectInputStream = new ObjectInputStream(localInputStream);
      Phonemetadata.PhoneMetadataCollection localPhoneMetadataCollection = new Phonemetadata.PhoneMetadataCollection();
      localPhoneMetadataCollection.readExternal(localObjectInputStream);
      Iterator localIterator = localPhoneMetadataCollection.getMetadataList().iterator();
      while (localIterator.hasNext())
      {
        Phonemetadata.PhoneMetadata localPhoneMetadata = (Phonemetadata.PhoneMetadata)localIterator.next();
        Object localObject = this.regionToMetadataMap.put(paramString2, localPhoneMetadata);
      }
    }
    catch (IOException localIOException)
    {
      Logger localLogger = LOGGER;
      Level localLevel = Level.WARNING;
      String str2 = localIOException.toString();
      localLogger.log(localLevel, str2);
    }
  }

  private void maybeGetFormattedExtension(Phonenumber.PhoneNumber paramPhoneNumber, String paramString, PhoneNumberFormat paramPhoneNumberFormat, StringBuilder paramStringBuilder)
  {
    if ((paramPhoneNumber.hasExtension()) && (paramPhoneNumber.getExtension().length() > 0))
    {
      PhoneNumberFormat localPhoneNumberFormat = PhoneNumberFormat.RFC3966;
      if (paramPhoneNumberFormat != localPhoneNumberFormat)
        break label53;
      StringBuilder localStringBuilder1 = paramStringBuilder.append(";ext=");
      String str1 = paramPhoneNumber.getExtension();
      StringBuilder localStringBuilder2 = localStringBuilder1.append(str1);
    }
    while (true)
    {
      return;
      label53: String str2 = paramPhoneNumber.getExtension();
      formatExtension(str2, paramString, paramStringBuilder);
    }
  }

  static String normalize(String paramString)
  {
    Map localMap;
    if (VALID_ALPHA_PHONE_PATTERN.matcher(paramString).matches())
      localMap = ALPHA_PHONE_MAPPINGS;
    for (String str = normalizeHelper(paramString, localMap, 1); ; str = normalizeDigitsOnly(paramString))
      return str;
  }

  static void normalize(StringBuilder paramStringBuilder)
  {
    String str = normalize(paramStringBuilder.toString());
    int i = paramStringBuilder.length();
    StringBuilder localStringBuilder = paramStringBuilder.replace(0, i, str);
  }

  private static StringBuilder normalizeDigits(String paramString, boolean paramBoolean)
  {
    int i = paramString.length();
    StringBuilder localStringBuilder1 = new StringBuilder(i);
    char[] arrayOfChar = paramString.toCharArray();
    int j = arrayOfChar.length;
    int k = 0;
    if (k < j)
    {
      char c = arrayOfChar[k];
      int m = Character.digit(c, 10);
      if (m != -1)
        StringBuilder localStringBuilder2 = localStringBuilder1.append(m);
      while (true)
      {
        k += 1;
        break;
        if (!paramBoolean)
          continue;
        StringBuilder localStringBuilder3 = localStringBuilder1.append(c);
      }
    }
    return localStringBuilder1;
  }

  public static String normalizeDigitsOnly(String paramString)
  {
    return normalizeDigits(paramString, 0).toString();
  }

  private static String normalizeHelper(String paramString, Map<Character, Character> paramMap, boolean paramBoolean)
  {
    int i = paramString.length();
    StringBuilder localStringBuilder1 = new StringBuilder(i);
    char[] arrayOfChar = paramString.toCharArray();
    int j = arrayOfChar.length;
    int k = 0;
    if (k < j)
    {
      char c = arrayOfChar[k];
      Character localCharacter1 = Character.valueOf(Character.toUpperCase(c));
      Character localCharacter2 = (Character)paramMap.get(localCharacter1);
      if (localCharacter2 != null)
        StringBuilder localStringBuilder2 = localStringBuilder1.append(localCharacter2);
      while (true)
      {
        k += 1;
        break;
        if (paramBoolean)
          continue;
        StringBuilder localStringBuilder3 = localStringBuilder1.append(c);
      }
    }
    return localStringBuilder1.toString();
  }

  private void parseHelper(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, Phonenumber.PhoneNumber paramPhoneNumber)
    throws NumberParseException
  {
    if (paramString1 == null)
    {
      NumberParseException.ErrorType localErrorType1 = NumberParseException.ErrorType.NOT_A_NUMBER;
      throw new NumberParseException(localErrorType1, "The phone number supplied was null.");
    }
    String str1 = extractPossibleNumber(paramString1);
    if (!isViablePhoneNumber(str1))
    {
      NumberParseException.ErrorType localErrorType2 = NumberParseException.ErrorType.NOT_A_NUMBER;
      throw new NumberParseException(localErrorType2, "The string supplied did not seem to be a phone number.");
    }
    if ((paramBoolean2) && (!checkRegionForParsing(str1, paramString2)))
    {
      NumberParseException.ErrorType localErrorType3 = NumberParseException.ErrorType.INVALID_COUNTRY_CODE;
      throw new NumberParseException(localErrorType3, "Missing or invalid default region.");
    }
    if (paramBoolean1)
      Phonenumber.PhoneNumber localPhoneNumber1 = paramPhoneNumber.setRawInput(paramString1);
    StringBuilder localStringBuilder1 = new StringBuilder(str1);
    str1 = maybeStripExtension(localStringBuilder1);
    if (str1.length() > 0)
      Phonenumber.PhoneNumber localPhoneNumber2 = paramPhoneNumber.setExtension(str1);
    Phonemetadata.PhoneMetadata localPhoneMetadata = getMetadataForRegion(paramString2);
    StringBuilder localStringBuilder2 = new StringBuilder();
    String str3 = localStringBuilder1.toString();
    PhoneNumberUtil localPhoneNumberUtil = this;
    boolean bool = paramBoolean1;
    Phonenumber.PhoneNumber localPhoneNumber3 = paramPhoneNumber;
    int i = localPhoneNumberUtil.maybeExtractCountryCode(str3, localPhoneMetadata, localStringBuilder2, bool, localPhoneNumber3);
    String str2;
    if (i != 0)
    {
      str2 = getRegionCodeForCountryCode(i);
      if (!str2.equals(paramString2))
        localPhoneMetadata = getMetadataForRegion(str2);
    }
    while (localStringBuilder2.length() < 3)
    {
      NumberParseException.ErrorType localErrorType4 = NumberParseException.ErrorType.TOO_SHORT_NSN;
      throw new NumberParseException(localErrorType4, "The string supplied is too short to be a phone number.");
      normalize(localStringBuilder1);
      StringBuilder localStringBuilder3 = localStringBuilder2.append(localStringBuilder1);
      if (paramString2 != null)
      {
        int k = localPhoneMetadata.getCountryCode();
        Phonenumber.PhoneNumber localPhoneNumber4 = paramPhoneNumber.setCountryCode(k);
        continue;
      }
      if (!paramBoolean1)
        continue;
      Phonenumber.PhoneNumber localPhoneNumber5 = paramPhoneNumber.clearCountryCodeSource();
    }
    if (localPhoneMetadata != null)
    {
      str2 = maybeStripNationalPrefixAndCarrierCode(localStringBuilder2, localPhoneMetadata);
      if (paramBoolean1)
        Phonenumber.PhoneNumber localPhoneNumber6 = paramPhoneNumber.setPreferredDomesticCarrierCode(str2);
    }
    int j = localStringBuilder2.length();
    if (j < 3)
    {
      NumberParseException.ErrorType localErrorType5 = NumberParseException.ErrorType.TOO_SHORT_NSN;
      throw new NumberParseException(localErrorType5, "The string supplied is too short to be a phone number.");
    }
    if (j > 15)
    {
      NumberParseException.ErrorType localErrorType6 = NumberParseException.ErrorType.TOO_LONG;
      throw new NumberParseException(localErrorType6, "The string supplied is too long to be a phone number.");
    }
    if (localStringBuilder2.charAt(0) == 48)
      Phonenumber.PhoneNumber localPhoneNumber7 = paramPhoneNumber.setItalianLeadingZero(1);
    long l = Long.parseLong(localStringBuilder2.toString());
    Phonenumber.PhoneNumber localPhoneNumber8 = paramPhoneNumber.setNationalNumber(l);
  }

  private boolean parsePrefixAsIdd(Pattern paramPattern, StringBuilder paramStringBuilder)
  {
    int i = 0;
    Matcher localMatcher1 = paramPattern.matcher(paramStringBuilder);
    int j;
    if (localMatcher1.lookingAt())
    {
      j = localMatcher1.end();
      Pattern localPattern = CAPTURING_DIGIT_PATTERN;
      String str = paramStringBuilder.substring(j);
      Matcher localMatcher2 = localPattern.matcher(str);
      if ((!localMatcher2.find()) || (!normalizeDigitsOnly(localMatcher2.group(1)).equals("0")))
        break label74;
    }
    while (true)
    {
      return i;
      label74: StringBuilder localStringBuilder = paramStringBuilder.delete(0, j);
      i = 1;
    }
  }

  /** @deprecated */
  static void resetInstance()
  {
    monitorenter;
    try
    {
      instance = null;
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  private ValidationResult testNumberLengthAgainstPattern(Pattern paramPattern, String paramString)
  {
    Object localObject = paramPattern.matcher(paramString);
    if (((Matcher)localObject).matches())
      localObject = ValidationResult.IS_POSSIBLE;
    while (true)
    {
      return localObject;
      if (((Matcher)localObject).lookingAt())
      {
        localObject = ValidationResult.TOO_LONG;
        continue;
      }
      localObject = ValidationResult.TOO_SHORT;
    }
  }

  boolean canBeInternationallyDialled(Phonenumber.PhoneNumber paramPhoneNumber)
  {
    int i = 1;
    String str1 = getRegionCodeForNumber(paramPhoneNumber);
    String str2 = getNationalSignificantNumber(paramPhoneNumber);
    int j = paramPhoneNumber.getCountryCode();
    if (!hasValidRegionCode(str1, j, str2));
    while (true)
    {
      return i;
      Phonemetadata.PhoneNumberDesc localPhoneNumberDesc = getMetadataForRegion(str1).getNoInternationalDialling();
      if (!isNumberMatchingDesc(str2, localPhoneNumberDesc))
        continue;
      i = 0;
    }
  }

  int extractCountryCode(StringBuilder paramStringBuilder1, StringBuilder paramStringBuilder2)
  {
    int i = paramStringBuilder1.length();
    int j = 1;
    int k;
    if ((j <= 3) && (j <= i))
    {
      k = Integer.parseInt(paramStringBuilder1.substring(0, j));
      Map localMap = this.countryCallingCodeToRegionCodeMap;
      Integer localInteger = Integer.valueOf(k);
      if (localMap.containsKey(localInteger))
      {
        String str = paramStringBuilder1.substring(j);
        StringBuilder localStringBuilder = paramStringBuilder2.append(str);
      }
    }
    while (true)
    {
      return k;
      j += 1;
      break;
      k = 0;
    }
  }

  public Iterable<PhoneNumberMatch> findNumbers(CharSequence paramCharSequence, String paramString)
  {
    Leniency localLeniency = Leniency.VALID;
    PhoneNumberUtil localPhoneNumberUtil = this;
    CharSequence localCharSequence = paramCharSequence;
    String str = paramString;
    return localPhoneNumberUtil.findNumbers(localCharSequence, str, localLeniency, 9223372036854775807L);
  }

  public Iterable<PhoneNumberMatch> findNumbers(CharSequence paramCharSequence, String paramString, Leniency paramLeniency, long paramLong)
  {
    PhoneNumberUtil localPhoneNumberUtil = this;
    CharSequence localCharSequence = paramCharSequence;
    String str = paramString;
    Leniency localLeniency = paramLeniency;
    long l = paramLong;
    return new PhoneNumberUtil.1(localPhoneNumberUtil, localCharSequence, str, localLeniency, l);
  }

  public String format(Phonenumber.PhoneNumber paramPhoneNumber, PhoneNumberFormat paramPhoneNumberFormat)
  {
    StringBuilder localStringBuilder = new StringBuilder(20);
    format(paramPhoneNumber, paramPhoneNumberFormat, localStringBuilder);
    return localStringBuilder.toString();
  }

  public void format(Phonenumber.PhoneNumber paramPhoneNumber, PhoneNumberFormat paramPhoneNumberFormat, StringBuilder paramStringBuilder)
  {
    paramStringBuilder.setLength(0);
    int i = paramPhoneNumber.getCountryCode();
    String str1 = getNationalSignificantNumber(paramPhoneNumber);
    PhoneNumberFormat localPhoneNumberFormat1 = PhoneNumberFormat.E164;
    if (paramPhoneNumberFormat == localPhoneNumberFormat1)
    {
      StringBuilder localStringBuilder1 = paramStringBuilder.append(str1);
      PhoneNumberFormat localPhoneNumberFormat2 = PhoneNumberFormat.E164;
      formatNumberByFormat(i, localPhoneNumberFormat2, paramStringBuilder);
    }
    while (true)
    {
      return;
      String str2 = getRegionCodeForCountryCode(i);
      if (!isValidRegionCode(str2))
      {
        StringBuilder localStringBuilder2 = paramStringBuilder.append(str1);
        continue;
      }
      String str3 = formatNationalNumber(str1, str2, paramPhoneNumberFormat);
      StringBuilder localStringBuilder3 = paramStringBuilder.append(str3);
      maybeGetFormattedExtension(paramPhoneNumber, str2, paramPhoneNumberFormat, paramStringBuilder);
      formatNumberByFormat(i, paramPhoneNumberFormat, paramStringBuilder);
    }
  }

  public String formatByPattern(Phonenumber.PhoneNumber paramPhoneNumber, PhoneNumberFormat paramPhoneNumberFormat, List<Phonemetadata.NumberFormat> paramList)
  {
    int i = paramPhoneNumber.getCountryCode();
    String str1 = getNationalSignificantNumber(paramPhoneNumber);
    String str2 = getRegionCodeForCountryCode(i);
    if (!hasValidRegionCode(str2, i, str1));
    StringBuilder localStringBuilder;
    for (Object localObject = str1; ; localObject = localStringBuilder.toString())
    {
      return localObject;
      int j = paramList.size();
      ArrayList localArrayList = new ArrayList(j);
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        localObject = (Phonemetadata.NumberFormat)localIterator.next();
        String str3 = ((Phonemetadata.NumberFormat)localObject).getNationalPrefixFormattingRule();
        if (str3.length() > 0)
        {
          Phonemetadata.NumberFormat localNumberFormat1 = new Phonemetadata.NumberFormat();
          Phonemetadata.NumberFormat localNumberFormat2 = localNumberFormat1.mergeFrom((Phonemetadata.NumberFormat)localObject);
          localObject = getMetadataForRegion(str2).getNationalPrefix();
          if (((String)localObject).length() > 0)
          {
            String str4 = NP_PATTERN.matcher(str3).replaceFirst((String)localObject);
            String str5 = FG_PATTERN.matcher(str4).replaceFirst("\\$1");
            Phonemetadata.NumberFormat localNumberFormat3 = localNumberFormat1.setNationalPrefixFormattingRule(str5);
          }
          while (true)
          {
            boolean bool1 = localArrayList.add(localNumberFormat1);
            break;
            Phonemetadata.NumberFormat localNumberFormat4 = localNumberFormat1.clearNationalPrefixFormattingRule();
          }
        }
        boolean bool2 = localArrayList.add(localObject);
      }
      String str6 = formatAccordingToFormats(str1, localArrayList, paramPhoneNumberFormat);
      localStringBuilder = new StringBuilder(str6);
      maybeGetFormattedExtension(paramPhoneNumber, str2, paramPhoneNumberFormat, localStringBuilder);
      formatNumberByFormat(i, paramPhoneNumberFormat, localStringBuilder);
    }
  }

  public String formatInOriginalFormat(Phonenumber.PhoneNumber paramPhoneNumber, String paramString)
  {
    String str;
    if (!paramPhoneNumber.hasCountryCodeSource())
    {
      PhoneNumberFormat localPhoneNumberFormat1 = PhoneNumberFormat.NATIONAL;
      str = format(paramPhoneNumber, localPhoneNumberFormat1);
    }
    while (true)
    {
      return str;
      int[] arrayOfInt = 2.$SwitchMap$com$google$i18n$phonenumbers$Phonenumber$PhoneNumber$CountryCodeSource;
      int i = paramPhoneNumber.getCountryCodeSource().ordinal();
      switch (arrayOfInt[i])
      {
      default:
        PhoneNumberFormat localPhoneNumberFormat2 = PhoneNumberFormat.NATIONAL;
        str = format(paramPhoneNumber, localPhoneNumberFormat2);
        break;
      case 1:
        PhoneNumberFormat localPhoneNumberFormat3 = PhoneNumberFormat.INTERNATIONAL;
        str = format(paramPhoneNumber, localPhoneNumberFormat3);
        break;
      case 2:
        str = formatOutOfCountryCallingNumber(paramPhoneNumber, paramString);
        break;
      case 3:
        PhoneNumberFormat localPhoneNumberFormat4 = PhoneNumberFormat.INTERNATIONAL;
        str = format(paramPhoneNumber, localPhoneNumberFormat4).substring(1);
      }
    }
  }

  public String formatNationalNumberWithCarrierCode(Phonenumber.PhoneNumber paramPhoneNumber, String paramString)
  {
    int i = paramPhoneNumber.getCountryCode();
    String str1 = getNationalSignificantNumber(paramPhoneNumber);
    String str2 = getRegionCodeForCountryCode(i);
    if (!hasValidRegionCode(str2, i, str1));
    while (true)
    {
      return str1;
      StringBuilder localStringBuilder1 = new StringBuilder(20);
      PhoneNumberFormat localPhoneNumberFormat1 = PhoneNumberFormat.NATIONAL;
      String str3 = formatNationalNumber(str1, str2, localPhoneNumberFormat1, paramString);
      StringBuilder localStringBuilder2 = localStringBuilder1.append(str3);
      PhoneNumberFormat localPhoneNumberFormat2 = PhoneNumberFormat.NATIONAL;
      maybeGetFormattedExtension(paramPhoneNumber, str2, localPhoneNumberFormat2, localStringBuilder1);
      PhoneNumberFormat localPhoneNumberFormat3 = PhoneNumberFormat.NATIONAL;
      formatNumberByFormat(i, localPhoneNumberFormat3, localStringBuilder1);
      str1 = localStringBuilder1.toString();
    }
  }

  public String formatNationalNumberWithPreferredCarrierCode(Phonenumber.PhoneNumber paramPhoneNumber, String paramString)
  {
    if (paramPhoneNumber.hasPreferredDomesticCarrierCode())
      paramString = paramPhoneNumber.getPreferredDomesticCarrierCode();
    return formatNationalNumberWithCarrierCode(paramPhoneNumber, paramString);
  }

  public String formatOutOfCountryCallingNumber(Phonenumber.PhoneNumber paramPhoneNumber, String paramString)
  {
    if (!isValidRegionCode(paramString))
    {
      PhoneNumberFormat localPhoneNumberFormat1 = PhoneNumberFormat.INTERNATIONAL;
      localObject1 = format(paramPhoneNumber, localPhoneNumberFormat1);
    }
    int i;
    String str1;
    while (true)
    {
      return localObject1;
      i = paramPhoneNumber.getCountryCode();
      str1 = getRegionCodeForCountryCode(i);
      localObject1 = getNationalSignificantNumber(paramPhoneNumber);
      if (!hasValidRegionCode(str1, i, (String)localObject1))
        continue;
      if (i == 1)
      {
        if (!isNANPACountry(paramString))
          break;
        StringBuilder localStringBuilder1 = new StringBuilder().append(i).append(" ");
        PhoneNumberFormat localPhoneNumberFormat2 = PhoneNumberFormat.NATIONAL;
        String str2 = format(paramPhoneNumber, localPhoneNumberFormat2);
        localObject1 = str2;
        continue;
      }
      int j = getCountryCodeForRegion(paramString);
      if (i != j)
        break;
      PhoneNumberFormat localPhoneNumberFormat3 = PhoneNumberFormat.NATIONAL;
      localObject1 = format(paramPhoneNumber, localPhoneNumberFormat3);
    }
    PhoneNumberFormat localPhoneNumberFormat4 = PhoneNumberFormat.INTERNATIONAL;
    String str3 = formatNationalNumber((String)localObject1, str1, localPhoneNumberFormat4);
    Phonemetadata.PhoneMetadata localPhoneMetadata = getMetadataForRegion(paramString);
    Object localObject1 = localPhoneMetadata.getInternationalPrefix();
    Object localObject2 = "";
    if (UNIQUE_INTERNATIONAL_PREFIX.matcher((CharSequence)localObject1).matches());
    while (true)
    {
      label201: localObject2 = new StringBuilder(str3);
      PhoneNumberFormat localPhoneNumberFormat5 = PhoneNumberFormat.INTERNATIONAL;
      maybeGetFormattedExtension(paramPhoneNumber, str1, localPhoneNumberFormat5, (StringBuilder)localObject2);
      if (((String)localObject1).length() > 0)
        StringBuilder localStringBuilder2 = ((StringBuilder)localObject2).insert(0, " ").insert(0, i).insert(0, " ").insert(0, (String)localObject1);
      while (true)
      {
        localObject1 = ((StringBuilder)localObject2).toString();
        break;
        if (!localPhoneMetadata.hasPreferredInternationalPrefix())
          break label312;
        localObject1 = localPhoneMetadata.getPreferredInternationalPrefix();
        break label201;
        PhoneNumberFormat localPhoneNumberFormat6 = PhoneNumberFormat.INTERNATIONAL;
        formatNumberByFormat(i, localPhoneNumberFormat6, (StringBuilder)localObject2);
      }
      label312: localObject1 = localObject2;
    }
  }

  public String formatOutOfCountryKeepingAlphaChars(Phonenumber.PhoneNumber paramPhoneNumber, String paramString)
  {
    String str1 = paramPhoneNumber.getRawInput();
    if (str1.length() == 0)
      str1 = formatOutOfCountryCallingNumber(paramPhoneNumber, paramString);
    int i;
    Object localObject1;
    do
    {
      return str1;
      i = paramPhoneNumber.getCountryCode();
      localObject1 = getRegionCodeForCountryCode(i);
    }
    while (!hasValidRegionCode((String)localObject1, i, str1));
    Map localMap = ALL_PLUS_NUMBER_GROUPING_SYMBOLS;
    str1 = normalizeHelper(str1, localMap, 1);
    String str2 = getNationalSignificantNumber(paramPhoneNumber);
    int j;
    if (str2.length() > 3)
    {
      String str4 = str2.substring(0, 3);
      j = str1.indexOf(str4);
      if (j == -1);
    }
    for (String str3 = str1.substring(j); ; str3 = str1)
    {
      Object localObject2 = getMetadataForRegion(paramString);
      ArrayList localArrayList;
      if (i == 1)
      {
        if (isNANPACountry(paramString))
        {
          str1 = i + " " + str3;
          break;
        }
      }
      else
      {
        int k = getCountryCodeForRegion(paramString);
        if (i == k)
        {
          int m = ((Phonemetadata.PhoneMetadata)localObject2).numberFormatSize();
          localArrayList = new ArrayList(m);
          localObject1 = ((Phonemetadata.PhoneMetadata)localObject2).numberFormats().iterator();
          while (((Iterator)localObject1).hasNext())
          {
            Phonemetadata.NumberFormat localNumberFormat1 = (Phonemetadata.NumberFormat)((Iterator)localObject1).next();
            Phonemetadata.NumberFormat localNumberFormat2 = new Phonemetadata.NumberFormat();
            Phonemetadata.NumberFormat localNumberFormat3 = localNumberFormat2.mergeFrom(localNumberFormat1);
            Phonemetadata.NumberFormat localNumberFormat4 = localNumberFormat2.setPattern("(\\d+)(.*)");
            Phonemetadata.NumberFormat localNumberFormat5 = localNumberFormat2.setFormat("$1$2");
            boolean bool = localArrayList.add(localNumberFormat2);
          }
          PhoneNumberFormat localPhoneNumberFormat1 = PhoneNumberFormat.NATIONAL;
          str1 = formatAccordingToFormats(str3, localArrayList, localPhoneNumberFormat1);
          break;
        }
      }
      str1 = ((Phonemetadata.PhoneMetadata)localObject2).getInternationalPrefix();
      if (UNIQUE_INTERNATIONAL_PREFIX.matcher(str1).matches())
      {
        label316: localObject2 = new StringBuilder(str3);
        PhoneNumberFormat localPhoneNumberFormat2 = PhoneNumberFormat.INTERNATIONAL;
        maybeGetFormattedExtension(paramPhoneNumber, (String)localObject1, localPhoneNumberFormat2, (StringBuilder)localObject2);
        if (str1.length() <= 0)
          break label397;
        StringBuilder localStringBuilder = ((StringBuilder)localObject2).insert(0, " ").insert(0, localArrayList).insert(0, " ").insert(0, str1);
      }
      while (true)
      {
        str1 = ((StringBuilder)localObject2).toString();
        break;
        str1 = ((Phonemetadata.PhoneMetadata)localObject2).getPreferredInternationalPrefix();
        break label316;
        label397: PhoneNumberFormat localPhoneNumberFormat3 = PhoneNumberFormat.INTERNATIONAL;
        formatNumberByFormat(localArrayList, localPhoneNumberFormat3, (StringBuilder)localObject2);
      }
    }
  }

  public AsYouTypeFormatter getAsYouTypeFormatter(String paramString)
  {
    return new AsYouTypeFormatter(paramString);
  }

  public int getCountryCodeForRegion(String paramString)
  {
    if (!isValidRegionCode(paramString));
    for (int i = 0; ; i = getMetadataForRegion(paramString).getCountryCode())
      return i;
  }

  public Phonenumber.PhoneNumber getExampleNumber(String paramString)
  {
    PhoneNumberType localPhoneNumberType = PhoneNumberType.FIXED_LINE;
    return getExampleNumberForType(paramString, localPhoneNumberType);
  }

  public Phonenumber.PhoneNumber getExampleNumberForType(String paramString, PhoneNumberType paramPhoneNumberType)
  {
    Object localObject = null;
    if (!isValidRegionCode(paramString))
    {
      Logger localLogger1 = LOGGER;
      Level localLevel1 = Level.WARNING;
      localLogger1.log(localLevel1, "Invalid or unknown region code provided.");
    }
    while (true)
    {
      return localObject;
      Phonemetadata.PhoneMetadata localPhoneMetadata = getMetadataForRegion(paramString);
      Phonemetadata.PhoneNumberDesc localPhoneNumberDesc = getNumberDescByType(localPhoneMetadata, paramPhoneNumberType);
      try
      {
        if (!localPhoneNumberDesc.hasExampleNumber())
          continue;
        String str1 = localPhoneNumberDesc.getExampleNumber();
        Phonenumber.PhoneNumber localPhoneNumber = parse(str1, paramString);
        localObject = localPhoneNumber;
      }
      catch (NumberParseException localNumberParseException)
      {
        Logger localLogger2 = LOGGER;
        Level localLevel2 = Level.SEVERE;
        String str2 = localNumberParseException.toString();
        localLogger2.log(localLevel2, str2);
      }
    }
  }

  public int getLengthOfGeographicalAreaCode(Phonenumber.PhoneNumber paramPhoneNumber)
  {
    int i = 0;
    Object localObject = getRegionCodeForNumber(paramPhoneNumber);
    if (!isValidRegionCode((String)localObject));
    while (true)
    {
      return i;
      localObject = getMetadataForRegion((String)localObject);
      if (!((Phonemetadata.PhoneMetadata)localObject).hasNationalPrefix())
        continue;
      String str = getNationalSignificantNumber(paramPhoneNumber);
      localObject = getNumberTypeHelper(str, (Phonemetadata.PhoneMetadata)localObject);
      PhoneNumberType localPhoneNumberType1 = PhoneNumberType.FIXED_LINE;
      if (localObject != localPhoneNumberType1)
      {
        PhoneNumberType localPhoneNumberType2 = PhoneNumberType.FIXED_LINE_OR_MOBILE;
        if (localObject != localPhoneNumberType2)
          continue;
      }
      i = getLengthOfNationalDestinationCode(paramPhoneNumber);
    }
  }

  public int getLengthOfNationalDestinationCode(Phonenumber.PhoneNumber paramPhoneNumber)
  {
    int i;
    if (paramPhoneNumber.hasExtension())
    {
      Object localObject = new Phonenumber.PhoneNumber();
      Phonenumber.PhoneNumber localPhoneNumber2 = ((Phonenumber.PhoneNumber)localObject).mergeFrom(paramPhoneNumber);
      Phonenumber.PhoneNumber localPhoneNumber3 = ((Phonenumber.PhoneNumber)localObject).clearExtension();
      PhoneNumberFormat localPhoneNumberFormat = PhoneNumberFormat.INTERNATIONAL;
      String str = format((Phonenumber.PhoneNumber)localObject, localPhoneNumberFormat);
      localObject = NON_DIGITS_PATTERN.split(str);
      if (localObject.length > 3)
        break label65;
      i = 0;
    }
    while (true)
    {
      return i;
      Phonenumber.PhoneNumber localPhoneNumber1 = paramPhoneNumber;
      break;
      label65: if (getRegionCodeForNumber(paramPhoneNumber).equals("AR"))
      {
        PhoneNumberType localPhoneNumberType1 = getNumberType(paramPhoneNumber);
        PhoneNumberType localPhoneNumberType2 = PhoneNumberType.MOBILE;
        if (localPhoneNumberType1 == localPhoneNumberType2)
        {
          j = localPhoneNumber1[3].length() + 1;
          continue;
        }
      }
      int j = j[2].length();
    }
  }

  Phonemetadata.PhoneMetadata getMetadataForRegion(String paramString)
  {
    if (!isValidRegionCode(paramString));
    for (Phonemetadata.PhoneMetadata localPhoneMetadata = null; ; localPhoneMetadata = (Phonemetadata.PhoneMetadata)this.regionToMetadataMap.get(paramString))
    {
      return localPhoneMetadata;
      if (this.regionToMetadataMap.containsKey(paramString))
        continue;
      String str = this.currentFilePrefix;
      loadMetadataForRegionFromFile(str, paramString);
    }
  }

  public String getNationalSignificantNumber(Phonenumber.PhoneNumber paramPhoneNumber)
  {
    StringBuilder localStringBuilder1 = new java/lang/StringBuilder;
    if ((paramPhoneNumber.hasItalianLeadingZero()) && (paramPhoneNumber.isItalianLeadingZero()))
    {
      int i = paramPhoneNumber.getCountryCode();
      if (!isLeadingZeroPossible(i));
    }
    for (String str = "0"; ; str = "")
    {
      localStringBuilder1.<init>(str);
      long l = paramPhoneNumber.getNationalNumber();
      StringBuilder localStringBuilder2 = localStringBuilder1.append(l);
      return localStringBuilder1.toString();
    }
  }

  public String getNddPrefixForRegion(String paramString, boolean paramBoolean)
  {
    String str;
    if (!isValidRegionCode(paramString))
    {
      Logger localLogger = LOGGER;
      Level localLevel = Level.SEVERE;
      localLogger.log(localLevel, "Invalid or missing region code provided.");
      str = null;
    }
    while (true)
    {
      return str;
      str = getMetadataForRegion(paramString).getNationalPrefix();
      if (str.length() == 0)
      {
        str = null;
        continue;
      }
      if (!paramBoolean)
        continue;
      str = str.replace("~", "");
    }
  }

  Phonemetadata.PhoneNumberDesc getNumberDescByType(Phonemetadata.PhoneMetadata paramPhoneMetadata, PhoneNumberType paramPhoneNumberType)
  {
    int[] arrayOfInt = 2.$SwitchMap$com$google$i18n$phonenumbers$PhoneNumberUtil$PhoneNumberType;
    int i = paramPhoneNumberType.ordinal();
    Phonemetadata.PhoneNumberDesc localPhoneNumberDesc;
    switch (arrayOfInt[i])
    {
    default:
      localPhoneNumberDesc = paramPhoneMetadata.getGeneralDesc();
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
    case 10:
    }
    while (true)
    {
      return localPhoneNumberDesc;
      localPhoneNumberDesc = paramPhoneMetadata.getPremiumRate();
      continue;
      localPhoneNumberDesc = paramPhoneMetadata.getTollFree();
      continue;
      localPhoneNumberDesc = paramPhoneMetadata.getMobile();
      continue;
      localPhoneNumberDesc = paramPhoneMetadata.getFixedLine();
      continue;
      localPhoneNumberDesc = paramPhoneMetadata.getSharedCost();
      continue;
      localPhoneNumberDesc = paramPhoneMetadata.getVoip();
      continue;
      localPhoneNumberDesc = paramPhoneMetadata.getPersonalNumber();
      continue;
      localPhoneNumberDesc = paramPhoneMetadata.getPager();
      continue;
      localPhoneNumberDesc = paramPhoneMetadata.getUan();
    }
  }

  public PhoneNumberType getNumberType(Phonenumber.PhoneNumber paramPhoneNumber)
  {
    Object localObject = getRegionCodeForNumber(paramPhoneNumber);
    if (!isValidRegionCode((String)localObject));
    String str;
    Phonemetadata.PhoneMetadata localPhoneMetadata;
    for (localObject = PhoneNumberType.UNKNOWN; ; localObject = getNumberTypeHelper(str, localPhoneMetadata))
    {
      return localObject;
      str = getNationalSignificantNumber(paramPhoneNumber);
      localPhoneMetadata = getMetadataForRegion((String)localObject);
    }
  }

  public String getRegionCodeForCountryCode(int paramInt)
  {
    Map localMap = this.countryCallingCodeToRegionCodeMap;
    Integer localInteger = Integer.valueOf(paramInt);
    Object localObject = (List)localMap.get(localInteger);
    if (localObject == null);
    for (localObject = "ZZ"; ; localObject = (String)((List)localObject).get(0))
      return localObject;
  }

  public String getRegionCodeForNumber(Phonenumber.PhoneNumber paramPhoneNumber)
  {
    int i = paramPhoneNumber.getCountryCode();
    Map localMap = this.countryCallingCodeToRegionCodeMap;
    Integer localInteger = Integer.valueOf(i);
    Object localObject = (List)localMap.get(localInteger);
    if (localObject == null)
      localObject = null;
    while (true)
    {
      return localObject;
      if (((List)localObject).size() == 1)
      {
        localObject = (String)((List)localObject).get(0);
        continue;
      }
      localObject = getRegionCodeForNumberFromRegionList(paramPhoneNumber, (List)localObject);
    }
  }

  public Set<String> getSupportedRegions()
  {
    return this.supportedRegions;
  }

  public boolean isAlphaNumber(String paramString)
  {
    if (!isViablePhoneNumber(paramString));
    StringBuilder localStringBuilder;
    boolean bool;
    for (int i = 0; ; bool = VALID_ALPHA_PHONE_PATTERN.matcher(localStringBuilder).matches())
    {
      return i;
      localStringBuilder = new StringBuilder(paramString);
      String str = maybeStripExtension(localStringBuilder);
    }
  }

  boolean isLeadingZeroPossible(int paramInt)
  {
    String str = getRegionCodeForCountryCode(paramInt);
    Phonemetadata.PhoneMetadata localPhoneMetadata = getMetadataForRegion(str);
    if (localPhoneMetadata == null);
    boolean bool;
    for (int i = 0; ; bool = i.isLeadingZeroPossible())
      return i;
  }

  public boolean isNANPACountry(String paramString)
  {
    return this.nanpaRegions.contains(paramString);
  }

  public MatchType isNumberMatch(Phonenumber.PhoneNumber paramPhoneNumber1, Phonenumber.PhoneNumber paramPhoneNumber2)
  {
    Object localObject = new Phonenumber.PhoneNumber();
    Phonenumber.PhoneNumber localPhoneNumber1 = ((Phonenumber.PhoneNumber)localObject).mergeFrom(paramPhoneNumber1);
    Phonenumber.PhoneNumber localPhoneNumber2 = new Phonenumber.PhoneNumber();
    Phonenumber.PhoneNumber localPhoneNumber3 = localPhoneNumber2.mergeFrom(paramPhoneNumber2);
    Phonenumber.PhoneNumber localPhoneNumber4 = ((Phonenumber.PhoneNumber)localObject).clearRawInput();
    Phonenumber.PhoneNumber localPhoneNumber5 = ((Phonenumber.PhoneNumber)localObject).clearCountryCodeSource();
    Phonenumber.PhoneNumber localPhoneNumber6 = ((Phonenumber.PhoneNumber)localObject).clearPreferredDomesticCarrierCode();
    Phonenumber.PhoneNumber localPhoneNumber7 = localPhoneNumber2.clearRawInput();
    Phonenumber.PhoneNumber localPhoneNumber8 = localPhoneNumber2.clearCountryCodeSource();
    Phonenumber.PhoneNumber localPhoneNumber9 = localPhoneNumber2.clearPreferredDomesticCarrierCode();
    if ((((Phonenumber.PhoneNumber)localObject).hasExtension()) && (((Phonenumber.PhoneNumber)localObject).getExtension().length() == 0))
      Phonenumber.PhoneNumber localPhoneNumber10 = ((Phonenumber.PhoneNumber)localObject).clearExtension();
    if ((localPhoneNumber2.hasExtension()) && (localPhoneNumber2.getExtension().length() == 0))
      Phonenumber.PhoneNumber localPhoneNumber11 = localPhoneNumber2.clearExtension();
    if ((((Phonenumber.PhoneNumber)localObject).hasExtension()) && (localPhoneNumber2.hasExtension()))
    {
      String str1 = ((Phonenumber.PhoneNumber)localObject).getExtension();
      String str2 = localPhoneNumber2.getExtension();
      if (!str1.equals(str2))
        localObject = MatchType.NO_MATCH;
    }
    while (true)
    {
      return localObject;
      int i = ((Phonenumber.PhoneNumber)localObject).getCountryCode();
      int j = localPhoneNumber2.getCountryCode();
      if ((i != 0) && (j != 0))
      {
        if (((Phonenumber.PhoneNumber)localObject).exactlySameAs(localPhoneNumber2))
        {
          localObject = MatchType.EXACT_MATCH;
          continue;
        }
        if ((i == j) && (isNationalNumberSuffixOfTheOther((Phonenumber.PhoneNumber)localObject, localPhoneNumber2)))
        {
          localObject = MatchType.SHORT_NSN_MATCH;
          continue;
        }
        localObject = MatchType.NO_MATCH;
        continue;
      }
      Phonenumber.PhoneNumber localPhoneNumber12 = ((Phonenumber.PhoneNumber)localObject).setCountryCode(j);
      if (((Phonenumber.PhoneNumber)localObject).exactlySameAs(localPhoneNumber2))
      {
        localObject = MatchType.NSN_MATCH;
        continue;
      }
      if (isNationalNumberSuffixOfTheOther((Phonenumber.PhoneNumber)localObject, localPhoneNumber2))
      {
        localObject = MatchType.SHORT_NSN_MATCH;
        continue;
      }
      localObject = MatchType.NO_MATCH;
    }
  }

  public MatchType isNumberMatch(Phonenumber.PhoneNumber paramPhoneNumber, String paramString)
  {
    try
    {
      Phonenumber.PhoneNumber localPhoneNumber1 = parse(paramString, "ZZ");
      localMatchType1 = isNumberMatch(paramPhoneNumber, localPhoneNumber1);
      localObject = localMatchType1;
      return localObject;
    }
    catch (NumberParseException localNumberParseException2)
    {
      while (true)
      {
        MatchType localMatchType1;
        NumberParseException.ErrorType localErrorType1 = localNumberParseException2.getErrorType();
        NumberParseException.ErrorType localErrorType2 = NumberParseException.ErrorType.INVALID_COUNTRY_CODE;
        if (localErrorType1 == localErrorType2)
        {
          int i = paramPhoneNumber.getCountryCode();
          localObject = getRegionCodeForCountryCode(i);
          try
          {
            if (!((String)localObject).equals("ZZ"))
            {
              Phonenumber.PhoneNumber localPhoneNumber2 = parse(paramString, (String)localObject);
              localObject = isNumberMatch(paramPhoneNumber, localPhoneNumber2);
              MatchType localMatchType2 = MatchType.EXACT_MATCH;
              if (localObject != localMatchType2)
                continue;
              localObject = MatchType.NSN_MATCH;
              continue;
            }
            Phonenumber.PhoneNumber localPhoneNumber3 = new Phonenumber.PhoneNumber();
            PhoneNumberUtil localPhoneNumberUtil = this;
            String str = paramString;
            localPhoneNumberUtil.parseHelper(str, null, 0, 0, localPhoneNumber3);
            localMatchType1 = isNumberMatch(paramPhoneNumber, localPhoneNumber3);
            localObject = localMatchType1;
          }
          catch (NumberParseException localNumberParseException1)
          {
          }
        }
        Object localObject = MatchType.NOT_A_NUMBER;
      }
    }
  }

  public MatchType isNumberMatch(String paramString1, String paramString2)
  {
    try
    {
      Phonenumber.PhoneNumber localPhoneNumber1 = parse(paramString1, "ZZ");
      localMatchType1 = isNumberMatch(localPhoneNumber1, paramString2);
      localMatchType2 = localMatchType1;
      return localMatchType2;
    }
    catch (NumberParseException localNumberParseException2)
    {
      while (true)
      {
        MatchType localMatchType1;
        NumberParseException.ErrorType localErrorType1 = localNumberParseException2.getErrorType();
        NumberParseException.ErrorType localErrorType2 = NumberParseException.ErrorType.INVALID_COUNTRY_CODE;
        if (localErrorType1 == localErrorType2)
          try
          {
            Phonenumber.PhoneNumber localPhoneNumber2 = parse(paramString2, "ZZ");
            localMatchType1 = isNumberMatch(localPhoneNumber2, paramString1);
            localMatchType2 = localMatchType1;
          }
          catch (NumberParseException localNumberParseException3)
          {
            NumberParseException.ErrorType localErrorType3 = localNumberParseException3.getErrorType();
            NumberParseException.ErrorType localErrorType4 = NumberParseException.ErrorType.INVALID_COUNTRY_CODE;
            if (localErrorType3 == localErrorType4)
              try
              {
                Phonenumber.PhoneNumber localPhoneNumber3 = new Phonenumber.PhoneNumber();
                Phonenumber.PhoneNumber localPhoneNumber4 = new Phonenumber.PhoneNumber();
                PhoneNumberUtil localPhoneNumberUtil1 = this;
                String str1 = paramString1;
                localPhoneNumberUtil1.parseHelper(str1, null, 0, 0, localPhoneNumber3);
                PhoneNumberUtil localPhoneNumberUtil2 = this;
                String str2 = paramString2;
                localPhoneNumberUtil2.parseHelper(str2, null, 0, 0, localPhoneNumber4);
                localMatchType1 = isNumberMatch(localPhoneNumber3, localPhoneNumber4);
                localMatchType2 = localMatchType1;
              }
              catch (NumberParseException localNumberParseException1)
              {
              }
          }
        MatchType localMatchType2 = MatchType.NOT_A_NUMBER;
      }
    }
  }

  public boolean isPossibleNumber(Phonenumber.PhoneNumber paramPhoneNumber)
  {
    ValidationResult localValidationResult1 = isPossibleNumberWithReason(paramPhoneNumber);
    ValidationResult localValidationResult2 = ValidationResult.IS_POSSIBLE;
    if (localValidationResult1 == localValidationResult2);
    for (int i = 1; ; i = 0)
      return i;
  }

  public boolean isPossibleNumber(String paramString1, String paramString2)
  {
    try
    {
      Phonenumber.PhoneNumber localPhoneNumber = parse(paramString1, paramString2);
      boolean bool1 = isPossibleNumber(localPhoneNumber);
      bool2 = bool1;
      return bool2;
    }
    catch (NumberParseException localNumberParseException)
    {
      while (true)
        boolean bool2 = false;
    }
  }

  public ValidationResult isPossibleNumberWithReason(Phonenumber.PhoneNumber paramPhoneNumber)
  {
    Object localObject1 = getNationalSignificantNumber(paramPhoneNumber);
    int j = paramPhoneNumber.getCountryCode();
    Object localObject2 = getRegionCodeForCountryCode(j);
    if (!isValidRegionCode((String)localObject2))
      localObject1 = ValidationResult.INVALID_COUNTRY_CODE;
    while (true)
    {
      return localObject1;
      localObject2 = getMetadataForRegion((String)localObject2).getGeneralDesc();
      if (!((Phonemetadata.PhoneNumberDesc)localObject2).hasNationalNumberPattern())
      {
        Logger localLogger = LOGGER;
        Level localLevel = Level.FINER;
        localLogger.log(localLevel, "Checking if number is possible with incomplete metadata.");
        int i = ((String)localObject1).length();
        if (i < 3)
        {
          localValidationResult = ValidationResult.TOO_SHORT;
          continue;
        }
        if (localValidationResult > 15)
        {
          localValidationResult = ValidationResult.TOO_LONG;
          continue;
        }
        localValidationResult = ValidationResult.IS_POSSIBLE;
        continue;
      }
      RegexCache localRegexCache = this.regexCache;
      String str = ((Phonemetadata.PhoneNumberDesc)localObject2).getPossibleNumberPattern();
      Pattern localPattern = localRegexCache.getPatternForRegex(str);
      ValidationResult localValidationResult = testNumberLengthAgainstPattern(localPattern, localValidationResult);
    }
  }

  public boolean isValidNumber(Phonenumber.PhoneNumber paramPhoneNumber)
  {
    String str = getRegionCodeForNumber(paramPhoneNumber);
    if ((isValidRegionCode(str)) && (isValidNumberForRegion(paramPhoneNumber, str)));
    for (int i = 1; ; i = 0)
      return i;
  }

  public boolean isValidNumberForRegion(Phonenumber.PhoneNumber paramPhoneNumber, String paramString)
  {
    int i = 1;
    int j = paramPhoneNumber.getCountryCode();
    int k = getCountryCodeForRegion(paramString);
    if (j != k)
      i = 0;
    while (true)
    {
      return i;
      Phonemetadata.PhoneMetadata localPhoneMetadata = getMetadataForRegion(paramString);
      Phonemetadata.PhoneNumberDesc localPhoneNumberDesc = localPhoneMetadata.getGeneralDesc();
      String str = getNationalSignificantNumber(paramPhoneNumber);
      int m;
      if (!localPhoneNumberDesc.hasNationalNumberPattern())
      {
        m = str.length();
        if ((m > 3) && (m <= 15))
          continue;
        i = 0;
        continue;
      }
      PhoneNumberType localPhoneNumberType1 = getNumberTypeHelper(str, m);
      PhoneNumberType localPhoneNumberType2 = PhoneNumberType.UNKNOWN;
      if (localPhoneNumberType1 != localPhoneNumberType2)
        continue;
      i = 0;
    }
  }

  int maybeExtractCountryCode(String paramString, Phonemetadata.PhoneMetadata paramPhoneMetadata, StringBuilder paramStringBuilder, boolean paramBoolean, Phonenumber.PhoneNumber paramPhoneNumber)
    throws NumberParseException
  {
    int i;
    if (paramString.length() == 0)
      i = 0;
    while (true)
    {
      return i;
      StringBuilder localStringBuilder1 = new StringBuilder(paramString);
      Object localObject1 = "NonMatch";
      if (paramPhoneMetadata != null)
        localObject1 = paramPhoneMetadata.getInternationalPrefix();
      localObject1 = maybeStripInternationalPrefixAndNormalize(localStringBuilder1, (String)localObject1);
      if (paramBoolean)
        Phonenumber.PhoneNumber localPhoneNumber1 = paramPhoneNumber.setCountryCodeSource((Phonenumber.PhoneNumber.CountryCodeSource)localObject1);
      Phonenumber.PhoneNumber.CountryCodeSource localCountryCodeSource1 = Phonenumber.PhoneNumber.CountryCodeSource.FROM_DEFAULT_COUNTRY;
      if (localObject1 != localCountryCodeSource1)
      {
        if (localStringBuilder1.length() < 3)
        {
          NumberParseException.ErrorType localErrorType1 = NumberParseException.ErrorType.TOO_SHORT_AFTER_IDD;
          throw new NumberParseException(localErrorType1, "Phone number had an IDD, but after this was not long enough to be a viable phone number.");
        }
        j = extractCountryCode(localStringBuilder1, paramStringBuilder);
        if (j != 0)
        {
          Phonenumber.PhoneNumber localPhoneNumber2 = paramPhoneNumber.setCountryCode(j);
          continue;
        }
        NumberParseException.ErrorType localErrorType2 = NumberParseException.ErrorType.INVALID_COUNTRY_CODE;
        throw new NumberParseException(localErrorType2, "Country calling code supplied was not recognised.");
      }
      Object localObject2;
      Object localObject3;
      if (paramPhoneMetadata != null)
      {
        j = paramPhoneMetadata.getCountryCode();
        localObject2 = String.valueOf(j);
        localObject3 = localStringBuilder1.toString();
        if (((String)localObject3).startsWith((String)localObject2))
        {
          int k = ((String)localObject2).length();
          String str1 = ((String)localObject3).substring(k);
          StringBuilder localStringBuilder2 = new StringBuilder(str1);
          Phonemetadata.PhoneNumberDesc localPhoneNumberDesc = paramPhoneMetadata.getGeneralDesc();
          RegexCache localRegexCache1 = this.regexCache;
          String str2 = localPhoneNumberDesc.getNationalNumberPattern();
          localObject3 = localRegexCache1.getPatternForRegex(str2);
          String str3 = maybeStripNationalPrefixAndCarrierCode(localStringBuilder2, paramPhoneMetadata);
          RegexCache localRegexCache2 = this.regexCache;
          String str4 = localPhoneNumberDesc.getPossibleNumberPattern();
          localObject2 = localRegexCache2.getPatternForRegex(str4);
          if ((((Pattern)localObject3).matcher(localStringBuilder1).matches()) || (!((Pattern)localObject3).matcher(localStringBuilder2).matches()))
          {
            String str5 = localStringBuilder1.toString();
            ValidationResult localValidationResult1 = testNumberLengthAgainstPattern((Pattern)localObject2, str5);
            ValidationResult localValidationResult2 = ValidationResult.TOO_LONG;
            if (localValidationResult1 != localValidationResult2);
          }
          else
          {
            StringBuilder localStringBuilder3 = paramStringBuilder.append(localStringBuilder2);
            if (paramBoolean)
            {
              Phonenumber.PhoneNumber.CountryCodeSource localCountryCodeSource2 = Phonenumber.PhoneNumber.CountryCodeSource.FROM_NUMBER_WITHOUT_PLUS_SIGN;
              Phonenumber.PhoneNumber localPhoneNumber3 = paramPhoneNumber.setCountryCodeSource(localCountryCodeSource2);
            }
            Phonenumber.PhoneNumber localPhoneNumber4 = paramPhoneNumber.setCountryCode(j);
            continue;
          }
        }
      }
      Phonenumber.PhoneNumber localPhoneNumber5 = paramPhoneNumber.setCountryCode(0);
      int j = 0;
    }
  }

  String maybeStripExtension(StringBuilder paramStringBuilder)
  {
    Matcher localMatcher = EXTN_PATTERN.matcher(paramStringBuilder);
    String str1;
    if (localMatcher.find())
    {
      int i = localMatcher.start();
      if (isViablePhoneNumber(paramStringBuilder.substring(0, i)))
      {
        int j = 1;
        int m = localMatcher.groupCount();
        if (j <= m)
          if (localMatcher.group(j) != null)
          {
            str1 = localMatcher.group(j);
            int n = localMatcher.start();
            int i1 = paramStringBuilder.length();
            StringBuilder localStringBuilder = paramStringBuilder.delete(n, i1);
          }
      }
    }
    while (true)
    {
      return str1;
      int k;
      str1 += 1;
      break;
      String str2 = "";
    }
  }

  Phonenumber.PhoneNumber.CountryCodeSource maybeStripInternationalPrefixAndNormalize(StringBuilder paramStringBuilder, String paramString)
  {
    Object localObject;
    if (paramStringBuilder.length() == 0)
      localObject = Phonenumber.PhoneNumber.CountryCodeSource.FROM_DEFAULT_COUNTRY;
    while (true)
    {
      return localObject;
      localObject = PLUS_CHARS_PATTERN.matcher(paramStringBuilder);
      if (((Matcher)localObject).lookingAt())
      {
        int i = ((Matcher)localObject).end();
        StringBuilder localStringBuilder = paramStringBuilder.delete(0, i);
        normalize(paramStringBuilder);
        localObject = Phonenumber.PhoneNumber.CountryCodeSource.FROM_NUMBER_WITH_PLUS_SIGN;
        continue;
      }
      localObject = this.regexCache.getPatternForRegex(paramString);
      if (parsePrefixAsIdd((Pattern)localObject, paramStringBuilder))
      {
        normalize(paramStringBuilder);
        localObject = Phonenumber.PhoneNumber.CountryCodeSource.FROM_NUMBER_WITH_IDD;
        continue;
      }
      normalize(paramStringBuilder);
      if (parsePrefixAsIdd((Pattern)localObject, paramStringBuilder))
      {
        localObject = Phonenumber.PhoneNumber.CountryCodeSource.FROM_NUMBER_WITH_IDD;
        continue;
      }
      localObject = Phonenumber.PhoneNumber.CountryCodeSource.FROM_DEFAULT_COUNTRY;
    }
  }

  String maybeStripNationalPrefixAndCarrierCode(StringBuilder paramStringBuilder, Phonemetadata.PhoneMetadata paramPhoneMetadata)
  {
    String str1 = "";
    int i = paramStringBuilder.length();
    Object localObject = paramPhoneMetadata.getNationalPrefixForParsing();
    if ((i == 0) || (((String)localObject).length() == 0))
      str1 = "";
    while (true)
    {
      return str1;
      localObject = this.regexCache.getPatternForRegex((String)localObject).matcher(paramStringBuilder);
      if (!((Matcher)localObject).lookingAt())
        continue;
      RegexCache localRegexCache = this.regexCache;
      String str2 = paramPhoneMetadata.getGeneralDesc().getNationalNumberPattern();
      Pattern localPattern = localRegexCache.getPatternForRegex(str2);
      boolean bool = localPattern.matcher(paramStringBuilder).matches();
      int j = ((Matcher)localObject).groupCount();
      String str3 = paramPhoneMetadata.getNationalPrefixTransformRule();
      if ((str3 == null) || (str3.length() == 0) || (((Matcher)localObject).group(j) == null))
      {
        if (bool)
        {
          int k = ((Matcher)localObject).end();
          String str4 = paramStringBuilder.substring(k);
          if (!localPattern.matcher(str4).matches())
          {
            str1 = "";
            continue;
          }
        }
        if ((j > 0) && (((Matcher)localObject).group(j) != null))
          str1 = ((Matcher)localObject).group(1);
        int m = ((Matcher)localObject).end();
        StringBuilder localStringBuilder1 = paramStringBuilder.delete(0, m);
        continue;
      }
      StringBuilder localStringBuilder2 = new StringBuilder(paramStringBuilder);
      String str5 = ((Matcher)localObject).replaceFirst(str3);
      StringBuilder localStringBuilder3 = localStringBuilder2.replace(0, i, str5);
      if (bool)
      {
        String str6 = localStringBuilder2.toString();
        if (!localPattern.matcher(str6).matches())
        {
          str1 = "";
          continue;
        }
      }
      if (j > 1)
        str1 = ((Matcher)localObject).group(1);
      int n = paramStringBuilder.length();
      String str7 = localStringBuilder2.toString();
      StringBuilder localStringBuilder4 = paramStringBuilder.replace(0, n, str7);
    }
  }

  public Phonenumber.PhoneNumber parse(String paramString1, String paramString2)
    throws NumberParseException
  {
    Phonenumber.PhoneNumber localPhoneNumber = new Phonenumber.PhoneNumber();
    parse(paramString1, paramString2, localPhoneNumber);
    return localPhoneNumber;
  }

  public void parse(String paramString1, String paramString2, Phonenumber.PhoneNumber paramPhoneNumber)
    throws NumberParseException
  {
    PhoneNumberUtil localPhoneNumberUtil = this;
    String str1 = paramString1;
    String str2 = paramString2;
    Phonenumber.PhoneNumber localPhoneNumber = paramPhoneNumber;
    localPhoneNumberUtil.parseHelper(str1, str2, 0, 1, localPhoneNumber);
  }

  public Phonenumber.PhoneNumber parseAndKeepRawInput(String paramString1, String paramString2)
    throws NumberParseException
  {
    Phonenumber.PhoneNumber localPhoneNumber = new Phonenumber.PhoneNumber();
    parseAndKeepRawInput(paramString1, paramString2, localPhoneNumber);
    return localPhoneNumber;
  }

  public void parseAndKeepRawInput(String paramString1, String paramString2, Phonenumber.PhoneNumber paramPhoneNumber)
    throws NumberParseException
  {
    PhoneNumberUtil localPhoneNumberUtil = this;
    String str1 = paramString1;
    String str2 = paramString2;
    int i = 1;
    Phonenumber.PhoneNumber localPhoneNumber = paramPhoneNumber;
    localPhoneNumberUtil.parseHelper(str1, str2, 1, i, localPhoneNumber);
  }

  public boolean truncateTooLongNumber(Phonenumber.PhoneNumber paramPhoneNumber)
  {
    int i;
    if (isValidNumber(paramPhoneNumber))
      i = 1;
    while (true)
    {
      return i;
      Phonenumber.PhoneNumber localPhoneNumber1 = new Phonenumber.PhoneNumber();
      Phonenumber.PhoneNumber localPhoneNumber2 = localPhoneNumber1.mergeFrom(paramPhoneNumber);
      long l = paramPhoneNumber.getNationalNumber();
      do
      {
        l /= 10L;
        Phonenumber.PhoneNumber localPhoneNumber3 = localPhoneNumber1.setNationalNumber(l);
        ValidationResult localValidationResult1 = isPossibleNumberWithReason(localPhoneNumber1);
        ValidationResult localValidationResult2 = ValidationResult.TOO_SHORT;
        if ((localValidationResult1 != localValidationResult2) && (l != 0L))
          continue;
        j = 0;
        break;
      }
      while (!isValidNumber(localPhoneNumber1));
      Phonenumber.PhoneNumber localPhoneNumber4 = paramPhoneNumber.setNationalNumber(j);
      int j = 1;
    }
  }

  public abstract enum Leniency
  {
    static
    {
      STRICT_GROUPING = new PhoneNumberUtil.Leniency.3("STRICT_GROUPING", 2);
      EXACT_GROUPING = new PhoneNumberUtil.Leniency.4("EXACT_GROUPING", 3);
      Leniency[] arrayOfLeniency = new Leniency[4];
      Leniency localLeniency1 = POSSIBLE;
      arrayOfLeniency[0] = localLeniency1;
      Leniency localLeniency2 = VALID;
      arrayOfLeniency[1] = localLeniency2;
      Leniency localLeniency3 = STRICT_GROUPING;
      arrayOfLeniency[2] = localLeniency3;
      Leniency localLeniency4 = EXACT_GROUPING;
      arrayOfLeniency[3] = localLeniency4;
      $VALUES = arrayOfLeniency;
    }

    private static boolean containsMoreThanOneSlash(String paramString)
    {
      int i = paramString.indexOf('/');
      if (i > 0)
      {
        int j = i + 1;
        if (!paramString.substring(j).contains("/"));
      }
      for (i = 1; ; i = 0)
        return i;
    }

    private static boolean containsOnlyValidXChars(Phonenumber.PhoneNumber paramPhoneNumber, String paramString, PhoneNumberUtil paramPhoneNumberUtil)
    {
      int i = 0;
      int j = i;
      int k = paramString.length() + -1;
      if (j < k)
      {
        int m = paramString.charAt(j);
        if ((m == 120) || (m == 88))
        {
          int n = j + 1;
          m = paramString.charAt(n);
          if ((m == 120) || (m == 88))
          {
            j += 1;
            String str1 = paramString.substring(j);
            PhoneNumberUtil.MatchType localMatchType1 = paramPhoneNumberUtil.isNumberMatch(paramPhoneNumber, str1);
            PhoneNumberUtil.MatchType localMatchType2 = PhoneNumberUtil.MatchType.NSN_MATCH;
            if (localMatchType1 == localMatchType2)
              break label135;
          }
        }
      }
      while (true)
      {
        return i;
        String str2 = PhoneNumberUtil.normalizeDigitsOnly(paramString.substring(j));
        String str3 = paramPhoneNumber.getExtension();
        if (!str2.equals(str3))
          continue;
        label135: j += 1;
        break;
        i = 1;
      }
    }

    private static String[] getNationalNumberGroups(PhoneNumberUtil paramPhoneNumberUtil, Phonenumber.PhoneNumber paramPhoneNumber)
    {
      PhoneNumberUtil.PhoneNumberFormat localPhoneNumberFormat = PhoneNumberUtil.PhoneNumberFormat.RFC3966;
      String str = paramPhoneNumberUtil.format(paramPhoneNumber, localPhoneNumberFormat);
      int i = str.indexOf(';');
      if (i < 0)
        i = str.length();
      int j = str.indexOf('-') + 1;
      return str.substring(j, i).split("-");
    }

    abstract boolean verify(Phonenumber.PhoneNumber paramPhoneNumber, String paramString, PhoneNumberUtil paramPhoneNumberUtil);
  }

  public enum ValidationResult
  {
    static
    {
      INVALID_COUNTRY_CODE = new ValidationResult("INVALID_COUNTRY_CODE", 1);
      TOO_SHORT = new ValidationResult("TOO_SHORT", 2);
      TOO_LONG = new ValidationResult("TOO_LONG", 3);
      ValidationResult[] arrayOfValidationResult = new ValidationResult[4];
      ValidationResult localValidationResult1 = IS_POSSIBLE;
      arrayOfValidationResult[0] = localValidationResult1;
      ValidationResult localValidationResult2 = INVALID_COUNTRY_CODE;
      arrayOfValidationResult[1] = localValidationResult2;
      ValidationResult localValidationResult3 = TOO_SHORT;
      arrayOfValidationResult[2] = localValidationResult3;
      ValidationResult localValidationResult4 = TOO_LONG;
      arrayOfValidationResult[3] = localValidationResult4;
      $VALUES = arrayOfValidationResult;
    }
  }

  public enum MatchType
  {
    static
    {
      NSN_MATCH = new MatchType("NSN_MATCH", 3);
      EXACT_MATCH = new MatchType("EXACT_MATCH", 4);
      MatchType[] arrayOfMatchType = new MatchType[5];
      MatchType localMatchType1 = NOT_A_NUMBER;
      arrayOfMatchType[0] = localMatchType1;
      MatchType localMatchType2 = NO_MATCH;
      arrayOfMatchType[1] = localMatchType2;
      MatchType localMatchType3 = SHORT_NSN_MATCH;
      arrayOfMatchType[2] = localMatchType3;
      MatchType localMatchType4 = NSN_MATCH;
      arrayOfMatchType[3] = localMatchType4;
      MatchType localMatchType5 = EXACT_MATCH;
      arrayOfMatchType[4] = localMatchType5;
      $VALUES = arrayOfMatchType;
    }
  }

  public enum PhoneNumberType
  {
    static
    {
      FIXED_LINE_OR_MOBILE = new PhoneNumberType("FIXED_LINE_OR_MOBILE", 2);
      TOLL_FREE = new PhoneNumberType("TOLL_FREE", 3);
      PREMIUM_RATE = new PhoneNumberType("PREMIUM_RATE", 4);
      SHARED_COST = new PhoneNumberType("SHARED_COST", 5);
      VOIP = new PhoneNumberType("VOIP", 6);
      PERSONAL_NUMBER = new PhoneNumberType("PERSONAL_NUMBER", 7);
      PAGER = new PhoneNumberType("PAGER", 8);
      UAN = new PhoneNumberType("UAN", 9);
      UNKNOWN = new PhoneNumberType("UNKNOWN", 10);
      PhoneNumberType[] arrayOfPhoneNumberType = new PhoneNumberType[11];
      PhoneNumberType localPhoneNumberType1 = FIXED_LINE;
      arrayOfPhoneNumberType[0] = localPhoneNumberType1;
      PhoneNumberType localPhoneNumberType2 = MOBILE;
      arrayOfPhoneNumberType[1] = localPhoneNumberType2;
      PhoneNumberType localPhoneNumberType3 = FIXED_LINE_OR_MOBILE;
      arrayOfPhoneNumberType[2] = localPhoneNumberType3;
      PhoneNumberType localPhoneNumberType4 = TOLL_FREE;
      arrayOfPhoneNumberType[3] = localPhoneNumberType4;
      PhoneNumberType localPhoneNumberType5 = PREMIUM_RATE;
      arrayOfPhoneNumberType[4] = localPhoneNumberType5;
      PhoneNumberType localPhoneNumberType6 = SHARED_COST;
      arrayOfPhoneNumberType[5] = localPhoneNumberType6;
      PhoneNumberType localPhoneNumberType7 = VOIP;
      arrayOfPhoneNumberType[6] = localPhoneNumberType7;
      PhoneNumberType localPhoneNumberType8 = PERSONAL_NUMBER;
      arrayOfPhoneNumberType[7] = localPhoneNumberType8;
      PhoneNumberType localPhoneNumberType9 = PAGER;
      arrayOfPhoneNumberType[8] = localPhoneNumberType9;
      PhoneNumberType localPhoneNumberType10 = UAN;
      arrayOfPhoneNumberType[9] = localPhoneNumberType10;
      PhoneNumberType localPhoneNumberType11 = UNKNOWN;
      arrayOfPhoneNumberType[10] = localPhoneNumberType11;
      $VALUES = arrayOfPhoneNumberType;
    }
  }

  public enum PhoneNumberFormat
  {
    static
    {
      PhoneNumberFormat[] arrayOfPhoneNumberFormat = new PhoneNumberFormat[4];
      PhoneNumberFormat localPhoneNumberFormat1 = E164;
      arrayOfPhoneNumberFormat[0] = localPhoneNumberFormat1;
      PhoneNumberFormat localPhoneNumberFormat2 = INTERNATIONAL;
      arrayOfPhoneNumberFormat[1] = localPhoneNumberFormat2;
      PhoneNumberFormat localPhoneNumberFormat3 = NATIONAL;
      arrayOfPhoneNumberFormat[2] = localPhoneNumberFormat3;
      PhoneNumberFormat localPhoneNumberFormat4 = RFC3966;
      arrayOfPhoneNumberFormat[3] = localPhoneNumberFormat4;
      $VALUES = arrayOfPhoneNumberFormat;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.i18n.phonenumbers.PhoneNumberUtil
 * JD-Core Version:    0.6.0
 */