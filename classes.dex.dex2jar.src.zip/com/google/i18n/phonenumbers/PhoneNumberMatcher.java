package com.google.i18n.phonenumbers;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class PhoneNumberMatcher
  implements Iterator<PhoneNumberMatch>
{
  private static final Pattern GROUP_SEPARATOR;
  private static final Pattern LEAD_CLASS;
  private static final Pattern MATCHING_BRACKETS;
  private static final Pattern PATTERN;
  private static final Pattern PUB_PAGES = Pattern.compile("\\d{1,5}-+\\d{1,5}\\s{0,4}\\(\\d{1,4}");
  private static final Pattern SLASH_SEPARATED_DATES = Pattern.compile("(?:(?:[0-3]?\\d/[01]?\\d)|(?:[01]?\\d/[0-3]?\\d))/(?:[12]\\d)?\\d{2}");
  private PhoneNumberMatch lastMatch;
  private final PhoneNumberUtil.Leniency leniency;
  private long maxTries;
  private final PhoneNumberUtil phoneUtil;
  private final String preferredRegion;
  private int searchIndex;
  private State state;
  private final CharSequence text;

  static
  {
    String str1 = "[^" + "(\\[（［" + ")\\]）］" + "]";
    String str2 = limit(0, 3);
    MATCHING_BRACKETS = Pattern.compile("(?:[" + "(\\[（［" + "])?" + "(?:" + str1 + "+" + "[" + ")\\]）］" + "])?" + str1 + "+" + "(?:[" + "(\\[（［" + "]" + str1 + "+[" + ")\\]）］" + "])" + str2 + str1 + "*");
    String str3 = limit(0, 2);
    String str4 = limit(0, 4);
    String str5 = limit(0, 18);
    String str6 = "[-x‐-―−ー－-／  ​⁠　()（）［］.\\[\\]/~⁓∼～]" + str4;
    StringBuilder localStringBuilder1 = new StringBuilder().append("\\p{Nd}");
    String str7 = limit(1, 18);
    String str8 = str7;
    String str9 = "(\\[（［" + "+＋";
    String str10 = "[" + str9 + "]";
    LEAD_CLASS = Pattern.compile(str10);
    GROUP_SEPARATOR = Pattern.compile("\\p{Z}[^" + str9 + "\\p{Nd}]*");
    StringBuilder localStringBuilder2 = new StringBuilder().append("(?:").append(str10).append(str6).append(")").append(str3).append(str8).append("(?:").append(str6).append(str8).append(")").append(str5).append("(?:");
    String str11 = PhoneNumberUtil.EXTN_PATTERNS_FOR_MATCHING;
    PATTERN = Pattern.compile(str11 + ")?", 66);
  }

  PhoneNumberMatcher(PhoneNumberUtil paramPhoneNumberUtil, CharSequence paramCharSequence, String paramString, PhoneNumberUtil.Leniency paramLeniency, long paramLong)
  {
    State localState = State.NOT_READY;
    this.state = localState;
    this.lastMatch = null;
    this.searchIndex = 0;
    if ((paramPhoneNumberUtil == null) || (paramLeniency == null))
      throw new NullPointerException();
    if (paramLong < 0L)
      throw new IllegalArgumentException();
    this.phoneUtil = paramPhoneNumberUtil;
    if (paramCharSequence != null);
    while (true)
    {
      this.text = paramCharSequence;
      this.preferredRegion = paramString;
      this.leniency = paramLeniency;
      this.maxTries = paramLong;
      return;
      paramCharSequence = "";
    }
  }

  private PhoneNumberMatch extractInnerMatch(String paramString, int paramInt)
  {
    Matcher localMatcher = GROUP_SEPARATOR.matcher(paramString);
    CharSequence localCharSequence;
    PhoneNumberMatch localPhoneNumberMatch1;
    if (localMatcher.find())
    {
      int i = localMatcher.start();
      String str1 = paramString.substring(0, i);
      localCharSequence = trimAfterFirstMatch(PhoneNumberUtil.UNWANTED_END_CHAR_PATTERN, str1);
      String str2 = localCharSequence.toString();
      localPhoneNumberMatch1 = parseAndVerify(str2, paramInt);
      if (localPhoneNumberMatch1 == null);
    }
    while (true)
    {
      return localPhoneNumberMatch1;
      long l1 = this.maxTries - 1L;
      this.maxTries = l1;
      int j = localMatcher.end();
      String str3 = paramString.substring(j);
      String str4 = trimAfterFirstMatch(PhoneNumberUtil.UNWANTED_END_CHAR_PATTERN, str3).toString();
      int m = paramInt + j;
      PhoneNumberMatch localPhoneNumberMatch2 = parseAndVerify(str4, m);
      if (localPhoneNumberMatch2 != null)
      {
        Object localObject1 = localPhoneNumberMatch2;
        continue;
      }
      long l2 = this.maxTries - 1L;
      this.maxTries = l2;
      if (this.maxTries > 0L)
      {
        int k;
        while (localMatcher.find())
          k = localMatcher.start();
        String str5 = paramString.substring(0, k);
        localObject2 = trimAfterFirstMatch(PhoneNumberUtil.UNWANTED_END_CHAR_PATTERN, str5);
        if (localObject2.equals(localCharSequence))
        {
          localObject2 = null;
          continue;
        }
        String str6 = localObject2.toString();
        localObject2 = parseAndVerify(str6, paramInt);
        if (localObject2 != null)
          continue;
        long l3 = this.maxTries - 1L;
        this.maxTries = l3;
      }
      Object localObject2 = null;
    }
  }

  private PhoneNumberMatch extractMatch(CharSequence paramCharSequence, int paramInt)
  {
    PhoneNumberMatch localPhoneNumberMatch;
    if ((PUB_PAGES.matcher(paramCharSequence).find()) || (SLASH_SEPARATED_DATES.matcher(paramCharSequence).find()))
      localPhoneNumberMatch = null;
    while (true)
    {
      return localPhoneNumberMatch;
      String str = paramCharSequence.toString();
      localPhoneNumberMatch = parseAndVerify(str, paramInt);
      if (localPhoneNumberMatch != null)
        continue;
      localPhoneNumberMatch = extractInnerMatch(str, paramInt);
    }
  }

  private PhoneNumberMatch find(int paramInt)
  {
    Pattern localPattern = PATTERN;
    CharSequence localCharSequence1 = this.text;
    Matcher localMatcher = localPattern.matcher(localCharSequence1);
    int i;
    CharSequence localCharSequence4;
    PhoneNumberMatch localPhoneNumberMatch;
    if ((this.maxTries > 0L) && (localMatcher.find(paramInt)))
    {
      i = localMatcher.start();
      CharSequence localCharSequence2 = this.text;
      int j = localMatcher.end();
      CharSequence localCharSequence3 = localCharSequence2.subSequence(i, j);
      localCharSequence4 = trimAfterFirstMatch(PhoneNumberUtil.SECOND_NUMBER_START_PATTERN, localCharSequence3);
      localPhoneNumberMatch = extractMatch(localCharSequence4, i);
      if (localPhoneNumberMatch == null);
    }
    while (true)
    {
      return localPhoneNumberMatch;
      int k = localCharSequence4.length();
      paramInt = i + k;
      long l = this.maxTries - 1L;
      this.maxTries = l;
      break;
      localPhoneNumberMatch = null;
    }
  }

  private static boolean isCurrencySymbol(char paramChar)
  {
    if (Character.getType(paramChar) == 26);
    for (int i = 1; ; i = 0)
      return i;
  }

  static boolean isLatinLetter(char paramChar)
  {
    int i = 0;
    if ((!Character.isLetter(paramChar)) && (Character.getType(paramChar) != 6));
    while (true)
    {
      return i;
      Character.UnicodeBlock localUnicodeBlock1 = Character.UnicodeBlock.of(paramChar);
      Character.UnicodeBlock localUnicodeBlock2 = Character.UnicodeBlock.BASIC_LATIN;
      if (!localUnicodeBlock1.equals(localUnicodeBlock2))
      {
        Character.UnicodeBlock localUnicodeBlock3 = Character.UnicodeBlock.LATIN_1_SUPPLEMENT;
        if (!localUnicodeBlock1.equals(localUnicodeBlock3))
        {
          Character.UnicodeBlock localUnicodeBlock4 = Character.UnicodeBlock.LATIN_EXTENDED_A;
          if (!localUnicodeBlock1.equals(localUnicodeBlock4))
          {
            Character.UnicodeBlock localUnicodeBlock5 = Character.UnicodeBlock.LATIN_EXTENDED_ADDITIONAL;
            if (!localUnicodeBlock1.equals(localUnicodeBlock5))
            {
              Character.UnicodeBlock localUnicodeBlock6 = Character.UnicodeBlock.LATIN_EXTENDED_B;
              if (!localUnicodeBlock1.equals(localUnicodeBlock6))
              {
                Character.UnicodeBlock localUnicodeBlock7 = Character.UnicodeBlock.COMBINING_DIACRITICAL_MARKS;
                if (!localUnicodeBlock1.equals(localUnicodeBlock7))
                  continue;
              }
            }
          }
        }
      }
      i = 1;
    }
  }

  private static String limit(int paramInt1, int paramInt2)
  {
    if ((paramInt1 < 0) || (paramInt2 <= 0) || (paramInt2 < paramInt1))
      throw new IllegalArgumentException();
    return "{" + paramInt1 + "," + paramInt2 + "}";
  }

  private PhoneNumberMatch parseAndVerify(String paramString, int paramInt)
  {
    Object localObject = null;
    try
    {
      if (!MATCHING_BRACKETS.matcher(paramString).matches());
      while (true)
      {
        label15: return localObject;
        PhoneNumberUtil.Leniency localLeniency1 = this.leniency;
        PhoneNumberUtil.Leniency localLeniency2 = PhoneNumberUtil.Leniency.VALID;
        if (localLeniency1.compareTo(localLeniency2) >= 0)
        {
          if ((paramInt > 0) && (!LEAD_CLASS.matcher(paramString).lookingAt()))
          {
            CharSequence localCharSequence = this.text;
            int i = paramInt + -1;
            char c = localCharSequence.charAt(i);
            if ((isCurrencySymbol(c)) || (isLatinLetter(c)))
              continue;
          }
          int j = paramString.length() + paramInt;
          int k = this.text.length();
          if (j < k)
          {
            j = this.text.charAt(j);
            if ((isCurrencySymbol(j)) || (isLatinLetter(j)))
              continue;
          }
        }
        PhoneNumberUtil localPhoneNumberUtil1 = this.phoneUtil;
        String str = this.preferredRegion;
        Phonenumber.PhoneNumber localPhoneNumber = localPhoneNumberUtil1.parse(paramString, str);
        PhoneNumberUtil.Leniency localLeniency3 = this.leniency;
        PhoneNumberUtil localPhoneNumberUtil2 = this.phoneUtil;
        if (!localLeniency3.verify(localPhoneNumber, paramString, localPhoneNumberUtil2))
          continue;
        PhoneNumberMatch localPhoneNumberMatch = new PhoneNumberMatch(paramInt, paramString, localPhoneNumber);
        localObject = localPhoneNumberMatch;
      }
    }
    catch (NumberParseException localNumberParseException)
    {
      break label15;
    }
  }

  private static CharSequence trimAfterFirstMatch(Pattern paramPattern, CharSequence paramCharSequence)
  {
    Matcher localMatcher = paramPattern.matcher(paramCharSequence);
    if (localMatcher.find())
    {
      int i = localMatcher.start();
      paramCharSequence = paramCharSequence.subSequence(0, i);
    }
    return paramCharSequence;
  }

  public boolean hasNext()
  {
    State localState1 = this.state;
    State localState2 = State.NOT_READY;
    if (localState1 == localState2)
    {
      int i = this.searchIndex;
      PhoneNumberMatch localPhoneNumberMatch = find(i);
      this.lastMatch = localPhoneNumberMatch;
      if (this.lastMatch == null)
      {
        State localState3 = State.DONE;
        this.state = localState3;
      }
    }
    else
    {
      State localState4 = this.state;
      State localState5 = State.READY;
      if (localState4 != localState5)
        break label103;
    }
    label103: for (int j = 1; ; j = 0)
    {
      return j;
      int k = this.lastMatch.end();
      this.searchIndex = k;
      State localState6 = State.READY;
      this.state = localState6;
      break;
    }
  }

  public PhoneNumberMatch next()
  {
    if (!hasNext())
      throw new NoSuchElementException();
    PhoneNumberMatch localPhoneNumberMatch = this.lastMatch;
    this.lastMatch = null;
    State localState = State.NOT_READY;
    this.state = localState;
    return localPhoneNumberMatch;
  }

  public void remove()
  {
    throw new UnsupportedOperationException();
  }

  enum State
  {
    static
    {
      DONE = new State("DONE", 2);
      State[] arrayOfState = new State[3];
      State localState1 = NOT_READY;
      arrayOfState[0] = localState1;
      State localState2 = READY;
      arrayOfState[1] = localState2;
      State localState3 = DONE;
      arrayOfState[2] = localState3;
      $VALUES = arrayOfState;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.i18n.phonenumbers.PhoneNumberMatcher
 * JD-Core Version:    0.6.0
 */