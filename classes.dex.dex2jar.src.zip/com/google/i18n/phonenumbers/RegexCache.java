package com.google.i18n.phonenumbers;

import java.util.LinkedHashMap;
import java.util.regex.Pattern;

public class RegexCache
{
  private LRUCache<String, Pattern> cache;

  public RegexCache(int paramInt)
  {
    LRUCache localLRUCache = new LRUCache();
    this.cache = localLRUCache;
  }

  boolean containsRegex(String paramString)
  {
    return this.cache.containsKey(paramString);
  }

  public Pattern getPatternForRegex(String paramString)
  {
    Pattern localPattern = (Pattern)this.cache.get(paramString);
    if (localPattern == null)
    {
      localPattern = Pattern.compile(paramString);
      this.cache.put(paramString, localPattern);
    }
    return localPattern;
  }

  class LRUCache<K, V>
  {
    private LinkedHashMap<K, V> map;
    private int size;

    public LRUCache()
    {
      this.size = this$1;
      int i = this$1 * 4 / 3 + 1;
      RegexCache.LRUCache.1 local1 = new RegexCache.LRUCache.1(this, i, 0.75F, 1);
      this.map = local1;
    }

    /** @deprecated */
    public boolean containsKey(K paramK)
    {
      monitorenter;
      try
      {
        boolean bool1 = this.map.containsKey(paramK);
        boolean bool2 = bool1;
        monitorexit;
        return bool2;
      }
      finally
      {
        localObject = finally;
        monitorexit;
      }
      throw localObject;
    }

    /** @deprecated */
    public V get(K paramK)
    {
      monitorenter;
      try
      {
        Object localObject1 = this.map.get(paramK);
        Object localObject2 = localObject1;
        monitorexit;
        return localObject2;
      }
      finally
      {
        localObject3 = finally;
        monitorexit;
      }
      throw localObject3;
    }

    /** @deprecated */
    public void put(K paramK, V paramV)
    {
      monitorenter;
      try
      {
        Object localObject1 = this.map.put(paramK, paramV);
        monitorexit;
        return;
      }
      finally
      {
        localObject2 = finally;
        monitorexit;
      }
      throw localObject2;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.i18n.phonenumbers.RegexCache
 * JD-Core Version:    0.6.0
 */