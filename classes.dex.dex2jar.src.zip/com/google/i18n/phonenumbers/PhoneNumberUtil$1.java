package com.google.i18n.phonenumbers;

import java.util.Iterator;

class PhoneNumberUtil$1
  implements Iterable<PhoneNumberMatch>
{
  public Iterator<PhoneNumberMatch> iterator()
  {
    PhoneNumberUtil localPhoneNumberUtil = this.this$0;
    CharSequence localCharSequence = this.val$text;
    String str = this.val$defaultRegion;
    PhoneNumberUtil.Leniency localLeniency = this.val$leniency;
    long l = this.val$maxTries;
    return new PhoneNumberMatcher(localPhoneNumberUtil, localCharSequence, str, localLeniency, l);
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.i18n.phonenumbers.PhoneNumberUtil.1
 * JD-Core Version:    0.6.0
 */