package com.google.i18n.phonenumbers;

import java.util.LinkedHashMap;
import java.util.Map.Entry;

class RegexCache$LRUCache$1 extends LinkedHashMap<K, V>
{
  protected boolean removeEldestEntry(Map.Entry<K, V> paramEntry)
  {
    int i = size();
    int j = RegexCache.LRUCache.access$000(this.this$0);
    if (i > j);
    for (int k = 1; ; k = 0)
      return k;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.i18n.phonenumbers.RegexCache.LRUCache.1
 * JD-Core Version:    0.6.0
 */