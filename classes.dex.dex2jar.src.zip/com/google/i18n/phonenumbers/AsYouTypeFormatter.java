package com.google.i18n.phonenumbers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AsYouTypeFormatter
{
  private static final Pattern CHARACTER_CLASS_PATTERN = ;
  private static final Pattern ELIGIBLE_FORMAT_PATTERN = ;
  private static final Phonemetadata.PhoneMetadata EMPTY_METADATA = ;
  private static final int MIN_LEADING_DIGITS_LENGTH = 3;
  private static final Pattern STANDALONE_DIGIT_PATTERN;
  private boolean ableToFormat;
  private StringBuilder accruedInput;
  private StringBuilder accruedInputWithoutFormatting;
  private String currentFormattingPattern;
  private Phonemetadata.PhoneMetadata currentMetaData;
  private String currentOutput = "";
  private String defaultCountry;
  private Phonemetadata.PhoneMetadata defaultMetaData;
  private Pattern digitPattern;
  private String digitPlaceholder;
  private StringBuilder formattingTemplate;
  private boolean isExpectingCountryCallingCode;
  private boolean isInternationalFormatting;
  private int lastMatchPosition;
  private StringBuilder nationalNumber;
  private int originalPosition;
  private final PhoneNumberUtil phoneUtil;
  private int positionToRemember;
  private List<Phonemetadata.NumberFormat> possibleFormats;
  private StringBuilder prefixBeforeNationalNumber;
  private RegexCache regexCache;

  static
  {
    CHARACTER_CLASS_PATTERN = Pattern.compile("\\[([^\\[\\]])*\\]");
    STANDALONE_DIGIT_PATTERN = Pattern.compile("\\d(?=[^,}][^,}])");
    ELIGIBLE_FORMAT_PATTERN = Pattern.compile("[-x‐-―−ー－-／  ​⁠　()（）［］.\\[\\]/~⁓∼～]*(\\$\\d[-x‐-―−ー－-／  ​⁠　()（）［］.\\[\\]/~⁓∼～]*)+");
  }

  AsYouTypeFormatter(String paramString)
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    this.formattingTemplate = localStringBuilder1;
    this.currentFormattingPattern = "";
    StringBuilder localStringBuilder2 = new StringBuilder();
    this.accruedInput = localStringBuilder2;
    StringBuilder localStringBuilder3 = new StringBuilder();
    this.accruedInputWithoutFormatting = localStringBuilder3;
    this.ableToFormat = 1;
    this.isInternationalFormatting = 0;
    this.isExpectingCountryCallingCode = 0;
    PhoneNumberUtil localPhoneNumberUtil = PhoneNumberUtil.getInstance();
    this.phoneUtil = localPhoneNumberUtil;
    this.digitPlaceholder = " ";
    Pattern localPattern = Pattern.compile(this.digitPlaceholder);
    this.digitPattern = localPattern;
    this.lastMatchPosition = 0;
    this.originalPosition = 0;
    this.positionToRemember = 0;
    StringBuilder localStringBuilder4 = new StringBuilder();
    this.prefixBeforeNationalNumber = localStringBuilder4;
    StringBuilder localStringBuilder5 = new StringBuilder();
    this.nationalNumber = localStringBuilder5;
    ArrayList localArrayList = new ArrayList();
    this.possibleFormats = localArrayList;
    RegexCache localRegexCache = new RegexCache(64);
    this.regexCache = localRegexCache;
    this.defaultCountry = paramString;
    String str = this.defaultCountry;
    Phonemetadata.PhoneMetadata localPhoneMetadata1 = getMetadataForRegion(str);
    this.currentMetaData = localPhoneMetadata1;
    Phonemetadata.PhoneMetadata localPhoneMetadata2 = this.currentMetaData;
    this.defaultMetaData = localPhoneMetadata2;
  }

  private String attemptToChooseFormattingPattern()
  {
    if (this.nationalNumber.length() >= 3)
    {
      String str1 = this.nationalNumber.substring(0, 3);
      getAvailableFormats(str1);
      boolean bool = maybeCreateNewTemplate();
    }
    StringBuilder localStringBuilder3;
    String str3;
    for (String str2 = inputAccruedNationalNumber(); ; str2 = str3)
    {
      return str2;
      StringBuilder localStringBuilder1 = new StringBuilder();
      StringBuilder localStringBuilder2 = this.prefixBeforeNationalNumber;
      localStringBuilder3 = localStringBuilder1.append(localStringBuilder2);
      str3 = this.nationalNumber.toString();
    }
  }

  private boolean attemptToExtractCountryCallingCode()
  {
    int i = 0;
    if (this.nationalNumber.length() == 0);
    while (true)
    {
      return i;
      StringBuilder localStringBuilder1 = new StringBuilder();
      PhoneNumberUtil localPhoneNumberUtil = this.phoneUtil;
      StringBuilder localStringBuilder2 = this.nationalNumber;
      int k = localPhoneNumberUtil.extractCountryCode(localStringBuilder2, localStringBuilder1);
      if (k == 0)
        continue;
      this.nationalNumber.setLength(0);
      StringBuilder localStringBuilder3 = this.nationalNumber.append(localStringBuilder1);
      String str1 = this.phoneUtil.getRegionCodeForCountryCode(k);
      String str2 = this.defaultCountry;
      if (!str1.equals(str2))
      {
        Phonemetadata.PhoneMetadata localPhoneMetadata = getMetadataForRegion(str1);
        this.currentMetaData = localPhoneMetadata;
      }
      String str3 = Integer.toString(k);
      StringBuilder localStringBuilder4 = this.prefixBeforeNationalNumber.append(str3).append(" ");
      int j = 1;
    }
  }

  private boolean attemptToExtractIdd()
  {
    int i = 1;
    RegexCache localRegexCache = this.regexCache;
    StringBuilder localStringBuilder1 = new StringBuilder().append("\\+|");
    String str1 = this.currentMetaData.getInternationalPrefix();
    String str2 = str1;
    Pattern localPattern = localRegexCache.getPatternForRegex(str2);
    StringBuilder localStringBuilder2 = this.accruedInputWithoutFormatting;
    Matcher localMatcher = localPattern.matcher(localStringBuilder2);
    if (localMatcher.lookingAt())
    {
      this.isInternationalFormatting = 1;
      int j = localMatcher.end();
      this.nationalNumber.setLength(0);
      StringBuilder localStringBuilder3 = this.nationalNumber;
      String str3 = this.accruedInputWithoutFormatting.substring(j);
      StringBuilder localStringBuilder4 = localStringBuilder3.append(str3);
      StringBuilder localStringBuilder5 = this.prefixBeforeNationalNumber;
      String str4 = this.accruedInputWithoutFormatting.substring(0, j);
      StringBuilder localStringBuilder6 = localStringBuilder5.append(str4);
      if (this.accruedInputWithoutFormatting.charAt(0) != 43)
        StringBuilder localStringBuilder7 = this.prefixBeforeNationalNumber.append(" ");
    }
    while (true)
    {
      return i;
      i = 0;
    }
  }

  private boolean createFormattingTemplate(Phonemetadata.NumberFormat paramNumberFormat)
  {
    int i = 0;
    String str1 = paramNumberFormat.getPattern();
    if (str1.indexOf('|') != -1);
    while (true)
    {
      return i;
      String str2 = CHARACTER_CLASS_PATTERN.matcher(str1).replaceAll("\\\\d");
      String str3 = STANDALONE_DIGIT_PATTERN.matcher(str2).replaceAll("\\\\d");
      this.formattingTemplate.setLength(0);
      String str4 = paramNumberFormat.getFormat();
      str1 = getFormattingTemplate(str3, str4);
      if (str1.length() <= 0)
        continue;
      StringBuilder localStringBuilder = this.formattingTemplate.append(str1);
      i = 1;
    }
  }

  private void getAvailableFormats(String paramString)
  {
    if ((this.isInternationalFormatting) && (this.currentMetaData.intlNumberFormatSize() > 0));
    for (Object localObject = this.currentMetaData.intlNumberFormats(); ; localObject = this.currentMetaData.numberFormats())
    {
      Iterator localIterator = ((List)localObject).iterator();
      while (localIterator.hasNext())
      {
        localObject = (Phonemetadata.NumberFormat)localIterator.next();
        String str = ((Phonemetadata.NumberFormat)localObject).getFormat();
        if (!isFormatEligible(str))
          continue;
        boolean bool = this.possibleFormats.add(localObject);
      }
    }
    narrowDownPossibleFormats(paramString);
  }

  private String getFormattingTemplate(String paramString1, String paramString2)
  {
    Matcher localMatcher = this.regexCache.getPatternForRegex(paramString1).matcher("999999999999999");
    boolean bool = localMatcher.find();
    String str1 = localMatcher.group();
    int i = str1.length();
    int j = this.nationalNumber.length();
    if (i < j);
    String str2;
    String str3;
    for (str1 = ""; ; str1 = str2.replaceAll("9", str3))
    {
      return str1;
      str2 = str1.replaceAll(paramString1, paramString2);
      str3 = this.digitPlaceholder;
    }
  }

  private Phonemetadata.PhoneMetadata getMetadataForRegion(String paramString)
  {
    int i = this.phoneUtil.getCountryCodeForRegion(paramString);
    String str = this.phoneUtil.getRegionCodeForCountryCode(i);
    Phonemetadata.PhoneMetadata localPhoneMetadata = this.phoneUtil.getMetadataForRegion(str);
    if (localPhoneMetadata != null);
    while (true)
    {
      return localPhoneMetadata;
      localPhoneMetadata = EMPTY_METADATA;
    }
  }

  private String inputAccruedNationalNumber()
  {
    int i = this.nationalNumber.length();
    StringBuilder localStringBuilder1;
    StringBuilder localStringBuilder2;
    if (i > 0)
    {
      int j = 0;
      localObject = "";
      int k = j;
      while (k < i)
      {
        char c = this.nationalNumber.charAt(k);
        String str = inputDigitHelper(c);
        k += 1;
        localObject = str;
      }
      if (this.ableToFormat)
      {
        localStringBuilder1 = new StringBuilder();
        localStringBuilder2 = this.prefixBeforeNationalNumber;
      }
    }
    for (Object localObject = localStringBuilder2 + (String)localObject; ; localObject = this.prefixBeforeNationalNumber.toString())
      return localObject;
  }

  private String inputDigitHelper(char paramChar)
  {
    Pattern localPattern = this.digitPattern;
    StringBuilder localStringBuilder1 = this.formattingTemplate;
    Object localObject = localPattern.matcher(localStringBuilder1);
    int i = this.lastMatchPosition;
    StringBuilder localStringBuilder4;
    int m;
    if (((Matcher)localObject).find(i))
    {
      String str1 = Character.toString(paramChar);
      String str2 = ((Matcher)localObject).replaceFirst(str1);
      StringBuilder localStringBuilder2 = this.formattingTemplate;
      int j = str2.length();
      StringBuilder localStringBuilder3 = localStringBuilder2.replace(0, j, str2);
      int k = ((Matcher)localObject).start();
      this.lastMatchPosition = k;
      localStringBuilder4 = this.formattingTemplate;
      m = this.lastMatchPosition + 1;
    }
    for (localObject = localStringBuilder4.substring(0, m); ; localObject = this.accruedInput.toString())
    {
      return localObject;
      if (this.possibleFormats.size() == 1)
        this.ableToFormat = 0;
      this.currentFormattingPattern = "";
    }
  }

  private String inputDigitWithOptionToRememberPosition(char paramChar, boolean paramBoolean)
  {
    StringBuilder localStringBuilder1 = this.accruedInput.append(paramChar);
    if (paramBoolean)
    {
      int i = this.accruedInput.length();
      this.originalPosition = i;
    }
    if (!isDigitOrLeadingPlusSign(paramChar))
      this.ableToFormat = 0;
    String str1;
    if (!this.ableToFormat)
      str1 = this.accruedInput.toString();
    while (true)
    {
      return str1;
      char c = normalizeAndAccrueDigitsAndPlusSign(paramChar, paramBoolean);
      switch (this.accruedInputWithoutFormatting.length())
      {
      default:
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      }
      do
      {
        if (this.possibleFormats.size() <= 0)
          break label372;
        localObject = inputDigitHelper(c);
        String str2 = attemptToFormatAccruedDigits();
        if (str2.length() <= 0)
          break label299;
        localObject = str2;
        break;
        localObject = this.accruedInput.toString();
        break;
        if (attemptToExtractIdd())
        {
          this.isExpectingCountryCallingCode = 1;
          if (!this.isExpectingCountryCallingCode)
            continue;
          if (attemptToExtractCountryCallingCode())
            this.isExpectingCountryCallingCode = 0;
          StringBuilder localStringBuilder2 = new StringBuilder();
          StringBuilder localStringBuilder3 = this.prefixBeforeNationalNumber;
          StringBuilder localStringBuilder4 = localStringBuilder2.append(localStringBuilder3);
          String str3 = this.nationalNumber.toString();
          localObject = str3;
          break;
        }
        removeNationalPrefixFromNationalNumber();
        localObject = attemptToChooseFormattingPattern();
        break;
      }
      while ((!this.isExpectingCountryCallingCode) || (attemptToExtractCountryCallingCode()));
      this.ableToFormat = 0;
      Object localObject = this.accruedInput.toString();
      continue;
      label299: String str4 = this.nationalNumber.toString();
      narrowDownPossibleFormats(str4);
      if (maybeCreateNewTemplate())
      {
        localObject = inputAccruedNationalNumber();
        continue;
      }
      if (!this.ableToFormat)
        continue;
      StringBuilder localStringBuilder5 = new StringBuilder();
      StringBuilder localStringBuilder6 = this.prefixBeforeNationalNumber;
      localObject = localStringBuilder6 + (String)localObject;
      continue;
      label372: localObject = attemptToChooseFormattingPattern();
    }
  }

  private boolean isDigitOrLeadingPlusSign(char paramChar)
  {
    int i = 1;
    if (!Character.isDigit(paramChar))
    {
      if (this.accruedInput.length() != 1)
        break label44;
      Pattern localPattern = PhoneNumberUtil.PLUS_CHARS_PATTERN;
      String str = Character.toString(paramChar);
      if (!localPattern.matcher(str).matches())
        break label44;
    }
    while (true)
    {
      return i;
      label44: i = 0;
    }
  }

  private boolean isFormatEligible(String paramString)
  {
    return ELIGIBLE_FORMAT_PATTERN.matcher(paramString).matches();
  }

  private boolean maybeCreateNewTemplate()
  {
    Iterator localIterator = this.possibleFormats.iterator();
    String str;
    int i;
    if (localIterator.hasNext())
    {
      Phonemetadata.NumberFormat localNumberFormat = (Phonemetadata.NumberFormat)localIterator.next();
      str = localNumberFormat.getPattern();
      if (this.currentFormattingPattern.equals(str))
        i = 0;
    }
    while (true)
    {
      return i;
      if (createFormattingTemplate(i))
      {
        this.currentFormattingPattern = str;
        i = 1;
        continue;
      }
      localIterator.remove();
      break;
      this.ableToFormat = 0;
      i = 0;
    }
  }

  private void narrowDownPossibleFormats(String paramString)
  {
    int i = paramString.length() + -3;
    Iterator localIterator = this.possibleFormats.iterator();
    while (localIterator.hasNext())
    {
      Phonemetadata.NumberFormat localNumberFormat = (Phonemetadata.NumberFormat)localIterator.next();
      if (localNumberFormat.leadingDigitsPatternSize() <= i)
        continue;
      RegexCache localRegexCache = this.regexCache;
      String str = localNumberFormat.getLeadingDigitsPattern(i);
      if (localRegexCache.getPatternForRegex(str).matcher(paramString).lookingAt())
        continue;
      localIterator.remove();
    }
  }

  private char normalizeAndAccrueDigitsAndPlusSign(char paramChar, boolean paramBoolean)
  {
    if (paramChar == '+')
      StringBuilder localStringBuilder1 = this.accruedInputWithoutFormatting.append(paramChar);
    while (true)
    {
      if (paramBoolean)
      {
        int i = this.accruedInputWithoutFormatting.length();
        this.positionToRemember = i;
      }
      return paramChar;
      paramChar = Character.forDigit(Character.digit(paramChar, 10), 10);
      StringBuilder localStringBuilder2 = this.accruedInputWithoutFormatting.append(paramChar);
      StringBuilder localStringBuilder3 = this.nationalNumber.append(paramChar);
    }
  }

  private void removeNationalPrefixFromNationalNumber()
  {
    int i = 1;
    if ((this.currentMetaData.getCountryCode() == i) && (this.nationalNumber.charAt(0) == 49))
    {
      StringBuilder localStringBuilder1 = this.prefixBeforeNationalNumber.append("1 ");
      this.isInternationalFormatting = 1;
    }
    while (true)
    {
      StringBuilder localStringBuilder2 = this.nationalNumber.delete(0, i);
      return;
      if (this.currentMetaData.hasNationalPrefix())
      {
        RegexCache localRegexCache = this.regexCache;
        String str1 = this.currentMetaData.getNationalPrefixForParsing();
        Pattern localPattern = localRegexCache.getPatternForRegex(str1);
        StringBuilder localStringBuilder3 = this.nationalNumber;
        Matcher localMatcher = localPattern.matcher(localStringBuilder3);
        if (localMatcher.lookingAt())
        {
          this.isInternationalFormatting = 1;
          i = localMatcher.end();
          StringBuilder localStringBuilder4 = this.prefixBeforeNationalNumber;
          String str2 = this.nationalNumber.substring(0, i);
          StringBuilder localStringBuilder5 = localStringBuilder4.append(str2);
          continue;
        }
      }
      i = 0;
    }
  }

  String attemptToFormatAccruedDigits()
  {
    Iterator localIterator = this.possibleFormats.iterator();
    String str3;
    StringBuilder localStringBuilder2;
    StringBuilder localStringBuilder3;
    while (localIterator.hasNext())
    {
      localObject = (Phonemetadata.NumberFormat)localIterator.next();
      RegexCache localRegexCache = this.regexCache;
      String str1 = ((Phonemetadata.NumberFormat)localObject).getPattern();
      Pattern localPattern = localRegexCache.getPatternForRegex(str1);
      StringBuilder localStringBuilder1 = this.nationalNumber;
      Matcher localMatcher = localPattern.matcher(localStringBuilder1);
      if (!localMatcher.matches())
        continue;
      String str2 = ((Phonemetadata.NumberFormat)localObject).getFormat();
      str3 = localMatcher.replaceAll(str2);
      localStringBuilder2 = new StringBuilder();
      localStringBuilder3 = this.prefixBeforeNationalNumber;
    }
    for (Object localObject = localStringBuilder3 + str3; ; localObject = "")
      return localObject;
  }

  public void clear()
  {
    this.currentOutput = "";
    this.accruedInput.setLength(0);
    this.accruedInputWithoutFormatting.setLength(0);
    this.formattingTemplate.setLength(0);
    this.lastMatchPosition = 0;
    this.currentFormattingPattern = "";
    this.prefixBeforeNationalNumber.setLength(0);
    this.nationalNumber.setLength(0);
    this.ableToFormat = 1;
    this.positionToRemember = 0;
    this.originalPosition = 0;
    this.isInternationalFormatting = 0;
    this.isExpectingCountryCallingCode = 0;
    this.possibleFormats.clear();
    Phonemetadata.PhoneMetadata localPhoneMetadata1 = this.currentMetaData;
    Phonemetadata.PhoneMetadata localPhoneMetadata2 = this.defaultMetaData;
    if (!localPhoneMetadata1.equals(localPhoneMetadata2))
    {
      String str = this.defaultCountry;
      Phonemetadata.PhoneMetadata localPhoneMetadata3 = getMetadataForRegion(str);
      this.currentMetaData = localPhoneMetadata3;
    }
  }

  public int getRememberedPosition()
  {
    int i = 0;
    if (!this.ableToFormat)
    {
      i = this.originalPosition;
      return i;
    }
    int j = 0;
    while (true)
    {
      int k = this.positionToRemember;
      if (j >= k)
        break;
      int m = this.currentOutput.length();
      if (i >= m)
        break;
      int n = this.accruedInputWithoutFormatting.charAt(j);
      int i1 = this.currentOutput.charAt(i);
      if (n == i1)
        j += 1;
      i += 1;
    }
  }

  public String inputDigit(char paramChar)
  {
    String str = inputDigitWithOptionToRememberPosition(paramChar, 0);
    this.currentOutput = str;
    return this.currentOutput;
  }

  public String inputDigitAndRememberPosition(char paramChar)
  {
    String str = inputDigitWithOptionToRememberPosition(paramChar, 1);
    this.currentOutput = str;
    return this.currentOutput;
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.i18n.phonenumbers.AsYouTypeFormatter
 * JD-Core Version:    0.6.0
 */