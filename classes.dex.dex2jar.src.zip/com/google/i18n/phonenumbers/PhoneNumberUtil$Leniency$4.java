package com.google.i18n.phonenumbers;

import java.util.regex.Pattern;

 enum PhoneNumberUtil$Leniency$4
{
  boolean verify(Phonenumber.PhoneNumber paramPhoneNumber, String paramString, PhoneNumberUtil paramPhoneNumberUtil)
  {
    int i = 0;
    if ((!paramPhoneNumberUtil.isValidNumber(paramPhoneNumber)) || (!PhoneNumberUtil.Leniency.access$100(paramPhoneNumber, paramString, paramPhoneNumberUtil)) || (PhoneNumberUtil.Leniency.access$200(paramString)))
      return i;
    StringBuilder localStringBuilder = PhoneNumberUtil.access$400(paramString, 1);
    Pattern localPattern = PhoneNumberUtil.access$500();
    String str1 = localStringBuilder.toString();
    String[] arrayOfString1 = localPattern.split(str1);
    if (paramPhoneNumber.hasExtension());
    for (int j = arrayOfString1.length + -2; ; j = arrayOfString1.length + -1)
    {
      if (arrayOfString1.length != 1)
      {
        String str2 = arrayOfString1[j];
        String str3 = paramPhoneNumberUtil.getNationalSignificantNumber(paramPhoneNumber);
        if (!str2.contains(str3))
          break label122;
      }
      i = 1;
      break;
    }
    label122: String[] arrayOfString2 = PhoneNumberUtil.Leniency.access$300(paramPhoneNumberUtil, paramPhoneNumber);
    int k = arrayOfString2.length + -1;
    int m = j;
    j = k;
    while (true)
    {
      if ((j <= 0) || (m < 0))
        break label196;
      String str4 = arrayOfString1[m];
      String str5 = arrayOfString2[j];
      if (!str4.equals(str5))
        break;
      j += -1;
      m += -1;
    }
    label196: if (m >= 0)
    {
      String str6 = arrayOfString1[m];
      String str7 = arrayOfString2[0];
      if (!str6.endsWith(str7));
    }
    for (j = 1; ; j = 0)
    {
      i = j;
      break;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.i18n.phonenumbers.PhoneNumberUtil.Leniency.4
 * JD-Core Version:    0.6.0
 */