package com.google.i18n.phonenumbers;

public class NumberParseException extends Exception
{
  private ErrorType errorType;
  private String message;

  public NumberParseException(ErrorType paramErrorType, String paramString)
  {
    super(paramString);
    this.message = paramString;
    this.errorType = paramErrorType;
  }

  public ErrorType getErrorType()
  {
    return this.errorType;
  }

  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("Error type: ");
    ErrorType localErrorType = this.errorType;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(localErrorType).append(". ");
    String str = this.message;
    return str;
  }

  public enum ErrorType
  {
    static
    {
      TOO_LONG = new ErrorType("TOO_LONG", 4);
      ErrorType[] arrayOfErrorType = new ErrorType[5];
      ErrorType localErrorType1 = INVALID_COUNTRY_CODE;
      arrayOfErrorType[0] = localErrorType1;
      ErrorType localErrorType2 = NOT_A_NUMBER;
      arrayOfErrorType[1] = localErrorType2;
      ErrorType localErrorType3 = TOO_SHORT_AFTER_IDD;
      arrayOfErrorType[2] = localErrorType3;
      ErrorType localErrorType4 = TOO_SHORT_NSN;
      arrayOfErrorType[3] = localErrorType4;
      ErrorType localErrorType5 = TOO_LONG;
      arrayOfErrorType[4] = localErrorType5;
      $VALUES = arrayOfErrorType;
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.google.i18n.phonenumbers.NumberParseException
 * JD-Core Version:    0.6.0
 */