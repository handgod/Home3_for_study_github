package com.htc.music;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract interface IMediaPlaybackService extends IInterface
{
  public abstract void activityGoSleep()
    throws RemoteException;

  public abstract void activityWakeup()
    throws RemoteException;

  public abstract long duration()
    throws RemoteException;

  public abstract void endAnimation()
    throws RemoteException;

  public abstract void enqueue(int[] paramArrayOfInt, int paramInt)
    throws RemoteException;

  public abstract int getAlbumId()
    throws RemoteException;

  public abstract String getAlbumName()
    throws RemoteException;

  public abstract int[] getAlbumQueue()
    throws RemoteException;

  public abstract int getAlbumQueuePosition()
    throws RemoteException;

  public abstract int getAlbumQueueSize()
    throws RemoteException;

  public abstract int getArtistId()
    throws RemoteException;

  public abstract String getArtistName()
    throws RemoteException;

  public abstract int getAudioId()
    throws RemoteException;

  public abstract int getMediaMountedCount()
    throws RemoteException;

  public abstract String getPath()
    throws RemoteException;

  public abstract int[] getQueue()
    throws RemoteException;

  public abstract int getQueuePosition()
    throws RemoteException;

  public abstract int getQueueSize()
    throws RemoteException;

  public abstract int getRepeatMode()
    throws RemoteException;

  public abstract int getShuffleMode()
    throws RemoteException;

  public abstract String getSongInfo(int paramInt)
    throws RemoteException;

  public abstract String getTrackName()
    throws RemoteException;

  public abstract boolean isPlaying()
    throws RemoteException;

  public abstract boolean isSystemReady()
    throws RemoteException;

  public abstract void moveQueueItem(int paramInt1, int paramInt2)
    throws RemoteException;

  public abstract void next()
    throws RemoteException;

  public abstract void nextAlbum()
    throws RemoteException;

  public abstract void open(int[] paramArrayOfInt, int paramInt)
    throws RemoteException;

  public abstract void openfile(String paramString)
    throws RemoteException;

  public abstract void openfileAsync(String paramString)
    throws RemoteException;

  public abstract void pause()
    throws RemoteException;

  public abstract void play()
    throws RemoteException;

  public abstract int playAlbum(int paramInt)
    throws RemoteException;

  public abstract long position()
    throws RemoteException;

  public abstract void prev()
    throws RemoteException;

  public abstract void prevAlbum()
    throws RemoteException;

  public abstract void reloadQueue()
    throws RemoteException;

  public abstract int removeTrack(int paramInt)
    throws RemoteException;

  public abstract int removeTracks(int paramInt1, int paramInt2)
    throws RemoteException;

  public abstract long seek(long paramLong)
    throws RemoteException;

  public abstract void setAlbumQueue(int[] paramArrayOfInt)
    throws RemoteException;

  public abstract void setMediaMode(boolean paramBoolean)
    throws RemoteException;

  public abstract void setQueuePosition(int paramInt)
    throws RemoteException;

  public abstract void setRepeatMode(int paramInt)
    throws RemoteException;

  public abstract void setShuffleMode(int paramInt)
    throws RemoteException;

  public abstract void startAnimation()
    throws RemoteException;

  public abstract void stop()
    throws RemoteException;

  public abstract void syncNowPlayingQueue(int[] paramArrayOfInt)
    throws RemoteException;

  public abstract class Stub extends Binder
    implements IMediaPlaybackService
  {
    private static final String DESCRIPTOR = "com.htc.music.IMediaPlaybackService";
    static final int TRANSACTION_activityGoSleep = 39;
    static final int TRANSACTION_activityWakeup = 40;
    static final int TRANSACTION_duration = 13;
    static final int TRANSACTION_endAnimation = 35;
    static final int TRANSACTION_enqueue = 21;
    static final int TRANSACTION_getAlbumId = 18;
    static final int TRANSACTION_getAlbumName = 17;
    static final int TRANSACTION_getAlbumQueue = 37;
    static final int TRANSACTION_getAlbumQueuePosition = 38;
    static final int TRANSACTION_getAlbumQueueSize = 42;
    static final int TRANSACTION_getArtistId = 20;
    static final int TRANSACTION_getArtistName = 19;
    static final int TRANSACTION_getAudioId = 26;
    static final int TRANSACTION_getMediaMountedCount = 33;
    static final int TRANSACTION_getPath = 25;
    static final int TRANSACTION_getQueue = 22;
    static final int TRANSACTION_getQueuePosition = 6;
    static final int TRANSACTION_getQueueSize = 41;
    static final int TRANSACTION_getRepeatMode = 32;
    static final int TRANSACTION_getShuffleMode = 28;
    static final int TRANSACTION_getSongInfo = 1;
    static final int TRANSACTION_getTrackName = 16;
    static final int TRANSACTION_isPlaying = 7;
    static final int TRANSACTION_isSystemReady = 45;
    static final int TRANSACTION_moveQueueItem = 23;
    static final int TRANSACTION_next = 12;
    static final int TRANSACTION_nextAlbum = 44;
    static final int TRANSACTION_open = 5;
    static final int TRANSACTION_openfile = 3;
    static final int TRANSACTION_openfileAsync = 4;
    static final int TRANSACTION_pause = 9;
    static final int TRANSACTION_play = 10;
    static final int TRANSACTION_playAlbum = 2;
    static final int TRANSACTION_position = 14;
    static final int TRANSACTION_prev = 11;
    static final int TRANSACTION_prevAlbum = 43;
    static final int TRANSACTION_reloadQueue = 46;
    static final int TRANSACTION_removeTrack = 30;
    static final int TRANSACTION_removeTracks = 29;
    static final int TRANSACTION_seek = 15;
    static final int TRANSACTION_setAlbumQueue = 36;
    static final int TRANSACTION_setMediaMode = 47;
    static final int TRANSACTION_setQueuePosition = 24;
    static final int TRANSACTION_setRepeatMode = 31;
    static final int TRANSACTION_setShuffleMode = 27;
    static final int TRANSACTION_startAnimation = 34;
    static final int TRANSACTION_stop = 8;
    static final int TRANSACTION_syncNowPlayingQueue = 48;

    public Stub()
    {
      attachInterface(this, "com.htc.music.IMediaPlaybackService");
    }

    public static IMediaPlaybackService asInterface(IBinder paramIBinder)
    {
      Object localObject;
      if (paramIBinder == null)
        localObject = null;
      while (true)
      {
        return localObject;
        localObject = paramIBinder.queryLocalInterface("com.htc.music.IMediaPlaybackService");
        if ((localObject != null) && ((localObject instanceof IMediaPlaybackService)))
        {
          localObject = (IMediaPlaybackService)localObject;
          continue;
        }
        localObject = new Proxy();
      }
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      int i = 0;
      boolean bool1 = true;
      switch (paramInt1)
      {
      default:
        bool1 = super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
      case 14:
      case 15:
      case 16:
      case 17:
      case 18:
      case 19:
      case 20:
      case 21:
      case 22:
      case 23:
      case 24:
      case 25:
      case 26:
      case 27:
      case 28:
      case 29:
      case 30:
      case 31:
      case 32:
      case 33:
      case 34:
      case 35:
      case 36:
      case 37:
      case 38:
      case 39:
      case 40:
      case 41:
      case 42:
      case 43:
      case 44:
      case 45:
      case 46:
      case 47:
      case 48:
      }
      while (true)
      {
        return bool1;
        paramParcel2.writeString("com.htc.music.IMediaPlaybackService");
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int j = paramParcel1.readInt();
        String str1 = getSongInfo(j);
        paramParcel2.writeNoException();
        paramParcel2.writeString(str1);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int k = paramParcel1.readInt();
        int m = playAlbum(k);
        paramParcel2.writeNoException();
        paramParcel2.writeInt(m);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        String str2 = paramParcel1.readString();
        openfile(str2);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        String str3 = paramParcel1.readString();
        openfileAsync(str3);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int[] arrayOfInt1 = paramParcel1.createIntArray();
        int n = paramParcel1.readInt();
        open(arrayOfInt1, n);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int i1 = getQueuePosition();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i1);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        boolean bool2 = isPlaying();
        paramParcel2.writeNoException();
        if (bool2)
          i = 1;
        paramParcel2.writeInt(i);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        stop();
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        pause();
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        play();
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        prev();
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        next();
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        long l1 = duration();
        paramParcel2.writeNoException();
        paramParcel2.writeLong(l1);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        long l2 = position();
        paramParcel2.writeNoException();
        paramParcel2.writeLong(l2);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        long l3 = paramParcel1.readLong();
        long l4 = seek(l3);
        paramParcel2.writeNoException();
        paramParcel2.writeLong(l4);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        String str4 = getTrackName();
        paramParcel2.writeNoException();
        paramParcel2.writeString(str4);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        String str5 = getAlbumName();
        paramParcel2.writeNoException();
        paramParcel2.writeString(str5);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int i2 = getAlbumId();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i2);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        String str6 = getArtistName();
        paramParcel2.writeNoException();
        paramParcel2.writeString(str6);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int i3 = getArtistId();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i3);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int[] arrayOfInt2 = paramParcel1.createIntArray();
        int i4 = paramParcel1.readInt();
        enqueue(arrayOfInt2, i4);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int[] arrayOfInt3 = getQueue();
        paramParcel2.writeNoException();
        paramParcel2.writeIntArray(arrayOfInt3);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int i5 = paramParcel1.readInt();
        int i6 = paramParcel1.readInt();
        moveQueueItem(i5, i6);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int i7 = paramParcel1.readInt();
        setQueuePosition(i7);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        String str7 = getPath();
        paramParcel2.writeNoException();
        paramParcel2.writeString(str7);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int i8 = getAudioId();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i8);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int i9 = paramParcel1.readInt();
        setShuffleMode(i9);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int i10 = getShuffleMode();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i10);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int i11 = paramParcel1.readInt();
        int i12 = paramParcel1.readInt();
        int i13 = removeTracks(i11, i12);
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i13);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int i14 = paramParcel1.readInt();
        int i15 = removeTrack(i14);
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i15);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int i16 = paramParcel1.readInt();
        setRepeatMode(i16);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int i17 = getRepeatMode();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i17);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int i18 = getMediaMountedCount();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i18);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        startAnimation();
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        endAnimation();
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int[] arrayOfInt4 = paramParcel1.createIntArray();
        setAlbumQueue(arrayOfInt4);
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int[] arrayOfInt5 = getAlbumQueue();
        paramParcel2.writeNoException();
        paramParcel2.writeIntArray(arrayOfInt5);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int i19 = getAlbumQueuePosition();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i19);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        activityGoSleep();
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        activityWakeup();
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int i20 = getQueueSize();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i20);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int i21 = getAlbumQueueSize();
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i21);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        prevAlbum();
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        nextAlbum();
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        boolean bool3 = isSystemReady();
        paramParcel2.writeNoException();
        if (bool3)
          i = 1;
        paramParcel2.writeInt(i);
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        reloadQueue();
        paramParcel2.writeNoException();
        continue;
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        if (paramParcel1.readInt() != 0);
        int i23;
        for (int i22 = 1; ; i23 = 0)
        {
          setMediaMode(i22);
          paramParcel2.writeNoException();
          break;
        }
        paramParcel1.enforceInterface("com.htc.music.IMediaPlaybackService");
        int[] arrayOfInt6 = paramParcel1.createIntArray();
        syncNowPlayingQueue(arrayOfInt6);
        paramParcel2.writeNoException();
      }
    }

    class Proxy
      implements IMediaPlaybackService
    {
      Proxy()
      {
      }

      public void activityGoSleep()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(39, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void activityWakeup()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(40, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public IBinder asBinder()
      {
        return IMediaPlaybackService.Stub.this;
      }

      public long duration()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(13, localParcel1, localParcel2, 0);
          localParcel2.readException();
          long l1 = localParcel2.readLong();
          long l2 = l1;
          return l2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void endAnimation()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(35, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void enqueue(int[] paramArrayOfInt, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          localParcel1.writeIntArray(paramArrayOfInt);
          localParcel1.writeInt(paramInt);
          boolean bool = IMediaPlaybackService.Stub.this.transact(21, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int getAlbumId()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(18, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = i;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public String getAlbumName()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(17, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str1 = localParcel2.readString();
          String str2 = str1;
          return str2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int[] getAlbumQueue()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(37, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int[] arrayOfInt1 = localParcel2.createIntArray();
          int[] arrayOfInt2 = arrayOfInt1;
          return arrayOfInt2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int getAlbumQueuePosition()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(38, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = i;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int getAlbumQueueSize()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(42, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = i;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int getArtistId()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(20, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = i;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public String getArtistName()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(19, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str1 = localParcel2.readString();
          String str2 = str1;
          return str2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int getAudioId()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(26, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = i;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public String getInterfaceDescriptor()
      {
        return "com.htc.music.IMediaPlaybackService";
      }

      public int getMediaMountedCount()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(33, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = i;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public String getPath()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(25, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str1 = localParcel2.readString();
          String str2 = str1;
          return str2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int[] getQueue()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(22, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int[] arrayOfInt1 = localParcel2.createIntArray();
          int[] arrayOfInt2 = arrayOfInt1;
          return arrayOfInt2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int getQueuePosition()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(6, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = i;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int getQueueSize()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(41, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = i;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int getRepeatMode()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(32, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = i;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int getShuffleMode()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(28, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = i;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public String getSongInfo(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          localParcel1.writeInt(paramInt);
          boolean bool = IMediaPlaybackService.Stub.this.transact(1, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str1 = localParcel2.readString();
          String str2 = str1;
          return str2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public String getTrackName()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(16, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str1 = localParcel2.readString();
          String str2 = str1;
          return str2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public boolean isPlaying()
        throws RemoteException
      {
        int i = 0;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(7, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int j = localParcel2.readInt();
          if (j != 0)
            i = 1;
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public boolean isSystemReady()
        throws RemoteException
      {
        int i = 0;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(45, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int j = localParcel2.readInt();
          if (j != 0)
            i = 1;
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void moveQueueItem(int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          boolean bool = IMediaPlaybackService.Stub.this.transact(23, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void next()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(12, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void nextAlbum()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(44, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void open(int[] paramArrayOfInt, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          localParcel1.writeIntArray(paramArrayOfInt);
          localParcel1.writeInt(paramInt);
          boolean bool = IMediaPlaybackService.Stub.this.transact(5, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void openfile(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          localParcel1.writeString(paramString);
          boolean bool = IMediaPlaybackService.Stub.this.transact(3, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void openfileAsync(String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          localParcel1.writeString(paramString);
          boolean bool = IMediaPlaybackService.Stub.this.transact(4, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void pause()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(9, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void play()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(10, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int playAlbum(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          localParcel1.writeInt(paramInt);
          boolean bool = IMediaPlaybackService.Stub.this.transact(2, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = i;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public long position()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(14, localParcel1, localParcel2, 0);
          localParcel2.readException();
          long l1 = localParcel2.readLong();
          long l2 = l1;
          return l2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void prev()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(11, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void prevAlbum()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(43, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void reloadQueue()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(46, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int removeTrack(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          localParcel1.writeInt(paramInt);
          boolean bool = IMediaPlaybackService.Stub.this.transact(30, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = i;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public int removeTracks(int paramInt1, int paramInt2)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          boolean bool = IMediaPlaybackService.Stub.this.transact(29, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          int j = i;
          return j;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public long seek(long paramLong)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          localParcel1.writeLong(paramLong);
          boolean bool = IMediaPlaybackService.Stub.this.transact(15, localParcel1, localParcel2, 0);
          localParcel2.readException();
          long l1 = localParcel2.readLong();
          long l2 = l1;
          return l2;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void setAlbumQueue(int[] paramArrayOfInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          localParcel1.writeIntArray(paramArrayOfInt);
          boolean bool = IMediaPlaybackService.Stub.this.transact(36, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void setMediaMode(boolean paramBoolean)
        throws RemoteException
      {
        int i = 0;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          if (paramBoolean)
            i = 1;
          localParcel1.writeInt(i);
          boolean bool = IMediaPlaybackService.Stub.this.transact(47, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void setQueuePosition(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          localParcel1.writeInt(paramInt);
          boolean bool = IMediaPlaybackService.Stub.this.transact(24, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void setRepeatMode(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          localParcel1.writeInt(paramInt);
          boolean bool = IMediaPlaybackService.Stub.this.transact(31, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void setShuffleMode(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          localParcel1.writeInt(paramInt);
          boolean bool = IMediaPlaybackService.Stub.this.transact(27, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void startAnimation()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(34, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void stop()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          boolean bool = IMediaPlaybackService.Stub.this.transact(8, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }

      public void syncNowPlayingQueue(int[] paramArrayOfInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.htc.music.IMediaPlaybackService");
          localParcel1.writeIntArray(paramArrayOfInt);
          boolean bool = IMediaPlaybackService.Stub.this.transact(48, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw localObject;
      }
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     com.htc.music.IMediaPlaybackService
 * JD-Core Version:    0.6.0
 */