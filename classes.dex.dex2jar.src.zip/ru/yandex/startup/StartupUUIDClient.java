package ru.yandex.startup;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.util.Xml;
import com.softspb.util.log.Logger;
import com.softspb.util.log.Loggers;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class StartupUUIDClient
{
  private static final String PREFERENCE_KEY_UUID = "uuid";
  private static final String QUERY_PARAM_APP_PLATFORM = "app_platform";
  private static final String QUERY_PARAM_APP_VERSION = "app_version";
  private static final String QUERY_PARAM_CLID = "clid";
  private static final String QUERY_PARAM_MANUFACTURER = "manufacturer";
  private static final String QUERY_PARAM_MODEL = "model";
  private static final String QUERY_PARAM_UUID = "uuid";
  public static final long SEND_PERIOD = 3600000L;
  private static final String SHARED_PREFERENCES_NAME = "startup";
  private static final String TAG_UUID = "uuid";
  private static String manufacturer;
  protected CallbackHandler callbackHandler;
  protected final Context context;
  protected DataHandler dataHandler;
  Logger logger;
  protected final QueryParams queryParams;
  protected SharedPreferences sharedPreferences;

  public StartupUUIDClient(Context paramContext, String paramString1, String paramString2, String paramString3)
  {
  }

  public StartupUUIDClient(Context paramContext, String paramString1, String paramString2, String paramString3, Looper paramLooper)
  {
    Logger localLogger = Loggers.getLogger(getClass());
    this.logger = localLogger;
    String str1 = "Ctor() >>> serviceUrl=" + paramString1 + " appVersion=" + paramString2 + " clid=" + paramString3;
    logd(str1);
    this.context = paramContext;
    SharedPreferences localSharedPreferences = paramContext.getSharedPreferences("startup", 0);
    this.sharedPreferences = localSharedPreferences;
    String str2 = this.sharedPreferences.getString("uuid", null);
    String str3 = paramString1;
    String str4 = paramString2;
    String str5 = paramString3;
    QueryParams localQueryParams = new QueryParams(str4, str5, str2, null);
    this.queryParams = localQueryParams;
    if (paramLooper != null)
    {
      CallbackHandler localCallbackHandler = new CallbackHandler(paramLooper);
      this.callbackHandler = localCallbackHandler;
    }
    start();
    logd("Ctor() <<<");
  }

  private static String buildUrl(QueryParams paramQueryParams)
  {
    StringBuilder localStringBuilder1 = new StringBuilder(256);
    String str1 = paramQueryParams.serviceUrl;
    StringBuilder localStringBuilder2 = localStringBuilder1.append(str1).append(63);
    int i = 0;
    if (paramQueryParams.appPlatform != null)
    {
      if (0 != 0)
        StringBuilder localStringBuilder3 = localStringBuilder1.append(38);
      StringBuilder localStringBuilder4 = localStringBuilder1.append("app_platform").append(61);
      String str2 = paramQueryParams.appPlatform;
      StringBuilder localStringBuilder5 = localStringBuilder4.append(str2);
      i = 1;
    }
    if (paramQueryParams.appVersion != null)
    {
      if (i != 0)
        StringBuilder localStringBuilder6 = localStringBuilder1.append(38);
      StringBuilder localStringBuilder7 = localStringBuilder1.append("app_version").append(61);
      String str3 = paramQueryParams.appVersion;
      StringBuilder localStringBuilder8 = localStringBuilder7.append(str3);
      i = 1;
    }
    if (paramQueryParams.manufacturer != null)
    {
      if (i != 0)
        StringBuilder localStringBuilder9 = localStringBuilder1.append(38);
      StringBuilder localStringBuilder10 = localStringBuilder1.append("manufacturer").append(61);
      String str4 = Uri.encode(paramQueryParams.manufacturer);
      StringBuilder localStringBuilder11 = localStringBuilder10.append(str4);
      i = 1;
    }
    if (paramQueryParams.model != null)
    {
      if (i != 0)
        StringBuilder localStringBuilder12 = localStringBuilder1.append(38);
      StringBuilder localStringBuilder13 = localStringBuilder1.append("model").append(61);
      String str5 = Uri.encode(paramQueryParams.model);
      StringBuilder localStringBuilder14 = localStringBuilder13.append(str5);
      i = 1;
    }
    if (paramQueryParams.uuid != null)
    {
      if (i != 0)
        StringBuilder localStringBuilder15 = localStringBuilder1.append(38);
      StringBuilder localStringBuilder16 = localStringBuilder1.append("uuid").append(61);
      String str6 = paramQueryParams.uuid;
      StringBuilder localStringBuilder17 = localStringBuilder16.append(str6);
      i = 1;
    }
    if (paramQueryParams.clid != null)
    {
      if (i != 0)
        StringBuilder localStringBuilder18 = localStringBuilder1.append(38);
      StringBuilder localStringBuilder19 = localStringBuilder1.append("clid").append(61);
      String str7 = paramQueryParams.clid;
      StringBuilder localStringBuilder20 = localStringBuilder19.append(str7);
    }
    return localStringBuilder1.toString();
  }

  private static String getManufacturer()
  {
    if (manufacturer == null);
    try
    {
      Field localField = Build.class.getField("MANUFACTURER");
      Build localBuild = new Build();
      manufacturer = (String)localField.get(localBuild);
      return manufacturer;
    }
    catch (Throwable localThrowable)
    {
      while (true)
        manufacturer = "Unknown";
    }
  }

  private static boolean isNetworkConnected(Context paramContext)
  {
    int i = 0;
    try
    {
      boolean bool = ((ConnectivityManager)paramContext.getSystemService("connectivity")).getActiveNetworkInfo().isConnected();
      i = bool;
      label20: return i;
    }
    catch (Throwable localThrowable)
    {
      break label20;
    }
  }

  private void logd(String paramString)
  {
    this.logger.d(paramString);
  }

  private void logi(String paramString)
  {
    this.logger.i(paramString);
  }

  private void logw(String paramString, Throwable paramThrowable)
  {
    this.logger.w(paramString, paramThrowable);
  }

  private static String parseUuidFromXml(InputStream paramInputStream, String paramString)
    throws XmlPullParserException, IOException
  {
    XmlPullParser localXmlPullParser = Xml.newPullParser();
    localXmlPullParser.setInput(paramInputStream, paramString);
    int i = localXmlPullParser.getEventType();
    if (i != 1)
      if (i == 2)
      {
        String str1 = localXmlPullParser.getName();
        if (!"uuid".equals(str1));
      }
    for (String str2 = localXmlPullParser.nextText(); ; str2 = null)
    {
      return str2;
      i = localXmlPullParser.next();
      break;
    }
  }

  private void start()
  {
    if (this.dataHandler == null)
    {
      logd("start");
      HandlerThread localHandlerThread = new HandlerThread("StartupUUIDClient.Data");
      localHandlerThread.start();
      Looper localLooper = localHandlerThread.getLooper();
      DataHandler localDataHandler = new DataHandler(localLooper);
      this.dataHandler = localDataHandler;
    }
  }

  public String getUuid()
  {
    return this.queryParams.uuid;
  }

  public void initiateStartupProtocol()
  {
    logd("initiateStartupProtocol()");
    if (this.dataHandler == null)
      throw new IllegalStateException("StartupUUIDClient is not running, probably start() hasn't been called.");
    this.dataHandler.postSendStartup();
  }

  public void notifyNetworkConnected()
  {
    logd("notifyNetworkConnected()");
    if (this.dataHandler != null)
      this.dataHandler.postNetworkConnected();
  }

  protected void onReceivedUuid(String paramString)
  {
  }

  protected void onStartupCompleted()
  {
  }

  protected void onStartupRequestFailed()
  {
  }

  public void stop()
  {
    if (this.dataHandler != null)
    {
      logd("stop");
      this.dataHandler.removeCallbacksAndMessages(null);
      this.dataHandler.getLooper().quit();
      this.dataHandler = null;
    }
    if (this.callbackHandler != null)
    {
      this.callbackHandler.removeCallbacksAndMessages(null);
      this.callbackHandler = null;
    }
  }

  final class QueryParams
  {
    private static final String APP_PLATFORM_ANDROID = "android";
    final String appPlatform = "android";
    final String appVersion;
    final String clid;
    final String manufacturer;
    final String model;
    volatile String uuid;

    private QueryParams(String paramString1, String paramString2, String arg4)
    {
      this.appVersion = paramString1;
      String str1 = StartupUUIDClient.access$700();
      this.manufacturer = str1;
      String str2 = Build.MODEL;
      this.model = str2;
      this.clid = paramString2;
      Object localObject;
      this.uuid = localObject;
    }
  }

  public class DataHandler extends Handler
  {
    private static final long FIRST_RETRY_PERIOD = 20000L;
    private static final long MAX_RETRY_PERIOD = 1800000L;
    private static final int MSG_ON_NETWORK_CONNECTED = 2;
    private static final int MSG_SEND_STARTUP = 1;
    private boolean isInitialUuidRequest;
    private long retryPeriod = 20000L;

    protected DataHandler(Looper arg2)
    {
      super();
      if (StartupUUIDClient.this.queryParams.uuid == null);
      for (int i = 1; ; i = 0)
      {
        this.isInitialUuidRequest = i;
        return;
      }
    }

    private void onCompleted()
    {
      StartupUUIDClient.this.logd("startup protocol completed");
      if (StartupUUIDClient.this.callbackHandler != null)
        StartupUUIDClient.this.callbackHandler.postOnStartupCompleted();
      while (true)
      {
        return;
        StartupUUIDClient.this.onStartupCompleted();
      }
    }

    private void onFailed(String paramString)
    {
      StartupUUIDClient localStartupUUIDClient = StartupUUIDClient.this;
      String str = "startup request failed: " + paramString;
      localStartupUUIDClient.logd(str);
      long l1 = this.retryPeriod;
      boolean bool = sendEmptyMessageDelayed(1, l1);
      long l2 = this.retryPeriod * 2L;
      this.retryPeriod = l2;
      if (this.retryPeriod > 1800000L)
        this.retryPeriod = 1800000L;
      if (StartupUUIDClient.this.callbackHandler != null)
        StartupUUIDClient.this.callbackHandler.postOnStartupRequestFailed();
      while (true)
      {
        return;
        StartupUUIDClient.this.onStartupRequestFailed();
      }
    }

    private void onReceivedUuid(String paramString)
    {
      StartupUUIDClient localStartupUUIDClient = StartupUUIDClient.this;
      String str = "received UUID: " + paramString;
      localStartupUUIDClient.logd(str);
      boolean bool = StartupUUIDClient.this.sharedPreferences.edit().putString("uuid", paramString).commit();
      if (StartupUUIDClient.this.callbackHandler != null)
        StartupUUIDClient.this.callbackHandler.postOnReceivedUuid(paramString);
      while (true)
      {
        return;
        StartupUUIDClient.this.onReceivedUuid(paramString);
      }
    }

    public void handleMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default:
      case 1:
      case 2:
      }
      while (true)
      {
        return;
        sendStartup();
        continue;
        onNetworkConnected();
      }
    }

    protected void onNetworkConnected()
    {
      if (hasMessages(1))
      {
        removeMessages(1);
        postSendStartup();
      }
    }

    public void postNetworkConnected()
    {
      boolean bool = sendEmptyMessage(2);
    }

    public void postSendStartup()
    {
      boolean bool = sendEmptyMessage(1);
    }

    // ERROR //
    protected void sendStartup()
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 29	ru/yandex/startup/StartupUUIDClient$DataHandler:this$0	Lru/yandex/startup/StartupUUIDClient;
      //   4: ldc 158
      //   6: invokestatic 55	ru/yandex/startup/StartupUUIDClient:access$100	(Lru/yandex/startup/StartupUUIDClient;Ljava/lang/String;)V
      //   9: aconst_null
      //   10: astore_1
      //   11: aload_0
      //   12: getfield 29	ru/yandex/startup/StartupUUIDClient$DataHandler:this$0	Lru/yandex/startup/StartupUUIDClient;
      //   15: getfield 162	ru/yandex/startup/StartupUUIDClient:context	Landroid/content/Context;
      //   18: invokestatic 166	ru/yandex/startup/StartupUUIDClient:access$200	(Landroid/content/Context;)Z
      //   21: ifne +39 -> 60
      //   24: aload_0
      //   25: getfield 29	ru/yandex/startup/StartupUUIDClient$DataHandler:this$0	Lru/yandex/startup/StartupUUIDClient;
      //   28: ldc 168
      //   30: invokestatic 55	ru/yandex/startup/StartupUUIDClient:access$100	(Lru/yandex/startup/StartupUUIDClient;Ljava/lang/String;)V
      //   33: aload_0
      //   34: iconst_1
      //   35: ldc2_w 14
      //   38: invokevirtual 87	ru/yandex/startup/StartupUUIDClient$DataHandler:sendEmptyMessageDelayed	(IJ)Z
      //   41: istore_2
      //   42: iconst_0
      //   43: ifeq +7 -> 50
      //   46: aconst_null
      //   47: invokevirtual 173	java/io/InputStream:close	()V
      //   50: aload_0
      //   51: getfield 29	ru/yandex/startup/StartupUUIDClient$DataHandler:this$0	Lru/yandex/startup/StartupUUIDClient;
      //   54: ldc 175
      //   56: invokestatic 55	ru/yandex/startup/StartupUUIDClient:access$100	(Lru/yandex/startup/StartupUUIDClient;Ljava/lang/String;)V
      //   59: return
      //   60: aload_0
      //   61: getfield 29	ru/yandex/startup/StartupUUIDClient$DataHandler:this$0	Lru/yandex/startup/StartupUUIDClient;
      //   64: getfield 38	ru/yandex/startup/StartupUUIDClient:queryParams	Lru/yandex/startup/StartupUUIDClient$QueryParams;
      //   67: invokestatic 179	ru/yandex/startup/StartupUUIDClient:access$300	(Lru/yandex/startup/StartupUUIDClient$QueryParams;)Ljava/lang/String;
      //   70: astore_3
      //   71: new 181	java/net/URL
      //   74: dup
      //   75: aload_3
      //   76: invokespecial 183	java/net/URL:<init>	(Ljava/lang/String;)V
      //   79: astore 4
      //   81: aload_0
      //   82: getfield 29	ru/yandex/startup/StartupUUIDClient$DataHandler:this$0	Lru/yandex/startup/StartupUUIDClient;
      //   85: astore 5
      //   87: new 71	java/lang/StringBuilder
      //   90: dup
      //   91: invokespecial 73	java/lang/StringBuilder:<init>	()V
      //   94: ldc 185
      //   96: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   99: astore 6
      //   101: aload_0
      //   102: getfield 29	ru/yandex/startup/StartupUUIDClient$DataHandler:this$0	Lru/yandex/startup/StartupUUIDClient;
      //   105: getfield 38	ru/yandex/startup/StartupUUIDClient:queryParams	Lru/yandex/startup/StartupUUIDClient$QueryParams;
      //   108: getfield 188	ru/yandex/startup/StartupUUIDClient$QueryParams:clid	Ljava/lang/String;
      //   111: ifnonnull +166 -> 277
      //   114: ldc 190
      //   116: astore 7
      //   118: aload 6
      //   120: aload 7
      //   122: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   125: ldc 192
      //   127: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   130: invokevirtual 83	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   133: astore 8
      //   135: aload 5
      //   137: aload 8
      //   139: invokestatic 195	ru/yandex/startup/StartupUUIDClient:access$400	(Lru/yandex/startup/StartupUUIDClient;Ljava/lang/String;)V
      //   142: aload_0
      //   143: getfield 29	ru/yandex/startup/StartupUUIDClient$DataHandler:this$0	Lru/yandex/startup/StartupUUIDClient;
      //   146: astore 9
      //   148: new 71	java/lang/StringBuilder
      //   151: dup
      //   152: invokespecial 73	java/lang/StringBuilder:<init>	()V
      //   155: ldc 197
      //   157: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   160: aload_3
      //   161: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   164: invokevirtual 83	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   167: astore 10
      //   169: aload 9
      //   171: aload 10
      //   173: invokestatic 195	ru/yandex/startup/StartupUUIDClient:access$400	(Lru/yandex/startup/StartupUUIDClient;Ljava/lang/String;)V
      //   176: aload 4
      //   178: invokevirtual 201	java/net/URL:openConnection	()Ljava/net/URLConnection;
      //   181: checkcast 203	java/net/HttpURLConnection
      //   184: astore 11
      //   186: aload 11
      //   188: invokevirtual 206	java/net/HttpURLConnection:connect	()V
      //   191: aload 11
      //   193: invokevirtual 210	java/net/HttpURLConnection:getResponseCode	()I
      //   196: sipush 200
      //   199: if_icmpeq +93 -> 292
      //   202: new 71	java/lang/StringBuilder
      //   205: dup
      //   206: invokespecial 73	java/lang/StringBuilder:<init>	()V
      //   209: astore 12
      //   211: aload 11
      //   213: invokevirtual 210	java/net/HttpURLConnection:getResponseCode	()I
      //   216: istore 13
      //   218: aload 12
      //   220: iload 13
      //   222: invokevirtual 213	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
      //   225: ldc 215
      //   227: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   230: astore 14
      //   232: aload 11
      //   234: invokevirtual 218	java/net/HttpURLConnection:getResponseMessage	()Ljava/lang/String;
      //   237: astore 15
      //   239: aload 14
      //   241: aload 15
      //   243: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   246: invokevirtual 83	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   249: astore 16
      //   251: aload_0
      //   252: aload 16
      //   254: invokespecial 220	ru/yandex/startup/StartupUUIDClient$DataHandler:onFailed	(Ljava/lang/String;)V
      //   257: iconst_0
      //   258: ifeq +7 -> 265
      //   261: aconst_null
      //   262: invokevirtual 173	java/io/InputStream:close	()V
      //   265: aload_0
      //   266: getfield 29	ru/yandex/startup/StartupUUIDClient$DataHandler:this$0	Lru/yandex/startup/StartupUUIDClient;
      //   269: ldc 175
      //   271: invokestatic 55	ru/yandex/startup/StartupUUIDClient:access$100	(Lru/yandex/startup/StartupUUIDClient;Ljava/lang/String;)V
      //   274: goto -215 -> 59
      //   277: aload_0
      //   278: getfield 29	ru/yandex/startup/StartupUUIDClient$DataHandler:this$0	Lru/yandex/startup/StartupUUIDClient;
      //   281: getfield 38	ru/yandex/startup/StartupUUIDClient:queryParams	Lru/yandex/startup/StartupUUIDClient$QueryParams;
      //   284: getfield 188	ru/yandex/startup/StartupUUIDClient$QueryParams:clid	Ljava/lang/String;
      //   287: astore 7
      //   289: goto -171 -> 118
      //   292: aload_0
      //   293: getfield 46	ru/yandex/startup/StartupUUIDClient$DataHandler:isInitialUuidRequest	Z
      //   296: ifne +27 -> 323
      //   299: aload_0
      //   300: invokespecial 222	ru/yandex/startup/StartupUUIDClient$DataHandler:onCompleted	()V
      //   303: iconst_0
      //   304: ifeq +7 -> 311
      //   307: aconst_null
      //   308: invokevirtual 173	java/io/InputStream:close	()V
      //   311: aload_0
      //   312: getfield 29	ru/yandex/startup/StartupUUIDClient$DataHandler:this$0	Lru/yandex/startup/StartupUUIDClient;
      //   315: ldc 175
      //   317: invokestatic 55	ru/yandex/startup/StartupUUIDClient:access$100	(Lru/yandex/startup/StartupUUIDClient;Ljava/lang/String;)V
      //   320: goto -261 -> 59
      //   323: aload 11
      //   325: invokevirtual 226	java/net/HttpURLConnection:getInputStream	()Ljava/io/InputStream;
      //   328: astore_1
      //   329: aload_1
      //   330: ldc 228
      //   332: invokestatic 232	ru/yandex/startup/StartupUUIDClient:access$500	(Ljava/io/InputStream;Ljava/lang/String;)Ljava/lang/String;
      //   335: astore 17
      //   337: aload 17
      //   339: ifnull +62 -> 401
      //   342: aload 17
      //   344: invokevirtual 237	java/lang/String:length	()I
      //   347: sipush 142
      //   350: if_icmpgt +51 -> 401
      //   353: aload 17
      //   355: bipush 38
      //   357: invokevirtual 241	java/lang/String:indexOf	(I)I
      //   360: bipush 255
      //   362: if_icmpne +39 -> 401
      //   365: aload 17
      //   367: bipush 34
      //   369: invokevirtual 241	java/lang/String:indexOf	(I)I
      //   372: bipush 255
      //   374: if_icmpne +27 -> 401
      //   377: aload 17
      //   379: bipush 60
      //   381: invokevirtual 241	java/lang/String:indexOf	(I)I
      //   384: bipush 255
      //   386: if_icmpne +15 -> 401
      //   389: aload 17
      //   391: bipush 62
      //   393: invokevirtual 241	java/lang/String:indexOf	(I)I
      //   396: bipush 255
      //   398: if_icmpeq +51 -> 449
      //   401: new 71	java/lang/StringBuilder
      //   404: dup
      //   405: invokespecial 73	java/lang/StringBuilder:<init>	()V
      //   408: ldc 243
      //   410: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   413: aload 17
      //   415: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   418: invokevirtual 83	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   421: astore 18
      //   423: aload_0
      //   424: aload 18
      //   426: invokespecial 220	ru/yandex/startup/StartupUUIDClient$DataHandler:onFailed	(Ljava/lang/String;)V
      //   429: aload_1
      //   430: ifnull +7 -> 437
      //   433: aload_1
      //   434: invokevirtual 173	java/io/InputStream:close	()V
      //   437: aload_0
      //   438: getfield 29	ru/yandex/startup/StartupUUIDClient$DataHandler:this$0	Lru/yandex/startup/StartupUUIDClient;
      //   441: ldc 175
      //   443: invokestatic 55	ru/yandex/startup/StartupUUIDClient:access$100	(Lru/yandex/startup/StartupUUIDClient;Ljava/lang/String;)V
      //   446: goto -387 -> 59
      //   449: aload_0
      //   450: getfield 29	ru/yandex/startup/StartupUUIDClient$DataHandler:this$0	Lru/yandex/startup/StartupUUIDClient;
      //   453: getfield 38	ru/yandex/startup/StartupUUIDClient:queryParams	Lru/yandex/startup/StartupUUIDClient$QueryParams;
      //   456: aload 17
      //   458: putfield 44	ru/yandex/startup/StartupUUIDClient$QueryParams:uuid	Ljava/lang/String;
      //   461: aload_0
      //   462: aload 17
      //   464: invokespecial 244	ru/yandex/startup/StartupUUIDClient$DataHandler:onReceivedUuid	(Ljava/lang/String;)V
      //   467: aload_0
      //   468: ldc 47
      //   470: putfield 46	ru/yandex/startup/StartupUUIDClient$DataHandler:isInitialUuidRequest	Z
      //   473: aload_0
      //   474: invokevirtual 148	ru/yandex/startup/StartupUUIDClient$DataHandler:postSendStartup	()V
      //   477: aload_1
      //   478: ifnull +7 -> 485
      //   481: aload_1
      //   482: invokevirtual 173	java/io/InputStream:close	()V
      //   485: aload_0
      //   486: getfield 29	ru/yandex/startup/StartupUUIDClient$DataHandler:this$0	Lru/yandex/startup/StartupUUIDClient;
      //   489: ldc 175
      //   491: invokestatic 55	ru/yandex/startup/StartupUUIDClient:access$100	(Lru/yandex/startup/StartupUUIDClient;Ljava/lang/String;)V
      //   494: goto -435 -> 59
      //   497: astore 19
      //   499: aload_0
      //   500: getfield 29	ru/yandex/startup/StartupUUIDClient$DataHandler:this$0	Lru/yandex/startup/StartupUUIDClient;
      //   503: astore 20
      //   505: new 71	java/lang/StringBuilder
      //   508: dup
      //   509: invokespecial 73	java/lang/StringBuilder:<init>	()V
      //   512: ldc 246
      //   514: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   517: aload 19
      //   519: invokevirtual 249	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   522: invokevirtual 83	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   525: astore 21
      //   527: aload 20
      //   529: aload 21
      //   531: aload 19
      //   533: invokestatic 253	ru/yandex/startup/StartupUUIDClient:access$600	(Lru/yandex/startup/StartupUUIDClient;Ljava/lang/String;Ljava/lang/Throwable;)V
      //   536: new 71	java/lang/StringBuilder
      //   539: dup
      //   540: invokespecial 73	java/lang/StringBuilder:<init>	()V
      //   543: ldc 255
      //   545: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   548: aload 19
      //   550: invokevirtual 249	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   553: invokevirtual 83	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   556: astore 22
      //   558: aload_0
      //   559: aload 22
      //   561: invokespecial 220	ru/yandex/startup/StartupUUIDClient$DataHandler:onFailed	(Ljava/lang/String;)V
      //   564: aload_1
      //   565: ifnull +7 -> 572
      //   568: aload_1
      //   569: invokevirtual 173	java/io/InputStream:close	()V
      //   572: aload_0
      //   573: getfield 29	ru/yandex/startup/StartupUUIDClient$DataHandler:this$0	Lru/yandex/startup/StartupUUIDClient;
      //   576: ldc 175
      //   578: invokestatic 55	ru/yandex/startup/StartupUUIDClient:access$100	(Lru/yandex/startup/StartupUUIDClient;Ljava/lang/String;)V
      //   581: goto -522 -> 59
      //   584: astore 7
      //   586: aload_1
      //   587: ifnull +7 -> 594
      //   590: aload_1
      //   591: invokevirtual 173	java/io/InputStream:close	()V
      //   594: aload_0
      //   595: getfield 29	ru/yandex/startup/StartupUUIDClient$DataHandler:this$0	Lru/yandex/startup/StartupUUIDClient;
      //   598: ldc 175
      //   600: invokestatic 55	ru/yandex/startup/StartupUUIDClient:access$100	(Lru/yandex/startup/StartupUUIDClient;Ljava/lang/String;)V
      //   603: aload 7
      //   605: athrow
      //   606: astore 23
      //   608: goto -558 -> 50
      //   611: astore 24
      //   613: goto -348 -> 265
      //   616: astore 25
      //   618: goto -307 -> 311
      //   621: astore 26
      //   623: goto -186 -> 437
      //   626: astore 27
      //   628: goto -143 -> 485
      //   631: astore 28
      //   633: goto -61 -> 572
      //   636: astore 29
      //   638: goto -44 -> 594
      //
      // Exception table:
      //   from	to	target	type
      //   11	42	497	java/lang/Throwable
      //   60	257	497	java/lang/Throwable
      //   277	303	497	java/lang/Throwable
      //   323	429	497	java/lang/Throwable
      //   449	477	497	java/lang/Throwable
      //   11	42	584	finally
      //   60	257	584	finally
      //   277	303	584	finally
      //   323	429	584	finally
      //   449	477	584	finally
      //   499	564	584	finally
      //   46	50	606	java/io/IOException
      //   261	265	611	java/io/IOException
      //   307	311	616	java/io/IOException
      //   433	437	621	java/io/IOException
      //   481	485	626	java/io/IOException
      //   568	572	631	java/io/IOException
      //   590	594	636	java/io/IOException
    }
  }

  public class CallbackHandler extends Handler
  {
    private static final int MSG_ON_RECEIVED_UUID = 1;
    private static final int MSG_ON_STARTUP_COMPLETED = 3;
    private static final int MSG_ON_STARTUP_REQUEST_FAILED = 2;

    CallbackHandler(Looper arg2)
    {
      super();
    }

    public void handleMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default:
      case 1:
      case 2:
      case 3:
      }
      while (true)
      {
        return;
        String str = (String)paramMessage.obj;
        StartupUUIDClient.this.onReceivedUuid(str);
        continue;
        StartupUUIDClient.this.onStartupRequestFailed();
        continue;
        StartupUUIDClient.this.onStartupCompleted();
      }
    }

    protected void postOnReceivedUuid(String paramString)
    {
      Message localMessage = Message.obtain(this, 1, paramString);
      boolean bool = sendMessage(localMessage);
    }

    protected void postOnStartupCompleted()
    {
      boolean bool = sendEmptyMessage(3);
    }

    protected void postOnStartupRequestFailed()
    {
      boolean bool = sendEmptyMessage(2);
    }
  }
}

/* Location:           D:\MyEclipse10\Home3\classes.dex.dex2jar.jar
 * Qualified Name:     ru.yandex.startup.StartupUUIDClient
 * JD-Core Version:    0.6.0
 */